<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head } from '@inertiajs/vue3';
</script>

<template>

  <Head title="Pos" />
  <AuthenticatedLayout>
    <div class="dashboard-content-one">
      <!-- Breadcubs Area Start Here -->
      <div class="row mt-5">
        <div class="col-md-9">
          <div class="input-group mb-3 mt-3">
            <div class="input-group-prepend">
              <span class="input-group-text" id="basic-addon1"><i class="fa fa-search"></i></span>
            </div>
            <input type="text" class="form-control" placeholder="Search" aria-label="Search">
          </div>
          <div class="row">
            <div class="col-md-2 pl-2 pr-2">
              <div class="card item-card text-center">
                <div class="card-body">
                  <img
                    src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg"
                    alt="Item">
                  <p class="mb-1">Burger - Md</p>
                  <p class="mb-0">Rs. 10</p>
                </div>
              </div>
            </div>
            <div class="col-md-2 pl-2 pr-2">
              <div class="card item-card text-center">
                <div class="card-body">
                  <img
                    src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg"
                    alt="Item">
                  <p class="mb-1">Burger - Md</p>
                  <p class="mb-0">Rs. 10</p>
                </div>
              </div>
            </div>
            <div class="col-md-2 pl-2 pr-2">
              <div class="card item-card text-center">
                <div class="card-body">
                  <img
                    src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg"
                    alt="Item">
                  <p class="mb-1">Burger - Md</p>
                  <p class="mb-0">Rs. 10</p>
                </div>
              </div>
            </div>
            <div class="col-md-2 pl-2 pr-2">
              <div class="card item-card text-center">
                <div class="card-body">
                  <img
                    src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg"
                    alt="Item">
                  <p class="mb-1">Burger - Md</p>
                  <p class="mb-0">Rs. 10</p>
                </div>
              </div>
            </div>
            <div class="col-md-2 pl-2 pr-2">
              <div class="card item-card text-center">
                <div class="card-body">
                  <img
                    src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg"
                    alt="Item">
                  <p class="mb-1">Burger - Md</p>
                  <p class="mb-0">Rs. 10</p>
                </div>
              </div>
            </div>
            <div class="col-md-2 pl-2 pr-2">
              <div class="card item-card text-center">
                <div class="card-body">
                  <img
                    src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg"
                    alt="Item">
                  <p class="mb-1">Burger - Md</p>
                  <p class="mb-0">Rs. 10</p>
                </div>
              </div>
            </div>
            <div class="col-md-2 pl-2 pr-2">
              <div class="card item-card text-center">
                <div class="card-body">
                  <img
                    src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg"
                    alt="Item">
                  <p class="mb-1">Burger - Md</p>
                  <p class="mb-0">Rs. 10</p>
                </div>
              </div>
            </div>
            <div class="col-md-2 pl-2 pr-2">
              <div class="card item-card text-center">
                <div class="card-body">
                  <img
                    src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg"
                    alt="Item">
                  <p class="mb-1">Burger - Md</p>
                  <p class="mb-0">Rs. 10</p>
                </div>
              </div>
            </div>
            <div class="col-md-2 pl-2 pr-2">
              <div class="card item-card text-center">
                <div class="card-body">
                  <img
                    src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg"
                    alt="Item">
                  <p class="mb-1">Burger - Md</p>
                  <p class="mb-0">Rs. 10</p>
                </div>
              </div>
            </div>
            <div class="col-md-2 pl-2 pr-2">
              <div class="card item-card text-center">
                <div class="card-body">
                  <img
                    src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg"
                    alt="Item">
                  <p class="mb-1">Burger - Md</p>
                  <p class="mb-0">Rs. 10</p>
                </div>
              </div>
            </div>
            <div class="col-md-2 pl-2 pr-2">
              <div class="card item-card text-center">
                <div class="card-body">
                  <img
                    src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg"
                    alt="Item">
                  <p class="mb-1">Burger - Md</p>
                  <p class="mb-0">Rs. 10</p>
                </div>
              </div>
            </div>
            <div class="col-md-2 pl-2 pr-2">
              <div class="card item-card text-center">
                <div class="card-body">
                  <img
                    src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg"
                    alt="Item">
                  <p class="mb-1">Burger - Md</p>
                  <p class="mb-0">Rs. 10</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card">
            <div class="card-body p-2">
              <div class="row">
                <div class="col-md-10">
                  <select class="form-control">
                    <option value="">Select Customer</option>
                  </select>
                </div>
                <div class="col-md-2 text-right">
                  <a href="#"><i class="fa fa-trash fa-2x"></i></a>
                </div>
              </div>
              <hr />
              <table class="table table-borderless">
                <tr>
                  <td><img style="max-width:30px"
                      src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg"
                      alt="Item"></td>
                  <td>
                    <p class="m-0">Burger - Md</p>
                    <p class="m-0">Rs.10</p>
                  </td>
                  <td>
                    <div class="input-group mb-3" style="max-width:100px">
                      <div class="input-group-prepend">
                        <button class="btn btn-outline-secondary btn-sm" type="button"><i
                            class="fa fa-minus"></i></button>
                      </div>
                      <input type="text" class="form-control" aria-label="Amount (to the nearest dollar)">
                      <div class="input-group-append">
                        <button class="btn btn-outline-secondary btn-sm" type="button"><i
                            class="fa fa-plus"></i></button>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td><img style="max-width:30px"
                      src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg"
                      alt="Item"></td>
                  <td>
                    <p class="m-0">Burger - Md</p>
                    <p class="m-0">Rs.10</p>
                  </td>
                  <td>
                    <div class="input-group mb-3" style="max-width:100px">
                      <div class="input-group-prepend">
                        <button class="btn btn-outline-secondary btn-sm" type="button"><i
                            class="fa fa-minus"></i></button>
                      </div>
                      <input type="text" class="form-control" aria-label="Amount (to the nearest dollar)">
                      <div class="input-group-append">
                        <button class="btn btn-outline-secondary btn-sm" type="button"><i
                            class="fa fa-plus"></i></button>
                      </div>
                    </div>
                  </td>
                </tr>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </AuthenticatedLayout>
</template>
