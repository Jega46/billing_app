<template>
    <img src="https://moziztech.com/images/logo/moziz-logo.png" class="app-logo"/>
</template>
