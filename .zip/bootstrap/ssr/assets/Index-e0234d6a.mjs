import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import "vue-request";
import { resolveComponent, withCtx, createVNode, createTextVNode, openBlock, createBlock, createCommentVNode, toDisplayString, mergeProps, Fragment, useSSRContext } from "vue";
import { Head, Link, useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./InputError-6d616b1a.mjs";
import { DownloadOutlined, UploadOutlined, PlusCircleOutlined, DeleteOutlined, BarcodeOutlined, DownCircleOutlined, CloudUploadOutlined, EditOutlined } from "@ant-design/icons-vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
const columns = [
  {
    title: "",
    key: "image",
    dataIndex: "image",
    width: "1%"
  },
  {
    title: "Product Name",
    key: "name",
    dataIndex: "name",
    width: "5%"
  },
  {
    title: "Category",
    key: "category",
    dataIndex: "category",
    width: "5%"
  },
  {
    title: "Brand",
    key: "brand",
    dataIndex: "brand",
    width: "5%"
  },
  {
    title: "Sales Price (INR)",
    key: "sales_price",
    dataIndex: "sales_price",
    width: "5%"
  },
  {
    title: "Purchase Price (INR)",
    key: "purchase_price",
    dataIndex: "purchase_price",
    width: "5%"
  },
  {
    title: "Action",
    key: "action",
    fixed: "right",
    width: "2%"
  }
];
const items = [
  {
    id: "1",
    image: "https://gw.alipayobjects.com/zos/rmsportal/KDpgvguMpGfqaHPjicRK.svg",
    name: "Product 1",
    category: "Category 1",
    brand: "Brand 1",
    sales_price: "100",
    purchase_price: "50",
    action: ""
  },
  {
    id: "2",
    image: "https://gw.alipayobjects.com/zos/rmsportal/KDpgvguMpGfqaHPjicRK.svg",
    name: "Product 2",
    category: "Category 2",
    brand: "Brand 2",
    sales_price: "100",
    purchase_price: "50",
    action: ""
  },
  {
    id: "3",
    image: "https://gw.alipayobjects.com/zos/rmsportal/KDpgvguMpGfqaHPjicRK.svg",
    name: "Product 3",
    category: "Category 3",
    brand: "Brand 3",
    sales_price: "100",
    purchase_price: "50",
    action: ""
  },
  {
    id: "4",
    image: "https://gw.alipayobjects.com/zos/rmsportal/KDpgvguMpGfqaHPjicRK.svg",
    name: "Product 4",
    category: "Category 4",
    brand: "Brand 4",
    sales_price: "100",
    purchase_price: "50",
    action: ""
  }
];
const invoicetransactions_column = [
  {
    title: "Date",
    key: "date",
    dataIndex: "date",
    width: "15%"
  },
  {
    title: "Invoice Number",
    key: "invoice_number",
    dataIndex: "invoice_number",
    width: "15%"
  },
  {
    title: "Customer Name",
    key: "customer_name",
    dataIndex: "customer_name",
    width: "2%"
  },
  {
    title: "Quantity Sold",
    key: "quantity_sold",
    dataIndex: "quantity_sold",
    width: "10%"
  },
  {
    title: "Price",
    key: "price",
    dataIndex: "price",
    width: "2%"
  },
  {
    title: "Total",
    key: "total",
    dataIndex: "total",
    width: "2%"
  },
  {
    title: "Status",
    key: "status",
    dataIndex: "status",
    width: "2%"
  }
];
const invoicetransactions = [
  {
    key: "1",
    date: "10-10-2023",
    invoice_number: "INV-0001",
    quantity_sold: 1,
    customer_name: "John",
    price: 12e3,
    total: 12e3,
    status: "Open"
  },
  {
    key: "2",
    date: "10-10-2023",
    invoice_number: "INV-0002",
    quantity_sold: 1,
    customer_name: "John",
    price: 12e3,
    total: 12e3,
    status: "Open"
  }
];
const _sfc_main = {
  components: {
    AuthenticatedLayout: _sfc_main$1,
    DownloadOutlined,
    UploadOutlined,
    PlusCircleOutlined,
    DeleteOutlined,
    BarcodeOutlined,
    DownCircleOutlined,
    CloudUploadOutlined,
    EditOutlined,
    Head,
    Link,
    InputError: _sfc_main$2
  },
  props: {},
  setup(props) {
    return {
      columns,
      items,
      invoicetransactions_column,
      invoicetransactions
    };
  },
  data() {
    const searchform = useForm({
      term: ""
    });
    const layout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 24 }
    };
    const form = useForm({});
    return {
      createvisible: false,
      searchform,
      form,
      layout,
      showdetail: false
    };
  },
  methods: {
    showDrawer() {
      this.createvisible = true;
    },
    showViewDrawer() {
      this.showdetail = true;
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_space = resolveComponent("a-space");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_button = resolveComponent("a-button");
  const _component_plus_circle_outlined = resolveComponent("plus-circle-outlined");
  const _component_CloudUploadOutlined = resolveComponent("CloudUploadOutlined");
  const _component_a_table = resolveComponent("a-table");
  const _component_a_image = resolveComponent("a-image");
  const _component_a_dropdown = resolveComponent("a-dropdown");
  const _component_DownCircleOutlined = resolveComponent("DownCircleOutlined");
  const _component_a_menu = resolveComponent("a-menu");
  const _component_a_menu_item = resolveComponent("a-menu-item");
  const _component_edit_outlined = resolveComponent("edit-outlined");
  const _component_delete_outlined = resolveComponent("delete-outlined");
  const _component_a_drawer = resolveComponent("a-drawer");
  const _component_a_tabs = resolveComponent("a-tabs");
  const _component_a_tab_pane = resolveComponent("a-tab-pane");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_upload = resolveComponent("a-upload");
  const _component_upload_outlined = resolveComponent("upload-outlined");
  const _component_a_auto_complete = resolveComponent("a-auto-complete");
  const _component_a_select_option = resolveComponent("a-select-option");
  const _component_BarcodeOutlined = resolveComponent("BarcodeOutlined");
  const _component_a_input_number = resolveComponent("a-input-number");
  const _component_a_textarea = resolveComponent("a-textarea");
  const _component_a_checkbox = resolveComponent("a-checkbox");
  const _component_a_descriptions = resolveComponent("a-descriptions");
  const _component_a_descriptions_item = resolveComponent("a-descriptions-item");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Products" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_layout_content, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, {
                      name: "nest-messages",
                      model: $data.searchform,
                      layout: "inline",
                      onFinish: _ctx.search
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input, {
                                  placeholder: "Search by product name",
                                  "allow-clear": true,
                                  value: $data.searchform.term,
                                  "onUpdate:value": ($event) => $data.searchform.term = $event
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input, {
                                    placeholder: "Search by product name",
                                    "allow-clear": true,
                                    value: $data.searchform.term,
                                    "onUpdate:value": ($event) => $data.searchform.term = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_select, { placeholder: "Search by Category" }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_select, { placeholder: "Search by Category" })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_select, { placeholder: "Search by Brand" }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_select, { placeholder: "Search by Brand" })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Search `);
                                    } else {
                                      return [
                                        createTextVNode(" Search ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Search ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_plus_circle_outlined)
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Add New Product `);
                                    } else {
                                      return [
                                        createTextVNode(" Add New Product ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    shape: "round",
                                    onClick: $options.showDrawer
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Add New Product ")
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_CloudUploadOutlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_CloudUploadOutlined)
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Import `);
                                    } else {
                                      return [
                                        createTextVNode(" Import ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    shape: "round",
                                    onClick: $options.showDrawer
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_CloudUploadOutlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Import ")
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  placeholder: "Search by product name",
                                  "allow-clear": true,
                                  value: $data.searchform.term,
                                  "onUpdate:value": ($event) => $data.searchform.term = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_select, { placeholder: "Search by Category" })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_select, { placeholder: "Search by Brand" })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Search ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Add New Product ")
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_CloudUploadOutlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Import ")
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_table, {
                      columns: $setup.columns,
                      "data-source": $setup.items
                    }, {
                      bodyCell: withCtx(({ column, record }, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          if (column.key === "image") {
                            _push5(ssrRenderComponent(_component_a_image, {
                              width: 30,
                              height: 30,
                              src: record.image,
                              fallback: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMIAAADDCAYAAADQvc6UAAABRWlDQ1BJQ0MgUHJvZmlsZQAAKJFjYGASSSwoyGFhYGDIzSspCnJ3UoiIjFJgf8LAwSDCIMogwMCcmFxc4BgQ4ANUwgCjUcG3awyMIPqyLsis7PPOq3QdDFcvjV3jOD1boQVTPQrgSkktTgbSf4A4LbmgqISBgTEFyFYuLykAsTuAbJEioKOA7DkgdjqEvQHEToKwj4DVhAQ5A9k3gGyB5IxEoBmML4BsnSQk8XQkNtReEOBxcfXxUQg1Mjc0dyHgXNJBSWpFCYh2zi+oLMpMzyhRcASGUqqCZ16yno6CkYGRAQMDKMwhqj/fAIcloxgHQqxAjIHBEugw5sUIsSQpBobtQPdLciLEVJYzMPBHMDBsayhILEqEO4DxG0txmrERhM29nYGBddr//5/DGRjYNRkY/l7////39v///y4Dmn+LgeHANwDrkl1AuO+pmgAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAwqADAAQAAAABAAAAwwAAAAD9b/HnAAAHlklEQVR4Ae3dP3PTWBSGcbGzM6GCKqlIBRV0dHRJFarQ0eUT8LH4BnRU0NHR0UEFVdIlFRV7TzRksomPY8uykTk/zewQfKw/9znv4yvJynLv4uLiV2dBoDiBf4qP3/ARuCRABEFAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghgg0Aj8i0JO4OzsrPv69Wv+hi2qPHr0qNvf39+iI97soRIh4f3z58/u7du3SXX7Xt7Z2enevHmzfQe+oSN2apSAPj09TSrb+XKI/f379+08+A0cNRE2ANkupk+ACNPvkSPcAAEibACyXUyfABGm3yNHuAECRNgAZLuYPgEirKlHu7u7XdyytGwHAd8jjNyng4OD7vnz51dbPT8/7z58+NB9+/bt6jU/TI+AGWHEnrx48eJ/EsSmHzx40L18+fLyzxF3ZVMjEyDCiEDjMYZZS5wiPXnyZFbJaxMhQIQRGzHvWR7XCyOCXsOmiDAi1HmPMMQjDpbpEiDCiL358eNHurW/5SnWdIBbXiDCiA38/Pnzrce2YyZ4//59F3ePLNMl4PbpiL2J0L979+7yDtHDhw8vtzzvdGnEXdvUigSIsCLAWavHp/+qM0BcXMd/q25n1vF57TYBp0a3mUzilePj4+7k5KSLb6gt6ydAhPUzXnoPR0dHl79WGTNCfBnn1uvSCJdegQhLI1vvCk+fPu2ePXt2tZOYEV6/fn31dz+shwAR1sP1cqvLntbEN9MxA9xcYjsxS1jWR4AIa2Ibzx0tc44fYX/16lV6NDFLXH+YL32jwiACRBiEbf5KcXoTIsQSpzXx4N28Ja4BQoK7rgXiydbHjx/P25TaQAJEGAguWy0+2Q8PD6/Ki4R8EVl+bzBOnZY95fq9rj9zAkTI2SxdidBHqG9+skdw43borCXO/ZcJdraPWdv22uIEiLA4q7nvvCug8WTqzQveOH26fodo7g6uFe/a17W3+nFBAkRYENRdb1vkkz1CH9cPsVy/jrhr27PqMYvENYNlHAIesRiBYwRy0V+8iXP8+/fvX11Mr7L7ECueb/r48eMqm7FuI2BGWDEG8cm+7G3NEOfmdcTQw4h9/55lhm7DekRYKQPZF2ArbXTAyu4kDYB2YxUzwg0gi/41ztHnfQG26HbGel/crVrm7tNY+/1btkOEAZ2M05r4FB7r9GbAIdxaZYrHdOsgJ/wCEQY0J74TmOKnbxxT9n3FgGGWWsVdowHtjt9Nnvf7yQM2aZU/TIAIAxrw6dOnAWtZZcoEnBpNuTuObWMEiLAx1HY0ZQJEmHJ3HNvGCBBhY6jtaMoEiJB0Z29vL6ls58vxPcO8/zfrdo5qvKO+d3Fx8Wu8zf1dW4p/cPzLly/dtv9Ts/EbcvGAHhHyfBIhZ6NSiIBTo0LNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiEC/wGgKKC4YMA4TAAAAABJRU5ErkJggg=="
                            }, null, _parent5, _scopeId4));
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "name") {
                            _push5(`<a href="javascript:;"${_scopeId4}>${ssrInterpolate(record.name)}</a>`);
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "action") {
                            _push5(ssrRenderComponent(_component_a_dropdown, null, {
                              overlay: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(ssrRenderComponent(_component_a_menu, null, {
                                    default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_a_menu_item, null, {
                                          default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(`<a href="javascript:;"${_scopeId7}>`);
                                              _push8(ssrRenderComponent(_component_edit_outlined, null, null, _parent8, _scopeId7));
                                              _push8(` Edit </a>`);
                                            } else {
                                              return [
                                                createVNode("a", { href: "javascript:;" }, [
                                                  createVNode(_component_edit_outlined),
                                                  createTextVNode(" Edit ")
                                                ])
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                        _push7(ssrRenderComponent(_component_a_menu_item, null, {
                                          default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(`<a href="javascript:;"${_scopeId7}>`);
                                              _push8(ssrRenderComponent(_component_delete_outlined, null, null, _parent8, _scopeId7));
                                              _push8(` Delete </a>`);
                                            } else {
                                              return [
                                                createVNode("a", { href: "javascript:;" }, [
                                                  createVNode(_component_delete_outlined),
                                                  createTextVNode(" Delete ")
                                                ])
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_a_menu_item, null, {
                                            default: withCtx(() => [
                                              createVNode("a", { href: "javascript:;" }, [
                                                createVNode(_component_edit_outlined),
                                                createTextVNode(" Edit ")
                                              ])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_menu_item, null, {
                                            default: withCtx(() => [
                                              createVNode("a", { href: "javascript:;" }, [
                                                createVNode(_component_delete_outlined),
                                                createTextVNode(" Delete ")
                                              ])
                                            ]),
                                            _: 1
                                          })
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  return [
                                    createVNode(_component_a_menu, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_menu_item, null, {
                                          default: withCtx(() => [
                                            createVNode("a", { href: "javascript:;" }, [
                                              createVNode(_component_edit_outlined),
                                              createTextVNode(" Edit ")
                                            ])
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_menu_item, null, {
                                          default: withCtx(() => [
                                            createVNode("a", { href: "javascript:;" }, [
                                              createVNode(_component_delete_outlined),
                                              createTextVNode(" Delete ")
                                            ])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ];
                                }
                              }),
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(ssrRenderComponent(_component_a_button, {
                                    type: "primary",
                                    size: _ctx.size,
                                    class: "ant-dropdown-link",
                                    shape: "circle"
                                  }, {
                                    icon: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_DownCircleOutlined, null, null, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_DownCircleOutlined)
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  return [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      size: _ctx.size,
                                      class: "ant-dropdown-link",
                                      shape: "circle"
                                    }, {
                                      icon: withCtx(() => [
                                        createVNode(_component_DownCircleOutlined)
                                      ]),
                                      _: 1
                                    }, 8, ["size"])
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                          } else {
                            _push5(`<!---->`);
                          }
                        } else {
                          return [
                            column.key === "image" ? (openBlock(), createBlock(_component_a_image, {
                              key: 0,
                              width: 30,
                              height: 30,
                              src: record.image,
                              fallback: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMIAAADDCAYAAADQvc6UAAABRWlDQ1BJQ0MgUHJvZmlsZQAAKJFjYGASSSwoyGFhYGDIzSspCnJ3UoiIjFJgf8LAwSDCIMogwMCcmFxc4BgQ4ANUwgCjUcG3awyMIPqyLsis7PPOq3QdDFcvjV3jOD1boQVTPQrgSkktTgbSf4A4LbmgqISBgTEFyFYuLykAsTuAbJEioKOA7DkgdjqEvQHEToKwj4DVhAQ5A9k3gGyB5IxEoBmML4BsnSQk8XQkNtReEOBxcfXxUQg1Mjc0dyHgXNJBSWpFCYh2zi+oLMpMzyhRcASGUqqCZ16yno6CkYGRAQMDKMwhqj/fAIcloxgHQqxAjIHBEugw5sUIsSQpBobtQPdLciLEVJYzMPBHMDBsayhILEqEO4DxG0txmrERhM29nYGBddr//5/DGRjYNRkY/l7////39v///y4Dmn+LgeHANwDrkl1AuO+pmgAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAwqADAAQAAAABAAAAwwAAAAD9b/HnAAAHlklEQVR4Ae3dP3PTWBSGcbGzM6GCKqlIBRV0dHRJFarQ0eUT8LH4BnRU0NHR0UEFVdIlFRV7TzRksomPY8uykTk/zewQfKw/9znv4yvJynLv4uLiV2dBoDiBf4qP3/ARuCRABEFAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghgg0Aj8i0JO4OzsrPv69Wv+hi2qPHr0qNvf39+iI97soRIh4f3z58/u7du3SXX7Xt7Z2enevHmzfQe+oSN2apSAPj09TSrb+XKI/f379+08+A0cNRE2ANkupk+ACNPvkSPcAAEibACyXUyfABGm3yNHuAECRNgAZLuYPgEirKlHu7u7XdyytGwHAd8jjNyng4OD7vnz51dbPT8/7z58+NB9+/bt6jU/TI+AGWHEnrx48eJ/EsSmHzx40L18+fLyzxF3ZVMjEyDCiEDjMYZZS5wiPXnyZFbJaxMhQIQRGzHvWR7XCyOCXsOmiDAi1HmPMMQjDpbpEiDCiL358eNHurW/5SnWdIBbXiDCiA38/Pnzrce2YyZ4//59F3ePLNMl4PbpiL2J0L979+7yDtHDhw8vtzzvdGnEXdvUigSIsCLAWavHp/+qM0BcXMd/q25n1vF57TYBp0a3mUzilePj4+7k5KSLb6gt6ydAhPUzXnoPR0dHl79WGTNCfBnn1uvSCJdegQhLI1vvCk+fPu2ePXt2tZOYEV6/fn31dz+shwAR1sP1cqvLntbEN9MxA9xcYjsxS1jWR4AIa2Ibzx0tc44fYX/16lV6NDFLXH+YL32jwiACRBiEbf5KcXoTIsQSpzXx4N28Ja4BQoK7rgXiydbHjx/P25TaQAJEGAguWy0+2Q8PD6/Ki4R8EVl+bzBOnZY95fq9rj9zAkTI2SxdidBHqG9+skdw43borCXO/ZcJdraPWdv22uIEiLA4q7nvvCug8WTqzQveOH26fodo7g6uFe/a17W3+nFBAkRYENRdb1vkkz1CH9cPsVy/jrhr27PqMYvENYNlHAIesRiBYwRy0V+8iXP8+/fvX11Mr7L7ECueb/r48eMqm7FuI2BGWDEG8cm+7G3NEOfmdcTQw4h9/55lhm7DekRYKQPZF2ArbXTAyu4kDYB2YxUzwg0gi/41ztHnfQG26HbGel/crVrm7tNY+/1btkOEAZ2M05r4FB7r9GbAIdxaZYrHdOsgJ/wCEQY0J74TmOKnbxxT9n3FgGGWWsVdowHtjt9Nnvf7yQM2aZU/TIAIAxrw6dOnAWtZZcoEnBpNuTuObWMEiLAx1HY0ZQJEmHJ3HNvGCBBhY6jtaMoEiJB0Z29vL6ls58vxPcO8/zfrdo5qvKO+d3Fx8Wu8zf1dW4p/cPzLly/dtv9Ts/EbcvGAHhHyfBIhZ6NSiIBTo0LNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiEC/wGgKKC4YMA4TAAAAABJRU5ErkJggg=="
                            }, null, 8, ["src"])) : createCommentVNode("", true),
                            column.key === "name" ? (openBlock(), createBlock("a", {
                              key: 1,
                              href: "javascript:;",
                              onClick: $options.showViewDrawer
                            }, toDisplayString(record.name), 9, ["onClick"])) : createCommentVNode("", true),
                            column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 2 }, {
                              overlay: withCtx(() => [
                                createVNode(_component_a_menu, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, null, {
                                      default: withCtx(() => [
                                        createVNode("a", { href: "javascript:;" }, [
                                          createVNode(_component_edit_outlined),
                                          createTextVNode(" Edit ")
                                        ])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_menu_item, null, {
                                      default: withCtx(() => [
                                        createVNode("a", { href: "javascript:;" }, [
                                          createVNode(_component_delete_outlined),
                                          createTextVNode(" Delete ")
                                        ])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  size: _ctx.size,
                                  class: "ant-dropdown-link",
                                  shape: "circle"
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_DownCircleOutlined)
                                  ]),
                                  _: 1
                                }, 8, ["size"])
                              ]),
                              _: 1
                            })) : createCommentVNode("", true)
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, {
                        name: "nest-messages",
                        model: $data.searchform,
                        layout: "inline",
                        onFinish: _ctx.search
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                placeholder: "Search by product name",
                                "allow-clear": true,
                                value: $data.searchform.term,
                                "onUpdate:value": ($event) => $data.searchform.term = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_select, { placeholder: "Search by Category" })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_select, { placeholder: "Search by Brand" })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Search ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                shape: "round",
                                onClick: $options.showDrawer
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Add New Product ")
                                ]),
                                _: 1
                              }, 8, ["onClick"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                shape: "round",
                                onClick: $options.showDrawer
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_CloudUploadOutlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Import ")
                                ]),
                                _: 1
                              }, 8, ["onClick"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["model", "onFinish"]),
                      createVNode(_component_a_table, {
                        columns: $setup.columns,
                        "data-source": $setup.items
                      }, {
                        bodyCell: withCtx(({ column, record }) => [
                          column.key === "image" ? (openBlock(), createBlock(_component_a_image, {
                            key: 0,
                            width: 30,
                            height: 30,
                            src: record.image,
                            fallback: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMIAAADDCAYAAADQvc6UAAABRWlDQ1BJQ0MgUHJvZmlsZQAAKJFjYGASSSwoyGFhYGDIzSspCnJ3UoiIjFJgf8LAwSDCIMogwMCcmFxc4BgQ4ANUwgCjUcG3awyMIPqyLsis7PPOq3QdDFcvjV3jOD1boQVTPQrgSkktTgbSf4A4LbmgqISBgTEFyFYuLykAsTuAbJEioKOA7DkgdjqEvQHEToKwj4DVhAQ5A9k3gGyB5IxEoBmML4BsnSQk8XQkNtReEOBxcfXxUQg1Mjc0dyHgXNJBSWpFCYh2zi+oLMpMzyhRcASGUqqCZ16yno6CkYGRAQMDKMwhqj/fAIcloxgHQqxAjIHBEugw5sUIsSQpBobtQPdLciLEVJYzMPBHMDBsayhILEqEO4DxG0txmrERhM29nYGBddr//5/DGRjYNRkY/l7////39v///y4Dmn+LgeHANwDrkl1AuO+pmgAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAwqADAAQAAAABAAAAwwAAAAD9b/HnAAAHlklEQVR4Ae3dP3PTWBSGcbGzM6GCKqlIBRV0dHRJFarQ0eUT8LH4BnRU0NHR0UEFVdIlFRV7TzRksomPY8uykTk/zewQfKw/9znv4yvJynLv4uLiV2dBoDiBf4qP3/ARuCRABEFAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghgg0Aj8i0JO4OzsrPv69Wv+hi2qPHr0qNvf39+iI97soRIh4f3z58/u7du3SXX7Xt7Z2enevHmzfQe+oSN2apSAPj09TSrb+XKI/f379+08+A0cNRE2ANkupk+ACNPvkSPcAAEibACyXUyfABGm3yNHuAECRNgAZLuYPgEirKlHu7u7XdyytGwHAd8jjNyng4OD7vnz51dbPT8/7z58+NB9+/bt6jU/TI+AGWHEnrx48eJ/EsSmHzx40L18+fLyzxF3ZVMjEyDCiEDjMYZZS5wiPXnyZFbJaxMhQIQRGzHvWR7XCyOCXsOmiDAi1HmPMMQjDpbpEiDCiL358eNHurW/5SnWdIBbXiDCiA38/Pnzrce2YyZ4//59F3ePLNMl4PbpiL2J0L979+7yDtHDhw8vtzzvdGnEXdvUigSIsCLAWavHp/+qM0BcXMd/q25n1vF57TYBp0a3mUzilePj4+7k5KSLb6gt6ydAhPUzXnoPR0dHl79WGTNCfBnn1uvSCJdegQhLI1vvCk+fPu2ePXt2tZOYEV6/fn31dz+shwAR1sP1cqvLntbEN9MxA9xcYjsxS1jWR4AIa2Ibzx0tc44fYX/16lV6NDFLXH+YL32jwiACRBiEbf5KcXoTIsQSpzXx4N28Ja4BQoK7rgXiydbHjx/P25TaQAJEGAguWy0+2Q8PD6/Ki4R8EVl+bzBOnZY95fq9rj9zAkTI2SxdidBHqG9+skdw43borCXO/ZcJdraPWdv22uIEiLA4q7nvvCug8WTqzQveOH26fodo7g6uFe/a17W3+nFBAkRYENRdb1vkkz1CH9cPsVy/jrhr27PqMYvENYNlHAIesRiBYwRy0V+8iXP8+/fvX11Mr7L7ECueb/r48eMqm7FuI2BGWDEG8cm+7G3NEOfmdcTQw4h9/55lhm7DekRYKQPZF2ArbXTAyu4kDYB2YxUzwg0gi/41ztHnfQG26HbGel/crVrm7tNY+/1btkOEAZ2M05r4FB7r9GbAIdxaZYrHdOsgJ/wCEQY0J74TmOKnbxxT9n3FgGGWWsVdowHtjt9Nnvf7yQM2aZU/TIAIAxrw6dOnAWtZZcoEnBpNuTuObWMEiLAx1HY0ZQJEmHJ3HNvGCBBhY6jtaMoEiJB0Z29vL6ls58vxPcO8/zfrdo5qvKO+d3Fx8Wu8zf1dW4p/cPzLly/dtv9Ts/EbcvGAHhHyfBIhZ6NSiIBTo0LNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiEC/wGgKKC4YMA4TAAAAABJRU5ErkJggg=="
                          }, null, 8, ["src"])) : createCommentVNode("", true),
                          column.key === "name" ? (openBlock(), createBlock("a", {
                            key: 1,
                            href: "javascript:;",
                            onClick: $options.showViewDrawer
                          }, toDisplayString(record.name), 9, ["onClick"])) : createCommentVNode("", true),
                          column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 2 }, {
                            overlay: withCtx(() => [
                              createVNode(_component_a_menu, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, null, {
                                    default: withCtx(() => [
                                      createVNode("a", { href: "javascript:;" }, [
                                        createVNode(_component_edit_outlined),
                                        createTextVNode(" Edit ")
                                      ])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_menu_item, null, {
                                    default: withCtx(() => [
                                      createVNode("a", { href: "javascript:;" }, [
                                        createVNode(_component_delete_outlined),
                                        createTextVNode(" Delete ")
                                      ])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                size: _ctx.size,
                                class: "ant-dropdown-link",
                                shape: "circle"
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_DownCircleOutlined)
                                ]),
                                _: 1
                              }, 8, ["size"])
                            ]),
                            _: 1
                          })) : createCommentVNode("", true)
                        ]),
                        _: 1
                      }, 8, ["columns", "data-source"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_drawer, {
                visible: $data.createvisible,
                "onUpdate:visible": ($event) => $data.createvisible = $event,
                class: "custom-class",
                title: "New Product",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                extra: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_space, null, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_button, {
                            type: "primary",
                            onClick: _ctx.onClose
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Save`);
                              } else {
                                return [
                                  createTextVNode("Save")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_button, {
                              type: "primary",
                              onClick: _ctx.onClose
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Save")
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_space, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            onClick: _ctx.onClose
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Save")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, mergeProps({ model: $data.form }, $data.layout, {
                      name: "nest-messages",
                      "validate-messages": _ctx.validateMessages,
                      onFinish: _ctx.submit,
                      "label-col": { span: 24 }
                    }), {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_tabs, {
                            activeKey: _ctx.activeKey,
                            "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_tab_pane, {
                                  key: "pc-1",
                                  tab: "Basic Information"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<h4 class="t1"${_scopeId6}>Details</h4>`);
                                      _push7(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, {
                                                    label: "Product Name",
                                                    name: "name",
                                                    rules: [{ required: true }]
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_input, { placeholder: "Please enter name" }, null, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_input, { placeholder: "Please enter name" })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, {
                                                      label: "Product Name",
                                                      name: "name",
                                                      rules: [{ required: true }]
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, { placeholder: "Please enter name" })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, {
                                                    label: "Image",
                                                    name: "image"
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_upload, {
                                                          "before-upload": _ctx.beforeUpload,
                                                          onRemove: _ctx.handleRemove,
                                                          "max-count": 1
                                                        }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(ssrRenderComponent(_component_a_button, null, {
                                                                default: withCtx((_11, _push12, _parent12, _scopeId11) => {
                                                                  if (_push12) {
                                                                    _push12(ssrRenderComponent(_component_upload_outlined, null, null, _parent12, _scopeId11));
                                                                    _push12(` Select File `);
                                                                  } else {
                                                                    return [
                                                                      createVNode(_component_upload_outlined),
                                                                      createTextVNode(" Select File ")
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 1
                                                              }, _parent11, _scopeId10));
                                                            } else {
                                                              return [
                                                                createVNode(_component_a_button, null, {
                                                                  default: withCtx(() => [
                                                                    createVNode(_component_upload_outlined),
                                                                    createTextVNode(" Select File ")
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_upload, {
                                                            "before-upload": _ctx.beforeUpload,
                                                            onRemove: _ctx.handleRemove,
                                                            "max-count": 1
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_a_button, null, {
                                                                default: withCtx(() => [
                                                                  createVNode(_component_upload_outlined),
                                                                  createTextVNode(" Select File ")
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          }, 8, ["before-upload", "onRemove"])
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, {
                                                      label: "Image",
                                                      name: "image"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_upload, {
                                                          "before-upload": _ctx.beforeUpload,
                                                          onRemove: _ctx.handleRemove,
                                                          "max-count": 1
                                                        }, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_a_button, null, {
                                                              default: withCtx(() => [
                                                                createVNode(_component_upload_outlined),
                                                                createTextVNode(" Select File ")
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        }, 8, ["before-upload", "onRemove"])
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, {
                                                    label: "Product Category",
                                                    name: "category"
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_auto_complete, {
                                                          options: _ctx.categories,
                                                          placeholder: "Select Category"
                                                        }, null, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_auto_complete, {
                                                            options: _ctx.categories,
                                                            placeholder: "Select Category"
                                                          }, null, 8, ["options"])
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, {
                                                      label: "Product Category",
                                                      name: "category"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_auto_complete, {
                                                          options: _ctx.categories,
                                                          placeholder: "Select Category"
                                                        }, null, 8, ["options"])
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, {
                                                    label: "Brand",
                                                    name: "brand"
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_auto_complete, { placeholder: "Select Brand" }, null, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_auto_complete, { placeholder: "Select Brand" })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, {
                                                      label: "Brand",
                                                      name: "brand"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_auto_complete, { placeholder: "Select Brand" })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, {
                                              class: "gutter-row",
                                              span: 6
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, {
                                                    label: "Barcode Symbology",
                                                    name: "sku"
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_select, null, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(ssrRenderComponent(_component_a_select_option, { value: "CODE128" }, {
                                                                default: withCtx((_11, _push12, _parent12, _scopeId11) => {
                                                                  if (_push12) {
                                                                    _push12(`CODE128`);
                                                                  } else {
                                                                    return [
                                                                      createTextVNode("CODE128")
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 1
                                                              }, _parent11, _scopeId10));
                                                              _push11(ssrRenderComponent(_component_a_select_option, { value: "CODE39" }, {
                                                                default: withCtx((_11, _push12, _parent12, _scopeId11) => {
                                                                  if (_push12) {
                                                                    _push12(`CODE39`);
                                                                  } else {
                                                                    return [
                                                                      createTextVNode("CODE39")
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 1
                                                              }, _parent11, _scopeId10));
                                                            } else {
                                                              return [
                                                                createVNode(_component_a_select_option, { value: "CODE128" }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode("CODE128")
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode(_component_a_select_option, { value: "CODE39" }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode("CODE39")
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_select, null, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_a_select_option, { value: "CODE128" }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode("CODE128")
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode(_component_a_select_option, { value: "CODE39" }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode("CODE39")
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, {
                                                      label: "Barcode Symbology",
                                                      name: "sku"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_select, null, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_a_select_option, { value: "CODE128" }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("CODE128")
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode(_component_a_select_option, { value: "CODE39" }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("CODE39")
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, {
                                              class: "gutter-row",
                                              span: 18
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, {
                                                    label: "Barcode",
                                                    name: "sku"
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_input, { placeholder: "Enter Barcode" }, {
                                                          addonAfter: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(ssrRenderComponent(_component_a_button, { style: { "width": "100px" } }, {
                                                                default: withCtx((_11, _push12, _parent12, _scopeId11) => {
                                                                  if (_push12) {
                                                                    _push12(ssrRenderComponent(_component_BarcodeOutlined, null, null, _parent12, _scopeId11));
                                                                    _push12(` Generate `);
                                                                  } else {
                                                                    return [
                                                                      createVNode(_component_BarcodeOutlined),
                                                                      createTextVNode(" Generate ")
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 1
                                                              }, _parent11, _scopeId10));
                                                            } else {
                                                              return [
                                                                createVNode(_component_a_button, { style: { "width": "100px" } }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(_component_BarcodeOutlined),
                                                                    createTextVNode(" Generate ")
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_input, { placeholder: "Enter Barcode" }, {
                                                            addonAfter: withCtx(() => [
                                                              createVNode(_component_a_button, { style: { "width": "100px" } }, {
                                                                default: withCtx(() => [
                                                                  createVNode(_component_BarcodeOutlined),
                                                                  createTextVNode(" Generate ")
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, {
                                                      label: "Barcode",
                                                      name: "sku"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, { placeholder: "Enter Barcode" }, {
                                                          addonAfter: withCtx(() => [
                                                            createVNode(_component_a_button, { style: { "width": "100px" } }, {
                                                              default: withCtx(() => [
                                                                createVNode(_component_BarcodeOutlined),
                                                                createTextVNode(" Generate ")
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, {
                                                    label: "HSN Code",
                                                    name: "hsn"
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_input, { placeholder: "Enter HSN Code" }, null, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_input, { placeholder: "Enter HSN Code" })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, {
                                                      label: "HSN Code",
                                                      name: "hsn"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, { placeholder: "Enter HSN Code" })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, {
                                                    label: "Unit",
                                                    name: "unit"
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_auto_complete, { placeholder: "Select Unit" }, null, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, {
                                                      label: "Unit",
                                                      name: "unit"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_col, {
                                                class: "gutter-row",
                                                span: 12
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, {
                                                    label: "Product Name",
                                                    name: "name",
                                                    rules: [{ required: true }]
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, { placeholder: "Please enter name" })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, {
                                                class: "gutter-row",
                                                span: 12
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, {
                                                    label: "Image",
                                                    name: "image"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_upload, {
                                                        "before-upload": _ctx.beforeUpload,
                                                        onRemove: _ctx.handleRemove,
                                                        "max-count": 1
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_button, null, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_upload_outlined),
                                                              createTextVNode(" Select File ")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      }, 8, ["before-upload", "onRemove"])
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, {
                                                class: "gutter-row",
                                                span: 12
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, {
                                                    label: "Product Category",
                                                    name: "category"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_auto_complete, {
                                                        options: _ctx.categories,
                                                        placeholder: "Select Category"
                                                      }, null, 8, ["options"])
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, {
                                                class: "gutter-row",
                                                span: 12
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, {
                                                    label: "Brand",
                                                    name: "brand"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_auto_complete, { placeholder: "Select Brand" })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, {
                                                class: "gutter-row",
                                                span: 6
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, {
                                                    label: "Barcode Symbology",
                                                    name: "sku"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_select, null, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_select_option, { value: "CODE128" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("CODE128")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_select_option, { value: "CODE39" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("CODE39")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, {
                                                class: "gutter-row",
                                                span: 18
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, {
                                                    label: "Barcode",
                                                    name: "sku"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, { placeholder: "Enter Barcode" }, {
                                                        addonAfter: withCtx(() => [
                                                          createVNode(_component_a_button, { style: { "width": "100px" } }, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_BarcodeOutlined),
                                                              createTextVNode(" Generate ")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, {
                                                class: "gutter-row",
                                                span: 12
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, {
                                                    label: "HSN Code",
                                                    name: "hsn"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, { placeholder: "Enter HSN Code" })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, {
                                                class: "gutter-row",
                                                span: 12
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, {
                                                    label: "Unit",
                                                    name: "unit"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(`<h4 class="t1"${_scopeId6}>Pricing &amp; Tax</h4>`);
                                      _push7(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, {
                                                    label: "Sales Price (INR)",
                                                    name: "sales_price"
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_input_number, {
                                                          style: { "width": "100%" },
                                                          placeholder: "Enter sales price"
                                                        }, {
                                                          addonAfter: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(ssrRenderComponent(_component_a_select, { style: { "width": "100px" } }, {
                                                                default: withCtx((_11, _push12, _parent12, _scopeId11) => {
                                                                  if (_push12) {
                                                                    _push12(ssrRenderComponent(_component_a_select_option, { value: "With Tax" }, {
                                                                      default: withCtx((_12, _push13, _parent13, _scopeId12) => {
                                                                        if (_push13) {
                                                                          _push13(`With Tax`);
                                                                        } else {
                                                                          return [
                                                                            createTextVNode("With Tax")
                                                                          ];
                                                                        }
                                                                      }),
                                                                      _: 1
                                                                    }, _parent12, _scopeId11));
                                                                    _push12(ssrRenderComponent(_component_a_select_option, { value: "Without Tax" }, {
                                                                      default: withCtx((_12, _push13, _parent13, _scopeId12) => {
                                                                        if (_push13) {
                                                                          _push13(`Without Tax`);
                                                                        } else {
                                                                          return [
                                                                            createTextVNode("Without Tax")
                                                                          ];
                                                                        }
                                                                      }),
                                                                      _: 1
                                                                    }, _parent12, _scopeId11));
                                                                  } else {
                                                                    return [
                                                                      createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                                        default: withCtx(() => [
                                                                          createTextVNode("With Tax")
                                                                        ]),
                                                                        _: 1
                                                                      }),
                                                                      createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                                        default: withCtx(() => [
                                                                          createTextVNode("Without Tax")
                                                                        ]),
                                                                        _: 1
                                                                      })
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 1
                                                              }, _parent11, _scopeId10));
                                                            } else {
                                                              return [
                                                                createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                                      default: withCtx(() => [
                                                                        createTextVNode("With Tax")
                                                                      ]),
                                                                      _: 1
                                                                    }),
                                                                    createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                                      default: withCtx(() => [
                                                                        createTextVNode("Without Tax")
                                                                      ]),
                                                                      _: 1
                                                                    })
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_input_number, {
                                                            style: { "width": "100%" },
                                                            placeholder: "Enter sales price"
                                                          }, {
                                                            addonAfter: withCtx(() => [
                                                              createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                                default: withCtx(() => [
                                                                  createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                                    default: withCtx(() => [
                                                                      createTextVNode("With Tax")
                                                                    ]),
                                                                    _: 1
                                                                  }),
                                                                  createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                                    default: withCtx(() => [
                                                                      createTextVNode("Without Tax")
                                                                    ]),
                                                                    _: 1
                                                                  })
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, {
                                                      label: "Sales Price (INR)",
                                                      name: "sales_price"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input_number, {
                                                          style: { "width": "100%" },
                                                          placeholder: "Enter sales price"
                                                        }, {
                                                          addonAfter: withCtx(() => [
                                                            createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                              default: withCtx(() => [
                                                                createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode("With Tax")
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode("Without Tax")
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, {
                                                    label: "Purchase Price (INR)",
                                                    name: "purchase_price"
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_input_number, {
                                                          style: { "width": "100%" },
                                                          placeholder: "Enter purchase price"
                                                        }, {
                                                          addonAfter: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(ssrRenderComponent(_component_a_select, { style: { "width": "100px" } }, {
                                                                default: withCtx((_11, _push12, _parent12, _scopeId11) => {
                                                                  if (_push12) {
                                                                    _push12(ssrRenderComponent(_component_a_select_option, { value: "With Tax" }, {
                                                                      default: withCtx((_12, _push13, _parent13, _scopeId12) => {
                                                                        if (_push13) {
                                                                          _push13(`With Tax`);
                                                                        } else {
                                                                          return [
                                                                            createTextVNode("With Tax")
                                                                          ];
                                                                        }
                                                                      }),
                                                                      _: 1
                                                                    }, _parent12, _scopeId11));
                                                                    _push12(ssrRenderComponent(_component_a_select_option, { value: "Without Tax" }, {
                                                                      default: withCtx((_12, _push13, _parent13, _scopeId12) => {
                                                                        if (_push13) {
                                                                          _push13(`Without Tax`);
                                                                        } else {
                                                                          return [
                                                                            createTextVNode("Without Tax")
                                                                          ];
                                                                        }
                                                                      }),
                                                                      _: 1
                                                                    }, _parent12, _scopeId11));
                                                                  } else {
                                                                    return [
                                                                      createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                                        default: withCtx(() => [
                                                                          createTextVNode("With Tax")
                                                                        ]),
                                                                        _: 1
                                                                      }),
                                                                      createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                                        default: withCtx(() => [
                                                                          createTextVNode("Without Tax")
                                                                        ]),
                                                                        _: 1
                                                                      })
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 1
                                                              }, _parent11, _scopeId10));
                                                            } else {
                                                              return [
                                                                createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                                      default: withCtx(() => [
                                                                        createTextVNode("With Tax")
                                                                      ]),
                                                                      _: 1
                                                                    }),
                                                                    createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                                      default: withCtx(() => [
                                                                        createTextVNode("Without Tax")
                                                                      ]),
                                                                      _: 1
                                                                    })
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_input_number, {
                                                            style: { "width": "100%" },
                                                            placeholder: "Enter purchase price"
                                                          }, {
                                                            addonAfter: withCtx(() => [
                                                              createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                                default: withCtx(() => [
                                                                  createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                                    default: withCtx(() => [
                                                                      createTextVNode("With Tax")
                                                                    ]),
                                                                    _: 1
                                                                  }),
                                                                  createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                                    default: withCtx(() => [
                                                                      createTextVNode("Without Tax")
                                                                    ]),
                                                                    _: 1
                                                                  })
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, {
                                                      label: "Purchase Price (INR)",
                                                      name: "purchase_price"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input_number, {
                                                          style: { "width": "100%" },
                                                          placeholder: "Enter purchase price"
                                                        }, {
                                                          addonAfter: withCtx(() => [
                                                            createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                              default: withCtx(() => [
                                                                createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode("With Tax")
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode("Without Tax")
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, {
                                                    label: "Tax Rate",
                                                    name: "tax"
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_select, {
                                                          "show-search": "",
                                                          placeholder: "Tax",
                                                          "default-active-first-option": false
                                                        }, null, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_select, {
                                                            "show-search": "",
                                                            placeholder: "Tax",
                                                            "default-active-first-option": false
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, {
                                                      label: "Tax Rate",
                                                      name: "tax"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_select, {
                                                          "show-search": "",
                                                          placeholder: "Tax",
                                                          "default-active-first-option": false
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_col, {
                                                class: "gutter-row",
                                                span: 12
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, {
                                                    label: "Sales Price (INR)",
                                                    name: "sales_price"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input_number, {
                                                        style: { "width": "100%" },
                                                        placeholder: "Enter sales price"
                                                      }, {
                                                        addonAfter: withCtx(() => [
                                                          createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode("With Tax")
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode("Without Tax")
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, {
                                                class: "gutter-row",
                                                span: 12
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, {
                                                    label: "Purchase Price (INR)",
                                                    name: "purchase_price"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input_number, {
                                                        style: { "width": "100%" },
                                                        placeholder: "Enter purchase price"
                                                      }, {
                                                        addonAfter: withCtx(() => [
                                                          createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode("With Tax")
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode("Without Tax")
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, {
                                                class: "gutter-row",
                                                span: 12
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, {
                                                    label: "Tax Rate",
                                                    name: "tax"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_select, {
                                                        "show-search": "",
                                                        placeholder: "Tax",
                                                        "default-active-first-option": false
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(`<h4 class="t1"${_scopeId6}>Description</h4>`);
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Description",
                                        name: "description"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_textarea, { placeholder: "Enter Description" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_textarea, { placeholder: "Enter Description" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_button, {
                                              type: "primary",
                                              "html-type": "submit",
                                              disabled: $data.form.processing
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`SUBMIT`);
                                                } else {
                                                  return [
                                                    createTextVNode("SUBMIT")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_button, {
                                                type: "primary",
                                                "html-type": "submit",
                                                disabled: $data.form.processing
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode("SUBMIT")
                                                ]),
                                                _: 1
                                              }, 8, ["disabled"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode("h4", { class: "t1" }, "Details"),
                                        createVNode(_component_a_row, { gutter: 24 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, {
                                                  label: "Product Name",
                                                  name: "name",
                                                  rules: [{ required: true }]
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, { placeholder: "Please enter name" })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, {
                                                  label: "Image",
                                                  name: "image"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_upload, {
                                                      "before-upload": _ctx.beforeUpload,
                                                      onRemove: _ctx.handleRemove,
                                                      "max-count": 1
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_button, null, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_upload_outlined),
                                                            createTextVNode(" Select File ")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }, 8, ["before-upload", "onRemove"])
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, {
                                                  label: "Product Category",
                                                  name: "category"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_auto_complete, {
                                                      options: _ctx.categories,
                                                      placeholder: "Select Category"
                                                    }, null, 8, ["options"])
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, {
                                                  label: "Brand",
                                                  name: "brand"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_auto_complete, { placeholder: "Select Brand" })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, {
                                              class: "gutter-row",
                                              span: 6
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, {
                                                  label: "Barcode Symbology",
                                                  name: "sku"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_select, null, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_select_option, { value: "CODE128" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("CODE128")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_select_option, { value: "CODE39" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("CODE39")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, {
                                              class: "gutter-row",
                                              span: 18
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, {
                                                  label: "Barcode",
                                                  name: "sku"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, { placeholder: "Enter Barcode" }, {
                                                      addonAfter: withCtx(() => [
                                                        createVNode(_component_a_button, { style: { "width": "100px" } }, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_BarcodeOutlined),
                                                            createTextVNode(" Generate ")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, {
                                                  label: "HSN Code",
                                                  name: "hsn"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, { placeholder: "Enter HSN Code" })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, {
                                                  label: "Unit",
                                                  name: "unit"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode("h4", { class: "t1" }, "Pricing & Tax"),
                                        createVNode(_component_a_row, { gutter: 24 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, {
                                                  label: "Sales Price (INR)",
                                                  name: "sales_price"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input_number, {
                                                      style: { "width": "100%" },
                                                      placeholder: "Enter sales price"
                                                    }, {
                                                      addonAfter: withCtx(() => [
                                                        createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("With Tax")
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("Without Tax")
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, {
                                                  label: "Purchase Price (INR)",
                                                  name: "purchase_price"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input_number, {
                                                      style: { "width": "100%" },
                                                      placeholder: "Enter purchase price"
                                                    }, {
                                                      addonAfter: withCtx(() => [
                                                        createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("With Tax")
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("Without Tax")
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, {
                                              class: "gutter-row",
                                              span: 12
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, {
                                                  label: "Tax Rate",
                                                  name: "tax"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_select, {
                                                      "show-search": "",
                                                      placeholder: "Tax",
                                                      "default-active-first-option": false
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode("h4", { class: "t1" }, "Description"),
                                        createVNode(_component_a_form_item, {
                                          label: "Description",
                                          name: "description"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_textarea, { placeholder: "Enter Description" })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_button, {
                                              type: "primary",
                                              "html-type": "submit",
                                              disabled: $data.form.processing
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode("SUBMIT")
                                              ]),
                                              _: 1
                                            }, 8, ["disabled"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_tab_pane, {
                                  key: "pc-2",
                                  tab: "Raw Materials (Optional)"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_table, {
                                        columns: [{
                                          title: "Item",
                                          dataIndex: "item",
                                          width: "60%"
                                        }, {
                                          title: "Unit",
                                          dataIndex: "unit"
                                        }, {
                                          title: "Yield",
                                          dataIndex: "yield"
                                        }],
                                        "data-source": [{ item: "Item-1", unit: "Pcs", yield: "1" }],
                                        pagination: false
                                      }, {
                                        bodyCell: withCtx(({ column, text }, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            if (column.dataIndex === "item") {
                                              _push8(ssrRenderComponent(_component_a_auto_complete, {
                                                placeholder: "Select Item",
                                                style: { "width": "100%" }
                                              }, null, _parent8, _scopeId7));
                                            } else {
                                              _push8(`<!---->`);
                                            }
                                            if (column.dataIndex === "unit") {
                                              _push8(`<!--[--> Pcs <!--]-->`);
                                            } else {
                                              _push8(`<!---->`);
                                            }
                                            if (column.dataIndex === "yield") {
                                              _push8(ssrRenderComponent(_component_a_input_number, {
                                                style: { "width": "100%" },
                                                placeholder: "Enter yield"
                                              }, null, _parent8, _scopeId7));
                                            } else {
                                              _push8(`<!---->`);
                                            }
                                          } else {
                                            return [
                                              column.dataIndex === "item" ? (openBlock(), createBlock(_component_a_auto_complete, {
                                                key: 0,
                                                placeholder: "Select Item",
                                                style: { "width": "100%" }
                                              })) : createCommentVNode("", true),
                                              column.dataIndex === "unit" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                                                createTextVNode(" Pcs ")
                                              ], 64)) : createCommentVNode("", true),
                                              column.dataIndex === "yield" ? (openBlock(), createBlock(_component_a_input_number, {
                                                key: 2,
                                                style: { "width": "100%" },
                                                placeholder: "Enter yield"
                                              })) : createCommentVNode("", true)
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "success",
                                        size: "small"
                                      }, {
                                        icon: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_plus_circle_outlined)
                                            ];
                                          }
                                        }),
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(` Add `);
                                          } else {
                                            return [
                                              createTextVNode(" Add ")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_table, {
                                          columns: [{
                                            title: "Item",
                                            dataIndex: "item",
                                            width: "60%"
                                          }, {
                                            title: "Unit",
                                            dataIndex: "unit"
                                          }, {
                                            title: "Yield",
                                            dataIndex: "yield"
                                          }],
                                          "data-source": [{ item: "Item-1", unit: "Pcs", yield: "1" }],
                                          pagination: false
                                        }, {
                                          bodyCell: withCtx(({ column, text }) => [
                                            column.dataIndex === "item" ? (openBlock(), createBlock(_component_a_auto_complete, {
                                              key: 0,
                                              placeholder: "Select Item",
                                              style: { "width": "100%" }
                                            })) : createCommentVNode("", true),
                                            column.dataIndex === "unit" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                                              createTextVNode(" Pcs ")
                                            ], 64)) : createCommentVNode("", true),
                                            column.dataIndex === "yield" ? (openBlock(), createBlock(_component_a_input_number, {
                                              key: 2,
                                              style: { "width": "100%" },
                                              placeholder: "Enter yield"
                                            })) : createCommentVNode("", true)
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_button, {
                                          type: "success",
                                          size: "small"
                                        }, {
                                          icon: withCtx(() => [
                                            createVNode(_component_plus_circle_outlined)
                                          ]),
                                          default: withCtx(() => [
                                            createTextVNode(" Add ")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_tab_pane, {
                                  key: "pc-3",
                                  tab: "Operations (Optional)"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_table, {
                                        columns: [{
                                          title: "Machine/Operation",
                                          dataIndex: "machine_operation",
                                          width: "60%"
                                        }, {
                                          title: "Operation Parameters",
                                          dataIndex: "operation_parameters"
                                        }, {
                                          title: "End Machine/Operation",
                                          dataIndex: "end_machine_operation"
                                        }],
                                        "data-source": [
                                          { machine_operation: "Cutting", operation_parameters: "Cutting Details", end_machine_operation: "Machine-1" },
                                          { machine_operation: "Machine-2", operation_parameters: "Operation-2", end_machine_operation: "Machine-2" }
                                        ],
                                        pagination: false
                                      }, {
                                        bodyCell: withCtx(({ column, text }, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            if (column.dataIndex === "machine_operation") {
                                              _push8(ssrRenderComponent(_component_a_auto_complete, {
                                                placeholder: "Select Machine / Operation",
                                                style: { "width": "100%" },
                                                options: [
                                                  { value: "Cutting" },
                                                  { value: "Stiching" },
                                                  { value: "Printing" },
                                                  { value: "Iorning" },
                                                  { value: "Packing" }
                                                ]
                                              }, null, _parent8, _scopeId7));
                                            } else {
                                              _push8(`<!---->`);
                                            }
                                            if (column.dataIndex === "operation_parameters") {
                                              _push8(ssrRenderComponent(_component_a_textarea, { placeholder: "Enter Operation Parameters" }, null, _parent8, _scopeId7));
                                            } else {
                                              _push8(`<!---->`);
                                            }
                                            if (column.dataIndex === "end_machine_operation") {
                                              _push8(ssrRenderComponent(_component_a_checkbox, { checked: true }, {
                                                default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                  if (_push9) {
                                                    _push9(`End`);
                                                  } else {
                                                    return [
                                                      createTextVNode("End")
                                                    ];
                                                  }
                                                }),
                                                _: 2
                                              }, _parent8, _scopeId7));
                                            } else {
                                              _push8(`<!---->`);
                                            }
                                          } else {
                                            return [
                                              column.dataIndex === "machine_operation" ? (openBlock(), createBlock(_component_a_auto_complete, {
                                                key: 0,
                                                placeholder: "Select Machine / Operation",
                                                style: { "width": "100%" },
                                                options: [
                                                  { value: "Cutting" },
                                                  { value: "Stiching" },
                                                  { value: "Printing" },
                                                  { value: "Iorning" },
                                                  { value: "Packing" }
                                                ]
                                              })) : createCommentVNode("", true),
                                              column.dataIndex === "operation_parameters" ? (openBlock(), createBlock(_component_a_textarea, {
                                                key: 1,
                                                placeholder: "Enter Operation Parameters"
                                              })) : createCommentVNode("", true),
                                              column.dataIndex === "end_machine_operation" ? (openBlock(), createBlock(_component_a_checkbox, {
                                                key: 2,
                                                checked: true
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode("End")
                                                ]),
                                                _: 1
                                              })) : createCommentVNode("", true)
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "success",
                                        size: "small"
                                      }, {
                                        icon: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_plus_circle_outlined)
                                            ];
                                          }
                                        }),
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(` Add `);
                                          } else {
                                            return [
                                              createTextVNode(" Add ")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_table, {
                                          columns: [{
                                            title: "Machine/Operation",
                                            dataIndex: "machine_operation",
                                            width: "60%"
                                          }, {
                                            title: "Operation Parameters",
                                            dataIndex: "operation_parameters"
                                          }, {
                                            title: "End Machine/Operation",
                                            dataIndex: "end_machine_operation"
                                          }],
                                          "data-source": [
                                            { machine_operation: "Cutting", operation_parameters: "Cutting Details", end_machine_operation: "Machine-1" },
                                            { machine_operation: "Machine-2", operation_parameters: "Operation-2", end_machine_operation: "Machine-2" }
                                          ],
                                          pagination: false
                                        }, {
                                          bodyCell: withCtx(({ column, text }) => [
                                            column.dataIndex === "machine_operation" ? (openBlock(), createBlock(_component_a_auto_complete, {
                                              key: 0,
                                              placeholder: "Select Machine / Operation",
                                              style: { "width": "100%" },
                                              options: [
                                                { value: "Cutting" },
                                                { value: "Stiching" },
                                                { value: "Printing" },
                                                { value: "Iorning" },
                                                { value: "Packing" }
                                              ]
                                            })) : createCommentVNode("", true),
                                            column.dataIndex === "operation_parameters" ? (openBlock(), createBlock(_component_a_textarea, {
                                              key: 1,
                                              placeholder: "Enter Operation Parameters"
                                            })) : createCommentVNode("", true),
                                            column.dataIndex === "end_machine_operation" ? (openBlock(), createBlock(_component_a_checkbox, {
                                              key: 2,
                                              checked: true
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode("End")
                                              ]),
                                              _: 1
                                            })) : createCommentVNode("", true)
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_button, {
                                          type: "success",
                                          size: "small"
                                        }, {
                                          icon: withCtx(() => [
                                            createVNode(_component_plus_circle_outlined)
                                          ]),
                                          default: withCtx(() => [
                                            createTextVNode(" Add ")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_tab_pane, {
                                    key: "pc-1",
                                    tab: "Basic Information"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("h4", { class: "t1" }, "Details"),
                                      createVNode(_component_a_row, { gutter: 24 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_col, {
                                            class: "gutter-row",
                                            span: 12
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, {
                                                label: "Product Name",
                                                name: "name",
                                                rules: [{ required: true }]
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, { placeholder: "Please enter name" })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, {
                                            class: "gutter-row",
                                            span: 12
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, {
                                                label: "Image",
                                                name: "image"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_upload, {
                                                    "before-upload": _ctx.beforeUpload,
                                                    onRemove: _ctx.handleRemove,
                                                    "max-count": 1
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_button, null, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_upload_outlined),
                                                          createTextVNode(" Select File ")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }, 8, ["before-upload", "onRemove"])
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, {
                                            class: "gutter-row",
                                            span: 12
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, {
                                                label: "Product Category",
                                                name: "category"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_auto_complete, {
                                                    options: _ctx.categories,
                                                    placeholder: "Select Category"
                                                  }, null, 8, ["options"])
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, {
                                            class: "gutter-row",
                                            span: 12
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, {
                                                label: "Brand",
                                                name: "brand"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_auto_complete, { placeholder: "Select Brand" })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, {
                                            class: "gutter-row",
                                            span: 6
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, {
                                                label: "Barcode Symbology",
                                                name: "sku"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select, null, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_select_option, { value: "CODE128" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("CODE128")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_select_option, { value: "CODE39" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("CODE39")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, {
                                            class: "gutter-row",
                                            span: 18
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, {
                                                label: "Barcode",
                                                name: "sku"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, { placeholder: "Enter Barcode" }, {
                                                    addonAfter: withCtx(() => [
                                                      createVNode(_component_a_button, { style: { "width": "100px" } }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_BarcodeOutlined),
                                                          createTextVNode(" Generate ")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, {
                                            class: "gutter-row",
                                            span: 12
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, {
                                                label: "HSN Code",
                                                name: "hsn"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, { placeholder: "Enter HSN Code" })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, {
                                            class: "gutter-row",
                                            span: 12
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, {
                                                label: "Unit",
                                                name: "unit"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode("h4", { class: "t1" }, "Pricing & Tax"),
                                      createVNode(_component_a_row, { gutter: 24 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_col, {
                                            class: "gutter-row",
                                            span: 12
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, {
                                                label: "Sales Price (INR)",
                                                name: "sales_price"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input_number, {
                                                    style: { "width": "100%" },
                                                    placeholder: "Enter sales price"
                                                  }, {
                                                    addonAfter: withCtx(() => [
                                                      createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("With Tax")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Without Tax")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, {
                                            class: "gutter-row",
                                            span: 12
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, {
                                                label: "Purchase Price (INR)",
                                                name: "purchase_price"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input_number, {
                                                    style: { "width": "100%" },
                                                    placeholder: "Enter purchase price"
                                                  }, {
                                                    addonAfter: withCtx(() => [
                                                      createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("With Tax")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Without Tax")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, {
                                            class: "gutter-row",
                                            span: 12
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, {
                                                label: "Tax Rate",
                                                name: "tax"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select, {
                                                    "show-search": "",
                                                    placeholder: "Tax",
                                                    "default-active-first-option": false
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode("h4", { class: "t1" }, "Description"),
                                      createVNode(_component_a_form_item, {
                                        label: "Description",
                                        name: "description"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_textarea, { placeholder: "Enter Description" })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_button, {
                                            type: "primary",
                                            "html-type": "submit",
                                            disabled: $data.form.processing
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode("SUBMIT")
                                            ]),
                                            _: 1
                                          }, 8, ["disabled"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_tab_pane, {
                                    key: "pc-2",
                                    tab: "Raw Materials (Optional)"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_table, {
                                        columns: [{
                                          title: "Item",
                                          dataIndex: "item",
                                          width: "60%"
                                        }, {
                                          title: "Unit",
                                          dataIndex: "unit"
                                        }, {
                                          title: "Yield",
                                          dataIndex: "yield"
                                        }],
                                        "data-source": [{ item: "Item-1", unit: "Pcs", yield: "1" }],
                                        pagination: false
                                      }, {
                                        bodyCell: withCtx(({ column, text }) => [
                                          column.dataIndex === "item" ? (openBlock(), createBlock(_component_a_auto_complete, {
                                            key: 0,
                                            placeholder: "Select Item",
                                            style: { "width": "100%" }
                                          })) : createCommentVNode("", true),
                                          column.dataIndex === "unit" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                                            createTextVNode(" Pcs ")
                                          ], 64)) : createCommentVNode("", true),
                                          column.dataIndex === "yield" ? (openBlock(), createBlock(_component_a_input_number, {
                                            key: 2,
                                            style: { "width": "100%" },
                                            placeholder: "Enter yield"
                                          })) : createCommentVNode("", true)
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_button, {
                                        type: "success",
                                        size: "small"
                                      }, {
                                        icon: withCtx(() => [
                                          createVNode(_component_plus_circle_outlined)
                                        ]),
                                        default: withCtx(() => [
                                          createTextVNode(" Add ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_tab_pane, {
                                    key: "pc-3",
                                    tab: "Operations (Optional)"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_table, {
                                        columns: [{
                                          title: "Machine/Operation",
                                          dataIndex: "machine_operation",
                                          width: "60%"
                                        }, {
                                          title: "Operation Parameters",
                                          dataIndex: "operation_parameters"
                                        }, {
                                          title: "End Machine/Operation",
                                          dataIndex: "end_machine_operation"
                                        }],
                                        "data-source": [
                                          { machine_operation: "Cutting", operation_parameters: "Cutting Details", end_machine_operation: "Machine-1" },
                                          { machine_operation: "Machine-2", operation_parameters: "Operation-2", end_machine_operation: "Machine-2" }
                                        ],
                                        pagination: false
                                      }, {
                                        bodyCell: withCtx(({ column, text }) => [
                                          column.dataIndex === "machine_operation" ? (openBlock(), createBlock(_component_a_auto_complete, {
                                            key: 0,
                                            placeholder: "Select Machine / Operation",
                                            style: { "width": "100%" },
                                            options: [
                                              { value: "Cutting" },
                                              { value: "Stiching" },
                                              { value: "Printing" },
                                              { value: "Iorning" },
                                              { value: "Packing" }
                                            ]
                                          })) : createCommentVNode("", true),
                                          column.dataIndex === "operation_parameters" ? (openBlock(), createBlock(_component_a_textarea, {
                                            key: 1,
                                            placeholder: "Enter Operation Parameters"
                                          })) : createCommentVNode("", true),
                                          column.dataIndex === "end_machine_operation" ? (openBlock(), createBlock(_component_a_checkbox, {
                                            key: 2,
                                            checked: true
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode("End")
                                            ]),
                                            _: 1
                                          })) : createCommentVNode("", true)
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_button, {
                                        type: "success",
                                        size: "small"
                                      }, {
                                        icon: withCtx(() => [
                                          createVNode(_component_plus_circle_outlined)
                                        ]),
                                        default: withCtx(() => [
                                          createTextVNode(" Add ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_tabs, {
                              activeKey: _ctx.activeKey,
                              "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_tab_pane, {
                                  key: "pc-1",
                                  tab: "Basic Information"
                                }, {
                                  default: withCtx(() => [
                                    createVNode("h4", { class: "t1" }, "Details"),
                                    createVNode(_component_a_row, { gutter: 24 }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 12
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Product Name",
                                              name: "name",
                                              rules: [{ required: true }]
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, { placeholder: "Please enter name" })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 12
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Image",
                                              name: "image"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_upload, {
                                                  "before-upload": _ctx.beforeUpload,
                                                  onRemove: _ctx.handleRemove,
                                                  "max-count": 1
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_button, null, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_upload_outlined),
                                                        createTextVNode(" Select File ")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }, 8, ["before-upload", "onRemove"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 12
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Product Category",
                                              name: "category"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_auto_complete, {
                                                  options: _ctx.categories,
                                                  placeholder: "Select Category"
                                                }, null, 8, ["options"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 12
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Brand",
                                              name: "brand"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_auto_complete, { placeholder: "Select Brand" })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 6
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Barcode Symbology",
                                              name: "sku"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select, null, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_select_option, { value: "CODE128" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("CODE128")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, { value: "CODE39" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("CODE39")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 18
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Barcode",
                                              name: "sku"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, { placeholder: "Enter Barcode" }, {
                                                  addonAfter: withCtx(() => [
                                                    createVNode(_component_a_button, { style: { "width": "100px" } }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_BarcodeOutlined),
                                                        createTextVNode(" Generate ")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 12
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "HSN Code",
                                              name: "hsn"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, { placeholder: "Enter HSN Code" })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 12
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Unit",
                                              name: "unit"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode("h4", { class: "t1" }, "Pricing & Tax"),
                                    createVNode(_component_a_row, { gutter: 24 }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 12
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Sales Price (INR)",
                                              name: "sales_price"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input_number, {
                                                  style: { "width": "100%" },
                                                  placeholder: "Enter sales price"
                                                }, {
                                                  addonAfter: withCtx(() => [
                                                    createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("With Tax")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Without Tax")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 12
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Purchase Price (INR)",
                                              name: "purchase_price"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input_number, {
                                                  style: { "width": "100%" },
                                                  placeholder: "Enter purchase price"
                                                }, {
                                                  addonAfter: withCtx(() => [
                                                    createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("With Tax")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Without Tax")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 12
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Tax Rate",
                                              name: "tax"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select, {
                                                  "show-search": "",
                                                  placeholder: "Tax",
                                                  "default-active-first-option": false
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode("h4", { class: "t1" }, "Description"),
                                    createVNode(_component_a_form_item, {
                                      label: "Description",
                                      name: "description"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_textarea, { placeholder: "Enter Description" })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          "html-type": "submit",
                                          disabled: $data.form.processing
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("SUBMIT")
                                          ]),
                                          _: 1
                                        }, 8, ["disabled"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_tab_pane, {
                                  key: "pc-2",
                                  tab: "Raw Materials (Optional)"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_table, {
                                      columns: [{
                                        title: "Item",
                                        dataIndex: "item",
                                        width: "60%"
                                      }, {
                                        title: "Unit",
                                        dataIndex: "unit"
                                      }, {
                                        title: "Yield",
                                        dataIndex: "yield"
                                      }],
                                      "data-source": [{ item: "Item-1", unit: "Pcs", yield: "1" }],
                                      pagination: false
                                    }, {
                                      bodyCell: withCtx(({ column, text }) => [
                                        column.dataIndex === "item" ? (openBlock(), createBlock(_component_a_auto_complete, {
                                          key: 0,
                                          placeholder: "Select Item",
                                          style: { "width": "100%" }
                                        })) : createCommentVNode("", true),
                                        column.dataIndex === "unit" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                                          createTextVNode(" Pcs ")
                                        ], 64)) : createCommentVNode("", true),
                                        column.dataIndex === "yield" ? (openBlock(), createBlock(_component_a_input_number, {
                                          key: 2,
                                          style: { "width": "100%" },
                                          placeholder: "Enter yield"
                                        })) : createCommentVNode("", true)
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_button, {
                                      type: "success",
                                      size: "small"
                                    }, {
                                      icon: withCtx(() => [
                                        createVNode(_component_plus_circle_outlined)
                                      ]),
                                      default: withCtx(() => [
                                        createTextVNode(" Add ")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_tab_pane, {
                                  key: "pc-3",
                                  tab: "Operations (Optional)"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_table, {
                                      columns: [{
                                        title: "Machine/Operation",
                                        dataIndex: "machine_operation",
                                        width: "60%"
                                      }, {
                                        title: "Operation Parameters",
                                        dataIndex: "operation_parameters"
                                      }, {
                                        title: "End Machine/Operation",
                                        dataIndex: "end_machine_operation"
                                      }],
                                      "data-source": [
                                        { machine_operation: "Cutting", operation_parameters: "Cutting Details", end_machine_operation: "Machine-1" },
                                        { machine_operation: "Machine-2", operation_parameters: "Operation-2", end_machine_operation: "Machine-2" }
                                      ],
                                      pagination: false
                                    }, {
                                      bodyCell: withCtx(({ column, text }) => [
                                        column.dataIndex === "machine_operation" ? (openBlock(), createBlock(_component_a_auto_complete, {
                                          key: 0,
                                          placeholder: "Select Machine / Operation",
                                          style: { "width": "100%" },
                                          options: [
                                            { value: "Cutting" },
                                            { value: "Stiching" },
                                            { value: "Printing" },
                                            { value: "Iorning" },
                                            { value: "Packing" }
                                          ]
                                        })) : createCommentVNode("", true),
                                        column.dataIndex === "operation_parameters" ? (openBlock(), createBlock(_component_a_textarea, {
                                          key: 1,
                                          placeholder: "Enter Operation Parameters"
                                        })) : createCommentVNode("", true),
                                        column.dataIndex === "end_machine_operation" ? (openBlock(), createBlock(_component_a_checkbox, {
                                          key: 2,
                                          checked: true
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("End")
                                          ]),
                                          _: 1
                                        })) : createCommentVNode("", true)
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_button, {
                                      type: "success",
                                      size: "small"
                                    }, {
                                      icon: withCtx(() => [
                                        createVNode(_component_plus_circle_outlined)
                                      ]),
                                      default: withCtx(() => [
                                        createTextVNode(" Add ")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["activeKey", "onUpdate:activeKey"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, mergeProps({ model: $data.form }, $data.layout, {
                        name: "nest-messages",
                        "validate-messages": _ctx.validateMessages,
                        onFinish: _ctx.submit,
                        "label-col": { span: 24 }
                      }), {
                        default: withCtx(() => [
                          createVNode(_component_a_tabs, {
                            activeKey: _ctx.activeKey,
                            "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_tab_pane, {
                                key: "pc-1",
                                tab: "Basic Information"
                              }, {
                                default: withCtx(() => [
                                  createVNode("h4", { class: "t1" }, "Details"),
                                  createVNode(_component_a_row, { gutter: 24 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 12
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Product Name",
                                            name: "name",
                                            rules: [{ required: true }]
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, { placeholder: "Please enter name" })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 12
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Image",
                                            name: "image"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_upload, {
                                                "before-upload": _ctx.beforeUpload,
                                                onRemove: _ctx.handleRemove,
                                                "max-count": 1
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_button, null, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_upload_outlined),
                                                      createTextVNode(" Select File ")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }, 8, ["before-upload", "onRemove"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 12
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Product Category",
                                            name: "category"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_auto_complete, {
                                                options: _ctx.categories,
                                                placeholder: "Select Category"
                                              }, null, 8, ["options"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 12
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Brand",
                                            name: "brand"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_auto_complete, { placeholder: "Select Brand" })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 6
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Barcode Symbology",
                                            name: "sku"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select, null, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select_option, { value: "CODE128" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("CODE128")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, { value: "CODE39" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("CODE39")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 18
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Barcode",
                                            name: "sku"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, { placeholder: "Enter Barcode" }, {
                                                addonAfter: withCtx(() => [
                                                  createVNode(_component_a_button, { style: { "width": "100px" } }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_BarcodeOutlined),
                                                      createTextVNode(" Generate ")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 12
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "HSN Code",
                                            name: "hsn"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, { placeholder: "Enter HSN Code" })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 12
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Unit",
                                            name: "unit"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode("h4", { class: "t1" }, "Pricing & Tax"),
                                  createVNode(_component_a_row, { gutter: 24 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 12
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Sales Price (INR)",
                                            name: "sales_price"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input_number, {
                                                style: { "width": "100%" },
                                                placeholder: "Enter sales price"
                                              }, {
                                                addonAfter: withCtx(() => [
                                                  createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("With Tax")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Without Tax")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 12
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Purchase Price (INR)",
                                            name: "purchase_price"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input_number, {
                                                style: { "width": "100%" },
                                                placeholder: "Enter purchase price"
                                              }, {
                                                addonAfter: withCtx(() => [
                                                  createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("With Tax")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Without Tax")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 12
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Tax Rate",
                                            name: "tax"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select, {
                                                "show-search": "",
                                                placeholder: "Tax",
                                                "default-active-first-option": false
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode("h4", { class: "t1" }, "Description"),
                                  createVNode(_component_a_form_item, {
                                    label: "Description",
                                    name: "description"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_textarea, { placeholder: "Enter Description" })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit",
                                        disabled: $data.form.processing
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("SUBMIT")
                                        ]),
                                        _: 1
                                      }, 8, ["disabled"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_tab_pane, {
                                key: "pc-2",
                                tab: "Raw Materials (Optional)"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_table, {
                                    columns: [{
                                      title: "Item",
                                      dataIndex: "item",
                                      width: "60%"
                                    }, {
                                      title: "Unit",
                                      dataIndex: "unit"
                                    }, {
                                      title: "Yield",
                                      dataIndex: "yield"
                                    }],
                                    "data-source": [{ item: "Item-1", unit: "Pcs", yield: "1" }],
                                    pagination: false
                                  }, {
                                    bodyCell: withCtx(({ column, text }) => [
                                      column.dataIndex === "item" ? (openBlock(), createBlock(_component_a_auto_complete, {
                                        key: 0,
                                        placeholder: "Select Item",
                                        style: { "width": "100%" }
                                      })) : createCommentVNode("", true),
                                      column.dataIndex === "unit" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                                        createTextVNode(" Pcs ")
                                      ], 64)) : createCommentVNode("", true),
                                      column.dataIndex === "yield" ? (openBlock(), createBlock(_component_a_input_number, {
                                        key: 2,
                                        style: { "width": "100%" },
                                        placeholder: "Enter yield"
                                      })) : createCommentVNode("", true)
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_button, {
                                    type: "success",
                                    size: "small"
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Add ")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_tab_pane, {
                                key: "pc-3",
                                tab: "Operations (Optional)"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_table, {
                                    columns: [{
                                      title: "Machine/Operation",
                                      dataIndex: "machine_operation",
                                      width: "60%"
                                    }, {
                                      title: "Operation Parameters",
                                      dataIndex: "operation_parameters"
                                    }, {
                                      title: "End Machine/Operation",
                                      dataIndex: "end_machine_operation"
                                    }],
                                    "data-source": [
                                      { machine_operation: "Cutting", operation_parameters: "Cutting Details", end_machine_operation: "Machine-1" },
                                      { machine_operation: "Machine-2", operation_parameters: "Operation-2", end_machine_operation: "Machine-2" }
                                    ],
                                    pagination: false
                                  }, {
                                    bodyCell: withCtx(({ column, text }) => [
                                      column.dataIndex === "machine_operation" ? (openBlock(), createBlock(_component_a_auto_complete, {
                                        key: 0,
                                        placeholder: "Select Machine / Operation",
                                        style: { "width": "100%" },
                                        options: [
                                          { value: "Cutting" },
                                          { value: "Stiching" },
                                          { value: "Printing" },
                                          { value: "Iorning" },
                                          { value: "Packing" }
                                        ]
                                      })) : createCommentVNode("", true),
                                      column.dataIndex === "operation_parameters" ? (openBlock(), createBlock(_component_a_textarea, {
                                        key: 1,
                                        placeholder: "Enter Operation Parameters"
                                      })) : createCommentVNode("", true),
                                      column.dataIndex === "end_machine_operation" ? (openBlock(), createBlock(_component_a_checkbox, {
                                        key: 2,
                                        checked: true
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("End")
                                        ]),
                                        _: 1
                                      })) : createCommentVNode("", true)
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_button, {
                                    type: "success",
                                    size: "small"
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Add ")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["activeKey", "onUpdate:activeKey"])
                        ]),
                        _: 1
                      }, 16, ["model", "validate-messages", "onFinish"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_drawer, {
                visible: $data.showdetail,
                "onUpdate:visible": ($event) => $data.showdetail = $event,
                class: "custom-class",
                title: "Product 1",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                extra: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_space, null, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Edit`);
                              } else {
                                return [
                                  createTextVNode("Edit")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_button, {
                            type: "primary",
                            onClick: _ctx.onClose
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Delete`);
                              } else {
                                return [
                                  createTextVNode("Delete")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                              default: withCtx(() => [
                                createTextVNode("Edit")
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(_component_a_button, {
                              type: "primary",
                              onClick: _ctx.onClose
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Delete")
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_space, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx(() => [
                              createTextVNode("Edit")
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(_component_a_button, {
                            type: "primary",
                            onClick: _ctx.onClose
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Delete")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_tabs, {
                      activeKey: _ctx.activeKey,
                      "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_tab_pane, {
                            key: "Overview",
                            tab: "Overview"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_descriptions, { size: _ctx.size }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_descriptions_item, {
                                        label: "Product Name",
                                        span: 4
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`Product 1`);
                                          } else {
                                            return [
                                              createTextVNode("Product 1")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_descriptions_item, { label: "Description" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget`);
                                          } else {
                                            return [
                                              createTextVNode("Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_descriptions_item, {
                                          label: "Product Name",
                                          span: 4
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("Product 1")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, { label: "Description" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_descriptions, { size: _ctx.size }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_descriptions_item, {
                                        label: "Product Name",
                                        span: 4
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Product 1")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, { label: "Description" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["size"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_tab_pane, {
                            key: "Transactions",
                            tab: "Transactions",
                            "force-render": ""
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_space, null, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_select, {
                                        ref: "select",
                                        placeholder: "Filter By"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "jack" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Invoice`);
                                                } else {
                                                  return [
                                                    createTextVNode("Invoice")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "lucy" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Sales Order`);
                                                } else {
                                                  return [
                                                    createTextVNode("Sales Order")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "disabled" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Quote`);
                                                } else {
                                                  return [
                                                    createTextVNode("Quote")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Yiminghe" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Purchase Order`);
                                                } else {
                                                  return [
                                                    createTextVNode("Purchase Order")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select_option, { value: "jack" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Invoice")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "lucy" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Sales Order")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "disabled" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Quote")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Purchase Order")
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_select, {
                                        ref: "select",
                                        placeholder: "Status"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "jack" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`All`);
                                                } else {
                                                  return [
                                                    createTextVNode("All")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "lucy" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Draft`);
                                                } else {
                                                  return [
                                                    createTextVNode("Draft")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select_option, { value: "jack" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("All")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "lucy" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Draft")
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_select, {
                                          ref: "select",
                                          placeholder: "Filter By"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "jack" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Invoice")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "lucy" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Sales Order")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "disabled" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Quote")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Purchase Order")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 512),
                                        createVNode(_component_a_select, {
                                          ref: "select",
                                          placeholder: "Status"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "jack" }, {
                                              default: withCtx(() => [
                                                createTextVNode("All")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "lucy" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Draft")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 512)
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_table, {
                                  columns: $setup.invoicetransactions_column,
                                  "data-source": $setup.invoicetransactions
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_space, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        ref: "select",
                                        placeholder: "Filter By"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "jack" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Invoice")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "lucy" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Sales Order")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "disabled" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Quote")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Purchase Order")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 512),
                                      createVNode(_component_a_select, {
                                        ref: "select",
                                        placeholder: "Status"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "jack" }, {
                                            default: withCtx(() => [
                                              createTextVNode("All")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "lucy" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Draft")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 512)
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_table, {
                                    columns: $setup.invoicetransactions_column,
                                    "data-source": $setup.invoicetransactions
                                  }, null, 8, ["columns", "data-source"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_tab_pane, {
                              key: "Overview",
                              tab: "Overview"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_descriptions, { size: _ctx.size }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_descriptions_item, {
                                      label: "Product Name",
                                      span: 4
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Product 1")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_descriptions_item, { label: "Description" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["size"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_tab_pane, {
                              key: "Transactions",
                              tab: "Transactions",
                              "force-render": ""
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_space, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      ref: "select",
                                      placeholder: "Filter By"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, { value: "jack" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Invoice")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "lucy" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Sales Order")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "disabled" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Quote")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Purchase Order")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 512),
                                    createVNode(_component_a_select, {
                                      ref: "select",
                                      placeholder: "Status"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, { value: "jack" }, {
                                          default: withCtx(() => [
                                            createTextVNode("All")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "lucy" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Draft")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 512)
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_table, {
                                  columns: $setup.invoicetransactions_column,
                                  "data-source": $setup.invoicetransactions
                                }, null, 8, ["columns", "data-source"])
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_tabs, {
                        activeKey: _ctx.activeKey,
                        "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_tab_pane, {
                            key: "Overview",
                            tab: "Overview"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_descriptions, { size: _ctx.size }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_descriptions_item, {
                                    label: "Product Name",
                                    span: 4
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Product 1")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_descriptions_item, { label: "Description" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["size"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_tab_pane, {
                            key: "Transactions",
                            tab: "Transactions",
                            "force-render": ""
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_space, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    ref: "select",
                                    placeholder: "Filter By"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, { value: "jack" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Invoice")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "lucy" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Sales Order")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "disabled" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Quote")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Purchase Order")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 512),
                                  createVNode(_component_a_select, {
                                    ref: "select",
                                    placeholder: "Status"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, { value: "jack" }, {
                                        default: withCtx(() => [
                                          createTextVNode("All")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "lucy" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Draft")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 512)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_table, {
                                columns: $setup.invoicetransactions_column,
                                "data-source": $setup.invoicetransactions
                              }, null, 8, ["columns", "data-source"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["activeKey", "onUpdate:activeKey"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_space, {
                  direction: "vertical",
                  style: { width: "100%" }
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, {
                      name: "nest-messages",
                      model: $data.searchform,
                      layout: "inline",
                      onFinish: _ctx.search
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, {
                              placeholder: "Search by product name",
                              "allow-clear": true,
                              value: $data.searchform.term,
                              "onUpdate:value": ($event) => $data.searchform.term = $event
                            }, null, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_select, { placeholder: "Search by Category" })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_select, { placeholder: "Search by Brand" })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Search ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              shape: "round",
                              onClick: $options.showDrawer
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_plus_circle_outlined)
                              ]),
                              default: withCtx(() => [
                                createTextVNode(" Add New Product ")
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              shape: "round",
                              onClick: $options.showDrawer
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_CloudUploadOutlined)
                              ]),
                              default: withCtx(() => [
                                createTextVNode(" Import ")
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["model", "onFinish"]),
                    createVNode(_component_a_table, {
                      columns: $setup.columns,
                      "data-source": $setup.items
                    }, {
                      bodyCell: withCtx(({ column, record }) => [
                        column.key === "image" ? (openBlock(), createBlock(_component_a_image, {
                          key: 0,
                          width: 30,
                          height: 30,
                          src: record.image,
                          fallback: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMIAAADDCAYAAADQvc6UAAABRWlDQ1BJQ0MgUHJvZmlsZQAAKJFjYGASSSwoyGFhYGDIzSspCnJ3UoiIjFJgf8LAwSDCIMogwMCcmFxc4BgQ4ANUwgCjUcG3awyMIPqyLsis7PPOq3QdDFcvjV3jOD1boQVTPQrgSkktTgbSf4A4LbmgqISBgTEFyFYuLykAsTuAbJEioKOA7DkgdjqEvQHEToKwj4DVhAQ5A9k3gGyB5IxEoBmML4BsnSQk8XQkNtReEOBxcfXxUQg1Mjc0dyHgXNJBSWpFCYh2zi+oLMpMzyhRcASGUqqCZ16yno6CkYGRAQMDKMwhqj/fAIcloxgHQqxAjIHBEugw5sUIsSQpBobtQPdLciLEVJYzMPBHMDBsayhILEqEO4DxG0txmrERhM29nYGBddr//5/DGRjYNRkY/l7////39v///y4Dmn+LgeHANwDrkl1AuO+pmgAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAwqADAAQAAAABAAAAwwAAAAD9b/HnAAAHlklEQVR4Ae3dP3PTWBSGcbGzM6GCKqlIBRV0dHRJFarQ0eUT8LH4BnRU0NHR0UEFVdIlFRV7TzRksomPY8uykTk/zewQfKw/9znv4yvJynLv4uLiV2dBoDiBf4qP3/ARuCRABEFAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghgg0Aj8i0JO4OzsrPv69Wv+hi2qPHr0qNvf39+iI97soRIh4f3z58/u7du3SXX7Xt7Z2enevHmzfQe+oSN2apSAPj09TSrb+XKI/f379+08+A0cNRE2ANkupk+ACNPvkSPcAAEibACyXUyfABGm3yNHuAECRNgAZLuYPgEirKlHu7u7XdyytGwHAd8jjNyng4OD7vnz51dbPT8/7z58+NB9+/bt6jU/TI+AGWHEnrx48eJ/EsSmHzx40L18+fLyzxF3ZVMjEyDCiEDjMYZZS5wiPXnyZFbJaxMhQIQRGzHvWR7XCyOCXsOmiDAi1HmPMMQjDpbpEiDCiL358eNHurW/5SnWdIBbXiDCiA38/Pnzrce2YyZ4//59F3ePLNMl4PbpiL2J0L979+7yDtHDhw8vtzzvdGnEXdvUigSIsCLAWavHp/+qM0BcXMd/q25n1vF57TYBp0a3mUzilePj4+7k5KSLb6gt6ydAhPUzXnoPR0dHl79WGTNCfBnn1uvSCJdegQhLI1vvCk+fPu2ePXt2tZOYEV6/fn31dz+shwAR1sP1cqvLntbEN9MxA9xcYjsxS1jWR4AIa2Ibzx0tc44fYX/16lV6NDFLXH+YL32jwiACRBiEbf5KcXoTIsQSpzXx4N28Ja4BQoK7rgXiydbHjx/P25TaQAJEGAguWy0+2Q8PD6/Ki4R8EVl+bzBOnZY95fq9rj9zAkTI2SxdidBHqG9+skdw43borCXO/ZcJdraPWdv22uIEiLA4q7nvvCug8WTqzQveOH26fodo7g6uFe/a17W3+nFBAkRYENRdb1vkkz1CH9cPsVy/jrhr27PqMYvENYNlHAIesRiBYwRy0V+8iXP8+/fvX11Mr7L7ECueb/r48eMqm7FuI2BGWDEG8cm+7G3NEOfmdcTQw4h9/55lhm7DekRYKQPZF2ArbXTAyu4kDYB2YxUzwg0gi/41ztHnfQG26HbGel/crVrm7tNY+/1btkOEAZ2M05r4FB7r9GbAIdxaZYrHdOsgJ/wCEQY0J74TmOKnbxxT9n3FgGGWWsVdowHtjt9Nnvf7yQM2aZU/TIAIAxrw6dOnAWtZZcoEnBpNuTuObWMEiLAx1HY0ZQJEmHJ3HNvGCBBhY6jtaMoEiJB0Z29vL6ls58vxPcO8/zfrdo5qvKO+d3Fx8Wu8zf1dW4p/cPzLly/dtv9Ts/EbcvGAHhHyfBIhZ6NSiIBTo0LNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiEC/wGgKKC4YMA4TAAAAABJRU5ErkJggg=="
                        }, null, 8, ["src"])) : createCommentVNode("", true),
                        column.key === "name" ? (openBlock(), createBlock("a", {
                          key: 1,
                          href: "javascript:;",
                          onClick: $options.showViewDrawer
                        }, toDisplayString(record.name), 9, ["onClick"])) : createCommentVNode("", true),
                        column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 2 }, {
                          overlay: withCtx(() => [
                            createVNode(_component_a_menu, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, null, {
                                  default: withCtx(() => [
                                    createVNode("a", { href: "javascript:;" }, [
                                      createVNode(_component_edit_outlined),
                                      createTextVNode(" Edit ")
                                    ])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_menu_item, null, {
                                  default: withCtx(() => [
                                    createVNode("a", { href: "javascript:;" }, [
                                      createVNode(_component_delete_outlined),
                                      createTextVNode(" Delete ")
                                    ])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              size: _ctx.size,
                              class: "ant-dropdown-link",
                              shape: "circle"
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_DownCircleOutlined)
                              ]),
                              _: 1
                            }, 8, ["size"])
                          ]),
                          _: 1
                        })) : createCommentVNode("", true)
                      ]),
                      _: 1
                    }, 8, ["columns", "data-source"])
                  ]),
                  _: 1
                }),
                createVNode(_component_a_drawer, {
                  visible: $data.createvisible,
                  "onUpdate:visible": ($event) => $data.createvisible = $event,
                  class: "custom-class",
                  title: "New Product",
                  size: "large",
                  placement: "right",
                  onAfterVisibleChange: _ctx.afterVisibleChange
                }, {
                  extra: withCtx(() => [
                    createVNode(_component_a_space, null, {
                      default: withCtx(() => [
                        createVNode(_component_a_button, {
                          type: "primary",
                          onClick: _ctx.onClose
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Save")
                          ]),
                          _: 1
                        }, 8, ["onClick"])
                      ]),
                      _: 1
                    })
                  ]),
                  default: withCtx(() => [
                    createVNode(_component_a_form, mergeProps({ model: $data.form }, $data.layout, {
                      name: "nest-messages",
                      "validate-messages": _ctx.validateMessages,
                      onFinish: _ctx.submit,
                      "label-col": { span: 24 }
                    }), {
                      default: withCtx(() => [
                        createVNode(_component_a_tabs, {
                          activeKey: _ctx.activeKey,
                          "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_tab_pane, {
                              key: "pc-1",
                              tab: "Basic Information"
                            }, {
                              default: withCtx(() => [
                                createVNode("h4", { class: "t1" }, "Details"),
                                createVNode(_component_a_row, { gutter: 24 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 12
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Product Name",
                                          name: "name",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Please enter name" })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 12
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Image",
                                          name: "image"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_upload, {
                                              "before-upload": _ctx.beforeUpload,
                                              onRemove: _ctx.handleRemove,
                                              "max-count": 1
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_button, null, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_upload_outlined),
                                                    createTextVNode(" Select File ")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }, 8, ["before-upload", "onRemove"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 12
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Product Category",
                                          name: "category"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_auto_complete, {
                                              options: _ctx.categories,
                                              placeholder: "Select Category"
                                            }, null, 8, ["options"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 12
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Brand",
                                          name: "brand"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_auto_complete, { placeholder: "Select Brand" })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 6
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Barcode Symbology",
                                          name: "sku"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, null, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select_option, { value: "CODE128" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("CODE128")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_select_option, { value: "CODE39" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("CODE39")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 18
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Barcode",
                                          name: "sku"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Enter Barcode" }, {
                                              addonAfter: withCtx(() => [
                                                createVNode(_component_a_button, { style: { "width": "100px" } }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_BarcodeOutlined),
                                                    createTextVNode(" Generate ")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 12
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "HSN Code",
                                          name: "hsn"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Enter HSN Code" })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 12
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Unit",
                                          name: "unit"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode("h4", { class: "t1" }, "Pricing & Tax"),
                                createVNode(_component_a_row, { gutter: 24 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 12
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Sales Price (INR)",
                                          name: "sales_price"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input_number, {
                                              style: { "width": "100%" },
                                              placeholder: "Enter sales price"
                                            }, {
                                              addonAfter: withCtx(() => [
                                                createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("With Tax")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Without Tax")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 12
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Purchase Price (INR)",
                                          name: "purchase_price"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input_number, {
                                              style: { "width": "100%" },
                                              placeholder: "Enter purchase price"
                                            }, {
                                              addonAfter: withCtx(() => [
                                                createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("With Tax")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Without Tax")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 12
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Tax Rate",
                                          name: "tax"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              "show-search": "",
                                              placeholder: "Tax",
                                              "default-active-first-option": false
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode("h4", { class: "t1" }, "Description"),
                                createVNode(_component_a_form_item, {
                                  label: "Description",
                                  name: "description"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_textarea, { placeholder: "Enter Description" })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      "html-type": "submit",
                                      disabled: $data.form.processing
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("SUBMIT")
                                      ]),
                                      _: 1
                                    }, 8, ["disabled"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_tab_pane, {
                              key: "pc-2",
                              tab: "Raw Materials (Optional)"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_table, {
                                  columns: [{
                                    title: "Item",
                                    dataIndex: "item",
                                    width: "60%"
                                  }, {
                                    title: "Unit",
                                    dataIndex: "unit"
                                  }, {
                                    title: "Yield",
                                    dataIndex: "yield"
                                  }],
                                  "data-source": [{ item: "Item-1", unit: "Pcs", yield: "1" }],
                                  pagination: false
                                }, {
                                  bodyCell: withCtx(({ column, text }) => [
                                    column.dataIndex === "item" ? (openBlock(), createBlock(_component_a_auto_complete, {
                                      key: 0,
                                      placeholder: "Select Item",
                                      style: { "width": "100%" }
                                    })) : createCommentVNode("", true),
                                    column.dataIndex === "unit" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                                      createTextVNode(" Pcs ")
                                    ], 64)) : createCommentVNode("", true),
                                    column.dataIndex === "yield" ? (openBlock(), createBlock(_component_a_input_number, {
                                      key: 2,
                                      style: { "width": "100%" },
                                      placeholder: "Enter yield"
                                    })) : createCommentVNode("", true)
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_button, {
                                  type: "success",
                                  size: "small"
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Add ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_tab_pane, {
                              key: "pc-3",
                              tab: "Operations (Optional)"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_table, {
                                  columns: [{
                                    title: "Machine/Operation",
                                    dataIndex: "machine_operation",
                                    width: "60%"
                                  }, {
                                    title: "Operation Parameters",
                                    dataIndex: "operation_parameters"
                                  }, {
                                    title: "End Machine/Operation",
                                    dataIndex: "end_machine_operation"
                                  }],
                                  "data-source": [
                                    { machine_operation: "Cutting", operation_parameters: "Cutting Details", end_machine_operation: "Machine-1" },
                                    { machine_operation: "Machine-2", operation_parameters: "Operation-2", end_machine_operation: "Machine-2" }
                                  ],
                                  pagination: false
                                }, {
                                  bodyCell: withCtx(({ column, text }) => [
                                    column.dataIndex === "machine_operation" ? (openBlock(), createBlock(_component_a_auto_complete, {
                                      key: 0,
                                      placeholder: "Select Machine / Operation",
                                      style: { "width": "100%" },
                                      options: [
                                        { value: "Cutting" },
                                        { value: "Stiching" },
                                        { value: "Printing" },
                                        { value: "Iorning" },
                                        { value: "Packing" }
                                      ]
                                    })) : createCommentVNode("", true),
                                    column.dataIndex === "operation_parameters" ? (openBlock(), createBlock(_component_a_textarea, {
                                      key: 1,
                                      placeholder: "Enter Operation Parameters"
                                    })) : createCommentVNode("", true),
                                    column.dataIndex === "end_machine_operation" ? (openBlock(), createBlock(_component_a_checkbox, {
                                      key: 2,
                                      checked: true
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("End")
                                      ]),
                                      _: 1
                                    })) : createCommentVNode("", true)
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_button, {
                                  type: "success",
                                  size: "small"
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Add ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 8, ["activeKey", "onUpdate:activeKey"])
                      ]),
                      _: 1
                    }, 16, ["model", "validate-messages", "onFinish"])
                  ]),
                  _: 1
                }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"]),
                createVNode(_component_a_drawer, {
                  visible: $data.showdetail,
                  "onUpdate:visible": ($event) => $data.showdetail = $event,
                  class: "custom-class",
                  title: "Product 1",
                  size: "large",
                  placement: "right",
                  onAfterVisibleChange: _ctx.afterVisibleChange
                }, {
                  extra: withCtx(() => [
                    createVNode(_component_a_space, null, {
                      default: withCtx(() => [
                        createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                          default: withCtx(() => [
                            createTextVNode("Edit")
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_component_a_button, {
                          type: "primary",
                          onClick: _ctx.onClose
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Delete")
                          ]),
                          _: 1
                        }, 8, ["onClick"])
                      ]),
                      _: 1
                    })
                  ]),
                  default: withCtx(() => [
                    createVNode(_component_a_tabs, {
                      activeKey: _ctx.activeKey,
                      "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_tab_pane, {
                          key: "Overview",
                          tab: "Overview"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_descriptions, { size: _ctx.size }, {
                              default: withCtx(() => [
                                createVNode(_component_a_descriptions_item, {
                                  label: "Product Name",
                                  span: 4
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Product 1")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_descriptions_item, { label: "Description" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["size"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_tab_pane, {
                          key: "Transactions",
                          tab: "Transactions",
                          "force-render": ""
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_space, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_select, {
                                  ref: "select",
                                  placeholder: "Filter By"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select_option, { value: "jack" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Invoice")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "lucy" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Sales Order")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "disabled" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Quote")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Purchase Order")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 512),
                                createVNode(_component_a_select, {
                                  ref: "select",
                                  placeholder: "Status"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select_option, { value: "jack" }, {
                                      default: withCtx(() => [
                                        createTextVNode("All")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "lucy" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Draft")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 512)
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_table, {
                              columns: $setup.invoicetransactions_column,
                              "data-source": $setup.invoicetransactions
                            }, null, 8, ["columns", "data-source"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["activeKey", "onUpdate:activeKey"])
                  ]),
                  _: 1
                }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_layout_content, null, {
            default: withCtx(() => [
              createVNode(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, {
                    name: "nest-messages",
                    model: $data.searchform,
                    layout: "inline",
                    onFinish: _ctx.search
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            placeholder: "Search by product name",
                            "allow-clear": true,
                            value: $data.searchform.term,
                            "onUpdate:value": ($event) => $data.searchform.term = $event
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_select, { placeholder: "Search by Category" })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_select, { placeholder: "Search by Brand" })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Search ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            shape: "round",
                            onClick: $options.showDrawer
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_plus_circle_outlined)
                            ]),
                            default: withCtx(() => [
                              createTextVNode(" Add New Product ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            shape: "round",
                            onClick: $options.showDrawer
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_CloudUploadOutlined)
                            ]),
                            default: withCtx(() => [
                              createTextVNode(" Import ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["model", "onFinish"]),
                  createVNode(_component_a_table, {
                    columns: $setup.columns,
                    "data-source": $setup.items
                  }, {
                    bodyCell: withCtx(({ column, record }) => [
                      column.key === "image" ? (openBlock(), createBlock(_component_a_image, {
                        key: 0,
                        width: 30,
                        height: 30,
                        src: record.image,
                        fallback: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMIAAADDCAYAAADQvc6UAAABRWlDQ1BJQ0MgUHJvZmlsZQAAKJFjYGASSSwoyGFhYGDIzSspCnJ3UoiIjFJgf8LAwSDCIMogwMCcmFxc4BgQ4ANUwgCjUcG3awyMIPqyLsis7PPOq3QdDFcvjV3jOD1boQVTPQrgSkktTgbSf4A4LbmgqISBgTEFyFYuLykAsTuAbJEioKOA7DkgdjqEvQHEToKwj4DVhAQ5A9k3gGyB5IxEoBmML4BsnSQk8XQkNtReEOBxcfXxUQg1Mjc0dyHgXNJBSWpFCYh2zi+oLMpMzyhRcASGUqqCZ16yno6CkYGRAQMDKMwhqj/fAIcloxgHQqxAjIHBEugw5sUIsSQpBobtQPdLciLEVJYzMPBHMDBsayhILEqEO4DxG0txmrERhM29nYGBddr//5/DGRjYNRkY/l7////39v///y4Dmn+LgeHANwDrkl1AuO+pmgAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAwqADAAQAAAABAAAAwwAAAAD9b/HnAAAHlklEQVR4Ae3dP3PTWBSGcbGzM6GCKqlIBRV0dHRJFarQ0eUT8LH4BnRU0NHR0UEFVdIlFRV7TzRksomPY8uykTk/zewQfKw/9znv4yvJynLv4uLiV2dBoDiBf4qP3/ARuCRABEFAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghgg0Aj8i0JO4OzsrPv69Wv+hi2qPHr0qNvf39+iI97soRIh4f3z58/u7du3SXX7Xt7Z2enevHmzfQe+oSN2apSAPj09TSrb+XKI/f379+08+A0cNRE2ANkupk+ACNPvkSPcAAEibACyXUyfABGm3yNHuAECRNgAZLuYPgEirKlHu7u7XdyytGwHAd8jjNyng4OD7vnz51dbPT8/7z58+NB9+/bt6jU/TI+AGWHEnrx48eJ/EsSmHzx40L18+fLyzxF3ZVMjEyDCiEDjMYZZS5wiPXnyZFbJaxMhQIQRGzHvWR7XCyOCXsOmiDAi1HmPMMQjDpbpEiDCiL358eNHurW/5SnWdIBbXiDCiA38/Pnzrce2YyZ4//59F3ePLNMl4PbpiL2J0L979+7yDtHDhw8vtzzvdGnEXdvUigSIsCLAWavHp/+qM0BcXMd/q25n1vF57TYBp0a3mUzilePj4+7k5KSLb6gt6ydAhPUzXnoPR0dHl79WGTNCfBnn1uvSCJdegQhLI1vvCk+fPu2ePXt2tZOYEV6/fn31dz+shwAR1sP1cqvLntbEN9MxA9xcYjsxS1jWR4AIa2Ibzx0tc44fYX/16lV6NDFLXH+YL32jwiACRBiEbf5KcXoTIsQSpzXx4N28Ja4BQoK7rgXiydbHjx/P25TaQAJEGAguWy0+2Q8PD6/Ki4R8EVl+bzBOnZY95fq9rj9zAkTI2SxdidBHqG9+skdw43borCXO/ZcJdraPWdv22uIEiLA4q7nvvCug8WTqzQveOH26fodo7g6uFe/a17W3+nFBAkRYENRdb1vkkz1CH9cPsVy/jrhr27PqMYvENYNlHAIesRiBYwRy0V+8iXP8+/fvX11Mr7L7ECueb/r48eMqm7FuI2BGWDEG8cm+7G3NEOfmdcTQw4h9/55lhm7DekRYKQPZF2ArbXTAyu4kDYB2YxUzwg0gi/41ztHnfQG26HbGel/crVrm7tNY+/1btkOEAZ2M05r4FB7r9GbAIdxaZYrHdOsgJ/wCEQY0J74TmOKnbxxT9n3FgGGWWsVdowHtjt9Nnvf7yQM2aZU/TIAIAxrw6dOnAWtZZcoEnBpNuTuObWMEiLAx1HY0ZQJEmHJ3HNvGCBBhY6jtaMoEiJB0Z29vL6ls58vxPcO8/zfrdo5qvKO+d3Fx8Wu8zf1dW4p/cPzLly/dtv9Ts/EbcvGAHhHyfBIhZ6NSiIBTo0LNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiEC/wGgKKC4YMA4TAAAAABJRU5ErkJggg=="
                      }, null, 8, ["src"])) : createCommentVNode("", true),
                      column.key === "name" ? (openBlock(), createBlock("a", {
                        key: 1,
                        href: "javascript:;",
                        onClick: $options.showViewDrawer
                      }, toDisplayString(record.name), 9, ["onClick"])) : createCommentVNode("", true),
                      column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 2 }, {
                        overlay: withCtx(() => [
                          createVNode(_component_a_menu, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, null, {
                                default: withCtx(() => [
                                  createVNode("a", { href: "javascript:;" }, [
                                    createVNode(_component_edit_outlined),
                                    createTextVNode(" Edit ")
                                  ])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_menu_item, null, {
                                default: withCtx(() => [
                                  createVNode("a", { href: "javascript:;" }, [
                                    createVNode(_component_delete_outlined),
                                    createTextVNode(" Delete ")
                                  ])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            size: _ctx.size,
                            class: "ant-dropdown-link",
                            shape: "circle"
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_DownCircleOutlined)
                            ]),
                            _: 1
                          }, 8, ["size"])
                        ]),
                        _: 1
                      })) : createCommentVNode("", true)
                    ]),
                    _: 1
                  }, 8, ["columns", "data-source"])
                ]),
                _: 1
              }),
              createVNode(_component_a_drawer, {
                visible: $data.createvisible,
                "onUpdate:visible": ($event) => $data.createvisible = $event,
                class: "custom-class",
                title: "New Product",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                extra: withCtx(() => [
                  createVNode(_component_a_space, null, {
                    default: withCtx(() => [
                      createVNode(_component_a_button, {
                        type: "primary",
                        onClick: _ctx.onClose
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Save")
                        ]),
                        _: 1
                      }, 8, ["onClick"])
                    ]),
                    _: 1
                  })
                ]),
                default: withCtx(() => [
                  createVNode(_component_a_form, mergeProps({ model: $data.form }, $data.layout, {
                    name: "nest-messages",
                    "validate-messages": _ctx.validateMessages,
                    onFinish: _ctx.submit,
                    "label-col": { span: 24 }
                  }), {
                    default: withCtx(() => [
                      createVNode(_component_a_tabs, {
                        activeKey: _ctx.activeKey,
                        "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_tab_pane, {
                            key: "pc-1",
                            tab: "Basic Information"
                          }, {
                            default: withCtx(() => [
                              createVNode("h4", { class: "t1" }, "Details"),
                              createVNode(_component_a_row, { gutter: 24 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Product Name",
                                        name: "name",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Please enter name" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Image",
                                        name: "image"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_upload, {
                                            "before-upload": _ctx.beforeUpload,
                                            onRemove: _ctx.handleRemove,
                                            "max-count": 1
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_button, null, {
                                                default: withCtx(() => [
                                                  createVNode(_component_upload_outlined),
                                                  createTextVNode(" Select File ")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }, 8, ["before-upload", "onRemove"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Product Category",
                                        name: "category"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_auto_complete, {
                                            options: _ctx.categories,
                                            placeholder: "Select Category"
                                          }, null, 8, ["options"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Brand",
                                        name: "brand"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_auto_complete, { placeholder: "Select Brand" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 6
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Barcode Symbology",
                                        name: "sku"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, null, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select_option, { value: "CODE128" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("CODE128")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "CODE39" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("CODE39")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 18
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Barcode",
                                        name: "sku"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Enter Barcode" }, {
                                            addonAfter: withCtx(() => [
                                              createVNode(_component_a_button, { style: { "width": "100px" } }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_BarcodeOutlined),
                                                  createTextVNode(" Generate ")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "HSN Code",
                                        name: "hsn"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Enter HSN Code" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Unit",
                                        name: "unit"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode("h4", { class: "t1" }, "Pricing & Tax"),
                              createVNode(_component_a_row, { gutter: 24 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Sales Price (INR)",
                                        name: "sales_price"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input_number, {
                                            style: { "width": "100%" },
                                            placeholder: "Enter sales price"
                                          }, {
                                            addonAfter: withCtx(() => [
                                              createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("With Tax")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Without Tax")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Purchase Price (INR)",
                                        name: "purchase_price"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input_number, {
                                            style: { "width": "100%" },
                                            placeholder: "Enter purchase price"
                                          }, {
                                            addonAfter: withCtx(() => [
                                              createVNode(_component_a_select, { style: { "width": "100px" } }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select_option, { value: "With Tax" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("With Tax")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, { value: "Without Tax" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Without Tax")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Tax Rate",
                                        name: "tax"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            "show-search": "",
                                            placeholder: "Tax",
                                            "default-active-first-option": false
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode("h4", { class: "t1" }, "Description"),
                              createVNode(_component_a_form_item, {
                                label: "Description",
                                name: "description"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_textarea, { placeholder: "Enter Description" })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit",
                                    disabled: $data.form.processing
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("SUBMIT")
                                    ]),
                                    _: 1
                                  }, 8, ["disabled"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_tab_pane, {
                            key: "pc-2",
                            tab: "Raw Materials (Optional)"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_table, {
                                columns: [{
                                  title: "Item",
                                  dataIndex: "item",
                                  width: "60%"
                                }, {
                                  title: "Unit",
                                  dataIndex: "unit"
                                }, {
                                  title: "Yield",
                                  dataIndex: "yield"
                                }],
                                "data-source": [{ item: "Item-1", unit: "Pcs", yield: "1" }],
                                pagination: false
                              }, {
                                bodyCell: withCtx(({ column, text }) => [
                                  column.dataIndex === "item" ? (openBlock(), createBlock(_component_a_auto_complete, {
                                    key: 0,
                                    placeholder: "Select Item",
                                    style: { "width": "100%" }
                                  })) : createCommentVNode("", true),
                                  column.dataIndex === "unit" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                                    createTextVNode(" Pcs ")
                                  ], 64)) : createCommentVNode("", true),
                                  column.dataIndex === "yield" ? (openBlock(), createBlock(_component_a_input_number, {
                                    key: 2,
                                    style: { "width": "100%" },
                                    placeholder: "Enter yield"
                                  })) : createCommentVNode("", true)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_button, {
                                type: "success",
                                size: "small"
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Add ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_tab_pane, {
                            key: "pc-3",
                            tab: "Operations (Optional)"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_table, {
                                columns: [{
                                  title: "Machine/Operation",
                                  dataIndex: "machine_operation",
                                  width: "60%"
                                }, {
                                  title: "Operation Parameters",
                                  dataIndex: "operation_parameters"
                                }, {
                                  title: "End Machine/Operation",
                                  dataIndex: "end_machine_operation"
                                }],
                                "data-source": [
                                  { machine_operation: "Cutting", operation_parameters: "Cutting Details", end_machine_operation: "Machine-1" },
                                  { machine_operation: "Machine-2", operation_parameters: "Operation-2", end_machine_operation: "Machine-2" }
                                ],
                                pagination: false
                              }, {
                                bodyCell: withCtx(({ column, text }) => [
                                  column.dataIndex === "machine_operation" ? (openBlock(), createBlock(_component_a_auto_complete, {
                                    key: 0,
                                    placeholder: "Select Machine / Operation",
                                    style: { "width": "100%" },
                                    options: [
                                      { value: "Cutting" },
                                      { value: "Stiching" },
                                      { value: "Printing" },
                                      { value: "Iorning" },
                                      { value: "Packing" }
                                    ]
                                  })) : createCommentVNode("", true),
                                  column.dataIndex === "operation_parameters" ? (openBlock(), createBlock(_component_a_textarea, {
                                    key: 1,
                                    placeholder: "Enter Operation Parameters"
                                  })) : createCommentVNode("", true),
                                  column.dataIndex === "end_machine_operation" ? (openBlock(), createBlock(_component_a_checkbox, {
                                    key: 2,
                                    checked: true
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("End")
                                    ]),
                                    _: 1
                                  })) : createCommentVNode("", true)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_button, {
                                type: "success",
                                size: "small"
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Add ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["activeKey", "onUpdate:activeKey"])
                    ]),
                    _: 1
                  }, 16, ["model", "validate-messages", "onFinish"])
                ]),
                _: 1
              }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"]),
              createVNode(_component_a_drawer, {
                visible: $data.showdetail,
                "onUpdate:visible": ($event) => $data.showdetail = $event,
                class: "custom-class",
                title: "Product 1",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                extra: withCtx(() => [
                  createVNode(_component_a_space, null, {
                    default: withCtx(() => [
                      createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                        default: withCtx(() => [
                          createTextVNode("Edit")
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_button, {
                        type: "primary",
                        onClick: _ctx.onClose
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Delete")
                        ]),
                        _: 1
                      }, 8, ["onClick"])
                    ]),
                    _: 1
                  })
                ]),
                default: withCtx(() => [
                  createVNode(_component_a_tabs, {
                    activeKey: _ctx.activeKey,
                    "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_tab_pane, {
                        key: "Overview",
                        tab: "Overview"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_descriptions, { size: _ctx.size }, {
                            default: withCtx(() => [
                              createVNode(_component_a_descriptions_item, {
                                label: "Product Name",
                                span: 4
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Product 1")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_descriptions_item, { label: "Description" }, {
                                default: withCtx(() => [
                                  createTextVNode("Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["size"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_tab_pane, {
                        key: "Transactions",
                        tab: "Transactions",
                        "force-render": ""
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_space, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_select, {
                                ref: "select",
                                placeholder: "Filter By"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select_option, { value: "jack" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Invoice")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "lucy" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Sales Order")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "disabled" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Quote")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Purchase Order")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 512),
                              createVNode(_component_a_select, {
                                ref: "select",
                                placeholder: "Status"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select_option, { value: "jack" }, {
                                    default: withCtx(() => [
                                      createTextVNode("All")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "lucy" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Draft")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 512)
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_table, {
                            columns: $setup.invoicetransactions_column,
                            "data-source": $setup.invoicetransactions
                          }, null, 8, ["columns", "data-source"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["activeKey", "onUpdate:activeKey"])
                ]),
                _: 1
              }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"])
            ]),
            _: 1
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Product/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Index as default
};
