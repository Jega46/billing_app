import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import "vue-request";
import { resolveComponent, withCtx, createVNode, createTextVNode, openBlock, createBlock, toDisplayString, createCommentVNode, mergeProps, useSSRContext } from "vue";
import { Head, Link, useForm } from "@inertiajs/vue3";
import { DownloadOutlined, PlusCircleOutlined, MoreOutlined, DownCircleOutlined, CloseCircleOutlined, EditOutlined, DeleteOutlined, MailOutlined, CheckOutlined, InteractionOutlined, FilePdfOutlined, PlusOutlined } from "@ant-design/icons-vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderStyle } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
const columns = [
  {
    title: "Date",
    key: "date",
    dataIndex: "date",
    width: "15%"
  },
  {
    title: "Invoice Number",
    key: "invoice_number",
    dataIndex: "invoice_number",
    width: "15%"
  },
  {
    title: "Order Number",
    key: "reference_number",
    dataIndex: "reference_number",
    width: "15%"
  },
  {
    title: "Customer Name",
    key: "customer_name",
    dataIndex: "customer_name",
    width: "15%"
  },
  {
    title: "Status",
    key: "status",
    dataIndex: "status",
    width: "15%"
  },
  {
    title: "Due Date",
    key: "due_date",
    dataIndex: "due_date",
    width: "15%"
  },
  {
    title: "Amount",
    key: "amount",
    dataIndex: "amount",
    width: "15%"
  },
  {
    title: "Balance Due",
    key: "balance_due",
    dataIndex: "balance_due",
    width: "15%"
  }
];
const invoices = [
  {
    key: "1",
    date: "10-10-2023",
    invoice_number: "invoice-0001",
    reference_number: "",
    customer_name: "John Doe",
    status: "Draft",
    due_date: "10-10-2023",
    amount: "1000.00",
    balance_due: "0.00"
  },
  //adding 5 more data with different invoice_number and customer_name
  {
    key: "2",
    date: "10-10-2023",
    invoice_number: "invoice-0002",
    reference_number: "",
    customer_name: "John Doe",
    status: "Draft",
    due_date: "10-10-2023",
    amount: "1000.00",
    balance_due: "0.00"
  },
  {
    key: "3",
    date: "10-10-2023",
    invoice_number: "invoice-0003",
    reference_number: "",
    customer_name: "John Doe",
    status: "Draft",
    due_date: "10-10-2023",
    amount: "1000.00",
    balance_due: "0.00"
  },
  {
    key: "4",
    date: "10-10-2023",
    invoice_number: "invoice-0004",
    reference_number: "",
    customer_name: "John Doe",
    status: "Draft",
    due_date: "10-10-2023",
    amount: "1000.00",
    balance_due: "0.00"
  },
  {
    key: "5",
    date: "10-10-2023",
    invoice_number: "invoice-0005",
    reference_number: "",
    customer_name: "John Doe",
    status: "Draft",
    due_date: "10-10-2023",
    amount: "1000.00",
    balance_due: "0.00"
  },
  {
    key: "6",
    date: "10-10-2023",
    invoice_number: "invoice-0006",
    reference_number: "",
    customer_name: "John Doe",
    status: "Draft",
    due_date: "10-10-2023",
    amount: "1000.00",
    balance_due: "0.00"
  },
  {
    key: "7",
    date: "10-10-2023",
    invoice_number: "invoice-0007",
    reference_number: "",
    customer_name: "John Doe",
    status: "Draft",
    due_date: "10-10-2023",
    amount: "1000.00",
    balance_due: "0.00"
  },
  {
    key: "8",
    date: "10-10-2023",
    invoice_number: "invoice-0008",
    reference_number: "",
    customer_name: "John Doe",
    status: "Draft",
    due_date: "10-10-2023",
    amount: "1000.00",
    balance_due: "0.00"
  },
  {
    key: "9",
    date: "10-10-2023",
    invoice_number: "invoice-0009",
    reference_number: "",
    customer_name: "John Doe",
    status: "Draft",
    due_date: "10-10-2023",
    amount: "1000.00",
    balance_due: "0.00"
  }
];
const invoicecolumns = [{
  title: "Item Details",
  dataIndex: "item_details",
  key: "item_details",
  width: "40%"
}, {
  title: "Quantity",
  dataIndex: "quantity",
  key: "quantity",
  width: "10%"
}, {
  title: "Rate",
  dataIndex: "rate",
  key: "rate",
  width: "10%"
}, {
  title: "Amount",
  key: "amount",
  dataIndex: "amount",
  width: "10%"
}, {
  title: "Action",
  key: "action",
  width: "3%"
}];
const createInvoiceItems = [
  {
    key: "1",
    item_details: "item 1",
    quantity: "1",
    rate: "0.00",
    amount: "1000.00",
    balance_due: "0.00",
    action: ""
  },
  {
    key: "2",
    item_details: "item 2",
    quantity: "1",
    rate: "0.00",
    amount: "1000.00",
    balance_due: "0.00",
    action: ""
  }
];
const _sfc_main = {
  components: {
    AuthenticatedLayout: _sfc_main$1,
    DownloadOutlined,
    PlusCircleOutlined,
    MoreOutlined,
    Head,
    Link,
    DownCircleOutlined,
    CloseCircleOutlined,
    EditOutlined,
    DeleteOutlined,
    MailOutlined,
    CheckOutlined,
    InteractionOutlined,
    FilePdfOutlined,
    PlusOutlined
  },
  props: {},
  setup(props) {
    return {
      columns,
      invoicecolumns,
      invoices,
      createInvoiceItems
    };
  },
  data() {
    const loading = false;
    const create_form_visible = false;
    const searchform = useForm({
      term: ""
    });
    const form = useForm({
      term: ""
    });
    return {
      create_form_visible,
      loading,
      searchform,
      form,
      showdetail: false
    };
  },
  methods: {
    showDrawer() {
      this.create_form_visible = true;
    },
    showDetailDrawer() {
      this.showdetail = true;
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_space = resolveComponent("a-space");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_button = resolveComponent("a-button");
  const _component_plus_circle_outlined = resolveComponent("plus-circle-outlined");
  const _component_a_table = resolveComponent("a-table");
  const _component_a_drawer = resolveComponent("a-drawer");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_textarea = resolveComponent("a-textarea");
  const _component_CloseCircleOutlined = resolveComponent("CloseCircleOutlined");
  const _component_a_descriptions = resolveComponent("a-descriptions");
  const _component_a_descriptions_item = resolveComponent("a-descriptions-item");
  const _component_EditOutlined = resolveComponent("EditOutlined");
  const _component_DeleteOutlined = resolveComponent("DeleteOutlined");
  const _component_a_dropdown = resolveComponent("a-dropdown");
  const _component_a_menu = resolveComponent("a-menu");
  const _component_a_menu_item = resolveComponent("a-menu-item");
  const _component_FilePdfOutlined = resolveComponent("FilePdfOutlined");
  const _component_PlusOutlined = resolveComponent("PlusOutlined");
  const _component_MailOutlined = resolveComponent("MailOutlined");
  const _component_CheckOutlined = resolveComponent("CheckOutlined");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Invoices" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_layout_content, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, {
                      name: "nest-messages",
                      model: $data.searchform,
                      layout: "inline",
                      onFinish: _ctx.search
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input, {
                                  placeholder: "Search by Invoice Number",
                                  "allow-clear": true,
                                  value: $data.searchform.term,
                                  "onUpdate:value": ($event) => $data.searchform.term = $event
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input, {
                                    placeholder: "Search by Invoice Number",
                                    "allow-clear": true,
                                    value: $data.searchform.term,
                                    "onUpdate:value": ($event) => $data.searchform.term = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Search `);
                                    } else {
                                      return [
                                        createTextVNode(" Search ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Search ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_plus_circle_outlined)
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` New Invoice `);
                                    } else {
                                      return [
                                        createTextVNode(" New Invoice ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    shape: "round",
                                    onClick: $options.showDrawer
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" New Invoice ")
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  placeholder: "Search by Invoice Number",
                                  "allow-clear": true,
                                  value: $data.searchform.term,
                                  "onUpdate:value": ($event) => $data.searchform.term = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Search ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" New Invoice ")
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_table, {
                      columns: $setup.columns,
                      "data-source": $setup.invoices
                    }, {
                      bodyCell: withCtx(({ column, record }, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          if (column.key === "invoice_number") {
                            _push5(`<a${_scopeId4}>${ssrInterpolate(record.invoice_number)}</a>`);
                          } else {
                            _push5(`<!---->`);
                          }
                        } else {
                          return [
                            column.key === "invoice_number" ? (openBlock(), createBlock("a", {
                              key: 0,
                              onClick: $options.showDetailDrawer
                            }, toDisplayString(record.invoice_number), 9, ["onClick"])) : createCommentVNode("", true)
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, {
                        name: "nest-messages",
                        model: $data.searchform,
                        layout: "inline",
                        onFinish: _ctx.search
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                placeholder: "Search by Invoice Number",
                                "allow-clear": true,
                                value: $data.searchform.term,
                                "onUpdate:value": ($event) => $data.searchform.term = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Search ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                shape: "round",
                                onClick: $options.showDrawer
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" New Invoice ")
                                ]),
                                _: 1
                              }, 8, ["onClick"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["model", "onFinish"]),
                      createVNode(_component_a_table, {
                        columns: $setup.columns,
                        "data-source": $setup.invoices
                      }, {
                        bodyCell: withCtx(({ column, record }) => [
                          column.key === "invoice_number" ? (openBlock(), createBlock("a", {
                            key: 0,
                            onClick: $options.showDetailDrawer
                          }, toDisplayString(record.invoice_number), 9, ["onClick"])) : createCommentVNode("", true)
                        ]),
                        _: 1
                      }, 8, ["columns", "data-source"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_drawer, {
                visible: $data.create_form_visible,
                "onUpdate:visible": ($event) => $data.create_form_visible = $event,
                class: "sales-bill",
                size: "large",
                style: { "color": "red" },
                title: "New Invoice",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, mergeProps({ model: $data.form }, _ctx.layout, {
                      name: "nest-messages",
                      "validate-messages": _ctx.validateMessages,
                      onFinish: _ctx.submit,
                      "label-col": { span: 24 },
                      style: { "min-height": "100%" }
                    }), {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "Customer",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select, {
                                              value: $data.form.tax,
                                              "onUpdate:value": ($event) => $data.form.tax = $event,
                                              "show-search": "",
                                              placeholder: "Select Customer",
                                              style: { "width": "100%" },
                                              "default-active-first-option": false,
                                              options: _ctx.customers,
                                              "not-found-content": _ctx.value
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select, {
                                                value: $data.form.tax,
                                                "onUpdate:value": ($event) => $data.form.tax = $event,
                                                "show-search": "",
                                                placeholder: "Select Customer",
                                                style: { "width": "100%" },
                                                "default-active-first-option": false,
                                                options: _ctx.customers,
                                                "not-found-content": _ctx.value
                                              }, null, 8, ["value", "onUpdate:value", "options", "not-found-content"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "Customer",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              value: $data.form.tax,
                                              "onUpdate:value": ($event) => $data.form.tax = $event,
                                              "show-search": "",
                                              placeholder: "Select Customer",
                                              style: { "width": "100%" },
                                              "default-active-first-option": false,
                                              options: _ctx.customers,
                                              "not-found-content": _ctx.value
                                            }, null, 8, ["value", "onUpdate:value", "options", "not-found-content"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "Invoice Number",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: $data.form.name,
                                                "onUpdate:value": ($event) => $data.form.name = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "Invoice Number",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "Reference Number"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: $data.form.name,
                                                "onUpdate:value": ($event) => $data.form.name = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "Reference Number"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "Invoice Date",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: $data.form.name,
                                                "onUpdate:value": ($event) => $data.form.name = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "Invoice Date",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "Expiry Date"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: $data.form.name,
                                                "onUpdate:value": ($event) => $data.form.name = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "Expiry Date"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "24"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "Subject",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: $data.form.name,
                                                "onUpdate:value": ($event) => $data.form.name = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "Subject",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "8"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "Customer",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            value: $data.form.tax,
                                            "onUpdate:value": ($event) => $data.form.tax = $event,
                                            "show-search": "",
                                            placeholder: "Select Customer",
                                            style: { "width": "100%" },
                                            "default-active-first-option": false,
                                            options: _ctx.customers,
                                            "not-found-content": _ctx.value
                                          }, null, 8, ["value", "onUpdate:value", "options", "not-found-content"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "8"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "Invoice Number",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: $data.form.name,
                                            "onUpdate:value": ($event) => $data.form.name = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "8"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "Reference Number"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: $data.form.name,
                                            "onUpdate:value": ($event) => $data.form.name = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "8"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "Invoice Date",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: $data.form.name,
                                            "onUpdate:value": ($event) => $data.form.name = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "8"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "Expiry Date"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: $data.form.name,
                                            "onUpdate:value": ($event) => $data.form.name = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "24"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "Subject",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: $data.form.name,
                                            "onUpdate:value": ($event) => $data.form.name = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<h4 class="t1"${_scopeId4}>Items / Services Info</h4>`);
                          _push5(ssrRenderComponent(_component_a_table, {
                            columns: $setup.invoicecolumns,
                            "data-source": $setup.createInvoiceItems,
                            pagination: false
                          }, {
                            bodyCell: withCtx(({ column, record }, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                if (column.key === "item_details") {
                                  _push6(ssrRenderComponent(_component_a_space, {
                                    direction: "vertical",
                                    style: { "width": "100%" }
                                  }, {
                                    default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_a_input, {
                                          value: record.item_details,
                                          "onUpdate:value": ($event) => record.item_details = $event
                                        }, null, _parent7, _scopeId6));
                                        _push7(ssrRenderComponent(_component_a_textarea, {
                                          value: record.item_details,
                                          "onUpdate:value": ($event) => record.item_details = $event,
                                          placeholder: "Item Description",
                                          "allow-clear": ""
                                        }, null, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_a_input, {
                                            value: record.item_details,
                                            "onUpdate:value": ($event) => record.item_details = $event
                                          }, null, 8, ["value", "onUpdate:value"]),
                                          createVNode(_component_a_textarea, {
                                            value: record.item_details,
                                            "onUpdate:value": ($event) => record.item_details = $event,
                                            placeholder: "Item Description",
                                            "allow-clear": ""
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "quantity") {
                                  _push6(ssrRenderComponent(_component_a_input, {
                                    value: record.quantity,
                                    "onUpdate:value": ($event) => record.quantity = $event
                                  }, null, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "rate") {
                                  _push6(ssrRenderComponent(_component_a_input, {
                                    value: record.rate,
                                    "onUpdate:value": ($event) => record.rate = $event
                                  }, null, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "amount") {
                                  _push6(ssrRenderComponent(_component_a_input, {
                                    value: record.amount,
                                    "onUpdate:value": ($event) => record.amount = $event
                                  }, null, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "action") {
                                  _push6(ssrRenderComponent(_component_a_space, null, {
                                    default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_a_button, {
                                          type: "primary",
                                          size: "small"
                                        }, {
                                          icon: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(ssrRenderComponent(_component_CloseCircleOutlined, null, null, _parent8, _scopeId7));
                                            } else {
                                              return [
                                                createVNode(_component_CloseCircleOutlined)
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_a_button, {
                                            type: "primary",
                                            size: "small"
                                          }, {
                                            icon: withCtx(() => [
                                              createVNode(_component_CloseCircleOutlined)
                                            ]),
                                            _: 1
                                          })
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                              } else {
                                return [
                                  column.key === "item_details" ? (openBlock(), createBlock(_component_a_space, {
                                    key: 0,
                                    direction: "vertical",
                                    style: { "width": "100%" }
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: record.item_details,
                                        "onUpdate:value": ($event) => record.item_details = $event
                                      }, null, 8, ["value", "onUpdate:value"]),
                                      createVNode(_component_a_textarea, {
                                        value: record.item_details,
                                        "onUpdate:value": ($event) => record.item_details = $event,
                                        placeholder: "Item Description",
                                        "allow-clear": ""
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 2
                                  }, 1024)) : createCommentVNode("", true),
                                  column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                                    key: 1,
                                    value: record.quantity,
                                    "onUpdate:value": ($event) => record.quantity = $event
                                  }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                  column.key === "rate" ? (openBlock(), createBlock(_component_a_input, {
                                    key: 2,
                                    value: record.rate,
                                    "onUpdate:value": ($event) => record.rate = $event
                                  }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                  column.key === "amount" ? (openBlock(), createBlock(_component_a_input, {
                                    key: 3,
                                    value: record.amount,
                                    "onUpdate:value": ($event) => record.amount = $event
                                  }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                  column.key === "action" ? (openBlock(), createBlock(_component_a_space, { key: 4 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        size: "small"
                                      }, {
                                        icon: withCtx(() => [
                                          createVNode(_component_CloseCircleOutlined)
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })) : createCommentVNode("", true)
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<br${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_space, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "success",
                                  size: "small"
                                }, {
                                  icon: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_plus_circle_outlined)
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Add Good `);
                                    } else {
                                      return [
                                        createTextVNode(" Add Good ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "success",
                                  size: "small"
                                }, {
                                  icon: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_plus_circle_outlined)
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Add Service `);
                                    } else {
                                      return [
                                        createTextVNode(" Add Service ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "success",
                                    size: "small"
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Add Good ")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_button, {
                                    type: "success",
                                    size: "small"
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Add Service ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<br${_scopeId4}><br${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "Customer Notes",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_textarea, {
                                              value: $data.form.description,
                                              "onUpdate:value": ($event) => $data.form.description = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_textarea, {
                                                value: $data.form.description,
                                                "onUpdate:value": ($event) => $data.form.description = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "Terms & Conditions",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_textarea, {
                                              value: $data.form.description,
                                              "onUpdate:value": ($event) => $data.form.description = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_textarea, {
                                                value: $data.form.description,
                                                "onUpdate:value": ($event) => $data.form.description = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "Customer Notes",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_textarea, {
                                              value: $data.form.description,
                                              "onUpdate:value": ($event) => $data.form.description = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "Terms & Conditions",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_textarea, {
                                              value: $data.form.description,
                                              "onUpdate:value": ($event) => $data.form.description = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<br${_scopeId6}>`);
                                      _push7(ssrRenderComponent(_component_a_descriptions, {
                                        title: "",
                                        bordered: "",
                                        size: "small"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_descriptions_item, {
                                              label: "Sub Total",
                                              span: 4
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`<p class="text-right m-0"${_scopeId8}>0.00</p>`);
                                                } else {
                                                  return [
                                                    createVNode("p", { class: "text-right m-0" }, "0.00")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_descriptions_item, {
                                              label: "Discount",
                                              span: 2
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_input, { style: { "width": "100px" } }, null, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_input, { style: { "width": "100px" } })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_descriptions_item, { span: 2 }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(` 0.00`);
                                                } else {
                                                  return [
                                                    createTextVNode(" 0.00")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_descriptions_item, {
                                              label: "Tax",
                                              span: 2
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_select, {
                                                    value: $data.form.tax,
                                                    "onUpdate:value": ($event) => $data.form.tax = $event,
                                                    "show-search": "",
                                                    placeholder: "Tax",
                                                    style: { "width": "100px" },
                                                    "default-active-first-option": false,
                                                    "not-found-content": _ctx.value
                                                  }, null, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_select, {
                                                      value: $data.form.tax,
                                                      "onUpdate:value": ($event) => $data.form.tax = $event,
                                                      "show-search": "",
                                                      placeholder: "Tax",
                                                      style: { "width": "100px" },
                                                      "default-active-first-option": false,
                                                      "not-found-content": _ctx.value
                                                    }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_descriptions_item, { span: 2 }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(` 0.00`);
                                                } else {
                                                  return [
                                                    createTextVNode(" 0.00")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_descriptions_item, {
                                              label: "Adjustment",
                                              span: 2
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_input, { style: { "width": "100px" } }, null, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_input, { style: { "width": "100px" } })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_descriptions_item, { span: 2 }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(` 0.00`);
                                                } else {
                                                  return [
                                                    createTextVNode(" 0.00")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_descriptions_item, {
                                              label: "Total",
                                              span: 4
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`<h4 class="text-right"${_scopeId8}>0.00</h4>`);
                                                } else {
                                                  return [
                                                    createVNode("h4", { class: "text-right" }, "0.00")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_descriptions_item, {
                                                label: "Sub Total",
                                                span: 4
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode("p", { class: "text-right m-0" }, "0.00")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_descriptions_item, {
                                                label: "Discount",
                                                span: 2
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, { style: { "width": "100px" } })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_descriptions_item, { span: 2 }, {
                                                default: withCtx(() => [
                                                  createTextVNode(" 0.00")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_descriptions_item, {
                                                label: "Tax",
                                                span: 2
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select, {
                                                    value: $data.form.tax,
                                                    "onUpdate:value": ($event) => $data.form.tax = $event,
                                                    "show-search": "",
                                                    placeholder: "Tax",
                                                    style: { "width": "100px" },
                                                    "default-active-first-option": false,
                                                    "not-found-content": _ctx.value
                                                  }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_descriptions_item, { span: 2 }, {
                                                default: withCtx(() => [
                                                  createTextVNode(" 0.00")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_descriptions_item, {
                                                label: "Adjustment",
                                                span: 2
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, { style: { "width": "100px" } })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_descriptions_item, { span: 2 }, {
                                                default: withCtx(() => [
                                                  createTextVNode(" 0.00")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_descriptions_item, {
                                                label: "Total",
                                                span: 4
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode("h4", { class: "text-right" }, "0.00")
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode("br"),
                                        createVNode(_component_a_descriptions, {
                                          title: "",
                                          bordered: "",
                                          size: "small"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_descriptions_item, {
                                              label: "Sub Total",
                                              span: 4
                                            }, {
                                              default: withCtx(() => [
                                                createVNode("p", { class: "text-right m-0" }, "0.00")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_descriptions_item, {
                                              label: "Discount",
                                              span: 2
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, { style: { "width": "100px" } })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_descriptions_item, { span: 2 }, {
                                              default: withCtx(() => [
                                                createTextVNode(" 0.00")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_descriptions_item, {
                                              label: "Tax",
                                              span: 2
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select, {
                                                  value: $data.form.tax,
                                                  "onUpdate:value": ($event) => $data.form.tax = $event,
                                                  "show-search": "",
                                                  placeholder: "Tax",
                                                  style: { "width": "100px" },
                                                  "default-active-first-option": false,
                                                  "not-found-content": _ctx.value
                                                }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_descriptions_item, { span: 2 }, {
                                              default: withCtx(() => [
                                                createTextVNode(" 0.00")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_descriptions_item, {
                                              label: "Adjustment",
                                              span: 2
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, { style: { "width": "100px" } })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_descriptions_item, { span: 2 }, {
                                              default: withCtx(() => [
                                                createTextVNode(" 0.00")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_descriptions_item, {
                                              label: "Total",
                                              span: 4
                                            }, {
                                              default: withCtx(() => [
                                                createVNode("h4", { class: "text-right" }, "0.00")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "Customer Notes",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_textarea, {
                                            value: $data.form.description,
                                            "onUpdate:value": ($event) => $data.form.description = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "Terms & Conditions",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_textarea, {
                                            value: $data.form.description,
                                            "onUpdate:value": ($event) => $data.form.description = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("br"),
                                      createVNode(_component_a_descriptions, {
                                        title: "",
                                        bordered: "",
                                        size: "small"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_descriptions_item, {
                                            label: "Sub Total",
                                            span: 4
                                          }, {
                                            default: withCtx(() => [
                                              createVNode("p", { class: "text-right m-0" }, "0.00")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_descriptions_item, {
                                            label: "Discount",
                                            span: 2
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, { style: { "width": "100px" } })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_descriptions_item, { span: 2 }, {
                                            default: withCtx(() => [
                                              createTextVNode(" 0.00")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_descriptions_item, {
                                            label: "Tax",
                                            span: 2
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select, {
                                                value: $data.form.tax,
                                                "onUpdate:value": ($event) => $data.form.tax = $event,
                                                "show-search": "",
                                                placeholder: "Tax",
                                                style: { "width": "100px" },
                                                "default-active-first-option": false,
                                                "not-found-content": _ctx.value
                                              }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_descriptions_item, { span: 2 }, {
                                            default: withCtx(() => [
                                              createTextVNode(" 0.00")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_descriptions_item, {
                                            label: "Adjustment",
                                            span: 2
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, { style: { "width": "100px" } })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_descriptions_item, { span: 2 }, {
                                            default: withCtx(() => [
                                              createTextVNode(" 0.00")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_descriptions_item, {
                                            label: "Total",
                                            span: 4
                                          }, {
                                            default: withCtx(() => [
                                              createVNode("h4", { class: "text-right" }, "0.00")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<br${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit",
                                        disabled: $data.form.processing,
                                        block: ""
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`SAVE (F2)`);
                                          } else {
                                            return [
                                              createTextVNode("SAVE (F2)")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          "html-type": "submit",
                                          disabled: $data.form.processing,
                                          block: ""
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("SAVE (F2)")
                                          ]),
                                          _: 1
                                        }, 8, ["disabled"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit",
                                        disabled: $data.form.processing,
                                        block: ""
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`SAVE &amp; SEND (F3)`);
                                          } else {
                                            return [
                                              createTextVNode("SAVE & SEND (F3)")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          "html-type": "submit",
                                          disabled: $data.form.processing,
                                          block: ""
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("SAVE & SEND (F3)")
                                          ]),
                                          _: 1
                                        }, 8, ["disabled"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit",
                                        disabled: $data.form.processing,
                                        block: ""
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`SAVE &amp; PRINT (F5)`);
                                          } else {
                                            return [
                                              createTextVNode("SAVE & PRINT (F5)")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          "html-type": "submit",
                                          disabled: $data.form.processing,
                                          block: ""
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("SAVE & PRINT (F5)")
                                          ]),
                                          _: 1
                                        }, 8, ["disabled"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "8"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit",
                                        disabled: $data.form.processing,
                                        block: ""
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("SAVE (F2)")
                                        ]),
                                        _: 1
                                      }, 8, ["disabled"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "8"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit",
                                        disabled: $data.form.processing,
                                        block: ""
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("SAVE & SEND (F3)")
                                        ]),
                                        _: 1
                                      }, 8, ["disabled"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "8"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit",
                                        disabled: $data.form.processing,
                                        block: ""
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("SAVE & PRINT (F5)")
                                        ]),
                                        _: 1
                                      }, 8, ["disabled"])
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_row, { gutter: 24 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "Customer",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          value: $data.form.tax,
                                          "onUpdate:value": ($event) => $data.form.tax = $event,
                                          "show-search": "",
                                          placeholder: "Select Customer",
                                          style: { "width": "100%" },
                                          "default-active-first-option": false,
                                          options: _ctx.customers,
                                          "not-found-content": _ctx.value
                                        }, null, 8, ["value", "onUpdate:value", "options", "not-found-content"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "Invoice Number",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: $data.form.name,
                                          "onUpdate:value": ($event) => $data.form.name = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "Reference Number"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: $data.form.name,
                                          "onUpdate:value": ($event) => $data.form.name = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "Invoice Date",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: $data.form.name,
                                          "onUpdate:value": ($event) => $data.form.name = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "Expiry Date"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: $data.form.name,
                                          "onUpdate:value": ($event) => $data.form.name = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "24"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "Subject",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: $data.form.name,
                                          "onUpdate:value": ($event) => $data.form.name = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("h4", { class: "t1" }, "Items / Services Info"),
                            createVNode(_component_a_table, {
                              columns: $setup.invoicecolumns,
                              "data-source": $setup.createInvoiceItems,
                              pagination: false
                            }, {
                              bodyCell: withCtx(({ column, record }) => [
                                column.key === "item_details" ? (openBlock(), createBlock(_component_a_space, {
                                  key: 0,
                                  direction: "vertical",
                                  style: { "width": "100%" }
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: record.item_details,
                                      "onUpdate:value": ($event) => record.item_details = $event
                                    }, null, 8, ["value", "onUpdate:value"]),
                                    createVNode(_component_a_textarea, {
                                      value: record.item_details,
                                      "onUpdate:value": ($event) => record.item_details = $event,
                                      placeholder: "Item Description",
                                      "allow-clear": ""
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 2
                                }, 1024)) : createCommentVNode("", true),
                                column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                                  key: 1,
                                  value: record.quantity,
                                  "onUpdate:value": ($event) => record.quantity = $event
                                }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                column.key === "rate" ? (openBlock(), createBlock(_component_a_input, {
                                  key: 2,
                                  value: record.rate,
                                  "onUpdate:value": ($event) => record.rate = $event
                                }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                column.key === "amount" ? (openBlock(), createBlock(_component_a_input, {
                                  key: 3,
                                  value: record.amount,
                                  "onUpdate:value": ($event) => record.amount = $event
                                }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                column.key === "action" ? (openBlock(), createBlock(_component_a_space, { key: 4 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      size: "small"
                                    }, {
                                      icon: withCtx(() => [
                                        createVNode(_component_CloseCircleOutlined)
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })) : createCommentVNode("", true)
                              ]),
                              _: 1
                            }, 8, ["columns", "data-source"]),
                            createVNode("br"),
                            createVNode(_component_a_space, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "success",
                                  size: "small"
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Add Good ")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_button, {
                                  type: "success",
                                  size: "small"
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Add Service ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("br"),
                            createVNode("br"),
                            createVNode(_component_a_row, { gutter: 24 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "Customer Notes",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_textarea, {
                                          value: $data.form.description,
                                          "onUpdate:value": ($event) => $data.form.description = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "Terms & Conditions",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_textarea, {
                                          value: $data.form.description,
                                          "onUpdate:value": ($event) => $data.form.description = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode("br"),
                                    createVNode(_component_a_descriptions, {
                                      title: "",
                                      bordered: "",
                                      size: "small"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_descriptions_item, {
                                          label: "Sub Total",
                                          span: 4
                                        }, {
                                          default: withCtx(() => [
                                            createVNode("p", { class: "text-right m-0" }, "0.00")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, {
                                          label: "Discount",
                                          span: 2
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { style: { "width": "100px" } })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, { span: 2 }, {
                                          default: withCtx(() => [
                                            createTextVNode(" 0.00")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, {
                                          label: "Tax",
                                          span: 2
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              value: $data.form.tax,
                                              "onUpdate:value": ($event) => $data.form.tax = $event,
                                              "show-search": "",
                                              placeholder: "Tax",
                                              style: { "width": "100px" },
                                              "default-active-first-option": false,
                                              "not-found-content": _ctx.value
                                            }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, { span: 2 }, {
                                          default: withCtx(() => [
                                            createTextVNode(" 0.00")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, {
                                          label: "Adjustment",
                                          span: 2
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { style: { "width": "100px" } })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, { span: 2 }, {
                                          default: withCtx(() => [
                                            createTextVNode(" 0.00")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, {
                                          label: "Total",
                                          span: 4
                                        }, {
                                          default: withCtx(() => [
                                            createVNode("h4", { class: "text-right" }, "0.00")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("br"),
                            createVNode(_component_a_row, { gutter: 24 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      "html-type": "submit",
                                      disabled: $data.form.processing,
                                      block: ""
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("SAVE (F2)")
                                      ]),
                                      _: 1
                                    }, 8, ["disabled"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      "html-type": "submit",
                                      disabled: $data.form.processing,
                                      block: ""
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("SAVE & SEND (F3)")
                                      ]),
                                      _: 1
                                    }, 8, ["disabled"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "8"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      "html-type": "submit",
                                      disabled: $data.form.processing,
                                      block: ""
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("SAVE & PRINT (F5)")
                                      ]),
                                      _: 1
                                    }, 8, ["disabled"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, mergeProps({ model: $data.form }, _ctx.layout, {
                        name: "nest-messages",
                        "validate-messages": _ctx.validateMessages,
                        onFinish: _ctx.submit,
                        "label-col": { span: 24 },
                        style: { "min-height": "100%" }
                      }), {
                        default: withCtx(() => [
                          createVNode(_component_a_row, { gutter: 24 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "8"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "Customer",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        value: $data.form.tax,
                                        "onUpdate:value": ($event) => $data.form.tax = $event,
                                        "show-search": "",
                                        placeholder: "Select Customer",
                                        style: { "width": "100%" },
                                        "default-active-first-option": false,
                                        options: _ctx.customers,
                                        "not-found-content": _ctx.value
                                      }, null, 8, ["value", "onUpdate:value", "options", "not-found-content"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "8"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "Invoice Number",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $data.form.name,
                                        "onUpdate:value": ($event) => $data.form.name = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "8"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "Reference Number"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $data.form.name,
                                        "onUpdate:value": ($event) => $data.form.name = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "8"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "Invoice Date",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $data.form.name,
                                        "onUpdate:value": ($event) => $data.form.name = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "8"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "Expiry Date"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $data.form.name,
                                        "onUpdate:value": ($event) => $data.form.name = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "24"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "Subject",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $data.form.name,
                                        "onUpdate:value": ($event) => $data.form.name = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("h4", { class: "t1" }, "Items / Services Info"),
                          createVNode(_component_a_table, {
                            columns: $setup.invoicecolumns,
                            "data-source": $setup.createInvoiceItems,
                            pagination: false
                          }, {
                            bodyCell: withCtx(({ column, record }) => [
                              column.key === "item_details" ? (openBlock(), createBlock(_component_a_space, {
                                key: 0,
                                direction: "vertical",
                                style: { "width": "100%" }
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: record.item_details,
                                    "onUpdate:value": ($event) => record.item_details = $event
                                  }, null, 8, ["value", "onUpdate:value"]),
                                  createVNode(_component_a_textarea, {
                                    value: record.item_details,
                                    "onUpdate:value": ($event) => record.item_details = $event,
                                    placeholder: "Item Description",
                                    "allow-clear": ""
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 2
                              }, 1024)) : createCommentVNode("", true),
                              column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                                key: 1,
                                value: record.quantity,
                                "onUpdate:value": ($event) => record.quantity = $event
                              }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                              column.key === "rate" ? (openBlock(), createBlock(_component_a_input, {
                                key: 2,
                                value: record.rate,
                                "onUpdate:value": ($event) => record.rate = $event
                              }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                              column.key === "amount" ? (openBlock(), createBlock(_component_a_input, {
                                key: 3,
                                value: record.amount,
                                "onUpdate:value": ($event) => record.amount = $event
                              }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                              column.key === "action" ? (openBlock(), createBlock(_component_a_space, { key: 4 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    size: "small"
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_CloseCircleOutlined)
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })) : createCommentVNode("", true)
                            ]),
                            _: 1
                          }, 8, ["columns", "data-source"]),
                          createVNode("br"),
                          createVNode(_component_a_space, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "success",
                                size: "small"
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Add Good ")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_button, {
                                type: "success",
                                size: "small"
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Add Service ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("br"),
                          createVNode("br"),
                          createVNode(_component_a_row, { gutter: 24 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "Customer Notes",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_textarea, {
                                        value: $data.form.description,
                                        "onUpdate:value": ($event) => $data.form.description = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "Terms & Conditions",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_textarea, {
                                        value: $data.form.description,
                                        "onUpdate:value": ($event) => $data.form.description = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode("br"),
                                  createVNode(_component_a_descriptions, {
                                    title: "",
                                    bordered: "",
                                    size: "small"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_descriptions_item, {
                                        label: "Sub Total",
                                        span: 4
                                      }, {
                                        default: withCtx(() => [
                                          createVNode("p", { class: "text-right m-0" }, "0.00")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, {
                                        label: "Discount",
                                        span: 2
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { style: { "width": "100px" } })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, { span: 2 }, {
                                        default: withCtx(() => [
                                          createTextVNode(" 0.00")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, {
                                        label: "Tax",
                                        span: 2
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            value: $data.form.tax,
                                            "onUpdate:value": ($event) => $data.form.tax = $event,
                                            "show-search": "",
                                            placeholder: "Tax",
                                            style: { "width": "100px" },
                                            "default-active-first-option": false,
                                            "not-found-content": _ctx.value
                                          }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, { span: 2 }, {
                                        default: withCtx(() => [
                                          createTextVNode(" 0.00")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, {
                                        label: "Adjustment",
                                        span: 2
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { style: { "width": "100px" } })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, { span: 2 }, {
                                        default: withCtx(() => [
                                          createTextVNode(" 0.00")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, {
                                        label: "Total",
                                        span: 4
                                      }, {
                                        default: withCtx(() => [
                                          createVNode("h4", { class: "text-right" }, "0.00")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("br"),
                          createVNode(_component_a_row, { gutter: 24 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "8"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit",
                                    disabled: $data.form.processing,
                                    block: ""
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("SAVE (F2)")
                                    ]),
                                    _: 1
                                  }, 8, ["disabled"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "8"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit",
                                    disabled: $data.form.processing,
                                    block: ""
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("SAVE & SEND (F3)")
                                    ]),
                                    _: 1
                                  }, 8, ["disabled"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "8"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit",
                                    disabled: $data.form.processing,
                                    block: ""
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("SAVE & PRINT (F5)")
                                    ]),
                                    _: 1
                                  }, 8, ["disabled"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 16, ["model", "validate-messages", "onFinish"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_drawer, {
                visible: $data.showdetail,
                "onUpdate:visible": ($event) => $data.showdetail = $event,
                class: "custom-class",
                title: "QT-000001",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_space, { style: { "margin-bottom": "10px" } }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_EditOutlined, null, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_EditOutlined)
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_button, {
                            type: "primary",
                            onClick: _ctx.onClose
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_DeleteOutlined, null, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_DeleteOutlined)
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_dropdown, null, {
                            overlay: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_menu_item, { key: "1" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(` PDF `);
                                          } else {
                                            return [
                                              createTextVNode(" PDF ")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_menu_item, { key: "2" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(` Print `);
                                          } else {
                                            return [
                                              createTextVNode(" Print ")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_menu_item, { key: "1" }, {
                                          default: withCtx(() => [
                                            createTextVNode(" PDF ")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_menu_item, { key: "2" }, {
                                          default: withCtx(() => [
                                            createTextVNode(" Print ")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_menu_item, { key: "1" }, {
                                        default: withCtx(() => [
                                          createTextVNode(" PDF ")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_menu_item, { key: "2" }, {
                                        default: withCtx(() => [
                                          createTextVNode(" Print ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ];
                              }
                            }),
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, null, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_FilePdfOutlined, null, null, _parent7, _scopeId6));
                                      _push7(` PDF / Print `);
                                    } else {
                                      return [
                                        createVNode(_component_FilePdfOutlined),
                                        createTextVNode(" PDF / Print ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_FilePdfOutlined),
                                      createTextVNode(" PDF / Print ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_PlusOutlined, null, null, _parent6, _scopeId5));
                                _push6(` Record Payment`);
                              } else {
                                return [
                                  createVNode(_component_PlusOutlined),
                                  createTextVNode(" Record Payment")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_MailOutlined, null, null, _parent6, _scopeId5));
                                _push6(` Send Invoice`);
                              } else {
                                return [
                                  createVNode(_component_MailOutlined),
                                  createTextVNode(" Send Invoice")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_CheckOutlined, null, null, _parent6, _scopeId5));
                                _push6(` Mark As Sent`);
                              } else {
                                return [
                                  createVNode(_component_CheckOutlined),
                                  createTextVNode(" Mark As Sent")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                              default: withCtx(() => [
                                createVNode(_component_EditOutlined)
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(_component_a_button, {
                              type: "primary",
                              onClick: _ctx.onClose
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_DeleteOutlined)
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(_component_a_dropdown, null, {
                              overlay: withCtx(() => [
                                createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "1" }, {
                                      default: withCtx(() => [
                                        createTextVNode(" PDF ")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_menu_item, { key: "2" }, {
                                      default: withCtx(() => [
                                        createTextVNode(" Print ")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])
                              ]),
                              default: withCtx(() => [
                                createVNode(_component_a_button, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_FilePdfOutlined),
                                    createTextVNode(" PDF / Print ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                              default: withCtx(() => [
                                createVNode(_component_PlusOutlined),
                                createTextVNode(" Record Payment")
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                              default: withCtx(() => [
                                createVNode(_component_MailOutlined),
                                createTextVNode(" Send Invoice")
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                              default: withCtx(() => [
                                createVNode(_component_CheckOutlined),
                                createTextVNode(" Mark As Sent")
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(`<div class="quote-template"${_scopeId3}><table style="${ssrRenderStyle({ "width": "100%" })}" class="quote-table"${_scopeId3}><tr${_scopeId3}><td colspan="2"${_scopeId3}><h2${_scopeId3}>INVOICE</h2><p${_scopeId3}><b${_scopeId3}>lynchpin</b></p><p${_scopeId3}>Tamil Nadu </p><p${_scopeId3}>India</p><p${_scopeId3}>mohana.lynchpin@gmail.com</p></td><td colspan="2" align="right"${_scopeId3}><img src="/images/logo-2.png" style="${ssrRenderStyle({ "max-width": "200px" })}"${_scopeId3}></td></tr><tr class="highlight"${_scopeId3}><td colspan="2"${_scopeId3}><p${_scopeId3}>Invoice Number : QT-000001</p><p${_scopeId3}>Invoice Date : 10/10/2023</p><p${_scopeId3}>Due Date : 10/10/2023</p></td><td colspan="2" align="right"${_scopeId3}><h4${_scopeId3}>INR 54000.00</h4><p${_scopeId3}><small${_scopeId3}>AMOUNT DUE</small></p></td></tr><tr${_scopeId3}><td colspan="4"${_scopeId3}><p${_scopeId3}><b${_scopeId3}>Bill To: </b></p><p${_scopeId3}>Mr John Doe</p><p${_scopeId3}>KK nagar</p><p${_scopeId3}>+91 9876543210</p><br${_scopeId3}></td></tr></table><table style="${ssrRenderStyle({ "width": "100%" })}" class="quote-table border"${_scopeId3}><tr${_scopeId3}><th align="left"${_scopeId3}>Item Details</th><th${_scopeId3}>Quantity</th><th${_scopeId3}>Rate</th><th width="100px" align="right"${_scopeId3}>Amount</th></tr><tr${_scopeId3}><td${_scopeId3}> item 1 <p${_scopeId3}>shopify Application development and service</p></td><td${_scopeId3}>1</td><td${_scopeId3}>0.00</td><td align="right"${_scopeId3}>0.00</td></tr><tr${_scopeId3}><td${_scopeId3}>item 2 <p${_scopeId3}>shopify Application development and service</p></td><td${_scopeId3}>1</td><td${_scopeId3}>0.00</td><td align="right"${_scopeId3}>0.00</td></tr><tr${_scopeId3}><td colspan="2"${_scopeId3}><div style="${ssrRenderStyle({ "margin-right": "20px" })}"${_scopeId3}><h5${_scopeId3}>Terms &amp; Conditions</h5><p${_scopeId3}>1. Payment should be made within 30 days from the date of invoice.</p><p${_scopeId3}>2. Goods once sold will not be taken back.</p><p${_scopeId3}>3. Interest @ 24% will be charged for the delay in payment.</p></div></td><td colspan="2" style="${ssrRenderStyle({ "padding": "0" })}"${_scopeId3}><table style="${ssrRenderStyle({ "width": "100%" })}"${_scopeId3}><tr${_scopeId3}><td colspan="3"${_scopeId3}>Sub Total</td><td width="100px" align="right"${_scopeId3}>0.00</td></tr><tr${_scopeId3}><td colspan="3"${_scopeId3}>Discount</td><td align="right"${_scopeId3}>0.00</td></tr><tr${_scopeId3}><td colspan="3"${_scopeId3}>Tax</td><td align="right"${_scopeId3}>0.00</td></tr><tr${_scopeId3}><td colspan="3"${_scopeId3}>Adjustment</td><td align="right"${_scopeId3}>0.00</td></tr><tr${_scopeId3}><td colspan="3"${_scopeId3}>Total</td><td align="right"${_scopeId3}>0.00</td></tr></table></td></tr></table></div>`);
                  } else {
                    return [
                      createVNode(_component_a_space, { style: { "margin-bottom": "10px" } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx(() => [
                              createVNode(_component_EditOutlined)
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(_component_a_button, {
                            type: "primary",
                            onClick: _ctx.onClose
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_DeleteOutlined)
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(_component_a_dropdown, null, {
                            overlay: withCtx(() => [
                              createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "1" }, {
                                    default: withCtx(() => [
                                      createTextVNode(" PDF ")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_menu_item, { key: "2" }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Print ")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["onClick"])
                            ]),
                            default: withCtx(() => [
                              createVNode(_component_a_button, null, {
                                default: withCtx(() => [
                                  createVNode(_component_FilePdfOutlined),
                                  createTextVNode(" PDF / Print ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx(() => [
                              createVNode(_component_PlusOutlined),
                              createTextVNode(" Record Payment")
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx(() => [
                              createVNode(_component_MailOutlined),
                              createTextVNode(" Send Invoice")
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx(() => [
                              createVNode(_component_CheckOutlined),
                              createTextVNode(" Mark As Sent")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        _: 1
                      }),
                      createVNode("div", { class: "quote-template" }, [
                        createVNode("table", {
                          style: { "width": "100%" },
                          class: "quote-table"
                        }, [
                          createVNode("tr", null, [
                            createVNode("td", { colspan: "2" }, [
                              createVNode("h2", null, "INVOICE"),
                              createVNode("p", null, [
                                createVNode("b", null, "lynchpin")
                              ]),
                              createVNode("p", null, "Tamil Nadu "),
                              createVNode("p", null, "India"),
                              createVNode("p", null, "mohana.lynchpin@gmail.com")
                            ]),
                            createVNode("td", {
                              colspan: "2",
                              align: "right"
                            }, [
                              createVNode("img", {
                                src: "/images/logo-2.png",
                                style: { "max-width": "200px" }
                              })
                            ])
                          ]),
                          createVNode("tr", { class: "highlight" }, [
                            createVNode("td", { colspan: "2" }, [
                              createVNode("p", null, "Invoice Number : QT-000001"),
                              createVNode("p", null, "Invoice Date : 10/10/2023"),
                              createVNode("p", null, "Due Date : 10/10/2023")
                            ]),
                            createVNode("td", {
                              colspan: "2",
                              align: "right"
                            }, [
                              createVNode("h4", null, "INR 54000.00"),
                              createVNode("p", null, [
                                createVNode("small", null, "AMOUNT DUE")
                              ])
                            ])
                          ]),
                          createVNode("tr", null, [
                            createVNode("td", { colspan: "4" }, [
                              createVNode("p", null, [
                                createVNode("b", null, "Bill To: ")
                              ]),
                              createVNode("p", null, "Mr John Doe"),
                              createVNode("p", null, "KK nagar"),
                              createVNode("p", null, "+91 9876543210"),
                              createVNode("br")
                            ])
                          ])
                        ]),
                        createVNode("table", {
                          style: { "width": "100%" },
                          class: "quote-table border"
                        }, [
                          createVNode("tr", null, [
                            createVNode("th", { align: "left" }, "Item Details"),
                            createVNode("th", null, "Quantity"),
                            createVNode("th", null, "Rate"),
                            createVNode("th", {
                              width: "100px",
                              align: "right"
                            }, "Amount")
                          ]),
                          createVNode("tr", null, [
                            createVNode("td", null, [
                              createTextVNode(" item 1 "),
                              createVNode("p", null, "shopify Application development and service")
                            ]),
                            createVNode("td", null, "1"),
                            createVNode("td", null, "0.00"),
                            createVNode("td", { align: "right" }, "0.00")
                          ]),
                          createVNode("tr", null, [
                            createVNode("td", null, [
                              createTextVNode("item 2 "),
                              createVNode("p", null, "shopify Application development and service")
                            ]),
                            createVNode("td", null, "1"),
                            createVNode("td", null, "0.00"),
                            createVNode("td", { align: "right" }, "0.00")
                          ]),
                          createVNode("tr", null, [
                            createVNode("td", { colspan: "2" }, [
                              createVNode("div", { style: { "margin-right": "20px" } }, [
                                createVNode("h5", null, "Terms & Conditions"),
                                createVNode("p", null, "1. Payment should be made within 30 days from the date of invoice."),
                                createVNode("p", null, "2. Goods once sold will not be taken back."),
                                createVNode("p", null, "3. Interest @ 24% will be charged for the delay in payment.")
                              ])
                            ]),
                            createVNode("td", {
                              colspan: "2",
                              style: { "padding": "0" }
                            }, [
                              createVNode("table", { style: { "width": "100%" } }, [
                                createVNode("tr", null, [
                                  createVNode("td", { colspan: "3" }, "Sub Total"),
                                  createVNode("td", {
                                    width: "100px",
                                    align: "right"
                                  }, "0.00")
                                ]),
                                createVNode("tr", null, [
                                  createVNode("td", { colspan: "3" }, "Discount"),
                                  createVNode("td", { align: "right" }, "0.00")
                                ]),
                                createVNode("tr", null, [
                                  createVNode("td", { colspan: "3" }, "Tax"),
                                  createVNode("td", { align: "right" }, "0.00")
                                ]),
                                createVNode("tr", null, [
                                  createVNode("td", { colspan: "3" }, "Adjustment"),
                                  createVNode("td", { align: "right" }, "0.00")
                                ]),
                                createVNode("tr", null, [
                                  createVNode("td", { colspan: "3" }, "Total"),
                                  createVNode("td", { align: "right" }, "0.00")
                                ])
                              ])
                            ])
                          ])
                        ])
                      ])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_space, {
                  direction: "vertical",
                  style: { width: "100%" }
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, {
                      name: "nest-messages",
                      model: $data.searchform,
                      layout: "inline",
                      onFinish: _ctx.search
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, {
                              placeholder: "Search by Invoice Number",
                              "allow-clear": true,
                              value: $data.searchform.term,
                              "onUpdate:value": ($event) => $data.searchform.term = $event
                            }, null, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Search ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              shape: "round",
                              onClick: $options.showDrawer
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_plus_circle_outlined)
                              ]),
                              default: withCtx(() => [
                                createTextVNode(" New Invoice ")
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["model", "onFinish"]),
                    createVNode(_component_a_table, {
                      columns: $setup.columns,
                      "data-source": $setup.invoices
                    }, {
                      bodyCell: withCtx(({ column, record }) => [
                        column.key === "invoice_number" ? (openBlock(), createBlock("a", {
                          key: 0,
                          onClick: $options.showDetailDrawer
                        }, toDisplayString(record.invoice_number), 9, ["onClick"])) : createCommentVNode("", true)
                      ]),
                      _: 1
                    }, 8, ["columns", "data-source"])
                  ]),
                  _: 1
                }),
                createVNode(_component_a_drawer, {
                  visible: $data.create_form_visible,
                  "onUpdate:visible": ($event) => $data.create_form_visible = $event,
                  class: "sales-bill",
                  size: "large",
                  style: { "color": "red" },
                  title: "New Invoice",
                  placement: "right",
                  onAfterVisibleChange: _ctx.afterVisibleChange
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, mergeProps({ model: $data.form }, _ctx.layout, {
                      name: "nest-messages",
                      "validate-messages": _ctx.validateMessages,
                      onFinish: _ctx.submit,
                      "label-col": { span: 24 },
                      style: { "min-height": "100%" }
                    }), {
                      default: withCtx(() => [
                        createVNode(_component_a_row, { gutter: 24 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "8"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "Customer",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      value: $data.form.tax,
                                      "onUpdate:value": ($event) => $data.form.tax = $event,
                                      "show-search": "",
                                      placeholder: "Select Customer",
                                      style: { "width": "100%" },
                                      "default-active-first-option": false,
                                      options: _ctx.customers,
                                      "not-found-content": _ctx.value
                                    }, null, 8, ["value", "onUpdate:value", "options", "not-found-content"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "8"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "Invoice Number",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $data.form.name,
                                      "onUpdate:value": ($event) => $data.form.name = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "8"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "Reference Number"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $data.form.name,
                                      "onUpdate:value": ($event) => $data.form.name = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "8"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "Invoice Date",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $data.form.name,
                                      "onUpdate:value": ($event) => $data.form.name = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "8"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "Expiry Date"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $data.form.name,
                                      "onUpdate:value": ($event) => $data.form.name = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "24"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "Subject",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $data.form.name,
                                      "onUpdate:value": ($event) => $data.form.name = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode("h4", { class: "t1" }, "Items / Services Info"),
                        createVNode(_component_a_table, {
                          columns: $setup.invoicecolumns,
                          "data-source": $setup.createInvoiceItems,
                          pagination: false
                        }, {
                          bodyCell: withCtx(({ column, record }) => [
                            column.key === "item_details" ? (openBlock(), createBlock(_component_a_space, {
                              key: 0,
                              direction: "vertical",
                              style: { "width": "100%" }
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: record.item_details,
                                  "onUpdate:value": ($event) => record.item_details = $event
                                }, null, 8, ["value", "onUpdate:value"]),
                                createVNode(_component_a_textarea, {
                                  value: record.item_details,
                                  "onUpdate:value": ($event) => record.item_details = $event,
                                  placeholder: "Item Description",
                                  "allow-clear": ""
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 2
                            }, 1024)) : createCommentVNode("", true),
                            column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                              key: 1,
                              value: record.quantity,
                              "onUpdate:value": ($event) => record.quantity = $event
                            }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                            column.key === "rate" ? (openBlock(), createBlock(_component_a_input, {
                              key: 2,
                              value: record.rate,
                              "onUpdate:value": ($event) => record.rate = $event
                            }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                            column.key === "amount" ? (openBlock(), createBlock(_component_a_input, {
                              key: 3,
                              value: record.amount,
                              "onUpdate:value": ($event) => record.amount = $event
                            }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                            column.key === "action" ? (openBlock(), createBlock(_component_a_space, { key: 4 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  size: "small"
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_CloseCircleOutlined)
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })) : createCommentVNode("", true)
                          ]),
                          _: 1
                        }, 8, ["columns", "data-source"]),
                        createVNode("br"),
                        createVNode(_component_a_space, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "success",
                              size: "small"
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_plus_circle_outlined)
                              ]),
                              default: withCtx(() => [
                                createTextVNode(" Add Good ")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_button, {
                              type: "success",
                              size: "small"
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_plus_circle_outlined)
                              ]),
                              default: withCtx(() => [
                                createTextVNode(" Add Service ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode("br"),
                        createVNode("br"),
                        createVNode(_component_a_row, { gutter: 24 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "Customer Notes",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_textarea, {
                                      value: $data.form.description,
                                      "onUpdate:value": ($event) => $data.form.description = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "Terms & Conditions",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_textarea, {
                                      value: $data.form.description,
                                      "onUpdate:value": ($event) => $data.form.description = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode("br"),
                                createVNode(_component_a_descriptions, {
                                  title: "",
                                  bordered: "",
                                  size: "small"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_descriptions_item, {
                                      label: "Sub Total",
                                      span: 4
                                    }, {
                                      default: withCtx(() => [
                                        createVNode("p", { class: "text-right m-0" }, "0.00")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_descriptions_item, {
                                      label: "Discount",
                                      span: 2
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { style: { "width": "100px" } })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_descriptions_item, { span: 2 }, {
                                      default: withCtx(() => [
                                        createTextVNode(" 0.00")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_descriptions_item, {
                                      label: "Tax",
                                      span: 2
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          value: $data.form.tax,
                                          "onUpdate:value": ($event) => $data.form.tax = $event,
                                          "show-search": "",
                                          placeholder: "Tax",
                                          style: { "width": "100px" },
                                          "default-active-first-option": false,
                                          "not-found-content": _ctx.value
                                        }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_descriptions_item, { span: 2 }, {
                                      default: withCtx(() => [
                                        createTextVNode(" 0.00")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_descriptions_item, {
                                      label: "Adjustment",
                                      span: 2
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { style: { "width": "100px" } })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_descriptions_item, { span: 2 }, {
                                      default: withCtx(() => [
                                        createTextVNode(" 0.00")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_descriptions_item, {
                                      label: "Total",
                                      span: 4
                                    }, {
                                      default: withCtx(() => [
                                        createVNode("h4", { class: "text-right" }, "0.00")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode("br"),
                        createVNode(_component_a_row, { gutter: 24 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "8"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit",
                                  disabled: $data.form.processing,
                                  block: ""
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("SAVE (F2)")
                                  ]),
                                  _: 1
                                }, 8, ["disabled"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "8"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit",
                                  disabled: $data.form.processing,
                                  block: ""
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("SAVE & SEND (F3)")
                                  ]),
                                  _: 1
                                }, 8, ["disabled"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "8"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit",
                                  disabled: $data.form.processing,
                                  block: ""
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("SAVE & PRINT (F5)")
                                  ]),
                                  _: 1
                                }, 8, ["disabled"])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 16, ["model", "validate-messages", "onFinish"])
                  ]),
                  _: 1
                }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"]),
                createVNode(_component_a_drawer, {
                  visible: $data.showdetail,
                  "onUpdate:visible": ($event) => $data.showdetail = $event,
                  class: "custom-class",
                  title: "QT-000001",
                  size: "large",
                  placement: "right",
                  onAfterVisibleChange: _ctx.afterVisibleChange
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_space, { style: { "margin-bottom": "10px" } }, {
                      default: withCtx(() => [
                        createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                          default: withCtx(() => [
                            createVNode(_component_EditOutlined)
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_component_a_button, {
                          type: "primary",
                          onClick: _ctx.onClose
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_DeleteOutlined)
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_component_a_dropdown, null, {
                          overlay: withCtx(() => [
                            createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "1" }, {
                                  default: withCtx(() => [
                                    createTextVNode(" PDF ")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_menu_item, { key: "2" }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Print ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ]),
                          default: withCtx(() => [
                            createVNode(_component_a_button, null, {
                              default: withCtx(() => [
                                createVNode(_component_FilePdfOutlined),
                                createTextVNode(" PDF / Print ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                          default: withCtx(() => [
                            createVNode(_component_PlusOutlined),
                            createTextVNode(" Record Payment")
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                          default: withCtx(() => [
                            createVNode(_component_MailOutlined),
                            createTextVNode(" Send Invoice")
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                          default: withCtx(() => [
                            createVNode(_component_CheckOutlined),
                            createTextVNode(" Mark As Sent")
                          ]),
                          _: 1
                        }, 8, ["onClick"])
                      ]),
                      _: 1
                    }),
                    createVNode("div", { class: "quote-template" }, [
                      createVNode("table", {
                        style: { "width": "100%" },
                        class: "quote-table"
                      }, [
                        createVNode("tr", null, [
                          createVNode("td", { colspan: "2" }, [
                            createVNode("h2", null, "INVOICE"),
                            createVNode("p", null, [
                              createVNode("b", null, "lynchpin")
                            ]),
                            createVNode("p", null, "Tamil Nadu "),
                            createVNode("p", null, "India"),
                            createVNode("p", null, "mohana.lynchpin@gmail.com")
                          ]),
                          createVNode("td", {
                            colspan: "2",
                            align: "right"
                          }, [
                            createVNode("img", {
                              src: "/images/logo-2.png",
                              style: { "max-width": "200px" }
                            })
                          ])
                        ]),
                        createVNode("tr", { class: "highlight" }, [
                          createVNode("td", { colspan: "2" }, [
                            createVNode("p", null, "Invoice Number : QT-000001"),
                            createVNode("p", null, "Invoice Date : 10/10/2023"),
                            createVNode("p", null, "Due Date : 10/10/2023")
                          ]),
                          createVNode("td", {
                            colspan: "2",
                            align: "right"
                          }, [
                            createVNode("h4", null, "INR 54000.00"),
                            createVNode("p", null, [
                              createVNode("small", null, "AMOUNT DUE")
                            ])
                          ])
                        ]),
                        createVNode("tr", null, [
                          createVNode("td", { colspan: "4" }, [
                            createVNode("p", null, [
                              createVNode("b", null, "Bill To: ")
                            ]),
                            createVNode("p", null, "Mr John Doe"),
                            createVNode("p", null, "KK nagar"),
                            createVNode("p", null, "+91 9876543210"),
                            createVNode("br")
                          ])
                        ])
                      ]),
                      createVNode("table", {
                        style: { "width": "100%" },
                        class: "quote-table border"
                      }, [
                        createVNode("tr", null, [
                          createVNode("th", { align: "left" }, "Item Details"),
                          createVNode("th", null, "Quantity"),
                          createVNode("th", null, "Rate"),
                          createVNode("th", {
                            width: "100px",
                            align: "right"
                          }, "Amount")
                        ]),
                        createVNode("tr", null, [
                          createVNode("td", null, [
                            createTextVNode(" item 1 "),
                            createVNode("p", null, "shopify Application development and service")
                          ]),
                          createVNode("td", null, "1"),
                          createVNode("td", null, "0.00"),
                          createVNode("td", { align: "right" }, "0.00")
                        ]),
                        createVNode("tr", null, [
                          createVNode("td", null, [
                            createTextVNode("item 2 "),
                            createVNode("p", null, "shopify Application development and service")
                          ]),
                          createVNode("td", null, "1"),
                          createVNode("td", null, "0.00"),
                          createVNode("td", { align: "right" }, "0.00")
                        ]),
                        createVNode("tr", null, [
                          createVNode("td", { colspan: "2" }, [
                            createVNode("div", { style: { "margin-right": "20px" } }, [
                              createVNode("h5", null, "Terms & Conditions"),
                              createVNode("p", null, "1. Payment should be made within 30 days from the date of invoice."),
                              createVNode("p", null, "2. Goods once sold will not be taken back."),
                              createVNode("p", null, "3. Interest @ 24% will be charged for the delay in payment.")
                            ])
                          ]),
                          createVNode("td", {
                            colspan: "2",
                            style: { "padding": "0" }
                          }, [
                            createVNode("table", { style: { "width": "100%" } }, [
                              createVNode("tr", null, [
                                createVNode("td", { colspan: "3" }, "Sub Total"),
                                createVNode("td", {
                                  width: "100px",
                                  align: "right"
                                }, "0.00")
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", { colspan: "3" }, "Discount"),
                                createVNode("td", { align: "right" }, "0.00")
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", { colspan: "3" }, "Tax"),
                                createVNode("td", { align: "right" }, "0.00")
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", { colspan: "3" }, "Adjustment"),
                                createVNode("td", { align: "right" }, "0.00")
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", { colspan: "3" }, "Total"),
                                createVNode("td", { align: "right" }, "0.00")
                              ])
                            ])
                          ])
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_layout_content, null, {
            default: withCtx(() => [
              createVNode(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, {
                    name: "nest-messages",
                    model: $data.searchform,
                    layout: "inline",
                    onFinish: _ctx.search
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            placeholder: "Search by Invoice Number",
                            "allow-clear": true,
                            value: $data.searchform.term,
                            "onUpdate:value": ($event) => $data.searchform.term = $event
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Search ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            shape: "round",
                            onClick: $options.showDrawer
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_plus_circle_outlined)
                            ]),
                            default: withCtx(() => [
                              createTextVNode(" New Invoice ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["model", "onFinish"]),
                  createVNode(_component_a_table, {
                    columns: $setup.columns,
                    "data-source": $setup.invoices
                  }, {
                    bodyCell: withCtx(({ column, record }) => [
                      column.key === "invoice_number" ? (openBlock(), createBlock("a", {
                        key: 0,
                        onClick: $options.showDetailDrawer
                      }, toDisplayString(record.invoice_number), 9, ["onClick"])) : createCommentVNode("", true)
                    ]),
                    _: 1
                  }, 8, ["columns", "data-source"])
                ]),
                _: 1
              }),
              createVNode(_component_a_drawer, {
                visible: $data.create_form_visible,
                "onUpdate:visible": ($event) => $data.create_form_visible = $event,
                class: "sales-bill",
                size: "large",
                style: { "color": "red" },
                title: "New Invoice",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, mergeProps({ model: $data.form }, _ctx.layout, {
                    name: "nest-messages",
                    "validate-messages": _ctx.validateMessages,
                    onFinish: _ctx.submit,
                    "label-col": { span: 24 },
                    style: { "min-height": "100%" }
                  }), {
                    default: withCtx(() => [
                      createVNode(_component_a_row, { gutter: 24 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "8"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "Customer",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    value: $data.form.tax,
                                    "onUpdate:value": ($event) => $data.form.tax = $event,
                                    "show-search": "",
                                    placeholder: "Select Customer",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    options: _ctx.customers,
                                    "not-found-content": _ctx.value
                                  }, null, 8, ["value", "onUpdate:value", "options", "not-found-content"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "8"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "Invoice Number",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $data.form.name,
                                    "onUpdate:value": ($event) => $data.form.name = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "8"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "Reference Number"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $data.form.name,
                                    "onUpdate:value": ($event) => $data.form.name = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "8"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "Invoice Date",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $data.form.name,
                                    "onUpdate:value": ($event) => $data.form.name = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "8"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "Expiry Date"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $data.form.name,
                                    "onUpdate:value": ($event) => $data.form.name = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "24"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "Subject",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $data.form.name,
                                    "onUpdate:value": ($event) => $data.form.name = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode("h4", { class: "t1" }, "Items / Services Info"),
                      createVNode(_component_a_table, {
                        columns: $setup.invoicecolumns,
                        "data-source": $setup.createInvoiceItems,
                        pagination: false
                      }, {
                        bodyCell: withCtx(({ column, record }) => [
                          column.key === "item_details" ? (openBlock(), createBlock(_component_a_space, {
                            key: 0,
                            direction: "vertical",
                            style: { "width": "100%" }
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: record.item_details,
                                "onUpdate:value": ($event) => record.item_details = $event
                              }, null, 8, ["value", "onUpdate:value"]),
                              createVNode(_component_a_textarea, {
                                value: record.item_details,
                                "onUpdate:value": ($event) => record.item_details = $event,
                                placeholder: "Item Description",
                                "allow-clear": ""
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 2
                          }, 1024)) : createCommentVNode("", true),
                          column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                            key: 1,
                            value: record.quantity,
                            "onUpdate:value": ($event) => record.quantity = $event
                          }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                          column.key === "rate" ? (openBlock(), createBlock(_component_a_input, {
                            key: 2,
                            value: record.rate,
                            "onUpdate:value": ($event) => record.rate = $event
                          }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                          column.key === "amount" ? (openBlock(), createBlock(_component_a_input, {
                            key: 3,
                            value: record.amount,
                            "onUpdate:value": ($event) => record.amount = $event
                          }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                          column.key === "action" ? (openBlock(), createBlock(_component_a_space, { key: 4 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                size: "small"
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_CloseCircleOutlined)
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })) : createCommentVNode("", true)
                        ]),
                        _: 1
                      }, 8, ["columns", "data-source"]),
                      createVNode("br"),
                      createVNode(_component_a_space, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "success",
                            size: "small"
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_plus_circle_outlined)
                            ]),
                            default: withCtx(() => [
                              createTextVNode(" Add Good ")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_button, {
                            type: "success",
                            size: "small"
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_plus_circle_outlined)
                            ]),
                            default: withCtx(() => [
                              createTextVNode(" Add Service ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode("br"),
                      createVNode("br"),
                      createVNode(_component_a_row, { gutter: 24 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "Customer Notes",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_textarea, {
                                    value: $data.form.description,
                                    "onUpdate:value": ($event) => $data.form.description = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "Terms & Conditions",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_textarea, {
                                    value: $data.form.description,
                                    "onUpdate:value": ($event) => $data.form.description = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode("br"),
                              createVNode(_component_a_descriptions, {
                                title: "",
                                bordered: "",
                                size: "small"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_descriptions_item, {
                                    label: "Sub Total",
                                    span: 4
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("p", { class: "text-right m-0" }, "0.00")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_descriptions_item, {
                                    label: "Discount",
                                    span: 2
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { style: { "width": "100px" } })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_descriptions_item, { span: 2 }, {
                                    default: withCtx(() => [
                                      createTextVNode(" 0.00")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_descriptions_item, {
                                    label: "Tax",
                                    span: 2
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        value: $data.form.tax,
                                        "onUpdate:value": ($event) => $data.form.tax = $event,
                                        "show-search": "",
                                        placeholder: "Tax",
                                        style: { "width": "100px" },
                                        "default-active-first-option": false,
                                        "not-found-content": _ctx.value
                                      }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_descriptions_item, { span: 2 }, {
                                    default: withCtx(() => [
                                      createTextVNode(" 0.00")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_descriptions_item, {
                                    label: "Adjustment",
                                    span: 2
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { style: { "width": "100px" } })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_descriptions_item, { span: 2 }, {
                                    default: withCtx(() => [
                                      createTextVNode(" 0.00")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_descriptions_item, {
                                    label: "Total",
                                    span: 4
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("h4", { class: "text-right" }, "0.00")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode("br"),
                      createVNode(_component_a_row, { gutter: 24 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "8"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit",
                                disabled: $data.form.processing,
                                block: ""
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("SAVE (F2)")
                                ]),
                                _: 1
                              }, 8, ["disabled"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "8"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit",
                                disabled: $data.form.processing,
                                block: ""
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("SAVE & SEND (F3)")
                                ]),
                                _: 1
                              }, 8, ["disabled"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "8"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit",
                                disabled: $data.form.processing,
                                block: ""
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("SAVE & PRINT (F5)")
                                ]),
                                _: 1
                              }, 8, ["disabled"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 16, ["model", "validate-messages", "onFinish"])
                ]),
                _: 1
              }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"]),
              createVNode(_component_a_drawer, {
                visible: $data.showdetail,
                "onUpdate:visible": ($event) => $data.showdetail = $event,
                class: "custom-class",
                title: "QT-000001",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_space, { style: { "margin-bottom": "10px" } }, {
                    default: withCtx(() => [
                      createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                        default: withCtx(() => [
                          createVNode(_component_EditOutlined)
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_button, {
                        type: "primary",
                        onClick: _ctx.onClose
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_DeleteOutlined)
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_dropdown, null, {
                        overlay: withCtx(() => [
                          createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "1" }, {
                                default: withCtx(() => [
                                  createTextVNode(" PDF ")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_menu_item, { key: "2" }, {
                                default: withCtx(() => [
                                  createTextVNode(" Print ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        default: withCtx(() => [
                          createVNode(_component_a_button, null, {
                            default: withCtx(() => [
                              createVNode(_component_FilePdfOutlined),
                              createTextVNode(" PDF / Print ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                        default: withCtx(() => [
                          createVNode(_component_PlusOutlined),
                          createTextVNode(" Record Payment")
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                        default: withCtx(() => [
                          createVNode(_component_MailOutlined),
                          createTextVNode(" Send Invoice")
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                        default: withCtx(() => [
                          createVNode(_component_CheckOutlined),
                          createTextVNode(" Mark As Sent")
                        ]),
                        _: 1
                      }, 8, ["onClick"])
                    ]),
                    _: 1
                  }),
                  createVNode("div", { class: "quote-template" }, [
                    createVNode("table", {
                      style: { "width": "100%" },
                      class: "quote-table"
                    }, [
                      createVNode("tr", null, [
                        createVNode("td", { colspan: "2" }, [
                          createVNode("h2", null, "INVOICE"),
                          createVNode("p", null, [
                            createVNode("b", null, "lynchpin")
                          ]),
                          createVNode("p", null, "Tamil Nadu "),
                          createVNode("p", null, "India"),
                          createVNode("p", null, "mohana.lynchpin@gmail.com")
                        ]),
                        createVNode("td", {
                          colspan: "2",
                          align: "right"
                        }, [
                          createVNode("img", {
                            src: "/images/logo-2.png",
                            style: { "max-width": "200px" }
                          })
                        ])
                      ]),
                      createVNode("tr", { class: "highlight" }, [
                        createVNode("td", { colspan: "2" }, [
                          createVNode("p", null, "Invoice Number : QT-000001"),
                          createVNode("p", null, "Invoice Date : 10/10/2023"),
                          createVNode("p", null, "Due Date : 10/10/2023")
                        ]),
                        createVNode("td", {
                          colspan: "2",
                          align: "right"
                        }, [
                          createVNode("h4", null, "INR 54000.00"),
                          createVNode("p", null, [
                            createVNode("small", null, "AMOUNT DUE")
                          ])
                        ])
                      ]),
                      createVNode("tr", null, [
                        createVNode("td", { colspan: "4" }, [
                          createVNode("p", null, [
                            createVNode("b", null, "Bill To: ")
                          ]),
                          createVNode("p", null, "Mr John Doe"),
                          createVNode("p", null, "KK nagar"),
                          createVNode("p", null, "+91 9876543210"),
                          createVNode("br")
                        ])
                      ])
                    ]),
                    createVNode("table", {
                      style: { "width": "100%" },
                      class: "quote-table border"
                    }, [
                      createVNode("tr", null, [
                        createVNode("th", { align: "left" }, "Item Details"),
                        createVNode("th", null, "Quantity"),
                        createVNode("th", null, "Rate"),
                        createVNode("th", {
                          width: "100px",
                          align: "right"
                        }, "Amount")
                      ]),
                      createVNode("tr", null, [
                        createVNode("td", null, [
                          createTextVNode(" item 1 "),
                          createVNode("p", null, "shopify Application development and service")
                        ]),
                        createVNode("td", null, "1"),
                        createVNode("td", null, "0.00"),
                        createVNode("td", { align: "right" }, "0.00")
                      ]),
                      createVNode("tr", null, [
                        createVNode("td", null, [
                          createTextVNode("item 2 "),
                          createVNode("p", null, "shopify Application development and service")
                        ]),
                        createVNode("td", null, "1"),
                        createVNode("td", null, "0.00"),
                        createVNode("td", { align: "right" }, "0.00")
                      ]),
                      createVNode("tr", null, [
                        createVNode("td", { colspan: "2" }, [
                          createVNode("div", { style: { "margin-right": "20px" } }, [
                            createVNode("h5", null, "Terms & Conditions"),
                            createVNode("p", null, "1. Payment should be made within 30 days from the date of invoice."),
                            createVNode("p", null, "2. Goods once sold will not be taken back."),
                            createVNode("p", null, "3. Interest @ 24% will be charged for the delay in payment.")
                          ])
                        ]),
                        createVNode("td", {
                          colspan: "2",
                          style: { "padding": "0" }
                        }, [
                          createVNode("table", { style: { "width": "100%" } }, [
                            createVNode("tr", null, [
                              createVNode("td", { colspan: "3" }, "Sub Total"),
                              createVNode("td", {
                                width: "100px",
                                align: "right"
                              }, "0.00")
                            ]),
                            createVNode("tr", null, [
                              createVNode("td", { colspan: "3" }, "Discount"),
                              createVNode("td", { align: "right" }, "0.00")
                            ]),
                            createVNode("tr", null, [
                              createVNode("td", { colspan: "3" }, "Tax"),
                              createVNode("td", { align: "right" }, "0.00")
                            ]),
                            createVNode("tr", null, [
                              createVNode("td", { colspan: "3" }, "Adjustment"),
                              createVNode("td", { align: "right" }, "0.00")
                            ]),
                            createVNode("tr", null, [
                              createVNode("td", { colspan: "3" }, "Total"),
                              createVNode("td", { align: "right" }, "0.00")
                            ])
                          ])
                        ])
                      ])
                    ])
                  ])
                ]),
                _: 1
              }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"])
            ]),
            _: 1
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Invoice/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Index as default
};
