import { useSSRContext, ref, resolveComponent, withCtx, unref, createVNode, createTextVNode, openBlock, createBlock, renderSlot } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrRenderSlot } from "vue/server-renderer";
import { Link } from "@inertiajs/vue3";
import { message } from "ant-design-vue";
import { LineChartOutlined, AppstoreOutlined, SlidersOutlined, BoxPlotOutlined, DollarCircleOutlined, PieChartOutlined, MenuUnfoldOutlined, MenuFoldOutlined } from "@ant-design/icons-vue";
const _sfc_main$1 = {
  watch: {
    "$page.props.flash.message": {
      handler() {
        if (this.$page.props.flash.message) {
          message.success(this.$page.props.flash.message);
        }
      },
      deep: true
    },
    "$page.props.flash.error": {
      handler() {
        if (this.$page.props.flash.error) {
          message.error(this.$page.props.flash.error);
        }
      },
      deep: true
    }
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/FlashMessage.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "AuthenticatedLayout",
  __ssrInlineRender: true,
  setup(__props) {
    ref(false);
    const collapsed = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_a_layout = resolveComponent("a-layout");
      const _component_a_layout_sider = resolveComponent("a-layout-sider");
      const _component_a_menu = resolveComponent("a-menu");
      const _component_a_menu_item = resolveComponent("a-menu-item");
      const _component_a_sub_menu = resolveComponent("a-sub-menu");
      const _component_a_layout_header = resolveComponent("a-layout-header");
      const _component_a_row = resolveComponent("a-row");
      const _component_a_col = resolveComponent("a-col");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_sfc_main$1, null, null, _parent));
      _push(ssrRenderComponent(_component_a_layout, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_a_layout_sider, {
              collapsed: collapsed.value,
              "onUpdate:collapsed": ($event) => collapsed.value = $event,
              trigger: null,
              collapsible: "",
              style: { overflow: "auto", height: "100vh", position: "fixed", left: 0, top: 0, bottom: 0 }
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="logo"${_scopeId2}><img${ssrRenderAttr("src", "/images/logo-2.png")} class="logo1"${_scopeId2}><img${ssrRenderAttr("src", "/images/icon mozitz-min 2.png")} class="collapsed-logo"${_scopeId2}></div>`);
                  _push3(ssrRenderComponent(_component_a_menu, {
                    selectedKeys: _ctx.selectedKeys,
                    "onUpdate:selectedKeys": ($event) => _ctx.selectedKeys = $event,
                    theme: "dark",
                    mode: "inline"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(Link), {
                          href: _ctx.route("dashboard")
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_a_menu_item, { key: "dashboard" }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(unref(LineChartOutlined), null, null, _parent6, _scopeId5));
                                    _push6(`<span${_scopeId5}>Dashboard</span>`);
                                  } else {
                                    return [
                                      createVNode(unref(LineChartOutlined)),
                                      createVNode("span", null, "Dashboard")
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_a_menu_item, { key: "dashboard" }, {
                                  default: withCtx(() => [
                                    createVNode(unref(LineChartOutlined)),
                                    createVNode("span", null, "Dashboard")
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_a_sub_menu, { key: "sub5" }, {
                          title: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<span${_scopeId4}>`);
                              _push5(ssrRenderComponent(unref(AppstoreOutlined), null, null, _parent5, _scopeId4));
                              _push5(`<span${_scopeId4}>Items</span></span>`);
                            } else {
                              return [
                                createVNode("span", null, [
                                  createVNode(unref(AppstoreOutlined)),
                                  createVNode("span", null, "Items")
                                ])
                              ];
                            }
                          }),
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(unref(Link), {
                                href: _ctx.route("products.index")
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu_item, { key: "products" }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Goods`);
                                        } else {
                                          return [
                                            createTextVNode("Goods")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu_item, { key: "products" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Goods")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(unref(Link), {
                                href: _ctx.route("services.index")
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu_item, { key: "services" }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Services`);
                                        } else {
                                          return [
                                            createTextVNode("Services")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu_item, { key: "services" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Services")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(_component_a_menu_item, { key: "3" }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`Inventory`);
                                  } else {
                                    return [
                                      createTextVNode("Inventory")
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(unref(Link), {
                                  href: _ctx.route("products.index")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "products" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Goods")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                createVNode(unref(Link), {
                                  href: _ctx.route("services.index")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "services" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Services")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                createVNode(_component_a_menu_item, { key: "3" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Inventory")
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_a_sub_menu, { key: "sales" }, {
                          title: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<span${_scopeId4}>`);
                              _push5(ssrRenderComponent(unref(SlidersOutlined), null, null, _parent5, _scopeId4));
                              _push5(`<span${_scopeId4}>Sales</span></span>`);
                            } else {
                              return [
                                createVNode("span", null, [
                                  createVNode(unref(SlidersOutlined)),
                                  createVNode("span", null, "Sales")
                                ])
                              ];
                            }
                          }),
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(unref(Link), {
                                href: _ctx.route("customers.index")
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu_item, { key: "4" }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Customers`);
                                        } else {
                                          return [
                                            createTextVNode("Customers")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu_item, { key: "4" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Customers")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(unref(Link), {
                                href: _ctx.route("quotes.index")
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu_item, { key: "5" }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Quotes`);
                                        } else {
                                          return [
                                            createTextVNode("Quotes")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu_item, { key: "5" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Quotes")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(unref(Link), {
                                href: _ctx.route("invoices.index")
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu_item, { key: "6" }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Invoices`);
                                        } else {
                                          return [
                                            createTextVNode("Invoices")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu_item, { key: "6" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Invoices")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(unref(Link), {
                                href: _ctx.route("payments.index")
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu_item, { key: "7" }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Payments`);
                                        } else {
                                          return [
                                            createTextVNode("Payments")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu_item, { key: "7" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Payments")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(unref(Link), {
                                href: _ctx.route("creditnotes.index")
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu_item, { key: "creditnotes" }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Credit Notes`);
                                        } else {
                                          return [
                                            createTextVNode("Credit Notes")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu_item, { key: "creditnotes" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Credit Notes")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(unref(Link), {
                                  href: _ctx.route("customers.index")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "4" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Customers")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                createVNode(unref(Link), {
                                  href: _ctx.route("quotes.index")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "5" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Quotes")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                createVNode(unref(Link), {
                                  href: _ctx.route("invoices.index")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "6" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Invoices")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                createVNode(unref(Link), {
                                  href: _ctx.route("payments.index")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "7" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Payments")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                createVNode(unref(Link), {
                                  href: _ctx.route("creditnotes.index")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "creditnotes" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Credit Notes")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_a_sub_menu, { key: "sub2" }, {
                          title: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<span${_scopeId4}>`);
                              _push5(ssrRenderComponent(unref(BoxPlotOutlined), null, null, _parent5, _scopeId4));
                              _push5(`<span${_scopeId4}>Purchase</span></span>`);
                            } else {
                              return [
                                createVNode("span", null, [
                                  createVNode(unref(BoxPlotOutlined)),
                                  createVNode("span", null, "Purchase")
                                ])
                              ];
                            }
                          }),
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(unref(Link), {
                                href: _ctx.route("vendors.index")
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu_item, { key: "1" }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Vendors`);
                                        } else {
                                          return [
                                            createTextVNode("Vendors")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu_item, { key: "1" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Vendors")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(unref(Link), {
                                href: _ctx.route("purchaseorders.index")
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu_item, { key: "purchaseorders3" }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Purchase Orders`);
                                        } else {
                                          return [
                                            createTextVNode("Purchase Orders")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu_item, { key: "purchaseorders3" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Purchase Orders")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(unref(Link), {
                                href: _ctx.route("bills.index")
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu_item, { key: "3" }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Bills`);
                                        } else {
                                          return [
                                            createTextVNode("Bills")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu_item, { key: "3" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Bills")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(unref(Link), {
                                href: _ctx.route("payments.index")
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu_item, { key: "payments3" }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Payments`);
                                        } else {
                                          return [
                                            createTextVNode("Payments")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu_item, { key: "payments3" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Payments")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(unref(Link), {
                                href: _ctx.route("creditnotes.index")
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu_item, { key: "creditnotes3" }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Vendor Credits`);
                                        } else {
                                          return [
                                            createTextVNode("Vendor Credits")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu_item, { key: "creditnotes3" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Vendor Credits")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(unref(Link), {
                                  href: _ctx.route("vendors.index")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "1" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Vendors")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                createVNode(unref(Link), {
                                  href: _ctx.route("purchaseorders.index")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "purchaseorders3" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Purchase Orders")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                createVNode(unref(Link), {
                                  href: _ctx.route("bills.index")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "3" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Bills")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                createVNode(unref(Link), {
                                  href: _ctx.route("payments.index")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "payments3" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Payments")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                createVNode(unref(Link), {
                                  href: _ctx.route("creditnotes.index")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "creditnotes3" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Vendor Credits")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_a_sub_menu, { key: "Production" }, {
                          title: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<span${_scopeId4}>`);
                              _push5(ssrRenderComponent(unref(BoxPlotOutlined), null, null, _parent5, _scopeId4));
                              _push5(`<span${_scopeId4}>Production</span></span>`);
                            } else {
                              return [
                                createVNode("span", null, [
                                  createVNode(unref(BoxPlotOutlined)),
                                  createVNode("span", null, "Production")
                                ])
                              ];
                            }
                          }),
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(unref(Link), {
                                href: _ctx.route("rawmaterials.index")
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu_item, { key: "rawmaterials" }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Raw materials`);
                                        } else {
                                          return [
                                            createTextVNode("Raw materials")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu_item, { key: "rawmaterials" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Raw materials")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(unref(Link), {
                                href: _ctx.route("joborders.index")
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu_item, { key: "joborders" }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Job Orders`);
                                        } else {
                                          return [
                                            createTextVNode("Job Orders")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu_item, { key: "joborders" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Job Orders")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(unref(Link), {
                                href: _ctx.route("billofmaterials.index")
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu_item, { key: "rawmaterials" }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Bill of materials`);
                                        } else {
                                          return [
                                            createTextVNode("Bill of materials")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu_item, { key: "rawmaterials" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Bill of materials")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(unref(Link), {
                                  href: _ctx.route("rawmaterials.index")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "rawmaterials" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Raw materials")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                createVNode(unref(Link), {
                                  href: _ctx.route("joborders.index")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "joborders" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Job Orders")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                createVNode(unref(Link), {
                                  href: _ctx.route("billofmaterials.index")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "rawmaterials" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Bill of materials")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_a_menu_item, { key: "sub3" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(unref(DollarCircleOutlined), null, null, _parent5, _scopeId4));
                              _push5(`<span${_scopeId4}>Expenses</span>`);
                            } else {
                              return [
                                createVNode(unref(DollarCircleOutlined)),
                                createVNode("span", null, "Expenses")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_a_menu_item, { key: "sub4" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(unref(PieChartOutlined), null, null, _parent5, _scopeId4));
                              _push5(`<span${_scopeId4}>Reports</span>`);
                            } else {
                              return [
                                createVNode(unref(PieChartOutlined)),
                                createVNode("span", null, "Reports")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(Link), {
                            href: _ctx.route("dashboard")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "dashboard" }, {
                                default: withCtx(() => [
                                  createVNode(unref(LineChartOutlined)),
                                  createVNode("span", null, "Dashboard")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(_component_a_sub_menu, { key: "sub5" }, {
                            title: withCtx(() => [
                              createVNode("span", null, [
                                createVNode(unref(AppstoreOutlined)),
                                createVNode("span", null, "Items")
                              ])
                            ]),
                            default: withCtx(() => [
                              createVNode(unref(Link), {
                                href: _ctx.route("products.index")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "products" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Goods")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(unref(Link), {
                                href: _ctx.route("services.index")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "services" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Services")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(_component_a_menu_item, { key: "3" }, {
                                default: withCtx(() => [
                                  createTextVNode("Inventory")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_sub_menu, { key: "sales" }, {
                            title: withCtx(() => [
                              createVNode("span", null, [
                                createVNode(unref(SlidersOutlined)),
                                createVNode("span", null, "Sales")
                              ])
                            ]),
                            default: withCtx(() => [
                              createVNode(unref(Link), {
                                href: _ctx.route("customers.index")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "4" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Customers")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(unref(Link), {
                                href: _ctx.route("quotes.index")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "5" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Quotes")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(unref(Link), {
                                href: _ctx.route("invoices.index")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "6" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Invoices")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(unref(Link), {
                                href: _ctx.route("payments.index")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "7" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Payments")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(unref(Link), {
                                href: _ctx.route("creditnotes.index")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "creditnotes" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Credit Notes")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_sub_menu, { key: "sub2" }, {
                            title: withCtx(() => [
                              createVNode("span", null, [
                                createVNode(unref(BoxPlotOutlined)),
                                createVNode("span", null, "Purchase")
                              ])
                            ]),
                            default: withCtx(() => [
                              createVNode(unref(Link), {
                                href: _ctx.route("vendors.index")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "1" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Vendors")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(unref(Link), {
                                href: _ctx.route("purchaseorders.index")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "purchaseorders3" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Purchase Orders")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(unref(Link), {
                                href: _ctx.route("bills.index")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "3" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Bills")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(unref(Link), {
                                href: _ctx.route("payments.index")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "payments3" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Payments")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(unref(Link), {
                                href: _ctx.route("creditnotes.index")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "creditnotes3" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Vendor Credits")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_sub_menu, { key: "Production" }, {
                            title: withCtx(() => [
                              createVNode("span", null, [
                                createVNode(unref(BoxPlotOutlined)),
                                createVNode("span", null, "Production")
                              ])
                            ]),
                            default: withCtx(() => [
                              createVNode(unref(Link), {
                                href: _ctx.route("rawmaterials.index")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "rawmaterials" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Raw materials")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(unref(Link), {
                                href: _ctx.route("joborders.index")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "joborders" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Job Orders")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(unref(Link), {
                                href: _ctx.route("billofmaterials.index")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "rawmaterials" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Bill of materials")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_menu_item, { key: "sub3" }, {
                            default: withCtx(() => [
                              createVNode(unref(DollarCircleOutlined)),
                              createVNode("span", null, "Expenses")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_menu_item, { key: "sub4" }, {
                            default: withCtx(() => [
                              createVNode(unref(PieChartOutlined)),
                              createVNode("span", null, "Reports")
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode("div", { class: "logo" }, [
                      createVNode("img", {
                        src: "/images/logo-2.png",
                        class: "logo1"
                      }, null, 8, ["src"]),
                      createVNode("img", {
                        src: "/images/icon mozitz-min 2.png",
                        class: "collapsed-logo"
                      }, null, 8, ["src"])
                    ]),
                    createVNode(_component_a_menu, {
                      selectedKeys: _ctx.selectedKeys,
                      "onUpdate:selectedKeys": ($event) => _ctx.selectedKeys = $event,
                      theme: "dark",
                      mode: "inline"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(Link), {
                          href: _ctx.route("dashboard")
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_menu_item, { key: "dashboard" }, {
                              default: withCtx(() => [
                                createVNode(unref(LineChartOutlined)),
                                createVNode("span", null, "Dashboard")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode(_component_a_sub_menu, { key: "sub5" }, {
                          title: withCtx(() => [
                            createVNode("span", null, [
                              createVNode(unref(AppstoreOutlined)),
                              createVNode("span", null, "Items")
                            ])
                          ]),
                          default: withCtx(() => [
                            createVNode(unref(Link), {
                              href: _ctx.route("products.index")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "products" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Goods")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(unref(Link), {
                              href: _ctx.route("services.index")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "services" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Services")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(_component_a_menu_item, { key: "3" }, {
                              default: withCtx(() => [
                                createTextVNode("Inventory")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_sub_menu, { key: "sales" }, {
                          title: withCtx(() => [
                            createVNode("span", null, [
                              createVNode(unref(SlidersOutlined)),
                              createVNode("span", null, "Sales")
                            ])
                          ]),
                          default: withCtx(() => [
                            createVNode(unref(Link), {
                              href: _ctx.route("customers.index")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "4" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Customers")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(unref(Link), {
                              href: _ctx.route("quotes.index")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "5" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Quotes")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(unref(Link), {
                              href: _ctx.route("invoices.index")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "6" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Invoices")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(unref(Link), {
                              href: _ctx.route("payments.index")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "7" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Payments")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(unref(Link), {
                              href: _ctx.route("creditnotes.index")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "creditnotes" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Credit Notes")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_sub_menu, { key: "sub2" }, {
                          title: withCtx(() => [
                            createVNode("span", null, [
                              createVNode(unref(BoxPlotOutlined)),
                              createVNode("span", null, "Purchase")
                            ])
                          ]),
                          default: withCtx(() => [
                            createVNode(unref(Link), {
                              href: _ctx.route("vendors.index")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "1" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Vendors")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(unref(Link), {
                              href: _ctx.route("purchaseorders.index")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "purchaseorders3" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Purchase Orders")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(unref(Link), {
                              href: _ctx.route("bills.index")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "3" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Bills")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(unref(Link), {
                              href: _ctx.route("payments.index")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "payments3" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Payments")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(unref(Link), {
                              href: _ctx.route("creditnotes.index")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "creditnotes3" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Vendor Credits")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_sub_menu, { key: "Production" }, {
                          title: withCtx(() => [
                            createVNode("span", null, [
                              createVNode(unref(BoxPlotOutlined)),
                              createVNode("span", null, "Production")
                            ])
                          ]),
                          default: withCtx(() => [
                            createVNode(unref(Link), {
                              href: _ctx.route("rawmaterials.index")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "rawmaterials" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Raw materials")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(unref(Link), {
                              href: _ctx.route("joborders.index")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "joborders" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Job Orders")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(unref(Link), {
                              href: _ctx.route("billofmaterials.index")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "rawmaterials" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Bill of materials")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_menu_item, { key: "sub3" }, {
                          default: withCtx(() => [
                            createVNode(unref(DollarCircleOutlined)),
                            createVNode("span", null, "Expenses")
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_menu_item, { key: "sub4" }, {
                          default: withCtx(() => [
                            createVNode(unref(PieChartOutlined)),
                            createVNode("span", null, "Reports")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["selectedKeys", "onUpdate:selectedKeys"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_a_layout, {
              collapsed: collapsed.value,
              "onUpdate:collapsed": ($event) => collapsed.value = $event,
              style: { marginLeft: "200px" }
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_a_layout_header, null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_a_row, { type: "flex" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_a_col, { flex: "100px" }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    if (collapsed.value) {
                                      _push6(ssrRenderComponent(unref(MenuUnfoldOutlined), {
                                        class: "trigger",
                                        onClick: () => collapsed.value = !collapsed.value
                                      }, null, _parent6, _scopeId5));
                                    } else {
                                      _push6(ssrRenderComponent(unref(MenuFoldOutlined), {
                                        class: "trigger",
                                        onClick: () => collapsed.value = !collapsed.value
                                      }, null, _parent6, _scopeId5));
                                    }
                                  } else {
                                    return [
                                      collapsed.value ? (openBlock(), createBlock(unref(MenuUnfoldOutlined), {
                                        key: 0,
                                        class: "trigger",
                                        onClick: () => collapsed.value = !collapsed.value
                                      }, null, 8, ["onClick"])) : (openBlock(), createBlock(unref(MenuFoldOutlined), {
                                        key: 1,
                                        class: "trigger",
                                        onClick: () => collapsed.value = !collapsed.value
                                      }, null, 8, ["onClick"]))
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(_component_a_col, { flex: "auto" }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_a_menu, {
                                      selectedKeys: _ctx.selectedKeys,
                                      "onUpdate:selectedKeys": ($event) => _ctx.selectedKeys = $event,
                                      mode: "horizontal"
                                    }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(_component_a_menu_item, { key: "profile" }, {
                                            default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                              if (_push8) {
                                                _push8(`Profile`);
                                              } else {
                                                return [
                                                  createTextVNode("Profile")
                                                ];
                                              }
                                            }),
                                            _: 1
                                          }, _parent7, _scopeId6));
                                          _push7(ssrRenderComponent(_component_a_menu_item, { key: "logout" }, {
                                            default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                              if (_push8) {
                                                _push8(`Logout`);
                                              } else {
                                                return [
                                                  createTextVNode("Logout")
                                                ];
                                              }
                                            }),
                                            _: 1
                                          }, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode(_component_a_menu_item, { key: "profile" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Profile")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_menu_item, { key: "logout" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Logout")
                                              ]),
                                              _: 1
                                            })
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_a_menu, {
                                        selectedKeys: _ctx.selectedKeys,
                                        "onUpdate:selectedKeys": ($event) => _ctx.selectedKeys = $event,
                                        mode: "horizontal"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_menu_item, { key: "profile" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Profile")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_menu_item, { key: "logout" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Logout")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["selectedKeys", "onUpdate:selectedKeys"])
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_a_col, { flex: "100px" }, {
                                  default: withCtx(() => [
                                    collapsed.value ? (openBlock(), createBlock(unref(MenuUnfoldOutlined), {
                                      key: 0,
                                      class: "trigger",
                                      onClick: () => collapsed.value = !collapsed.value
                                    }, null, 8, ["onClick"])) : (openBlock(), createBlock(unref(MenuFoldOutlined), {
                                      key: 1,
                                      class: "trigger",
                                      onClick: () => collapsed.value = !collapsed.value
                                    }, null, 8, ["onClick"]))
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { flex: "auto" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu, {
                                      selectedKeys: _ctx.selectedKeys,
                                      "onUpdate:selectedKeys": ($event) => _ctx.selectedKeys = $event,
                                      mode: "horizontal"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_menu_item, { key: "profile" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Profile")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_menu_item, { key: "logout" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Logout")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["selectedKeys", "onUpdate:selectedKeys"])
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_a_row, { type: "flex" }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, { flex: "100px" }, {
                                default: withCtx(() => [
                                  collapsed.value ? (openBlock(), createBlock(unref(MenuUnfoldOutlined), {
                                    key: 0,
                                    class: "trigger",
                                    onClick: () => collapsed.value = !collapsed.value
                                  }, null, 8, ["onClick"])) : (openBlock(), createBlock(unref(MenuFoldOutlined), {
                                    key: 1,
                                    class: "trigger",
                                    onClick: () => collapsed.value = !collapsed.value
                                  }, null, 8, ["onClick"]))
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { flex: "auto" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu, {
                                    selectedKeys: _ctx.selectedKeys,
                                    "onUpdate:selectedKeys": ($event) => _ctx.selectedKeys = $event,
                                    mode: "horizontal"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_menu_item, { key: "profile" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Profile")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_menu_item, { key: "logout" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Logout")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["selectedKeys", "onUpdate:selectedKeys"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push3, _parent3, _scopeId2);
                } else {
                  return [
                    createVNode(_component_a_layout_header, null, {
                      default: withCtx(() => [
                        createVNode(_component_a_row, { type: "flex" }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, { flex: "100px" }, {
                              default: withCtx(() => [
                                collapsed.value ? (openBlock(), createBlock(unref(MenuUnfoldOutlined), {
                                  key: 0,
                                  class: "trigger",
                                  onClick: () => collapsed.value = !collapsed.value
                                }, null, 8, ["onClick"])) : (openBlock(), createBlock(unref(MenuFoldOutlined), {
                                  key: 1,
                                  class: "trigger",
                                  onClick: () => collapsed.value = !collapsed.value
                                }, null, 8, ["onClick"]))
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { flex: "auto" }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu, {
                                  selectedKeys: _ctx.selectedKeys,
                                  "onUpdate:selectedKeys": ($event) => _ctx.selectedKeys = $event,
                                  mode: "horizontal"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "profile" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Profile")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_menu_item, { key: "logout" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Logout")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["selectedKeys", "onUpdate:selectedKeys"])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    renderSlot(_ctx.$slots, "default")
                  ];
                }
              }),
              _: 3
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_a_layout_sider, {
                collapsed: collapsed.value,
                "onUpdate:collapsed": ($event) => collapsed.value = $event,
                trigger: null,
                collapsible: "",
                style: { overflow: "auto", height: "100vh", position: "fixed", left: 0, top: 0, bottom: 0 }
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "logo" }, [
                    createVNode("img", {
                      src: "/images/logo-2.png",
                      class: "logo1"
                    }, null, 8, ["src"]),
                    createVNode("img", {
                      src: "/images/icon mozitz-min 2.png",
                      class: "collapsed-logo"
                    }, null, 8, ["src"])
                  ]),
                  createVNode(_component_a_menu, {
                    selectedKeys: _ctx.selectedKeys,
                    "onUpdate:selectedKeys": ($event) => _ctx.selectedKeys = $event,
                    theme: "dark",
                    mode: "inline"
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(Link), {
                        href: _ctx.route("dashboard")
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_menu_item, { key: "dashboard" }, {
                            default: withCtx(() => [
                              createVNode(unref(LineChartOutlined)),
                              createVNode("span", null, "Dashboard")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      createVNode(_component_a_sub_menu, { key: "sub5" }, {
                        title: withCtx(() => [
                          createVNode("span", null, [
                            createVNode(unref(AppstoreOutlined)),
                            createVNode("span", null, "Items")
                          ])
                        ]),
                        default: withCtx(() => [
                          createVNode(unref(Link), {
                            href: _ctx.route("products.index")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "products" }, {
                                default: withCtx(() => [
                                  createTextVNode("Goods")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(unref(Link), {
                            href: _ctx.route("services.index")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "services" }, {
                                default: withCtx(() => [
                                  createTextVNode("Services")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(_component_a_menu_item, { key: "3" }, {
                            default: withCtx(() => [
                              createTextVNode("Inventory")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_sub_menu, { key: "sales" }, {
                        title: withCtx(() => [
                          createVNode("span", null, [
                            createVNode(unref(SlidersOutlined)),
                            createVNode("span", null, "Sales")
                          ])
                        ]),
                        default: withCtx(() => [
                          createVNode(unref(Link), {
                            href: _ctx.route("customers.index")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "4" }, {
                                default: withCtx(() => [
                                  createTextVNode("Customers")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(unref(Link), {
                            href: _ctx.route("quotes.index")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "5" }, {
                                default: withCtx(() => [
                                  createTextVNode("Quotes")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(unref(Link), {
                            href: _ctx.route("invoices.index")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "6" }, {
                                default: withCtx(() => [
                                  createTextVNode("Invoices")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(unref(Link), {
                            href: _ctx.route("payments.index")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "7" }, {
                                default: withCtx(() => [
                                  createTextVNode("Payments")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(unref(Link), {
                            href: _ctx.route("creditnotes.index")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "creditnotes" }, {
                                default: withCtx(() => [
                                  createTextVNode("Credit Notes")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_sub_menu, { key: "sub2" }, {
                        title: withCtx(() => [
                          createVNode("span", null, [
                            createVNode(unref(BoxPlotOutlined)),
                            createVNode("span", null, "Purchase")
                          ])
                        ]),
                        default: withCtx(() => [
                          createVNode(unref(Link), {
                            href: _ctx.route("vendors.index")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "1" }, {
                                default: withCtx(() => [
                                  createTextVNode("Vendors")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(unref(Link), {
                            href: _ctx.route("purchaseorders.index")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "purchaseorders3" }, {
                                default: withCtx(() => [
                                  createTextVNode("Purchase Orders")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(unref(Link), {
                            href: _ctx.route("bills.index")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "3" }, {
                                default: withCtx(() => [
                                  createTextVNode("Bills")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(unref(Link), {
                            href: _ctx.route("payments.index")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "payments3" }, {
                                default: withCtx(() => [
                                  createTextVNode("Payments")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(unref(Link), {
                            href: _ctx.route("creditnotes.index")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "creditnotes3" }, {
                                default: withCtx(() => [
                                  createTextVNode("Vendor Credits")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_sub_menu, { key: "Production" }, {
                        title: withCtx(() => [
                          createVNode("span", null, [
                            createVNode(unref(BoxPlotOutlined)),
                            createVNode("span", null, "Production")
                          ])
                        ]),
                        default: withCtx(() => [
                          createVNode(unref(Link), {
                            href: _ctx.route("rawmaterials.index")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "rawmaterials" }, {
                                default: withCtx(() => [
                                  createTextVNode("Raw materials")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(unref(Link), {
                            href: _ctx.route("joborders.index")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "joborders" }, {
                                default: withCtx(() => [
                                  createTextVNode("Job Orders")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(unref(Link), {
                            href: _ctx.route("billofmaterials.index")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "rawmaterials" }, {
                                default: withCtx(() => [
                                  createTextVNode("Bill of materials")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_menu_item, { key: "sub3" }, {
                        default: withCtx(() => [
                          createVNode(unref(DollarCircleOutlined)),
                          createVNode("span", null, "Expenses")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_menu_item, { key: "sub4" }, {
                        default: withCtx(() => [
                          createVNode(unref(PieChartOutlined)),
                          createVNode("span", null, "Reports")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["selectedKeys", "onUpdate:selectedKeys"])
                ]),
                _: 1
              }, 8, ["collapsed", "onUpdate:collapsed"]),
              createVNode(_component_a_layout, {
                collapsed: collapsed.value,
                "onUpdate:collapsed": ($event) => collapsed.value = $event,
                style: { marginLeft: "200px" }
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_layout_header, null, {
                    default: withCtx(() => [
                      createVNode(_component_a_row, { type: "flex" }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, { flex: "100px" }, {
                            default: withCtx(() => [
                              collapsed.value ? (openBlock(), createBlock(unref(MenuUnfoldOutlined), {
                                key: 0,
                                class: "trigger",
                                onClick: () => collapsed.value = !collapsed.value
                              }, null, 8, ["onClick"])) : (openBlock(), createBlock(unref(MenuFoldOutlined), {
                                key: 1,
                                class: "trigger",
                                onClick: () => collapsed.value = !collapsed.value
                              }, null, 8, ["onClick"]))
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { flex: "auto" }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu, {
                                selectedKeys: _ctx.selectedKeys,
                                "onUpdate:selectedKeys": ($event) => _ctx.selectedKeys = $event,
                                mode: "horizontal"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "profile" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Profile")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_menu_item, { key: "logout" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Logout")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["selectedKeys", "onUpdate:selectedKeys"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  renderSlot(_ctx.$slots, "default")
                ]),
                _: 3
              }, 8, ["collapsed", "onUpdate:collapsed"])
            ];
          }
        }),
        _: 3
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/AuthenticatedLayout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
