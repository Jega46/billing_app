import { resolveComponent, withCtx, createTextVNode, createVNode, mergeProps, toDisplayString, openBlock, createBlock, Fragment, renderList, useSSRContext } from "vue";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import { Head, useForm } from "@inertiajs/vue3";
import { ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
import "@ant-design/icons-vue";
const _sfc_main = {
  inject: ["validateMessages"],
  components: {
    AuthenticatedLayout: _sfc_main$1,
    Head
  },
  props: {
    branches: Object,
    errors: Object
  },
  setup() {
    const layout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 16 }
    };
    const formState = useForm({
      name: "",
      designation: "",
      branch_id: [],
      mobile: "",
      gender: "",
      email: "",
      doj: "",
      address: "",
      working_days: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
      work_timing: "",
      bank_name: "",
      account_number: "",
      ifsc_code: "",
      accountholder_name: "",
      employeeid: "",
      dob: "",
      aadhar_number: "",
      uan_number: "",
      pan_number: "",
      pf_number: "",
      esi_number: ""
    });
    return {
      formState,
      layout
    };
  },
  mounted() {
  },
  methods: {
    submit() {
      this.formState.post(route("employees.store"));
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_affix = resolveComponent("a-affix");
  const _component_a_page_header = resolveComponent("a-page-header");
  const _component_a_button = resolveComponent("a-button");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_select_option = resolveComponent("a-select-option");
  const _component_a_input_group = resolveComponent("a-input-group");
  const _component_a_date_picker = resolveComponent("a-date-picker");
  const _component_a_textarea = resolveComponent("a-textarea");
  const _component_a_checkbox_group = resolveComponent("a-checkbox-group");
  const _component_a_checkbox = resolveComponent("a-checkbox");
  const _component_a_time_range_picker = resolveComponent("a-time-range-picker");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Employees" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_affix, { "offset-top": 0 }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_page_header, {
                ghost: false,
                title: "Add Employee",
                onBack: () => _ctx.$inertia.visit(_ctx.route("employees.index"))
              }, {
                extra: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_button, {
                      key: "1",
                      type: "primary"
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`Save`);
                        } else {
                          return [
                            createTextVNode("Save")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_button, {
                        key: "1",
                        type: "primary"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Save")
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_page_header, {
                  ghost: false,
                  title: "Add Employee",
                  onBack: () => _ctx.$inertia.visit(_ctx.route("employees.index"))
                }, {
                  extra: withCtx(() => [
                    createVNode(_component_a_button, {
                      key: "1",
                      type: "primary"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Save")
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }, 8, ["onBack"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_layout_content, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_row, null, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_col, {
                      span: 12,
                      offset: 6
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                            name: "nest-messages",
                            "validate-messages": $options.validateMessages,
                            onFinish: $options.submit
                          }), {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`<h3${ssrRenderAttr("wrapper-col", { span: 12, offset: 6 })}${_scopeId5}> Basic </h3>`);
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Name",
                                  name: "name",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: $setup.formState.name,
                                        "onUpdate:value": ($event) => $setup.formState.name = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: $setup.formState.name,
                                          "onUpdate:value": ($event) => $setup.formState.name = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Job Title",
                                  name: "designation",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: $setup.formState.designation,
                                        "onUpdate:value": ($event) => $setup.formState.designation = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: $setup.formState.designation,
                                          "onUpdate:value": ($event) => $setup.formState.designation = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Branch",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_select, {
                                        placeholder: "Select Branch",
                                        value: $setup.formState.branch_id,
                                        "onUpdate:value": ($event) => $setup.formState.branch_id = $event,
                                        mode: "multiple"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`<!--[-->`);
                                            ssrRenderList($props.branches, (branch) => {
                                              _push8(ssrRenderComponent(_component_a_select_option, {
                                                value: branch.id
                                              }, {
                                                default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                  if (_push9) {
                                                    _push9(`${ssrInterpolate(branch.branch_name)}`);
                                                  } else {
                                                    return [
                                                      createTextVNode(toDisplayString(branch.branch_name), 1)
                                                    ];
                                                  }
                                                }),
                                                _: 2
                                              }, _parent8, _scopeId7));
                                            });
                                            _push8(`<!--]-->`);
                                          } else {
                                            return [
                                              (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                                return openBlock(), createBlock(_component_a_select_option, {
                                                  value: branch.id
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode(toDisplayString(branch.branch_name), 1)
                                                  ]),
                                                  _: 2
                                                }, 1032, ["value"]);
                                              }), 256))
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_select, {
                                          placeholder: "Select Branch",
                                          value: $setup.formState.branch_id,
                                          "onUpdate:value": ($event) => $setup.formState.branch_id = $event,
                                          mode: "multiple"
                                        }, {
                                          default: withCtx(() => [
                                            (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                              return openBlock(), createBlock(_component_a_select_option, {
                                                value: branch.id
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode(toDisplayString(branch.branch_name), 1)
                                                ]),
                                                _: 2
                                              }, 1032, ["value"]);
                                            }), 256))
                                          ]),
                                          _: 1
                                        }, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Mobile Number",
                                  name: "mobile",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input_group, { compact: "" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select, {
                                              style: { "width": "80px" },
                                              value: "+91"
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_select_option, { value: "+91" }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(`+91`);
                                                      } else {
                                                        return [
                                                          createTextVNode("+91")
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_select_option, { value: "+91" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("+91")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              style: { "width": "calc(100% - 80px)" },
                                              value: $setup.formState.mobile,
                                              "onUpdate:value": ($event) => $setup.formState.mobile = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select, {
                                                style: { "width": "80px" },
                                                value: "+91"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select_option, { value: "+91" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("+91")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_input, {
                                                style: { "width": "calc(100% - 80px)" },
                                                value: $setup.formState.mobile,
                                                "onUpdate:value": ($event) => $setup.formState.mobile = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input_group, { compact: "" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              style: { "width": "80px" },
                                              value: "+91"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select_option, { value: "+91" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("+91")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_input, {
                                              style: { "width": "calc(100% - 80px)" },
                                              value: $setup.formState.mobile,
                                              "onUpdate:value": ($event) => $setup.formState.mobile = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Gender",
                                  name: "gender",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_select, {
                                        value: $setup.formState.gender,
                                        "onUpdate:value": ($event) => $setup.formState.gender = $event
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Male" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Male`);
                                                } else {
                                                  return [
                                                    createTextVNode("Male")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Female" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Female`);
                                                } else {
                                                  return [
                                                    createTextVNode("Female")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select_option, { value: "Male" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Male")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Female" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Female")
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_select, {
                                          value: $setup.formState.gender,
                                          "onUpdate:value": ($event) => $setup.formState.gender = $event
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "Male" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Male")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Female" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Female")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Email",
                                  name: "email",
                                  rules: [{ types: _ctx.email }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: $setup.formState.email,
                                        "onUpdate:value": ($event) => $setup.formState.email = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: $setup.formState.email,
                                          "onUpdate:value": ($event) => $setup.formState.email = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  name: "doj",
                                  label: "Date of Joining"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_date_picker, {
                                        "value-format": "YYYY-MM-DD",
                                        style: { "width": "100%" },
                                        value: $setup.formState.doj,
                                        "onUpdate:value": ($event) => $setup.formState.doj = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_date_picker, {
                                          "value-format": "YYYY-MM-DD",
                                          style: { "width": "100%" },
                                          value: $setup.formState.doj,
                                          "onUpdate:value": ($event) => $setup.formState.doj = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Address",
                                  name: "address"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_textarea, {
                                        value: $setup.formState.address,
                                        "onUpdate:value": ($event) => $setup.formState.address = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_textarea, {
                                          value: $setup.formState.address,
                                          "onUpdate:value": ($event) => $setup.formState.address = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(`<h3${ssrRenderAttr("wrapper-col", { span: 12, offset: 6 })}${_scopeId5}> Attendance </h3>`);
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Working Days",
                                  name: "working_days"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_checkbox_group, {
                                        value: $setup.formState.working_days,
                                        "onUpdate:value": ($event) => $setup.formState.working_days = $event,
                                        style: { "width": "100%" }
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_row, null, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_col, { span: 4 }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_checkbox, { value: "Sun" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`Sun`);
                                                            } else {
                                                              return [
                                                                createTextVNode("Sun")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_checkbox, { value: "Sun" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Sun")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_a_col, { span: 4 }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_checkbox, { value: "Mon" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`Mon`);
                                                            } else {
                                                              return [
                                                                createTextVNode("Mon")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_checkbox, { value: "Mon" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Mon")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_a_col, { span: 4 }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_checkbox, { value: "Tue" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`Tue`);
                                                            } else {
                                                              return [
                                                                createTextVNode("Tue")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_checkbox, { value: "Tue" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Tue")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_a_col, { span: 4 }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_checkbox, { value: "Wed" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`Wed`);
                                                            } else {
                                                              return [
                                                                createTextVNode("Wed")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_checkbox, { value: "Wed" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Wed")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_a_col, { span: 4 }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_checkbox, { value: "Thu" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`Thu`);
                                                            } else {
                                                              return [
                                                                createTextVNode("Thu")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_checkbox, { value: "Thu" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Thu")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_a_col, { span: 4 }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_checkbox, { value: "Fri" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`Fri`);
                                                            } else {
                                                              return [
                                                                createTextVNode("Fri")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_checkbox, { value: "Fri" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Fri")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_a_col, { span: 4 }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_checkbox, { value: "Sat" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`Sat`);
                                                            } else {
                                                              return [
                                                                createTextVNode("Sat")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_checkbox, { value: "Sat" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Sat")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_col, { span: 4 }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_checkbox, { value: "Sun" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Sun")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_col, { span: 4 }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_checkbox, { value: "Mon" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Mon")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_col, { span: 4 }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_checkbox, { value: "Tue" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Tue")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_col, { span: 4 }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_checkbox, { value: "Wed" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Wed")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_col, { span: 4 }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_checkbox, { value: "Thu" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Thu")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_col, { span: 4 }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_checkbox, { value: "Fri" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Fri")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_col, { span: 4 }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_checkbox, { value: "Sat" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Sat")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_row, null, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_col, { span: 4 }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_checkbox, { value: "Sun" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Sun")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_col, { span: 4 }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_checkbox, { value: "Mon" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Mon")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_col, { span: 4 }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_checkbox, { value: "Tue" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Tue")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_col, { span: 4 }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_checkbox, { value: "Wed" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Wed")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_col, { span: 4 }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_checkbox, { value: "Thu" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Thu")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_col, { span: 4 }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_checkbox, { value: "Fri" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Fri")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_col, { span: 4 }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_checkbox, { value: "Sat" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Sat")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_checkbox_group, {
                                          value: $setup.formState.working_days,
                                          "onUpdate:value": ($event) => $setup.formState.working_days = $event,
                                          style: { "width": "100%" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_row, null, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_col, { span: 4 }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_checkbox, { value: "Sun" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Sun")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_col, { span: 4 }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_checkbox, { value: "Mon" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Mon")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_col, { span: 4 }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_checkbox, { value: "Tue" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Tue")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_col, { span: 4 }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_checkbox, { value: "Wed" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Wed")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_col, { span: 4 }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_checkbox, { value: "Thu" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Thu")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_col, { span: 4 }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_checkbox, { value: "Fri" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Fri")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_col, { span: 4 }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_checkbox, { value: "Sat" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Sat")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Timing",
                                  name: "work_timing"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_time_range_picker, {
                                        style: { width: "100%" },
                                        format: "h:mm a",
                                        value: $setup.formState.work_timing,
                                        "onUpdate:value": ($event) => $setup.formState.work_timing = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_time_range_picker, {
                                          style: { width: "100%" },
                                          format: "h:mm a",
                                          value: $setup.formState.work_timing,
                                          "onUpdate:value": ($event) => $setup.formState.work_timing = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(`<h3${ssrRenderAttr("wrapper-col", { span: 12, offset: 6 })}${_scopeId5}> Bank Account Details </h3>`);
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Bank Name",
                                  name: "bank_name"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: $setup.formState.bank_name,
                                        "onUpdate:value": ($event) => $setup.formState.bank_name = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: $setup.formState.bank_name,
                                          "onUpdate:value": ($event) => $setup.formState.bank_name = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Account Number",
                                  name: "account_number"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: $setup.formState.account_number,
                                        "onUpdate:value": ($event) => $setup.formState.account_number = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: $setup.formState.account_number,
                                          "onUpdate:value": ($event) => $setup.formState.account_number = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "IFSC Code",
                                  name: "ifsc_code"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: $setup.formState.ifsc_code,
                                        "onUpdate:value": ($event) => $setup.formState.ifsc_code = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: $setup.formState.ifsc_code,
                                          "onUpdate:value": ($event) => $setup.formState.ifsc_code = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Account holders name",
                                  name: "accountholder_name"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: $setup.formState.accountholder_name,
                                        "onUpdate:value": ($event) => $setup.formState.accountholder_name = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: $setup.formState.accountholder_name,
                                          "onUpdate:value": ($event) => $setup.formState.accountholder_name = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(`<h3${ssrRenderAttr("wrapper-col", { span: 12, offset: 6 })}${_scopeId5}> Additional Details </h3>`);
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Employee Id",
                                  name: "employeeid"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: $setup.formState.employeeid,
                                        "onUpdate:value": ($event) => $setup.formState.employeeid = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: $setup.formState.employeeid,
                                          "onUpdate:value": ($event) => $setup.formState.employeeid = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Date of Birth",
                                  name: "dob"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_date_picker, {
                                        "value-format": "YYYY-MM-DD",
                                        value: $setup.formState.dob,
                                        "onUpdate:value": ($event) => $setup.formState.dob = $event,
                                        style: { "width": "100%" }
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_date_picker, {
                                          "value-format": "YYYY-MM-DD",
                                          value: $setup.formState.dob,
                                          "onUpdate:value": ($event) => $setup.formState.dob = $event,
                                          style: { "width": "100%" }
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Aadhar No",
                                  name: "aadhar_number",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: $setup.formState.aadhar_number,
                                        "onUpdate:value": ($event) => $setup.formState.aadhar_number = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: $setup.formState.aadhar_number,
                                          "onUpdate:value": ($event) => $setup.formState.aadhar_number = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "UAN",
                                  name: "uan_number"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: $setup.formState.uan_number,
                                        "onUpdate:value": ($event) => $setup.formState.uan_number = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: $setup.formState.uan_number,
                                          "onUpdate:value": ($event) => $setup.formState.uan_number = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "PAN",
                                  name: "pan_number"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: $setup.formState.pan_number,
                                        "onUpdate:value": ($event) => $setup.formState.pan_number = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: $setup.formState.pan_number,
                                          "onUpdate:value": ($event) => $setup.formState.pan_number = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "PF No.",
                                  name: "pf_number"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: $setup.formState.pf_number,
                                        "onUpdate:value": ($event) => $setup.formState.pf_number = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: $setup.formState.pf_number,
                                          "onUpdate:value": ($event) => $setup.formState.pf_number = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "ESI No.",
                                  name: "esi_number"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: $setup.formState.esi_number,
                                        "onUpdate:value": ($event) => $setup.formState.esi_number = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: $setup.formState.esi_number,
                                          "onUpdate:value": ($event) => $setup.formState.esi_number = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`Save`);
                                          } else {
                                            return [
                                              createTextVNode("Save")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          "html-type": "submit"
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("Save")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Basic "),
                                  createVNode(_component_a_form_item, {
                                    label: "Name",
                                    name: "name",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $setup.formState.name,
                                        "onUpdate:value": ($event) => $setup.formState.name = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Job Title",
                                    name: "designation",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $setup.formState.designation,
                                        "onUpdate:value": ($event) => $setup.formState.designation = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Branch",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        placeholder: "Select Branch",
                                        value: $setup.formState.branch_id,
                                        "onUpdate:value": ($event) => $setup.formState.branch_id = $event,
                                        mode: "multiple"
                                      }, {
                                        default: withCtx(() => [
                                          (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                            return openBlock(), createBlock(_component_a_select_option, {
                                              value: branch.id
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode(toDisplayString(branch.branch_name), 1)
                                              ]),
                                              _: 2
                                            }, 1032, ["value"]);
                                          }), 256))
                                        ]),
                                        _: 1
                                      }, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Mobile Number",
                                    name: "mobile",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input_group, { compact: "" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            style: { "width": "80px" },
                                            value: "+91"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select_option, { value: "+91" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("+91")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_input, {
                                            style: { "width": "calc(100% - 80px)" },
                                            value: $setup.formState.mobile,
                                            "onUpdate:value": ($event) => $setup.formState.mobile = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Gender",
                                    name: "gender",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        value: $setup.formState.gender,
                                        "onUpdate:value": ($event) => $setup.formState.gender = $event
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "Male" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Male")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Female" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Female")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Email",
                                    name: "email",
                                    rules: [{ types: _ctx.email }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $setup.formState.email,
                                        "onUpdate:value": ($event) => $setup.formState.email = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }, 8, ["rules"]),
                                  createVNode(_component_a_form_item, {
                                    name: "doj",
                                    label: "Date of Joining"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_date_picker, {
                                        "value-format": "YYYY-MM-DD",
                                        style: { "width": "100%" },
                                        value: $setup.formState.doj,
                                        "onUpdate:value": ($event) => $setup.formState.doj = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Address",
                                    name: "address"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_textarea, {
                                        value: $setup.formState.address,
                                        "onUpdate:value": ($event) => $setup.formState.address = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Attendance "),
                                  createVNode(_component_a_form_item, {
                                    label: "Working Days",
                                    name: "working_days"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_checkbox_group, {
                                        value: $setup.formState.working_days,
                                        "onUpdate:value": ($event) => $setup.formState.working_days = $event,
                                        style: { "width": "100%" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_row, null, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_col, { span: 4 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_checkbox, { value: "Sun" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Sun")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 4 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_checkbox, { value: "Mon" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Mon")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 4 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_checkbox, { value: "Tue" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Tue")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 4 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_checkbox, { value: "Wed" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Wed")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 4 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_checkbox, { value: "Thu" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Thu")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 4 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_checkbox, { value: "Fri" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Fri")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 4 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_checkbox, { value: "Sat" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Sat")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Timing",
                                    name: "work_timing"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_time_range_picker, {
                                        style: { width: "100%" },
                                        format: "h:mm a",
                                        value: $setup.formState.work_timing,
                                        "onUpdate:value": ($event) => $setup.formState.work_timing = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Bank Account Details "),
                                  createVNode(_component_a_form_item, {
                                    label: "Bank Name",
                                    name: "bank_name"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $setup.formState.bank_name,
                                        "onUpdate:value": ($event) => $setup.formState.bank_name = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Account Number",
                                    name: "account_number"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $setup.formState.account_number,
                                        "onUpdate:value": ($event) => $setup.formState.account_number = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "IFSC Code",
                                    name: "ifsc_code"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $setup.formState.ifsc_code,
                                        "onUpdate:value": ($event) => $setup.formState.ifsc_code = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Account holders name",
                                    name: "accountholder_name"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $setup.formState.accountholder_name,
                                        "onUpdate:value": ($event) => $setup.formState.accountholder_name = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Additional Details "),
                                  createVNode(_component_a_form_item, {
                                    label: "Employee Id",
                                    name: "employeeid"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $setup.formState.employeeid,
                                        "onUpdate:value": ($event) => $setup.formState.employeeid = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Date of Birth",
                                    name: "dob"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_date_picker, {
                                        "value-format": "YYYY-MM-DD",
                                        value: $setup.formState.dob,
                                        "onUpdate:value": ($event) => $setup.formState.dob = $event,
                                        style: { "width": "100%" }
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Aadhar No",
                                    name: "aadhar_number",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $setup.formState.aadhar_number,
                                        "onUpdate:value": ($event) => $setup.formState.aadhar_number = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "UAN",
                                    name: "uan_number"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $setup.formState.uan_number,
                                        "onUpdate:value": ($event) => $setup.formState.uan_number = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "PAN",
                                    name: "pan_number"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $setup.formState.pan_number,
                                        "onUpdate:value": ($event) => $setup.formState.pan_number = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "PF No.",
                                    name: "pf_number"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $setup.formState.pf_number,
                                        "onUpdate:value": ($event) => $setup.formState.pf_number = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "ESI No.",
                                    name: "esi_number"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $setup.formState.esi_number,
                                        "onUpdate:value": ($event) => $setup.formState.esi_number = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit"
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Save")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                              name: "nest-messages",
                              "validate-messages": $options.validateMessages,
                              onFinish: $options.submit
                            }), {
                              default: withCtx(() => [
                                createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Basic "),
                                createVNode(_component_a_form_item, {
                                  label: "Name",
                                  name: "name",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $setup.formState.name,
                                      "onUpdate:value": ($event) => $setup.formState.name = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Job Title",
                                  name: "designation",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $setup.formState.designation,
                                      "onUpdate:value": ($event) => $setup.formState.designation = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Branch",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      placeholder: "Select Branch",
                                      value: $setup.formState.branch_id,
                                      "onUpdate:value": ($event) => $setup.formState.branch_id = $event,
                                      mode: "multiple"
                                    }, {
                                      default: withCtx(() => [
                                        (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                          return openBlock(), createBlock(_component_a_select_option, {
                                            value: branch.id
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(branch.branch_name), 1)
                                            ]),
                                            _: 2
                                          }, 1032, ["value"]);
                                        }), 256))
                                      ]),
                                      _: 1
                                    }, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Mobile Number",
                                  name: "mobile",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input_group, { compact: "" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          style: { "width": "80px" },
                                          value: "+91"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "+91" }, {
                                              default: withCtx(() => [
                                                createTextVNode("+91")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_input, {
                                          style: { "width": "calc(100% - 80px)" },
                                          value: $setup.formState.mobile,
                                          "onUpdate:value": ($event) => $setup.formState.mobile = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Gender",
                                  name: "gender",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      value: $setup.formState.gender,
                                      "onUpdate:value": ($event) => $setup.formState.gender = $event
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, { value: "Male" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Male")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "Female" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Female")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Email",
                                  name: "email",
                                  rules: [{ types: _ctx.email }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $setup.formState.email,
                                      "onUpdate:value": ($event) => $setup.formState.email = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }, 8, ["rules"]),
                                createVNode(_component_a_form_item, {
                                  name: "doj",
                                  label: "Date of Joining"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_date_picker, {
                                      "value-format": "YYYY-MM-DD",
                                      style: { "width": "100%" },
                                      value: $setup.formState.doj,
                                      "onUpdate:value": ($event) => $setup.formState.doj = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Address",
                                  name: "address"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_textarea, {
                                      value: $setup.formState.address,
                                      "onUpdate:value": ($event) => $setup.formState.address = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Attendance "),
                                createVNode(_component_a_form_item, {
                                  label: "Working Days",
                                  name: "working_days"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_checkbox_group, {
                                      value: $setup.formState.working_days,
                                      "onUpdate:value": ($event) => $setup.formState.working_days = $event,
                                      style: { "width": "100%" }
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_row, null, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_col, { span: 4 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_checkbox, { value: "Sun" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Sun")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 4 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_checkbox, { value: "Mon" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Mon")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 4 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_checkbox, { value: "Tue" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Tue")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 4 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_checkbox, { value: "Wed" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Wed")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 4 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_checkbox, { value: "Thu" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Thu")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 4 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_checkbox, { value: "Fri" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Fri")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 4 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_checkbox, { value: "Sat" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Sat")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Timing",
                                  name: "work_timing"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_time_range_picker, {
                                      style: { width: "100%" },
                                      format: "h:mm a",
                                      value: $setup.formState.work_timing,
                                      "onUpdate:value": ($event) => $setup.formState.work_timing = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Bank Account Details "),
                                createVNode(_component_a_form_item, {
                                  label: "Bank Name",
                                  name: "bank_name"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $setup.formState.bank_name,
                                      "onUpdate:value": ($event) => $setup.formState.bank_name = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Account Number",
                                  name: "account_number"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $setup.formState.account_number,
                                      "onUpdate:value": ($event) => $setup.formState.account_number = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "IFSC Code",
                                  name: "ifsc_code"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $setup.formState.ifsc_code,
                                      "onUpdate:value": ($event) => $setup.formState.ifsc_code = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Account holders name",
                                  name: "accountholder_name"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $setup.formState.accountholder_name,
                                      "onUpdate:value": ($event) => $setup.formState.accountholder_name = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Additional Details "),
                                createVNode(_component_a_form_item, {
                                  label: "Employee Id",
                                  name: "employeeid"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $setup.formState.employeeid,
                                      "onUpdate:value": ($event) => $setup.formState.employeeid = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Date of Birth",
                                  name: "dob"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_date_picker, {
                                      "value-format": "YYYY-MM-DD",
                                      value: $setup.formState.dob,
                                      "onUpdate:value": ($event) => $setup.formState.dob = $event,
                                      style: { "width": "100%" }
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Aadhar No",
                                  name: "aadhar_number",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $setup.formState.aadhar_number,
                                      "onUpdate:value": ($event) => $setup.formState.aadhar_number = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "UAN",
                                  name: "uan_number"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $setup.formState.uan_number,
                                      "onUpdate:value": ($event) => $setup.formState.uan_number = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "PAN",
                                  name: "pan_number"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $setup.formState.pan_number,
                                      "onUpdate:value": ($event) => $setup.formState.pan_number = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "PF No.",
                                  name: "pf_number"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $setup.formState.pf_number,
                                      "onUpdate:value": ($event) => $setup.formState.pf_number = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "ESI No.",
                                  name: "esi_number"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $setup.formState.esi_number,
                                      "onUpdate:value": ($event) => $setup.formState.esi_number = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      "html-type": "submit"
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Save")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 16, ["model", "validate-messages", "onFinish"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_col, {
                        span: 12,
                        offset: 6
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                            name: "nest-messages",
                            "validate-messages": $options.validateMessages,
                            onFinish: $options.submit
                          }), {
                            default: withCtx(() => [
                              createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Basic "),
                              createVNode(_component_a_form_item, {
                                label: "Name",
                                name: "name",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $setup.formState.name,
                                    "onUpdate:value": ($event) => $setup.formState.name = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Job Title",
                                name: "designation",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $setup.formState.designation,
                                    "onUpdate:value": ($event) => $setup.formState.designation = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Branch",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    placeholder: "Select Branch",
                                    value: $setup.formState.branch_id,
                                    "onUpdate:value": ($event) => $setup.formState.branch_id = $event,
                                    mode: "multiple"
                                  }, {
                                    default: withCtx(() => [
                                      (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                        return openBlock(), createBlock(_component_a_select_option, {
                                          value: branch.id
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(branch.branch_name), 1)
                                          ]),
                                          _: 2
                                        }, 1032, ["value"]);
                                      }), 256))
                                    ]),
                                    _: 1
                                  }, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Mobile Number",
                                name: "mobile",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input_group, { compact: "" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        style: { "width": "80px" },
                                        value: "+91"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "+91" }, {
                                            default: withCtx(() => [
                                              createTextVNode("+91")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_input, {
                                        style: { "width": "calc(100% - 80px)" },
                                        value: $setup.formState.mobile,
                                        "onUpdate:value": ($event) => $setup.formState.mobile = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Gender",
                                name: "gender",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    value: $setup.formState.gender,
                                    "onUpdate:value": ($event) => $setup.formState.gender = $event
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, { value: "Male" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Male")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "Female" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Female")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Email",
                                name: "email",
                                rules: [{ types: _ctx.email }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $setup.formState.email,
                                    "onUpdate:value": ($event) => $setup.formState.email = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }, 8, ["rules"]),
                              createVNode(_component_a_form_item, {
                                name: "doj",
                                label: "Date of Joining"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_date_picker, {
                                    "value-format": "YYYY-MM-DD",
                                    style: { "width": "100%" },
                                    value: $setup.formState.doj,
                                    "onUpdate:value": ($event) => $setup.formState.doj = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Address",
                                name: "address"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_textarea, {
                                    value: $setup.formState.address,
                                    "onUpdate:value": ($event) => $setup.formState.address = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Attendance "),
                              createVNode(_component_a_form_item, {
                                label: "Working Days",
                                name: "working_days"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_checkbox_group, {
                                    value: $setup.formState.working_days,
                                    "onUpdate:value": ($event) => $setup.formState.working_days = $event,
                                    style: { "width": "100%" }
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_row, null, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_col, { span: 4 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_checkbox, { value: "Sun" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Sun")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 4 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_checkbox, { value: "Mon" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Mon")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 4 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_checkbox, { value: "Tue" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Tue")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 4 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_checkbox, { value: "Wed" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Wed")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 4 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_checkbox, { value: "Thu" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Thu")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 4 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_checkbox, { value: "Fri" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Fri")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 4 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_checkbox, { value: "Sat" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Sat")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Timing",
                                name: "work_timing"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_time_range_picker, {
                                    style: { width: "100%" },
                                    format: "h:mm a",
                                    value: $setup.formState.work_timing,
                                    "onUpdate:value": ($event) => $setup.formState.work_timing = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Bank Account Details "),
                              createVNode(_component_a_form_item, {
                                label: "Bank Name",
                                name: "bank_name"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $setup.formState.bank_name,
                                    "onUpdate:value": ($event) => $setup.formState.bank_name = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Account Number",
                                name: "account_number"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $setup.formState.account_number,
                                    "onUpdate:value": ($event) => $setup.formState.account_number = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "IFSC Code",
                                name: "ifsc_code"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $setup.formState.ifsc_code,
                                    "onUpdate:value": ($event) => $setup.formState.ifsc_code = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Account holders name",
                                name: "accountholder_name"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $setup.formState.accountholder_name,
                                    "onUpdate:value": ($event) => $setup.formState.accountholder_name = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Additional Details "),
                              createVNode(_component_a_form_item, {
                                label: "Employee Id",
                                name: "employeeid"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $setup.formState.employeeid,
                                    "onUpdate:value": ($event) => $setup.formState.employeeid = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Date of Birth",
                                name: "dob"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_date_picker, {
                                    "value-format": "YYYY-MM-DD",
                                    value: $setup.formState.dob,
                                    "onUpdate:value": ($event) => $setup.formState.dob = $event,
                                    style: { "width": "100%" }
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Aadhar No",
                                name: "aadhar_number",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $setup.formState.aadhar_number,
                                    "onUpdate:value": ($event) => $setup.formState.aadhar_number = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "UAN",
                                name: "uan_number"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $setup.formState.uan_number,
                                    "onUpdate:value": ($event) => $setup.formState.uan_number = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "PAN",
                                name: "pan_number"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $setup.formState.pan_number,
                                    "onUpdate:value": ($event) => $setup.formState.pan_number = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "PF No.",
                                name: "pf_number"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $setup.formState.pf_number,
                                    "onUpdate:value": ($event) => $setup.formState.pf_number = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "ESI No.",
                                name: "esi_number"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $setup.formState.esi_number,
                                    "onUpdate:value": ($event) => $setup.formState.esi_number = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Save")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 16, ["model", "validate-messages", "onFinish"])
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_a_col, {
                      span: 12,
                      offset: 6
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                          name: "nest-messages",
                          "validate-messages": $options.validateMessages,
                          onFinish: $options.submit
                        }), {
                          default: withCtx(() => [
                            createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Basic "),
                            createVNode(_component_a_form_item, {
                              label: "Name",
                              name: "name",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: $setup.formState.name,
                                  "onUpdate:value": ($event) => $setup.formState.name = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Job Title",
                              name: "designation",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: $setup.formState.designation,
                                  "onUpdate:value": ($event) => $setup.formState.designation = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Branch",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_select, {
                                  placeholder: "Select Branch",
                                  value: $setup.formState.branch_id,
                                  "onUpdate:value": ($event) => $setup.formState.branch_id = $event,
                                  mode: "multiple"
                                }, {
                                  default: withCtx(() => [
                                    (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                      return openBlock(), createBlock(_component_a_select_option, {
                                        value: branch.id
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(branch.branch_name), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["value"]);
                                    }), 256))
                                  ]),
                                  _: 1
                                }, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Mobile Number",
                              name: "mobile",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input_group, { compact: "" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      style: { "width": "80px" },
                                      value: "+91"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, { value: "+91" }, {
                                          default: withCtx(() => [
                                            createTextVNode("+91")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_input, {
                                      style: { "width": "calc(100% - 80px)" },
                                      value: $setup.formState.mobile,
                                      "onUpdate:value": ($event) => $setup.formState.mobile = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Gender",
                              name: "gender",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_select, {
                                  value: $setup.formState.gender,
                                  "onUpdate:value": ($event) => $setup.formState.gender = $event
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select_option, { value: "Male" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Male")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Female" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Female")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Email",
                              name: "email",
                              rules: [{ types: _ctx.email }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: $setup.formState.email,
                                  "onUpdate:value": ($event) => $setup.formState.email = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }, 8, ["rules"]),
                            createVNode(_component_a_form_item, {
                              name: "doj",
                              label: "Date of Joining"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_date_picker, {
                                  "value-format": "YYYY-MM-DD",
                                  style: { "width": "100%" },
                                  value: $setup.formState.doj,
                                  "onUpdate:value": ($event) => $setup.formState.doj = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Address",
                              name: "address"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_textarea, {
                                  value: $setup.formState.address,
                                  "onUpdate:value": ($event) => $setup.formState.address = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Attendance "),
                            createVNode(_component_a_form_item, {
                              label: "Working Days",
                              name: "working_days"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_checkbox_group, {
                                  value: $setup.formState.working_days,
                                  "onUpdate:value": ($event) => $setup.formState.working_days = $event,
                                  style: { "width": "100%" }
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_row, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_col, { span: 4 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_checkbox, { value: "Sun" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Sun")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 4 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_checkbox, { value: "Mon" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Mon")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 4 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_checkbox, { value: "Tue" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Tue")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 4 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_checkbox, { value: "Wed" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Wed")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 4 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_checkbox, { value: "Thu" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Thu")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 4 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_checkbox, { value: "Fri" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Fri")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 4 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_checkbox, { value: "Sat" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Sat")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Timing",
                              name: "work_timing"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_time_range_picker, {
                                  style: { width: "100%" },
                                  format: "h:mm a",
                                  value: $setup.formState.work_timing,
                                  "onUpdate:value": ($event) => $setup.formState.work_timing = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Bank Account Details "),
                            createVNode(_component_a_form_item, {
                              label: "Bank Name",
                              name: "bank_name"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: $setup.formState.bank_name,
                                  "onUpdate:value": ($event) => $setup.formState.bank_name = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Account Number",
                              name: "account_number"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: $setup.formState.account_number,
                                  "onUpdate:value": ($event) => $setup.formState.account_number = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "IFSC Code",
                              name: "ifsc_code"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: $setup.formState.ifsc_code,
                                  "onUpdate:value": ($event) => $setup.formState.ifsc_code = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Account holders name",
                              name: "accountholder_name"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: $setup.formState.accountholder_name,
                                  "onUpdate:value": ($event) => $setup.formState.accountholder_name = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Additional Details "),
                            createVNode(_component_a_form_item, {
                              label: "Employee Id",
                              name: "employeeid"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: $setup.formState.employeeid,
                                  "onUpdate:value": ($event) => $setup.formState.employeeid = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Date of Birth",
                              name: "dob"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_date_picker, {
                                  "value-format": "YYYY-MM-DD",
                                  value: $setup.formState.dob,
                                  "onUpdate:value": ($event) => $setup.formState.dob = $event,
                                  style: { "width": "100%" }
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Aadhar No",
                              name: "aadhar_number",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: $setup.formState.aadhar_number,
                                  "onUpdate:value": ($event) => $setup.formState.aadhar_number = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "UAN",
                              name: "uan_number"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: $setup.formState.uan_number,
                                  "onUpdate:value": ($event) => $setup.formState.uan_number = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "PAN",
                              name: "pan_number"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: $setup.formState.pan_number,
                                  "onUpdate:value": ($event) => $setup.formState.pan_number = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "PF No.",
                              name: "pf_number"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: $setup.formState.pf_number,
                                  "onUpdate:value": ($event) => $setup.formState.pf_number = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "ESI No.",
                              name: "esi_number"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: $setup.formState.esi_number,
                                  "onUpdate:value": ($event) => $setup.formState.esi_number = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Save")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 16, ["model", "validate-messages", "onFinish"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_affix, { "offset-top": 0 }, {
            default: withCtx(() => [
              createVNode(_component_a_page_header, {
                ghost: false,
                title: "Add Employee",
                onBack: () => _ctx.$inertia.visit(_ctx.route("employees.index"))
              }, {
                extra: withCtx(() => [
                  createVNode(_component_a_button, {
                    key: "1",
                    type: "primary"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Save")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["onBack"])
            ]),
            _: 1
          }),
          createVNode(_component_a_layout_content, null, {
            default: withCtx(() => [
              createVNode(_component_a_row, null, {
                default: withCtx(() => [
                  createVNode(_component_a_col, {
                    span: 12,
                    offset: 6
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                        name: "nest-messages",
                        "validate-messages": $options.validateMessages,
                        onFinish: $options.submit
                      }), {
                        default: withCtx(() => [
                          createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Basic "),
                          createVNode(_component_a_form_item, {
                            label: "Name",
                            name: "name",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: $setup.formState.name,
                                "onUpdate:value": ($event) => $setup.formState.name = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Job Title",
                            name: "designation",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: $setup.formState.designation,
                                "onUpdate:value": ($event) => $setup.formState.designation = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Branch",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_select, {
                                placeholder: "Select Branch",
                                value: $setup.formState.branch_id,
                                "onUpdate:value": ($event) => $setup.formState.branch_id = $event,
                                mode: "multiple"
                              }, {
                                default: withCtx(() => [
                                  (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                    return openBlock(), createBlock(_component_a_select_option, {
                                      value: branch.id
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(branch.branch_name), 1)
                                      ]),
                                      _: 2
                                    }, 1032, ["value"]);
                                  }), 256))
                                ]),
                                _: 1
                              }, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Mobile Number",
                            name: "mobile",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input_group, { compact: "" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    style: { "width": "80px" },
                                    value: "+91"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, { value: "+91" }, {
                                        default: withCtx(() => [
                                          createTextVNode("+91")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_input, {
                                    style: { "width": "calc(100% - 80px)" },
                                    value: $setup.formState.mobile,
                                    "onUpdate:value": ($event) => $setup.formState.mobile = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Gender",
                            name: "gender",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_select, {
                                value: $setup.formState.gender,
                                "onUpdate:value": ($event) => $setup.formState.gender = $event
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select_option, { value: "Male" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Male")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Female" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Female")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Email",
                            name: "email",
                            rules: [{ types: _ctx.email }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: $setup.formState.email,
                                "onUpdate:value": ($event) => $setup.formState.email = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }, 8, ["rules"]),
                          createVNode(_component_a_form_item, {
                            name: "doj",
                            label: "Date of Joining"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_date_picker, {
                                "value-format": "YYYY-MM-DD",
                                style: { "width": "100%" },
                                value: $setup.formState.doj,
                                "onUpdate:value": ($event) => $setup.formState.doj = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Address",
                            name: "address"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_textarea, {
                                value: $setup.formState.address,
                                "onUpdate:value": ($event) => $setup.formState.address = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Attendance "),
                          createVNode(_component_a_form_item, {
                            label: "Working Days",
                            name: "working_days"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_checkbox_group, {
                                value: $setup.formState.working_days,
                                "onUpdate:value": ($event) => $setup.formState.working_days = $event,
                                style: { "width": "100%" }
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_row, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, { span: 4 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_checkbox, { value: "Sun" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Sun")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 4 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_checkbox, { value: "Mon" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Mon")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 4 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_checkbox, { value: "Tue" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Tue")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 4 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_checkbox, { value: "Wed" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Wed")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 4 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_checkbox, { value: "Thu" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Thu")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 4 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_checkbox, { value: "Fri" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Fri")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 4 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_checkbox, { value: "Sat" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Sat")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Timing",
                            name: "work_timing"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_time_range_picker, {
                                style: { width: "100%" },
                                format: "h:mm a",
                                value: $setup.formState.work_timing,
                                "onUpdate:value": ($event) => $setup.formState.work_timing = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Bank Account Details "),
                          createVNode(_component_a_form_item, {
                            label: "Bank Name",
                            name: "bank_name"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: $setup.formState.bank_name,
                                "onUpdate:value": ($event) => $setup.formState.bank_name = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Account Number",
                            name: "account_number"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: $setup.formState.account_number,
                                "onUpdate:value": ($event) => $setup.formState.account_number = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "IFSC Code",
                            name: "ifsc_code"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: $setup.formState.ifsc_code,
                                "onUpdate:value": ($event) => $setup.formState.ifsc_code = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Account holders name",
                            name: "accountholder_name"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: $setup.formState.accountholder_name,
                                "onUpdate:value": ($event) => $setup.formState.accountholder_name = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Additional Details "),
                          createVNode(_component_a_form_item, {
                            label: "Employee Id",
                            name: "employeeid"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: $setup.formState.employeeid,
                                "onUpdate:value": ($event) => $setup.formState.employeeid = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Date of Birth",
                            name: "dob"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_date_picker, {
                                "value-format": "YYYY-MM-DD",
                                value: $setup.formState.dob,
                                "onUpdate:value": ($event) => $setup.formState.dob = $event,
                                style: { "width": "100%" }
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Aadhar No",
                            name: "aadhar_number",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: $setup.formState.aadhar_number,
                                "onUpdate:value": ($event) => $setup.formState.aadhar_number = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "UAN",
                            name: "uan_number"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: $setup.formState.uan_number,
                                "onUpdate:value": ($event) => $setup.formState.uan_number = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "PAN",
                            name: "pan_number"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: $setup.formState.pan_number,
                                "onUpdate:value": ($event) => $setup.formState.pan_number = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "PF No.",
                            name: "pf_number"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: $setup.formState.pf_number,
                                "onUpdate:value": ($event) => $setup.formState.pf_number = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "ESI No.",
                            name: "esi_number"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: $setup.formState.esi_number,
                                "onUpdate:value": ($event) => $setup.formState.esi_number = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Save")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 16, ["model", "validate-messages", "onFinish"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Employees/Create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Create = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Create as default
};
