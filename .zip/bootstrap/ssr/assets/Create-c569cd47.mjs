import { ref, computed, defineComponent, resolveComponent, withCtx, createTextVNode, createVNode, mergeProps, withModifiers, openBlock, createBlock, Fragment, createCommentVNode, toDisplayString, withDirectives, vShow, useSSRContext } from "vue";
import { EditOutlined, PlusOutlined, DownOutlined, PlusCircleOutlined, AlignLeftOutlined } from "@ant-design/icons-vue";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import { Head, useForm } from "@inertiajs/vue3";
import { ssrRenderComponent, ssrRenderAttr, ssrRenderStyle, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
const Create_vue_vue_type_style_index_0_lang = "";
const columns = [
  {
    title: "S.NO",
    key: "sno",
    dataIndex: "sno",
    width: "8%"
  },
  {
    title: "Product Name",
    key: "name",
    dataIndex: "name",
    sorter: true,
    width: "15%"
  },
  {
    title: "HSN or Material code",
    key: "hsn_mat",
    dataIndex: "hsn_mat",
    sorter: true,
    width: "15%"
  },
  {
    title: "Quantity",
    key: "quantity",
    dataIndex: "quantity",
    sorter: true,
    width: "10%"
  },
  {
    title: "Price",
    key: "price",
    dataIndex: "price",
    sorter: true,
    width: "10%"
  },
  {
    title: "Discount",
    key: "discount",
    dataIndex: "discount",
    width: "10%"
  },
  {
    title: "Tax",
    key: "tax",
    dataIndex: "tax",
    width: "10%"
  },
  {
    title: "TOTAL",
    key: "total",
    dataIndex: "total",
    fixed: "right",
    width: "10%"
  }
];
const data = [
  {
    key: "1",
    title: "Tax Exempted",
    description: "",
    value: ""
  },
  {
    key: "2",
    title: "GST@ 0%",
    description: "(NO GST )",
    value: "GST@ 0%"
  },
  {
    title: "GST@ 0.1%",
    description: "(0.05% CSGT + 0.05% SGST/UT GST ; 0.1% IGST )"
  },
  {
    title: "GST@ 0.25%",
    description: "(0.125% CSGT + 0.125% SGST/UT GST ; 0.25% IGST )"
  },
  {
    title: "GST@ 3%",
    description: "(1.5% CSGT + 1.5% SGST/UT GST ; 3% IGST )"
  },
  {
    title: "GST@ 5%",
    description: "(2.5% CSGT + 2.5% SGST/UT GST ; 5% IGST )"
  },
  {
    title: "GST@ 6%",
    description: "(3% CSGT + 3% SGST/UT GST ; 6% IGST )"
  },
  {
    title: "GST@ 7.5%",
    description: "(3.75% CSGT + 3.75% SGST/UT GST ; 7.5% IGST )"
  },
  {
    title: "GST@ 12%",
    description: "(6% CSGT + 6% SGST/UT GST ; 12% IGST )"
  },
  {
    title: "GST@ 18%",
    description: "(9% CSGT + 9% SGST/UT GST ; 18% IGST )"
  },
  {
    title: "GST@ 28%",
    description: "(14% CSGT + 14% SGST/UT GST ; 28% IGST )"
  }
];
const datas = [
  {
    key: "1",
    title: "Tax Exempted",
    description: "",
    value: ""
  }
];
const dataSource = ref([
  {
    key: "1",
    sno: "0",
    name: "Product Name",
    hsn_mat: "",
    quantity: "",
    price: "",
    discount: "",
    tax: "",
    total: ""
  }
]);
const handleAdd = () => {
  const newData = {
    key: "${count.value}",
    name: "Product Name",
    hsn_mat: "",
    quantity: "",
    price: "",
    discount: "",
    tax: "",
    total: ""
  };
  dataSource.value.push(newData);
};
const count = computed(() => dataSource.value.length + 1);
const _sfc_main = defineComponent({
  inject: ["validateMessages"],
  props: {
    pagination: Object,
    errors: Object
  },
  components: {
    AuthenticatedLayout: _sfc_main$1,
    Head,
    EditOutlined,
    PlusOutlined,
    DownOutlined,
    PlusCircleOutlined,
    AlignLeftOutlined
  },
  setup(props) {
    const layout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 16 }
    };
    const checked = ref(false);
    const handleCancel = () => {
      showmodel_visible.value = false;
    };
    const formParty = useForm({
      partyname: "",
      mobile: "",
      who_r_they: "",
      gstin: "",
      flat_no: "",
      area_loc: "",
      pincode: "",
      city: "",
      state: "",
      same_ship: false
    });
    return {
      formParty,
      layout,
      handleAdd,
      handleCancel,
      columns,
      datas,
      data,
      count,
      checked,
      dataSource
    };
  },
  mounted() {
  },
  data() {
    return {
      showmodel_visible: false,
      menu_visible: false,
      invdrawer_visible: false,
      isShowing: false,
      addcustom: false,
      gstShowing: false
    };
  },
  methods: {
    partySubmit() {
      this.formParty.post(this.route("purchase.store"), {
        onError: (errors) => {
        },
        onFinish: (visit) => {
          this.showmodel_visible = false;
        }
      });
    },
    handleTableChange(val) {
      this.$inertia.get(
        "/purchase/index",
        { page: val.current },
        { preserveState: true }
      );
    }
  }
});
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_affix = resolveComponent("a-affix");
  const _component_a_page_header = resolveComponent("a-page-header");
  const _component_a_button = resolveComponent("a-button");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_card = resolveComponent("a-card");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_input_group = resolveComponent("a-input-group");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_select_option = resolveComponent("a-select-option");
  const _component_PlusCircleOutlined = resolveComponent("PlusCircleOutlined");
  const _component_a_modal = resolveComponent("a-modal");
  const _component_a_radio_group = resolveComponent("a-radio-group");
  const _component_a_radio = resolveComponent("a-radio");
  const _component_a_menu = resolveComponent("a-menu");
  const _component_a_sub_menu = resolveComponent("a-sub-menu");
  const _component_a_checkbox = resolveComponent("a-checkbox");
  const _component_a_date_picker = resolveComponent("a-date-picker");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_table = resolveComponent("a-table");
  const _component_EditOutlined = resolveComponent("EditOutlined");
  const _component_a_drawer = resolveComponent("a-drawer");
  const _component_a_input_search = resolveComponent("a-input-search");
  const _component_AlignLeftOutlined = resolveComponent("AlignLeftOutlined");
  const _component_PlusOutlined = resolveComponent("PlusOutlined");
  const _component_a_list = resolveComponent("a-list");
  const _component_a_list_item = resolveComponent("a-list-item");
  const _component_a_list_item_meta = resolveComponent("a-list-item-meta");
  const _component_a_switch = resolveComponent("a-switch");
  const _component_DownOutlined = resolveComponent("DownOutlined");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Employees" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_affix, { "offset-top": 0 }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_page_header, {
                ghost: false,
                title: "Add Purchase",
                onBack: () => _ctx.$inertia.visit(_ctx.route("purchase.index"))
              }, {
                extra: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_button, {
                      key: "1",
                      type: "primary"
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`Save`);
                        } else {
                          return [
                            createTextVNode("Save")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_button, {
                        key: "1",
                        type: "primary"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Save")
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_page_header, {
                  ghost: false,
                  title: "Add Purchase",
                  onBack: () => _ctx.$inertia.visit(_ctx.route("purchase.index"))
                }, {
                  extra: withCtx(() => [
                    createVNode(_component_a_button, {
                      key: "1",
                      type: "primary"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Save")
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }, 8, ["onBack"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_row, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_col, {
                span: 12,
                offset: 0
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_card, { style: { "padding": "0px", "background": "#fff", "minHeight": "2px", "margin-top": "16px", "margin-bottom": "12px", "margin-left": "16px", "height": "270px" } }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                            name: "nest-messages",
                            "validate-messages": _ctx.validateMessages,
                            onFinish: _ctx.submit
                          }), {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`<h3${ssrRenderAttr("wrapper-col", { span: 12, offset: 6 })} style="${ssrRenderStyle({ "margin-bottom": "20px", "font-size": "14px", "margin-top": "10px" })}"${_scopeId5}>PARTY DETAILS</h3>`);
                                _push6(ssrRenderComponent(_component_a_input_group, { size: "medium" }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "PO Number",
                                        name: "po_number"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "PO Number" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "PO Number" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Add Party",
                                        name: "po_number"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select, { placeholder: "Party Name" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_select_option, {
                                                    value: "undefined",
                                                    onClick: () => {
                                                      _ctx.showmodel_visible = true;
                                                    }
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_PlusCircleOutlined, null, null, _parent10, _scopeId9));
                                                        _push10(` Add New Party`);
                                                      } else {
                                                        return [
                                                          createVNode(_component_PlusCircleOutlined),
                                                          createTextVNode(" Add New Party")
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_select_option, {
                                                      value: "undefined",
                                                      onClick: withModifiers(() => {
                                                        _ctx.showmodel_visible = true;
                                                      }, ["stop"])
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_PlusCircleOutlined),
                                                        createTextVNode(" Add New Party")
                                                      ]),
                                                      _: 1
                                                    }, 8, ["onClick"])
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select, { placeholder: "Party Name" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select_option, {
                                                    value: "undefined",
                                                    onClick: withModifiers(() => {
                                                      _ctx.showmodel_visible = true;
                                                    }, ["stop"])
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_PlusCircleOutlined),
                                                      createTextVNode(" Add New Party")
                                                    ]),
                                                    _: 1
                                                  }, 8, ["onClick"])
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "PO Number",
                                          name: "po_number"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "PO Number" })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_form_item, {
                                          label: "Add Party",
                                          name: "po_number"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, { placeholder: "Party Name" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select_option, {
                                                  value: "undefined",
                                                  onClick: withModifiers(() => {
                                                    _ctx.showmodel_visible = true;
                                                  }, ["stop"])
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_PlusCircleOutlined),
                                                    createTextVNode(" Add New Party")
                                                  ]),
                                                  _: 1
                                                }, 8, ["onClick"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_modal, {
                                  title: "Add New Party",
                                  closable: true,
                                  visible: _ctx.showmodel_visible,
                                  "onUpdate:visible": ($event) => _ctx.showmodel_visible = $event,
                                  onClose: ($event) => _ctx.showmodel_visible = false
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form, mergeProps({ model: _ctx.formParty }, _ctx.layout, {
                                        name: "nest-messages",
                                        "validate-messages": _ctx.validateMessages,
                                        onFinish: _ctx.partySubmit
                                      }), {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_form_item, {
                                              label: "Party Name",
                                              name: "partyname",
                                              rules: [{ required: true }]
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_input, {
                                                    value: _ctx.formParty.partyname,
                                                    "onUpdate:value": ($event) => _ctx.formParty.partyname = $event,
                                                    placeholder: "Enter Party Name"
                                                  }, null, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.formParty.partyname,
                                                      "onUpdate:value": ($event) => _ctx.formParty.partyname = $event,
                                                      placeholder: "Enter Party Name"
                                                    }, null, 8, ["value", "onUpdate:value"])
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_form_item, {
                                              label: "Mobile Number",
                                              name: "mobile"
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_input, {
                                                    value: _ctx.formParty.mobile,
                                                    "onUpdate:value": ($event) => _ctx.formParty.mobile = $event,
                                                    placeholder: "Enter Mobile Number"
                                                  }, null, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.formParty.mobile,
                                                      "onUpdate:value": ($event) => _ctx.formParty.mobile = $event,
                                                      placeholder: "Enter Mobile Number"
                                                    }, null, 8, ["value", "onUpdate:value"])
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_form_item, {
                                              label: "Who are they?",
                                              name: "who_r_they"
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_radio_group, {
                                                    value: _ctx.formParty.who_r_they,
                                                    "onUpdate:value": ($event) => _ctx.formParty.who_r_they = $event
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_radio, { value: "customer" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`Customer`);
                                                            } else {
                                                              return [
                                                                createTextVNode("Customer")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                        _push10(ssrRenderComponent(_component_a_radio, { value: "supplier" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`Supplier`);
                                                            } else {
                                                              return [
                                                                createTextVNode("Supplier")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_radio, { value: "customer" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Customer")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_radio, { value: "supplier" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Supplier")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_radio_group, {
                                                      value: _ctx.formParty.who_r_they,
                                                      "onUpdate:value": ($event) => _ctx.formParty.who_r_they = $event
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_radio, { value: "customer" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Customer")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_radio, { value: "supplier" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Supplier")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }, 8, ["value", "onUpdate:value"])
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_form_item, {
                                              label: "GSTIN",
                                              name: "gstin",
                                              rules: [{ required: true }]
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_input, {
                                                    value: _ctx.formParty.gstin,
                                                    "onUpdate:value": ($event) => _ctx.formParty.gstin = $event,
                                                    placeholder: "Enter GSTIN"
                                                  }, null, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.formParty.gstin,
                                                      "onUpdate:value": ($event) => _ctx.formParty.gstin = $event,
                                                      placeholder: "Enter GSTIN"
                                                    }, null, 8, ["value", "onUpdate:value"])
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_menu, {
                                              id: "dddddd",
                                              style: { "width": "100%" },
                                              mode: "inline",
                                              onClick: () => {
                                                _ctx.menu_visible = true;
                                              }
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_sub_menu, {
                                                    key: "sub1",
                                                    visible: _ctx.menu_visible,
                                                    onClose: ($event) => _ctx.menu_visible = false
                                                  }, {
                                                    title: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(`Add GSTIN &amp; Address (Optional)`);
                                                      } else {
                                                        return [
                                                          createTextVNode("Add GSTIN & Address (Optional)")
                                                        ];
                                                      }
                                                    }),
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(`<h5${ssrRenderAttr("wrapper-col", { span: 12, offset: 6 })} style="${ssrRenderStyle({ "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" })}"${_scopeId9}>Shipping Address</h5><br${_scopeId9}><br${_scopeId9}>`);
                                                        _push10(ssrRenderComponent(_component_a_form_item, {
                                                          label: "Flat / Building Number",
                                                          name: "flat_no"
                                                        }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(ssrRenderComponent(_component_a_input, {
                                                                value: _ctx.formParty.flat_no,
                                                                "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                                                placeholder: "Enter Flat / Building Number"
                                                              }, null, _parent11, _scopeId10));
                                                            } else {
                                                              return [
                                                                createVNode(_component_a_input, {
                                                                  value: _ctx.formParty.flat_no,
                                                                  "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                                                  placeholder: "Enter Flat / Building Number"
                                                                }, null, 8, ["value", "onUpdate:value"])
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                        _push10(ssrRenderComponent(_component_a_form_item, {
                                                          label: "Area / Locality",
                                                          name: "area_loc"
                                                        }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(ssrRenderComponent(_component_a_input, {
                                                                value: _ctx.formParty.area_loc,
                                                                "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                                                placeholder: "Enter Area / Locality"
                                                              }, null, _parent11, _scopeId10));
                                                            } else {
                                                              return [
                                                                createVNode(_component_a_input, {
                                                                  value: _ctx.formParty.area_loc,
                                                                  "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                                                  placeholder: "Enter Area / Locality"
                                                                }, null, 8, ["value", "onUpdate:value"])
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                        _push10(ssrRenderComponent(_component_a_form_item, {
                                                          label: "PIN Code",
                                                          name: "pincode"
                                                        }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(ssrRenderComponent(_component_a_input, {
                                                                value: _ctx.formParty.pincode,
                                                                "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                                                placeholder: "Enter PIN Code"
                                                              }, null, _parent11, _scopeId10));
                                                            } else {
                                                              return [
                                                                createVNode(_component_a_input, {
                                                                  value: _ctx.formParty.pincode,
                                                                  "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                                                  placeholder: "Enter PIN Code"
                                                                }, null, 8, ["value", "onUpdate:value"])
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                        _push10(ssrRenderComponent(_component_a_form_item, {
                                                          label: "City",
                                                          name: "city"
                                                        }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(ssrRenderComponent(_component_a_input, {
                                                                value: _ctx.formParty.city,
                                                                "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                                                placeholder: "Enter City"
                                                              }, null, _parent11, _scopeId10));
                                                            } else {
                                                              return [
                                                                createVNode(_component_a_input, {
                                                                  value: _ctx.formParty.city,
                                                                  "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                                                  placeholder: "Enter City"
                                                                }, null, 8, ["value", "onUpdate:value"])
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                        _push10(ssrRenderComponent(_component_a_form_item, {
                                                          label: "State",
                                                          name: "state"
                                                        }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(ssrRenderComponent(_component_a_input, {
                                                                value: _ctx.formParty.state,
                                                                "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                                                placeholder: "Enter State"
                                                              }, null, _parent11, _scopeId10));
                                                            } else {
                                                              return [
                                                                createVNode(_component_a_input, {
                                                                  value: _ctx.formParty.state,
                                                                  "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                                                  placeholder: "Enter State"
                                                                }, null, 8, ["value", "onUpdate:value"])
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                        _push10(ssrRenderComponent(_component_a_form_item, { name: "same_ship" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(ssrRenderComponent(_component_a_checkbox, {
                                                                checked: _ctx.formParty.same_ship,
                                                                "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                                              }, {
                                                                default: withCtx((_11, _push12, _parent12, _scopeId11) => {
                                                                  if (_push12) {
                                                                    _push12(`Shipping address same as billing address`);
                                                                  } else {
                                                                    return [
                                                                      createTextVNode("Shipping address same as billing address")
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 1
                                                              }, _parent11, _scopeId10));
                                                            } else {
                                                              return [
                                                                createVNode(_component_a_checkbox, {
                                                                  checked: _ctx.formParty.same_ship,
                                                                  "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode("Shipping address same as billing address")
                                                                  ]),
                                                                  _: 1
                                                                }, 8, ["checked", "onUpdate:checked"])
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode("h5", {
                                                            "wrapper-col": { span: 12, offset: 6 },
                                                            style: { "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" }
                                                          }, "Shipping Address"),
                                                          createVNode("br"),
                                                          createVNode("br"),
                                                          createVNode(_component_a_form_item, {
                                                            label: "Flat / Building Number",
                                                            name: "flat_no"
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_a_input, {
                                                                value: _ctx.formParty.flat_no,
                                                                "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                                                placeholder: "Enter Flat / Building Number"
                                                              }, null, 8, ["value", "onUpdate:value"])
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_form_item, {
                                                            label: "Area / Locality",
                                                            name: "area_loc"
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_a_input, {
                                                                value: _ctx.formParty.area_loc,
                                                                "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                                                placeholder: "Enter Area / Locality"
                                                              }, null, 8, ["value", "onUpdate:value"])
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_form_item, {
                                                            label: "PIN Code",
                                                            name: "pincode"
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_a_input, {
                                                                value: _ctx.formParty.pincode,
                                                                "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                                                placeholder: "Enter PIN Code"
                                                              }, null, 8, ["value", "onUpdate:value"])
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_form_item, {
                                                            label: "City",
                                                            name: "city"
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_a_input, {
                                                                value: _ctx.formParty.city,
                                                                "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                                                placeholder: "Enter City"
                                                              }, null, 8, ["value", "onUpdate:value"])
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_form_item, {
                                                            label: "State",
                                                            name: "state"
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_a_input, {
                                                                value: _ctx.formParty.state,
                                                                "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                                                placeholder: "Enter State"
                                                              }, null, 8, ["value", "onUpdate:value"])
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_form_item, { name: "same_ship" }, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_a_checkbox, {
                                                                checked: _ctx.formParty.same_ship,
                                                                "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                                              }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode("Shipping address same as billing address")
                                                                ]),
                                                                _: 1
                                                              }, 8, ["checked", "onUpdate:checked"])
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_sub_menu, {
                                                      key: "sub1",
                                                      visible: _ctx.menu_visible,
                                                      onClose: ($event) => _ctx.menu_visible = false
                                                    }, {
                                                      title: withCtx(() => [
                                                        createTextVNode("Add GSTIN & Address (Optional)")
                                                      ]),
                                                      default: withCtx(() => [
                                                        createVNode("h5", {
                                                          "wrapper-col": { span: 12, offset: 6 },
                                                          style: { "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" }
                                                        }, "Shipping Address"),
                                                        createVNode("br"),
                                                        createVNode("br"),
                                                        createVNode(_component_a_form_item, {
                                                          label: "Flat / Building Number",
                                                          name: "flat_no"
                                                        }, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_a_input, {
                                                              value: _ctx.formParty.flat_no,
                                                              "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                                              placeholder: "Enter Flat / Building Number"
                                                            }, null, 8, ["value", "onUpdate:value"])
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_form_item, {
                                                          label: "Area / Locality",
                                                          name: "area_loc"
                                                        }, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_a_input, {
                                                              value: _ctx.formParty.area_loc,
                                                              "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                                              placeholder: "Enter Area / Locality"
                                                            }, null, 8, ["value", "onUpdate:value"])
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_form_item, {
                                                          label: "PIN Code",
                                                          name: "pincode"
                                                        }, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_a_input, {
                                                              value: _ctx.formParty.pincode,
                                                              "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                                              placeholder: "Enter PIN Code"
                                                            }, null, 8, ["value", "onUpdate:value"])
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_form_item, {
                                                          label: "City",
                                                          name: "city"
                                                        }, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_a_input, {
                                                              value: _ctx.formParty.city,
                                                              "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                                              placeholder: "Enter City"
                                                            }, null, 8, ["value", "onUpdate:value"])
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_form_item, {
                                                          label: "State",
                                                          name: "state"
                                                        }, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_a_input, {
                                                              value: _ctx.formParty.state,
                                                              "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                                              placeholder: "Enter State"
                                                            }, null, 8, ["value", "onUpdate:value"])
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_form_item, { name: "same_ship" }, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_a_checkbox, {
                                                              checked: _ctx.formParty.same_ship,
                                                              "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                                            }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("Shipping address same as billing address")
                                                              ]),
                                                              _: 1
                                                            }, 8, ["checked", "onUpdate:checked"])
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }, 8, ["visible", "onClose"])
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_form_item, {
                                              "wrapper-col": { span: 12, offset: 6 },
                                              style: { "margin-top": "19px", "margin-left": "100px" }
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_button, {
                                                    type: "primary",
                                                    "html-type": "submit"
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(`Save`);
                                                      } else {
                                                        return [
                                                          createTextVNode("Save")
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_button, {
                                                      type: "primary",
                                                      "html-type": "submit"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Save")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_form_item, {
                                                label: "Party Name",
                                                name: "partyname",
                                                rules: [{ required: true }]
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.formParty.partyname,
                                                    "onUpdate:value": ($event) => _ctx.formParty.partyname = $event,
                                                    placeholder: "Enter Party Name"
                                                  }, null, 8, ["value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_form_item, {
                                                label: "Mobile Number",
                                                name: "mobile"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.formParty.mobile,
                                                    "onUpdate:value": ($event) => _ctx.formParty.mobile = $event,
                                                    placeholder: "Enter Mobile Number"
                                                  }, null, 8, ["value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_form_item, {
                                                label: "Who are they?",
                                                name: "who_r_they"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_radio_group, {
                                                    value: _ctx.formParty.who_r_they,
                                                    "onUpdate:value": ($event) => _ctx.formParty.who_r_they = $event
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_radio, { value: "customer" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Customer")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_radio, { value: "supplier" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Supplier")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }, 8, ["value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_form_item, {
                                                label: "GSTIN",
                                                name: "gstin",
                                                rules: [{ required: true }]
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.formParty.gstin,
                                                    "onUpdate:value": ($event) => _ctx.formParty.gstin = $event,
                                                    placeholder: "Enter GSTIN"
                                                  }, null, 8, ["value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_menu, {
                                                id: "dddddd",
                                                style: { "width": "100%" },
                                                mode: "inline",
                                                onClick: withModifiers(() => {
                                                  _ctx.menu_visible = true;
                                                }, ["stop"])
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_sub_menu, {
                                                    key: "sub1",
                                                    visible: _ctx.menu_visible,
                                                    onClose: ($event) => _ctx.menu_visible = false
                                                  }, {
                                                    title: withCtx(() => [
                                                      createTextVNode("Add GSTIN & Address (Optional)")
                                                    ]),
                                                    default: withCtx(() => [
                                                      createVNode("h5", {
                                                        "wrapper-col": { span: 12, offset: 6 },
                                                        style: { "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" }
                                                      }, "Shipping Address"),
                                                      createVNode("br"),
                                                      createVNode("br"),
                                                      createVNode(_component_a_form_item, {
                                                        label: "Flat / Building Number",
                                                        name: "flat_no"
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_input, {
                                                            value: _ctx.formParty.flat_no,
                                                            "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                                            placeholder: "Enter Flat / Building Number"
                                                          }, null, 8, ["value", "onUpdate:value"])
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_form_item, {
                                                        label: "Area / Locality",
                                                        name: "area_loc"
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_input, {
                                                            value: _ctx.formParty.area_loc,
                                                            "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                                            placeholder: "Enter Area / Locality"
                                                          }, null, 8, ["value", "onUpdate:value"])
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_form_item, {
                                                        label: "PIN Code",
                                                        name: "pincode"
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_input, {
                                                            value: _ctx.formParty.pincode,
                                                            "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                                            placeholder: "Enter PIN Code"
                                                          }, null, 8, ["value", "onUpdate:value"])
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_form_item, {
                                                        label: "City",
                                                        name: "city"
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_input, {
                                                            value: _ctx.formParty.city,
                                                            "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                                            placeholder: "Enter City"
                                                          }, null, 8, ["value", "onUpdate:value"])
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_form_item, {
                                                        label: "State",
                                                        name: "state"
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_input, {
                                                            value: _ctx.formParty.state,
                                                            "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                                            placeholder: "Enter State"
                                                          }, null, 8, ["value", "onUpdate:value"])
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_form_item, { name: "same_ship" }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_checkbox, {
                                                            checked: _ctx.formParty.same_ship,
                                                            "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                                          }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Shipping address same as billing address")
                                                            ]),
                                                            _: 1
                                                          }, 8, ["checked", "onUpdate:checked"])
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }, 8, ["visible", "onClose"])
                                                ]),
                                                _: 1
                                              }, 8, ["onClick"]),
                                              createVNode(_component_a_form_item, {
                                                "wrapper-col": { span: 12, offset: 6 },
                                                style: { "margin-top": "19px", "margin-left": "100px" }
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_button, {
                                                    type: "primary",
                                                    "html-type": "submit"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Save")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form, mergeProps({ model: _ctx.formParty }, _ctx.layout, {
                                          name: "nest-messages",
                                          "validate-messages": _ctx.validateMessages,
                                          onFinish: _ctx.partySubmit
                                        }), {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Party Name",
                                              name: "partyname",
                                              rules: [{ required: true }]
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.formParty.partyname,
                                                  "onUpdate:value": ($event) => _ctx.formParty.partyname = $event,
                                                  placeholder: "Enter Party Name"
                                                }, null, 8, ["value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_form_item, {
                                              label: "Mobile Number",
                                              name: "mobile"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.formParty.mobile,
                                                  "onUpdate:value": ($event) => _ctx.formParty.mobile = $event,
                                                  placeholder: "Enter Mobile Number"
                                                }, null, 8, ["value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_form_item, {
                                              label: "Who are they?",
                                              name: "who_r_they"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_radio_group, {
                                                  value: _ctx.formParty.who_r_they,
                                                  "onUpdate:value": ($event) => _ctx.formParty.who_r_they = $event
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_radio, { value: "customer" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Customer")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_radio, { value: "supplier" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Supplier")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }, 8, ["value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_form_item, {
                                              label: "GSTIN",
                                              name: "gstin",
                                              rules: [{ required: true }]
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.formParty.gstin,
                                                  "onUpdate:value": ($event) => _ctx.formParty.gstin = $event,
                                                  placeholder: "Enter GSTIN"
                                                }, null, 8, ["value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_menu, {
                                              id: "dddddd",
                                              style: { "width": "100%" },
                                              mode: "inline",
                                              onClick: withModifiers(() => {
                                                _ctx.menu_visible = true;
                                              }, ["stop"])
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_sub_menu, {
                                                  key: "sub1",
                                                  visible: _ctx.menu_visible,
                                                  onClose: ($event) => _ctx.menu_visible = false
                                                }, {
                                                  title: withCtx(() => [
                                                    createTextVNode("Add GSTIN & Address (Optional)")
                                                  ]),
                                                  default: withCtx(() => [
                                                    createVNode("h5", {
                                                      "wrapper-col": { span: 12, offset: 6 },
                                                      style: { "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" }
                                                    }, "Shipping Address"),
                                                    createVNode("br"),
                                                    createVNode("br"),
                                                    createVNode(_component_a_form_item, {
                                                      label: "Flat / Building Number",
                                                      name: "flat_no"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, {
                                                          value: _ctx.formParty.flat_no,
                                                          "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                                          placeholder: "Enter Flat / Building Number"
                                                        }, null, 8, ["value", "onUpdate:value"])
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_form_item, {
                                                      label: "Area / Locality",
                                                      name: "area_loc"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, {
                                                          value: _ctx.formParty.area_loc,
                                                          "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                                          placeholder: "Enter Area / Locality"
                                                        }, null, 8, ["value", "onUpdate:value"])
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_form_item, {
                                                      label: "PIN Code",
                                                      name: "pincode"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, {
                                                          value: _ctx.formParty.pincode,
                                                          "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                                          placeholder: "Enter PIN Code"
                                                        }, null, 8, ["value", "onUpdate:value"])
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_form_item, {
                                                      label: "City",
                                                      name: "city"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, {
                                                          value: _ctx.formParty.city,
                                                          "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                                          placeholder: "Enter City"
                                                        }, null, 8, ["value", "onUpdate:value"])
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_form_item, {
                                                      label: "State",
                                                      name: "state"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, {
                                                          value: _ctx.formParty.state,
                                                          "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                                          placeholder: "Enter State"
                                                        }, null, 8, ["value", "onUpdate:value"])
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_form_item, { name: "same_ship" }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_checkbox, {
                                                          checked: _ctx.formParty.same_ship,
                                                          "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                                        }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Shipping address same as billing address")
                                                          ]),
                                                          _: 1
                                                        }, 8, ["checked", "onUpdate:checked"])
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }, 8, ["visible", "onClose"])
                                              ]),
                                              _: 1
                                            }, 8, ["onClick"]),
                                            createVNode(_component_a_form_item, {
                                              "wrapper-col": { span: 12, offset: 6 },
                                              style: { "margin-top": "19px", "margin-left": "100px" }
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_button, {
                                                  type: "primary",
                                                  "html-type": "submit"
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Save")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 16, ["model", "validate-messages", "onFinish"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode("h3", {
                                    "wrapper-col": { span: 12, offset: 6 },
                                    style: { "margin-bottom": "20px", "font-size": "14px", "margin-top": "10px" }
                                  }, "PARTY DETAILS"),
                                  createVNode(_component_a_input_group, { size: "medium" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "PO Number",
                                        name: "po_number"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "PO Number" })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_form_item, {
                                        label: "Add Party",
                                        name: "po_number"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, { placeholder: "Party Name" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select_option, {
                                                value: "undefined",
                                                onClick: withModifiers(() => {
                                                  _ctx.showmodel_visible = true;
                                                }, ["stop"])
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_PlusCircleOutlined),
                                                  createTextVNode(" Add New Party")
                                                ]),
                                                _: 1
                                              }, 8, ["onClick"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_modal, {
                                    title: "Add New Party",
                                    closable: true,
                                    visible: _ctx.showmodel_visible,
                                    "onUpdate:visible": ($event) => _ctx.showmodel_visible = $event,
                                    onClose: ($event) => _ctx.showmodel_visible = false
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form, mergeProps({ model: _ctx.formParty }, _ctx.layout, {
                                        name: "nest-messages",
                                        "validate-messages": _ctx.validateMessages,
                                        onFinish: _ctx.partySubmit
                                      }), {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Party Name",
                                            name: "partyname",
                                            rules: [{ required: true }]
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.formParty.partyname,
                                                "onUpdate:value": ($event) => _ctx.formParty.partyname = $event,
                                                placeholder: "Enter Party Name"
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_form_item, {
                                            label: "Mobile Number",
                                            name: "mobile"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.formParty.mobile,
                                                "onUpdate:value": ($event) => _ctx.formParty.mobile = $event,
                                                placeholder: "Enter Mobile Number"
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_form_item, {
                                            label: "Who are they?",
                                            name: "who_r_they"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_radio_group, {
                                                value: _ctx.formParty.who_r_they,
                                                "onUpdate:value": ($event) => _ctx.formParty.who_r_they = $event
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_radio, { value: "customer" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Customer")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_radio, { value: "supplier" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Supplier")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }, 8, ["value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_form_item, {
                                            label: "GSTIN",
                                            name: "gstin",
                                            rules: [{ required: true }]
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.formParty.gstin,
                                                "onUpdate:value": ($event) => _ctx.formParty.gstin = $event,
                                                placeholder: "Enter GSTIN"
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_menu, {
                                            id: "dddddd",
                                            style: { "width": "100%" },
                                            mode: "inline",
                                            onClick: withModifiers(() => {
                                              _ctx.menu_visible = true;
                                            }, ["stop"])
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_sub_menu, {
                                                key: "sub1",
                                                visible: _ctx.menu_visible,
                                                onClose: ($event) => _ctx.menu_visible = false
                                              }, {
                                                title: withCtx(() => [
                                                  createTextVNode("Add GSTIN & Address (Optional)")
                                                ]),
                                                default: withCtx(() => [
                                                  createVNode("h5", {
                                                    "wrapper-col": { span: 12, offset: 6 },
                                                    style: { "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" }
                                                  }, "Shipping Address"),
                                                  createVNode("br"),
                                                  createVNode("br"),
                                                  createVNode(_component_a_form_item, {
                                                    label: "Flat / Building Number",
                                                    name: "flat_no"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, {
                                                        value: _ctx.formParty.flat_no,
                                                        "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                                        placeholder: "Enter Flat / Building Number"
                                                      }, null, 8, ["value", "onUpdate:value"])
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_form_item, {
                                                    label: "Area / Locality",
                                                    name: "area_loc"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, {
                                                        value: _ctx.formParty.area_loc,
                                                        "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                                        placeholder: "Enter Area / Locality"
                                                      }, null, 8, ["value", "onUpdate:value"])
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_form_item, {
                                                    label: "PIN Code",
                                                    name: "pincode"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, {
                                                        value: _ctx.formParty.pincode,
                                                        "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                                        placeholder: "Enter PIN Code"
                                                      }, null, 8, ["value", "onUpdate:value"])
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_form_item, {
                                                    label: "City",
                                                    name: "city"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, {
                                                        value: _ctx.formParty.city,
                                                        "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                                        placeholder: "Enter City"
                                                      }, null, 8, ["value", "onUpdate:value"])
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_form_item, {
                                                    label: "State",
                                                    name: "state"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, {
                                                        value: _ctx.formParty.state,
                                                        "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                                        placeholder: "Enter State"
                                                      }, null, 8, ["value", "onUpdate:value"])
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_form_item, { name: "same_ship" }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_checkbox, {
                                                        checked: _ctx.formParty.same_ship,
                                                        "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                                      }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Shipping address same as billing address")
                                                        ]),
                                                        _: 1
                                                      }, 8, ["checked", "onUpdate:checked"])
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }, 8, ["visible", "onClose"])
                                            ]),
                                            _: 1
                                          }, 8, ["onClick"]),
                                          createVNode(_component_a_form_item, {
                                            "wrapper-col": { span: 12, offset: 6 },
                                            style: { "margin-top": "19px", "margin-left": "100px" }
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_button, {
                                                type: "primary",
                                                "html-type": "submit"
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Save")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 16, ["model", "validate-messages", "onFinish"])
                                    ]),
                                    _: 1
                                  }, 8, ["visible", "onUpdate:visible", "onClose"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                              name: "nest-messages",
                              "validate-messages": _ctx.validateMessages,
                              onFinish: _ctx.submit
                            }), {
                              default: withCtx(() => [
                                createVNode("h3", {
                                  "wrapper-col": { span: 12, offset: 6 },
                                  style: { "margin-bottom": "20px", "font-size": "14px", "margin-top": "10px" }
                                }, "PARTY DETAILS"),
                                createVNode(_component_a_input_group, { size: "medium" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "PO Number",
                                      name: "po_number"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "PO Number" })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_form_item, {
                                      label: "Add Party",
                                      name: "po_number"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, { placeholder: "Party Name" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, {
                                              value: "undefined",
                                              onClick: withModifiers(() => {
                                                _ctx.showmodel_visible = true;
                                              }, ["stop"])
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_PlusCircleOutlined),
                                                createTextVNode(" Add New Party")
                                              ]),
                                              _: 1
                                            }, 8, ["onClick"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_modal, {
                                  title: "Add New Party",
                                  closable: true,
                                  visible: _ctx.showmodel_visible,
                                  "onUpdate:visible": ($event) => _ctx.showmodel_visible = $event,
                                  onClose: ($event) => _ctx.showmodel_visible = false
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form, mergeProps({ model: _ctx.formParty }, _ctx.layout, {
                                      name: "nest-messages",
                                      "validate-messages": _ctx.validateMessages,
                                      onFinish: _ctx.partySubmit
                                    }), {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Party Name",
                                          name: "partyname",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: _ctx.formParty.partyname,
                                              "onUpdate:value": ($event) => _ctx.formParty.partyname = $event,
                                              placeholder: "Enter Party Name"
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_form_item, {
                                          label: "Mobile Number",
                                          name: "mobile"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: _ctx.formParty.mobile,
                                              "onUpdate:value": ($event) => _ctx.formParty.mobile = $event,
                                              placeholder: "Enter Mobile Number"
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_form_item, {
                                          label: "Who are they?",
                                          name: "who_r_they"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_radio_group, {
                                              value: _ctx.formParty.who_r_they,
                                              "onUpdate:value": ($event) => _ctx.formParty.who_r_they = $event
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_radio, { value: "customer" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Customer")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_radio, { value: "supplier" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Supplier")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_form_item, {
                                          label: "GSTIN",
                                          name: "gstin",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: _ctx.formParty.gstin,
                                              "onUpdate:value": ($event) => _ctx.formParty.gstin = $event,
                                              placeholder: "Enter GSTIN"
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_menu, {
                                          id: "dddddd",
                                          style: { "width": "100%" },
                                          mode: "inline",
                                          onClick: withModifiers(() => {
                                            _ctx.menu_visible = true;
                                          }, ["stop"])
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_sub_menu, {
                                              key: "sub1",
                                              visible: _ctx.menu_visible,
                                              onClose: ($event) => _ctx.menu_visible = false
                                            }, {
                                              title: withCtx(() => [
                                                createTextVNode("Add GSTIN & Address (Optional)")
                                              ]),
                                              default: withCtx(() => [
                                                createVNode("h5", {
                                                  "wrapper-col": { span: 12, offset: 6 },
                                                  style: { "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" }
                                                }, "Shipping Address"),
                                                createVNode("br"),
                                                createVNode("br"),
                                                createVNode(_component_a_form_item, {
                                                  label: "Flat / Building Number",
                                                  name: "flat_no"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.formParty.flat_no,
                                                      "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                                      placeholder: "Enter Flat / Building Number"
                                                    }, null, 8, ["value", "onUpdate:value"])
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_form_item, {
                                                  label: "Area / Locality",
                                                  name: "area_loc"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.formParty.area_loc,
                                                      "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                                      placeholder: "Enter Area / Locality"
                                                    }, null, 8, ["value", "onUpdate:value"])
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_form_item, {
                                                  label: "PIN Code",
                                                  name: "pincode"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.formParty.pincode,
                                                      "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                                      placeholder: "Enter PIN Code"
                                                    }, null, 8, ["value", "onUpdate:value"])
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_form_item, {
                                                  label: "City",
                                                  name: "city"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.formParty.city,
                                                      "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                                      placeholder: "Enter City"
                                                    }, null, 8, ["value", "onUpdate:value"])
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_form_item, {
                                                  label: "State",
                                                  name: "state"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.formParty.state,
                                                      "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                                      placeholder: "Enter State"
                                                    }, null, 8, ["value", "onUpdate:value"])
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_form_item, { name: "same_ship" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_checkbox, {
                                                      checked: _ctx.formParty.same_ship,
                                                      "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                                    }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Shipping address same as billing address")
                                                      ]),
                                                      _: 1
                                                    }, 8, ["checked", "onUpdate:checked"])
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }, 8, ["visible", "onClose"])
                                          ]),
                                          _: 1
                                        }, 8, ["onClick"]),
                                        createVNode(_component_a_form_item, {
                                          "wrapper-col": { span: 12, offset: 6 },
                                          style: { "margin-top": "19px", "margin-left": "100px" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_button, {
                                              type: "primary",
                                              "html-type": "submit"
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode("Save")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 16, ["model", "validate-messages", "onFinish"])
                                  ]),
                                  _: 1
                                }, 8, ["visible", "onUpdate:visible", "onClose"])
                              ]),
                              _: 1
                            }, 16, ["model", "validate-messages", "onFinish"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_card, { style: { "padding": "0px", "background": "#fff", "minHeight": "2px", "margin-top": "16px", "margin-bottom": "12px", "margin-left": "16px", "height": "270px" } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                            name: "nest-messages",
                            "validate-messages": _ctx.validateMessages,
                            onFinish: _ctx.submit
                          }), {
                            default: withCtx(() => [
                              createVNode("h3", {
                                "wrapper-col": { span: 12, offset: 6 },
                                style: { "margin-bottom": "20px", "font-size": "14px", "margin-top": "10px" }
                              }, "PARTY DETAILS"),
                              createVNode(_component_a_input_group, { size: "medium" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "PO Number",
                                    name: "po_number"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "PO Number" })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Add Party",
                                    name: "po_number"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, { placeholder: "Party Name" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, {
                                            value: "undefined",
                                            onClick: withModifiers(() => {
                                              _ctx.showmodel_visible = true;
                                            }, ["stop"])
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_PlusCircleOutlined),
                                              createTextVNode(" Add New Party")
                                            ]),
                                            _: 1
                                          }, 8, ["onClick"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_modal, {
                                title: "Add New Party",
                                closable: true,
                                visible: _ctx.showmodel_visible,
                                "onUpdate:visible": ($event) => _ctx.showmodel_visible = $event,
                                onClose: ($event) => _ctx.showmodel_visible = false
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form, mergeProps({ model: _ctx.formParty }, _ctx.layout, {
                                    name: "nest-messages",
                                    "validate-messages": _ctx.validateMessages,
                                    onFinish: _ctx.partySubmit
                                  }), {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Party Name",
                                        name: "partyname",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: _ctx.formParty.partyname,
                                            "onUpdate:value": ($event) => _ctx.formParty.partyname = $event,
                                            placeholder: "Enter Party Name"
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_form_item, {
                                        label: "Mobile Number",
                                        name: "mobile"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: _ctx.formParty.mobile,
                                            "onUpdate:value": ($event) => _ctx.formParty.mobile = $event,
                                            placeholder: "Enter Mobile Number"
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_form_item, {
                                        label: "Who are they?",
                                        name: "who_r_they"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_radio_group, {
                                            value: _ctx.formParty.who_r_they,
                                            "onUpdate:value": ($event) => _ctx.formParty.who_r_they = $event
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_radio, { value: "customer" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Customer")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_radio, { value: "supplier" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Supplier")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_form_item, {
                                        label: "GSTIN",
                                        name: "gstin",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: _ctx.formParty.gstin,
                                            "onUpdate:value": ($event) => _ctx.formParty.gstin = $event,
                                            placeholder: "Enter GSTIN"
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_menu, {
                                        id: "dddddd",
                                        style: { "width": "100%" },
                                        mode: "inline",
                                        onClick: withModifiers(() => {
                                          _ctx.menu_visible = true;
                                        }, ["stop"])
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_sub_menu, {
                                            key: "sub1",
                                            visible: _ctx.menu_visible,
                                            onClose: ($event) => _ctx.menu_visible = false
                                          }, {
                                            title: withCtx(() => [
                                              createTextVNode("Add GSTIN & Address (Optional)")
                                            ]),
                                            default: withCtx(() => [
                                              createVNode("h5", {
                                                "wrapper-col": { span: 12, offset: 6 },
                                                style: { "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" }
                                              }, "Shipping Address"),
                                              createVNode("br"),
                                              createVNode("br"),
                                              createVNode(_component_a_form_item, {
                                                label: "Flat / Building Number",
                                                name: "flat_no"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.formParty.flat_no,
                                                    "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                                    placeholder: "Enter Flat / Building Number"
                                                  }, null, 8, ["value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_form_item, {
                                                label: "Area / Locality",
                                                name: "area_loc"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.formParty.area_loc,
                                                    "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                                    placeholder: "Enter Area / Locality"
                                                  }, null, 8, ["value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_form_item, {
                                                label: "PIN Code",
                                                name: "pincode"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.formParty.pincode,
                                                    "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                                    placeholder: "Enter PIN Code"
                                                  }, null, 8, ["value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_form_item, {
                                                label: "City",
                                                name: "city"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.formParty.city,
                                                    "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                                    placeholder: "Enter City"
                                                  }, null, 8, ["value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_form_item, {
                                                label: "State",
                                                name: "state"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.formParty.state,
                                                    "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                                    placeholder: "Enter State"
                                                  }, null, 8, ["value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_form_item, { name: "same_ship" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_checkbox, {
                                                    checked: _ctx.formParty.same_ship,
                                                    "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                                  }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Shipping address same as billing address")
                                                    ]),
                                                    _: 1
                                                  }, 8, ["checked", "onUpdate:checked"])
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }, 8, ["visible", "onClose"])
                                        ]),
                                        _: 1
                                      }, 8, ["onClick"]),
                                      createVNode(_component_a_form_item, {
                                        "wrapper-col": { span: 12, offset: 6 },
                                        style: { "margin-top": "19px", "margin-left": "100px" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_button, {
                                            type: "primary",
                                            "html-type": "submit"
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode("Save")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 16, ["model", "validate-messages", "onFinish"])
                                ]),
                                _: 1
                              }, 8, ["visible", "onUpdate:visible", "onClose"])
                            ]),
                            _: 1
                          }, 16, ["model", "validate-messages", "onFinish"])
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_col, { span: 12 }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_card, { style: { "margin-top": "16px", "margin-bottom": "12px", "margin-left": "12px", "margin-right": "16px", "padding": "0px", "background": "#fff", "minHeight": "2px" } }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                            name: "nest-messages",
                            "validate-messages": _ctx.validateMessages,
                            onFinish: _ctx.submit
                          }), {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`<h3${ssrRenderAttr("wrapper-col", { span: 12, offset: 6 })} style="${ssrRenderStyle({ "margin-bottom": "20px", "font-size": "14px", "margin-top": "10px" })}"${_scopeId5}>PURCHASE DETAILS</h3>`);
                                _push6(ssrRenderComponent(_component_a_input_group, { size: "medium" }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Bill Number",
                                        name: "bill_no",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: _ctx.value,
                                              "onUpdate:value": ($event) => _ctx.value = $event,
                                              placeholder: "Bill Number"
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: _ctx.value,
                                                "onUpdate:value": ($event) => _ctx.value = $event,
                                                placeholder: "Bill Number"
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Bill Date",
                                        name: "date",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_date_picker, {
                                              "value-format": "YYYY-MM-DD",
                                              style: { "width": "100%" }
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_date_picker, {
                                                "value-format": "YYYY-MM-DD",
                                                style: { "width": "100%" }
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Delivery Date",
                                        name: "date"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_date_picker, {
                                              "value-format": "YYYY-MM-DD",
                                              style: { "width": "100%" }
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_date_picker, {
                                                "value-format": "YYYY-MM-DD",
                                                style: { "width": "100%" }
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Bill Number",
                                          name: "bill_no",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: _ctx.value,
                                              "onUpdate:value": ($event) => _ctx.value = $event,
                                              placeholder: "Bill Number"
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_form_item, {
                                          label: "Bill Date",
                                          name: "date",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_date_picker, {
                                              "value-format": "YYYY-MM-DD",
                                              style: { "width": "100%" }
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_form_item, {
                                          label: "Delivery Date",
                                          name: "date"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_date_picker, {
                                              "value-format": "YYYY-MM-DD",
                                              style: { "width": "100%" }
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode("h3", {
                                    "wrapper-col": { span: 12, offset: 6 },
                                    style: { "margin-bottom": "20px", "font-size": "14px", "margin-top": "10px" }
                                  }, "PURCHASE DETAILS"),
                                  createVNode(_component_a_input_group, { size: "medium" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Bill Number",
                                        name: "bill_no",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: _ctx.value,
                                            "onUpdate:value": ($event) => _ctx.value = $event,
                                            placeholder: "Bill Number"
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_form_item, {
                                        label: "Bill Date",
                                        name: "date",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_date_picker, {
                                            "value-format": "YYYY-MM-DD",
                                            style: { "width": "100%" }
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_form_item, {
                                        label: "Delivery Date",
                                        name: "date"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_date_picker, {
                                            "value-format": "YYYY-MM-DD",
                                            style: { "width": "100%" }
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                              name: "nest-messages",
                              "validate-messages": _ctx.validateMessages,
                              onFinish: _ctx.submit
                            }), {
                              default: withCtx(() => [
                                createVNode("h3", {
                                  "wrapper-col": { span: 12, offset: 6 },
                                  style: { "margin-bottom": "20px", "font-size": "14px", "margin-top": "10px" }
                                }, "PURCHASE DETAILS"),
                                createVNode(_component_a_input_group, { size: "medium" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Bill Number",
                                      name: "bill_no",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: _ctx.value,
                                          "onUpdate:value": ($event) => _ctx.value = $event,
                                          placeholder: "Bill Number"
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_form_item, {
                                      label: "Bill Date",
                                      name: "date",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_date_picker, {
                                          "value-format": "YYYY-MM-DD",
                                          style: { "width": "100%" }
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_form_item, {
                                      label: "Delivery Date",
                                      name: "date"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_date_picker, {
                                          "value-format": "YYYY-MM-DD",
                                          style: { "width": "100%" }
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 16, ["model", "validate-messages", "onFinish"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_card, { style: { "margin-top": "16px", "margin-bottom": "12px", "margin-left": "12px", "margin-right": "16px", "padding": "0px", "background": "#fff", "minHeight": "2px" } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                            name: "nest-messages",
                            "validate-messages": _ctx.validateMessages,
                            onFinish: _ctx.submit
                          }), {
                            default: withCtx(() => [
                              createVNode("h3", {
                                "wrapper-col": { span: 12, offset: 6 },
                                style: { "margin-bottom": "20px", "font-size": "14px", "margin-top": "10px" }
                              }, "PURCHASE DETAILS"),
                              createVNode(_component_a_input_group, { size: "medium" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Bill Number",
                                    name: "bill_no",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.value,
                                        "onUpdate:value": ($event) => _ctx.value = $event,
                                        placeholder: "Bill Number"
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Bill Date",
                                    name: "date",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_date_picker, {
                                        "value-format": "YYYY-MM-DD",
                                        style: { "width": "100%" }
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Delivery Date",
                                    name: "date"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_date_picker, {
                                        "value-format": "YYYY-MM-DD",
                                        style: { "width": "100%" }
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 16, ["model", "validate-messages", "onFinish"])
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_col, {
                  span: 12,
                  offset: 0
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_card, { style: { "padding": "0px", "background": "#fff", "minHeight": "2px", "margin-top": "16px", "margin-bottom": "12px", "margin-left": "16px", "height": "270px" } }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                          name: "nest-messages",
                          "validate-messages": _ctx.validateMessages,
                          onFinish: _ctx.submit
                        }), {
                          default: withCtx(() => [
                            createVNode("h3", {
                              "wrapper-col": { span: 12, offset: 6 },
                              style: { "margin-bottom": "20px", "font-size": "14px", "margin-top": "10px" }
                            }, "PARTY DETAILS"),
                            createVNode(_component_a_input_group, { size: "medium" }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "PO Number",
                                  name: "po_number"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "PO Number" })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Add Party",
                                  name: "po_number"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, { placeholder: "Party Name" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, {
                                          value: "undefined",
                                          onClick: withModifiers(() => {
                                            _ctx.showmodel_visible = true;
                                          }, ["stop"])
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_PlusCircleOutlined),
                                            createTextVNode(" Add New Party")
                                          ]),
                                          _: 1
                                        }, 8, ["onClick"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_modal, {
                              title: "Add New Party",
                              closable: true,
                              visible: _ctx.showmodel_visible,
                              "onUpdate:visible": ($event) => _ctx.showmodel_visible = $event,
                              onClose: ($event) => _ctx.showmodel_visible = false
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form, mergeProps({ model: _ctx.formParty }, _ctx.layout, {
                                  name: "nest-messages",
                                  "validate-messages": _ctx.validateMessages,
                                  onFinish: _ctx.partySubmit
                                }), {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Party Name",
                                      name: "partyname",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: _ctx.formParty.partyname,
                                          "onUpdate:value": ($event) => _ctx.formParty.partyname = $event,
                                          placeholder: "Enter Party Name"
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_form_item, {
                                      label: "Mobile Number",
                                      name: "mobile"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: _ctx.formParty.mobile,
                                          "onUpdate:value": ($event) => _ctx.formParty.mobile = $event,
                                          placeholder: "Enter Mobile Number"
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_form_item, {
                                      label: "Who are they?",
                                      name: "who_r_they"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_radio_group, {
                                          value: _ctx.formParty.who_r_they,
                                          "onUpdate:value": ($event) => _ctx.formParty.who_r_they = $event
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_radio, { value: "customer" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Customer")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_radio, { value: "supplier" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Supplier")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_form_item, {
                                      label: "GSTIN",
                                      name: "gstin",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: _ctx.formParty.gstin,
                                          "onUpdate:value": ($event) => _ctx.formParty.gstin = $event,
                                          placeholder: "Enter GSTIN"
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_menu, {
                                      id: "dddddd",
                                      style: { "width": "100%" },
                                      mode: "inline",
                                      onClick: withModifiers(() => {
                                        _ctx.menu_visible = true;
                                      }, ["stop"])
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_sub_menu, {
                                          key: "sub1",
                                          visible: _ctx.menu_visible,
                                          onClose: ($event) => _ctx.menu_visible = false
                                        }, {
                                          title: withCtx(() => [
                                            createTextVNode("Add GSTIN & Address (Optional)")
                                          ]),
                                          default: withCtx(() => [
                                            createVNode("h5", {
                                              "wrapper-col": { span: 12, offset: 6 },
                                              style: { "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" }
                                            }, "Shipping Address"),
                                            createVNode("br"),
                                            createVNode("br"),
                                            createVNode(_component_a_form_item, {
                                              label: "Flat / Building Number",
                                              name: "flat_no"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.formParty.flat_no,
                                                  "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                                  placeholder: "Enter Flat / Building Number"
                                                }, null, 8, ["value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_form_item, {
                                              label: "Area / Locality",
                                              name: "area_loc"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.formParty.area_loc,
                                                  "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                                  placeholder: "Enter Area / Locality"
                                                }, null, 8, ["value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_form_item, {
                                              label: "PIN Code",
                                              name: "pincode"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.formParty.pincode,
                                                  "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                                  placeholder: "Enter PIN Code"
                                                }, null, 8, ["value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_form_item, {
                                              label: "City",
                                              name: "city"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.formParty.city,
                                                  "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                                  placeholder: "Enter City"
                                                }, null, 8, ["value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_form_item, {
                                              label: "State",
                                              name: "state"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.formParty.state,
                                                  "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                                  placeholder: "Enter State"
                                                }, null, 8, ["value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_form_item, { name: "same_ship" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_checkbox, {
                                                  checked: _ctx.formParty.same_ship,
                                                  "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Shipping address same as billing address")
                                                  ]),
                                                  _: 1
                                                }, 8, ["checked", "onUpdate:checked"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["visible", "onClose"])
                                      ]),
                                      _: 1
                                    }, 8, ["onClick"]),
                                    createVNode(_component_a_form_item, {
                                      "wrapper-col": { span: 12, offset: 6 },
                                      style: { "margin-top": "19px", "margin-left": "100px" }
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          "html-type": "submit"
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("Save")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 16, ["model", "validate-messages", "onFinish"])
                              ]),
                              _: 1
                            }, 8, ["visible", "onUpdate:visible", "onClose"])
                          ]),
                          _: 1
                        }, 16, ["model", "validate-messages", "onFinish"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_a_col, { span: 12 }, {
                  default: withCtx(() => [
                    createVNode(_component_a_card, { style: { "margin-top": "16px", "margin-bottom": "12px", "margin-left": "12px", "margin-right": "16px", "padding": "0px", "background": "#fff", "minHeight": "2px" } }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                          name: "nest-messages",
                          "validate-messages": _ctx.validateMessages,
                          onFinish: _ctx.submit
                        }), {
                          default: withCtx(() => [
                            createVNode("h3", {
                              "wrapper-col": { span: 12, offset: 6 },
                              style: { "margin-bottom": "20px", "font-size": "14px", "margin-top": "10px" }
                            }, "PURCHASE DETAILS"),
                            createVNode(_component_a_input_group, { size: "medium" }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Bill Number",
                                  name: "bill_no",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: _ctx.value,
                                      "onUpdate:value": ($event) => _ctx.value = $event,
                                      placeholder: "Bill Number"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Bill Date",
                                  name: "date",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_date_picker, {
                                      "value-format": "YYYY-MM-DD",
                                      style: { "width": "100%" }
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Delivery Date",
                                  name: "date"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_date_picker, {
                                      "value-format": "YYYY-MM-DD",
                                      style: { "width": "100%" }
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 16, ["model", "validate-messages", "onFinish"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_layout_content, { style: { margin: "5px 16px", padding: "24px", background: "#fff", minHeight: "calc(100vh - 115px)" } }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(`<h5${ssrRenderAttr("wrapper-col", { span: 12, offset: 6 })} style="${ssrRenderStyle({ "margin-bottom": "20px", "font-size": "14px", "margin-top": "10px" })}"${_scopeId2}>ITEMS ON THE PURCHASE</h5>`);
              _push3(ssrRenderComponent(_component_a_table, {
                columns: _ctx.columns,
                dataSource: _ctx.dataSource,
                pagination: _ctx.pagination,
                loading: _ctx.loading,
                onChange: _ctx.handleTableChange,
                bordered: ""
              }, {
                headerCell: withCtx(({ column }, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    if (column.key === "discount") {
                      _push4(`<!--[--><span style="${ssrRenderStyle({ "margin-right": "15px" })}"${_scopeId3}> Discount </span>`);
                      _push4(ssrRenderComponent(_component_EditOutlined, null, null, _parent4, _scopeId3));
                      _push4(`<!--]-->`);
                    } else {
                      _push4(`<!---->`);
                    }
                    if (column.key === "tax") {
                      _push4(`<!--[--><span style="${ssrRenderStyle({ "margin-right": "50px" })}"${_scopeId3}> Tax </span>`);
                      _push4(ssrRenderComponent(_component_EditOutlined, null, null, _parent4, _scopeId3));
                      _push4(`<!--]-->`);
                    } else {
                      _push4(`<!---->`);
                    }
                  } else {
                    return [
                      column.key === "discount" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                        createVNode("span", { style: { "margin-right": "15px" } }, " Discount "),
                        createVNode(_component_EditOutlined)
                      ], 64)) : createCommentVNode("", true),
                      column.key === "tax" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                        createVNode("span", { style: { "margin-right": "50px" } }, " Tax "),
                        createVNode(_component_EditOutlined)
                      ], 64)) : createCommentVNode("", true)
                    ];
                  }
                }),
                bodyCell: withCtx(({ column, text, record, index }, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(`<template${_scopeId3}>${ssrInterpolate(text ?? "-")}</template>`);
                    if (column.key === "name") {
                      _push4(ssrRenderComponent(_component_a_button, {
                        style: { "margin-top": "12px" },
                        key: "1",
                        type: "primary",
                        onClick: () => {
                          _ctx.invdrawer_visible = true;
                        }
                      }, {
                        default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                          if (_push5) {
                            _push5(`Select Items from Inventory`);
                          } else {
                            return [
                              createTextVNode("Select Items from Inventory")
                            ];
                          }
                        }),
                        _: 2
                      }, _parent4, _scopeId3));
                    } else {
                      _push4(`<!---->`);
                    }
                    if (column.key === "hsn_mat") {
                      _push4(`<!--[-->${ssrInterpolate(text)}<!--]-->`);
                    } else {
                      _push4(`<!---->`);
                    }
                    if (column.key === "sno") {
                      _push4(`<!--[-->${ssrInterpolate(index + 1)}<!--]-->`);
                    } else {
                      _push4(`<!---->`);
                    }
                  } else {
                    return [
                      createVNode("template", null, [
                        createTextVNode(toDisplayString(text ?? "-"), 1)
                      ]),
                      column.key === "name" ? (openBlock(), createBlock(_component_a_button, {
                        style: { "margin-top": "12px" },
                        key: "1",
                        type: "primary",
                        onClick: withModifiers(() => {
                          _ctx.invdrawer_visible = true;
                        }, ["stop"])
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Select Items from Inventory")
                        ]),
                        _: 1
                      }, 8, ["onClick"])) : createCommentVNode("", true),
                      column.key === "hsn_mat" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                        createTextVNode(toDisplayString(text), 1)
                      ], 64)) : createCommentVNode("", true),
                      column.key === "sno" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                        createTextVNode(toDisplayString(index + 1), 1)
                      ], 64)) : createCommentVNode("", true)
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_button, {
                class: "editable-add-btn",
                type: "primary",
                style: { "margin-top": "12px" },
                onClick: _ctx.handleAdd
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(`Add Rows`);
                  } else {
                    return [
                      createTextVNode("Add Rows")
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_card, { style: { "width": "350px", "float": "right", "margin-top": "12px" } }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                      name: "nest-messages",
                      "validate-messages": _ctx.validateMessages,
                      onFinish: _ctx.submit
                    }), {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form_item, {
                            label: "Sub Total",
                            name: "area_loc"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input, { placeholder: "" }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input, { placeholder: "" })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, {
                            label: "Paid Amount",
                            name: "area_loc"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input, { placeholder: "" }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input, { placeholder: "" })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, {
                            label: "Grand Total",
                            name: "area_loc"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input, { placeholder: "" }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input, { placeholder: "" })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form_item, {
                              label: "Sub Total",
                              name: "area_loc"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, { placeholder: "" })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Paid Amount",
                              name: "area_loc"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, { placeholder: "" })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Grand Total",
                              name: "area_loc"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, { placeholder: "" })
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                        name: "nest-messages",
                        "validate-messages": _ctx.validateMessages,
                        onFinish: _ctx.submit
                      }), {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, {
                            label: "Sub Total",
                            name: "area_loc"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, { placeholder: "" })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Paid Amount",
                            name: "area_loc"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, { placeholder: "" })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Grand Total",
                            name: "area_loc"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, { placeholder: "" })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 16, ["model", "validate-messages", "onFinish"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_drawer, {
                title: "Create a new account",
                width: 620,
                closable: true,
                visible: _ctx.invdrawer_visible,
                onClose: ($event) => _ctx.invdrawer_visible = false
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_row, {
                      type: "flex",
                      style: { "margin-bottom": "15px" }
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_col, { flex: "auto" }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input_search, {
                                  value: _ctx.value,
                                  "onUpdate:value": ($event) => _ctx.value = $event,
                                  placeholder: "Search for any items in your inventory ",
                                  "enter-button": ""
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input_search, {
                                    value: _ctx.value,
                                    "onUpdate:value": ($event) => _ctx.value = $event,
                                    placeholder: "Search for any items in your inventory ",
                                    "enter-button": ""
                                  }, null, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_col, {
                            flex: "45px",
                            style: { "margin-left": "5px" }
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  size: _ctx.size
                                }, {
                                  icon: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_AlignLeftOutlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_AlignLeftOutlined)
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`sort `);
                                    } else {
                                      return [
                                        createTextVNode("sort ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    size: _ctx.size
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_AlignLeftOutlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode("sort ")
                                    ]),
                                    _: 1
                                  }, 8, ["size"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_col, { flex: "auto" }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input_search, {
                                  value: _ctx.value,
                                  "onUpdate:value": ($event) => _ctx.value = $event,
                                  placeholder: "Search for any items in your inventory ",
                                  "enter-button": ""
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              flex: "45px",
                              style: { "margin-left": "5px" }
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  size: _ctx.size
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_AlignLeftOutlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode("sort ")
                                  ]),
                                  _: 1
                                }, 8, ["size"])
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_button, {
                      type: "primary",
                      onClick: ($event) => _ctx.isShowing ^= true,
                      style: { "margin-bottom": "10px" }
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_PlusOutlined, null, null, _parent5, _scopeId4));
                          _push5(`Add New Item`);
                        } else {
                          return [
                            createVNode(_component_PlusOutlined),
                            createTextVNode("Add New Item")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_list, {
                      "item-layout": "horizontal",
                      "data-source": _ctx.datas
                    }, {
                      renderItem: withCtx(({ item }, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_list_item, null, {
                            default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_list_item_meta, null, {
                                  title: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Oil `);
                                    } else {
                                      return [
                                        createTextVNode(" Oil ")
                                      ];
                                    }
                                  }),
                                  description: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_row, { style: { "margin-top": "10px" } }, {
                                        default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_col, { span: 8 }, {
                                              default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(` PURCHASE PRICE`);
                                                } else {
                                                  return [
                                                    createTextVNode(" PURCHASE PRICE")
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, { span: 8 }, {
                                              default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`STOCK`);
                                                } else {
                                                  return [
                                                    createTextVNode("STOCK")
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, { span: 8 }, {
                                              default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_button, {
                                                    type: "primary",
                                                    style: { "margin-bottom": "0px" }
                                                  }, {
                                                    default: withCtx((_8, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_PlusOutlined, null, null, _parent10, _scopeId9));
                                                        _push10(`Add`);
                                                      } else {
                                                        return [
                                                          createVNode(_component_PlusOutlined),
                                                          createTextVNode("Add")
                                                        ];
                                                      }
                                                    }),
                                                    _: 2
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_button, {
                                                      type: "primary",
                                                      style: { "margin-bottom": "0px" }
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_PlusOutlined),
                                                        createTextVNode("Add")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_col, { span: 8 }, {
                                                default: withCtx(() => [
                                                  createTextVNode(" PURCHASE PRICE")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 8 }, {
                                                default: withCtx(() => [
                                                  createTextVNode("STOCK")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 8 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_button, {
                                                    type: "primary",
                                                    style: { "margin-bottom": "0px" }
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_PlusOutlined),
                                                      createTextVNode("Add")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 2
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_row, null, {
                                        default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_col, { span: 8 }, {
                                              default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`2`);
                                                } else {
                                                  return [
                                                    createTextVNode("2")
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, { span: 8 }, {
                                              default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`2`);
                                                } else {
                                                  return [
                                                    createTextVNode("2")
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_col, { span: 8 }, {
                                                default: withCtx(() => [
                                                  createTextVNode("2")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 8 }, {
                                                default: withCtx(() => [
                                                  createTextVNode("2")
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 2
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_row, { style: { "margin-top": "10px" } }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_col, { span: 8 }, {
                                              default: withCtx(() => [
                                                createTextVNode(" PURCHASE PRICE")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 8 }, {
                                              default: withCtx(() => [
                                                createTextVNode("STOCK")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 8 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_button, {
                                                  type: "primary",
                                                  style: { "margin-bottom": "0px" }
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_PlusOutlined),
                                                    createTextVNode("Add")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_row, null, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_col, { span: 8 }, {
                                              default: withCtx(() => [
                                                createTextVNode("2")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 8 }, {
                                              default: withCtx(() => [
                                                createTextVNode("2")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_list_item_meta, null, {
                                    title: withCtx(() => [
                                      createTextVNode(" Oil ")
                                    ]),
                                    description: withCtx(() => [
                                      createVNode(_component_a_row, { style: { "margin-top": "10px" } }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_col, { span: 8 }, {
                                            default: withCtx(() => [
                                              createTextVNode(" PURCHASE PRICE")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 8 }, {
                                            default: withCtx(() => [
                                              createTextVNode("STOCK")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 8 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_button, {
                                                type: "primary",
                                                style: { "margin-bottom": "0px" }
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_PlusOutlined),
                                                  createTextVNode("Add")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_row, null, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_col, { span: 8 }, {
                                            default: withCtx(() => [
                                              createTextVNode("2")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 8 }, {
                                            default: withCtx(() => [
                                              createTextVNode("2")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 2
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_list_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_list_item_meta, null, {
                                  title: withCtx(() => [
                                    createTextVNode(" Oil ")
                                  ]),
                                  description: withCtx(() => [
                                    createVNode(_component_a_row, { style: { "margin-top": "10px" } }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_col, { span: 8 }, {
                                          default: withCtx(() => [
                                            createTextVNode(" PURCHASE PRICE")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 8 }, {
                                          default: withCtx(() => [
                                            createTextVNode("STOCK")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 8 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_button, {
                                              type: "primary",
                                              style: { "margin-bottom": "0px" }
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_PlusOutlined),
                                                createTextVNode("Add")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_row, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_col, { span: 8 }, {
                                          default: withCtx(() => [
                                            createTextVNode("2")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 8 }, {
                                          default: withCtx(() => [
                                            createTextVNode("2")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form, {
                      model: _ctx.formState,
                      "label-col": _ctx.labelCol,
                      style: _ctx.isShowing ? null : { display: "none" },
                      "wrapper-col": _ctx.wrapperCol,
                      rules: _ctx.rules,
                      layout: "vertical"
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form_item, {
                            label: "Item name",
                            style: { "row-gap": "0px", "margin-bottom": "12px" }
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input, { placeholder: "Enter Item name here (Eg, Milk, Bulb, Mobile)" }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input, { placeholder: "Enter Item name here (Eg, Milk, Bulb, Mobile)" })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 16 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Sale price",
                                        style: { "row-gap": "0px", "margin-bottom": "12px" }
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Please enter sale price" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Please enter sale price" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Sale price",
                                          style: { "row-gap": "0px", "margin-bottom": "12px" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Please enter sale price" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Purchase price",
                                        style: { "row-gap": "0px", "margin-bottom": "12px" }
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Please enter purchase price" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Please enter purchase price" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Purchase price",
                                          style: { "row-gap": "0px", "margin-bottom": "12px" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Please enter purchase price" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Sale price",
                                        style: { "row-gap": "0px", "margin-bottom": "12px" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Please enter sale price" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Purchase price",
                                        style: { "row-gap": "0px", "margin-bottom": "12px" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Please enter purchase price" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 16 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Units",
                                        style: { "row-gap": "0px", "margin-bottom": "12px" }
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select, { placeholder: "Please select unit" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_select_option, { value: "xiao" }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(`Xiaoxiao Fu`);
                                                      } else {
                                                        return [
                                                          createTextVNode("Xiaoxiao Fu")
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_a_select_option, { value: "mao" }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(`Maomao Zhou`);
                                                      } else {
                                                        return [
                                                          createTextVNode("Maomao Zhou")
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_select_option, { value: "xiao" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Xiaoxiao Fu")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, { value: "mao" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Maomao Zhou")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select, { placeholder: "Please select unit" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select_option, { value: "xiao" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Xiaoxiao Fu")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, { value: "mao" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Maomao Zhou")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Units",
                                          style: { "row-gap": "0px", "margin-bottom": "12px" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, { placeholder: "Please select unit" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select_option, { value: "xiao" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Xiaoxiao Fu")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_select_option, { value: "mao" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Maomao Zhou")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Tax Included",
                                        style: { "row-gap": "0px", "margin-bottom": "12px" }
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_switch, {
                                              checked: _ctx.checked,
                                              "onUpdate:checked": ($event) => _ctx.checked = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_switch, {
                                                checked: _ctx.checked,
                                                "onUpdate:checked": ($event) => _ctx.checked = $event
                                              }, null, 8, ["checked", "onUpdate:checked"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Tax Included",
                                          style: { "row-gap": "0px", "margin-bottom": "12px" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_switch, {
                                              checked: _ctx.checked,
                                              "onUpdate:checked": ($event) => _ctx.checked = $event
                                            }, null, 8, ["checked", "onUpdate:checked"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Units",
                                        style: { "row-gap": "0px", "margin-bottom": "12px" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, { placeholder: "Please select unit" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select_option, { value: "xiao" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Xiaoxiao Fu")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "mao" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Maomao Zhou")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Tax Included",
                                        style: { "row-gap": "0px", "margin-bottom": "12px" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_switch, {
                                            checked: _ctx.checked,
                                            "onUpdate:checked": ($event) => _ctx.checked = $event
                                          }, null, 8, ["checked", "onUpdate:checked"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 16 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Opening stock",
                                        style: { "row-gap": "0px", "margin-bottom": "12px" }
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Enter count" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Enter count" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Opening stock",
                                          style: { "row-gap": "0px", "margin-bottom": "12px" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Enter count" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Low stock",
                                        style: { "row-gap": "0px", "margin-bottom": "12px" }
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Enter low count" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Enter low count" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Low stock",
                                          style: { "row-gap": "0px", "margin-bottom": "12px" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Enter low count" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Opening stock",
                                        style: { "row-gap": "0px", "margin-bottom": "12px" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Enter count" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Low stock",
                                        style: { "row-gap": "0px", "margin-bottom": "12px" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Enter low count" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 16 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "HSN Code" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Enter HSN code" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Enter HSN code" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "HSN Code" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Enter HSN code" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "GST %" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              placeholder: "Enter GST %",
                                              onClick: ($event) => _ctx.gstShowing ^= true
                                            }, {
                                              suffix: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_DownOutlined, { style: { "color": "rgba(0, 0, 0, 0.25)", "font-size": "12px" } }, null, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_DownOutlined, { style: { "color": "rgba(0, 0, 0, 0.25)", "font-size": "12px" } })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                placeholder: "Enter GST %",
                                                onClick: ($event) => _ctx.gstShowing ^= true
                                              }, {
                                                suffix: withCtx(() => [
                                                  createVNode(_component_DownOutlined, { style: { "color": "rgba(0, 0, 0, 0.25)", "font-size": "12px" } })
                                                ]),
                                                _: 1
                                              }, 8, ["onClick"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "GST %" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              placeholder: "Enter GST %",
                                              onClick: ($event) => _ctx.gstShowing ^= true
                                            }, {
                                              suffix: withCtx(() => [
                                                createVNode(_component_DownOutlined, { style: { "color": "rgba(0, 0, 0, 0.25)", "font-size": "12px" } })
                                              ]),
                                              _: 1
                                            }, 8, ["onClick"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "HSN Code" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Enter HSN code" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "GST %" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            placeholder: "Enter GST %",
                                            onClick: ($event) => _ctx.gstShowing ^= true
                                          }, {
                                            suffix: withCtx(() => [
                                              createVNode(_component_DownOutlined, { style: { "color": "rgba(0, 0, 0, 0.25)", "font-size": "12px" } })
                                            ]),
                                            _: 1
                                          }, 8, ["onClick"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_list, {
                            "item-layout": "horizontal",
                            "data-source": _ctx.data,
                            style: [
                              _ctx.gstShowing ? null : { display: "none" },
                              { "margin-bottom": "16px" }
                            ]
                          }, {
                            renderItem: withCtx(({ item }, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_list_item, null, {
                                  actions: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_radio, {
                                        checked: _ctx.checked,
                                        "onUpdate:checked": ($event) => _ctx.checked = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_radio, {
                                          checked: _ctx.checked,
                                          "onUpdate:checked": ($event) => _ctx.checked = $event
                                        }, null, 8, ["checked", "onUpdate:checked"])
                                      ];
                                    }
                                  }),
                                  default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_list_item_meta, {
                                        description: item.description
                                      }, {
                                        title: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`${ssrInterpolate(item.title)}`);
                                          } else {
                                            return [
                                              createTextVNode(toDisplayString(item.title), 1)
                                            ];
                                          }
                                        }),
                                        _: 2
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_list_item_meta, {
                                          description: item.description
                                        }, {
                                          title: withCtx(() => [
                                            createTextVNode(toDisplayString(item.title), 1)
                                          ]),
                                          _: 2
                                        }, 1032, ["description"])
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_list_item, null, {
                                    actions: withCtx(() => [
                                      createVNode(_component_a_radio, {
                                        checked: _ctx.checked,
                                        "onUpdate:checked": ($event) => _ctx.checked = $event
                                      }, null, 8, ["checked", "onUpdate:checked"])
                                    ]),
                                    default: withCtx(() => [
                                      createVNode(_component_a_list_item_meta, {
                                        description: item.description
                                      }, {
                                        title: withCtx(() => [
                                          createTextVNode(toDisplayString(item.title), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["description"])
                                    ]),
                                    _: 2
                                  }, 1024)
                                ];
                              }
                            }),
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`<p style="${ssrRenderStyle({ "margin-bottom": "20px", "cursor": "pointer", "color": "#1890ff" })}"${_scopeId5}>`);
                                _push6(ssrRenderComponent(_component_PlusCircleOutlined, null, null, _parent6, _scopeId5));
                                _push6(` Add Custom Tax</p>`);
                                _push6(ssrRenderComponent(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                                  name: "nest-messages",
                                  style: _ctx.addcustom ? null : { display: "none" },
                                  "validate-messages": _ctx.validateMessages,
                                  onFinish: _ctx.submit
                                }), {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "CUSTOM TAX %",
                                        style: { "margin-bottom": "70px" }
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input_group, { size: "medium" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_row, { gutter: 8 }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_col, { span: 8 }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(ssrRenderComponent(_component_a_input, { placeholder: "GST" }, null, _parent11, _scopeId10));
                                                            } else {
                                                              return [
                                                                createVNode(_component_a_input, { placeholder: "GST" })
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                        _push10(ssrRenderComponent(_component_a_col, { span: 8 }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(ssrRenderComponent(_component_a_input, { placeholder: "CESS" }, null, _parent11, _scopeId10));
                                                            } else {
                                                              return [
                                                                createVNode(_component_a_input, { placeholder: "CESS" })
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                        _push10(ssrRenderComponent(_component_a_col, { span: 8 }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(ssrRenderComponent(_component_a_button, {
                                                                type: "primary",
                                                                "html-type": "submit"
                                                              }, {
                                                                default: withCtx((_11, _push12, _parent12, _scopeId11) => {
                                                                  if (_push12) {
                                                                    _push12(`Save`);
                                                                  } else {
                                                                    return [
                                                                      createTextVNode("Save")
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 1
                                                              }, _parent11, _scopeId10));
                                                            } else {
                                                              return [
                                                                createVNode(_component_a_button, {
                                                                  type: "primary",
                                                                  "html-type": "submit"
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode("Save")
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_col, { span: 8 }, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_a_input, { placeholder: "GST" })
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_col, { span: 8 }, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_a_input, { placeholder: "CESS" })
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_col, { span: 8 }, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_a_button, {
                                                                type: "primary",
                                                                "html-type": "submit"
                                                              }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode("Save")
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_row, { gutter: 8 }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_col, { span: 8 }, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_a_input, { placeholder: "GST" })
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_col, { span: 8 }, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_a_input, { placeholder: "CESS" })
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_col, { span: 8 }, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_a_button, {
                                                              type: "primary",
                                                              "html-type": "submit"
                                                            }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("Save")
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input_group, { size: "medium" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_row, { gutter: 8 }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_col, { span: 8 }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_input, { placeholder: "GST" })
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_col, { span: 8 }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_input, { placeholder: "CESS" })
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_col, { span: 8 }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_button, {
                                                            type: "primary",
                                                            "html-type": "submit"
                                                          }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Save")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "CUSTOM TAX %",
                                          style: { "margin-bottom": "70px" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input_group, { size: "medium" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_row, { gutter: 8 }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_col, { span: 8 }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, { placeholder: "GST" })
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_col, { span: 8 }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, { placeholder: "CESS" })
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_col, { span: 8 }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_button, {
                                                          type: "primary",
                                                          "html-type": "submit"
                                                        }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Save")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode("p", {
                                    style: { "margin-bottom": "20px", "cursor": "pointer", "color": "#1890ff" },
                                    onClick: ($event) => _ctx.addcustom ^= true
                                  }, [
                                    createVNode(_component_PlusCircleOutlined),
                                    createTextVNode(" Add Custom Tax")
                                  ], 8, ["onClick"]),
                                  withDirectives(createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                                    name: "nest-messages",
                                    "validate-messages": _ctx.validateMessages,
                                    onFinish: _ctx.submit
                                  }), {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "CUSTOM TAX %",
                                        style: { "margin-bottom": "70px" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input_group, { size: "medium" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_row, { gutter: 8 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_col, { span: 8 }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, { placeholder: "GST" })
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_col, { span: 8 }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, { placeholder: "CESS" })
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_col, { span: 8 }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_button, {
                                                        type: "primary",
                                                        "html-type": "submit"
                                                      }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Save")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 16, ["model", "validate-messages", "onFinish"]), [
                                    [vShow, _ctx.addcustom]
                                  ])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, { type: "primary" }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`Add Item`);
                                    } else {
                                      return [
                                        createTextVNode("Add Item")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_button, { style: { "margin-left": "10px" } }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`Cancel`);
                                    } else {
                                      return [
                                        createTextVNode("Cancel")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, { type: "primary" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Add Item")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_button, { style: { "margin-left": "10px" } }, {
                                    default: withCtx(() => [
                                      createTextVNode("Cancel")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form_item, {
                              label: "Item name",
                              style: { "row-gap": "0px", "margin-bottom": "12px" }
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, { placeholder: "Enter Item name here (Eg, Milk, Bulb, Mobile)" })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_row, { gutter: 16 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Sale price",
                                      style: { "row-gap": "0px", "margin-bottom": "12px" }
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Please enter sale price" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Purchase price",
                                      style: { "row-gap": "0px", "margin-bottom": "12px" }
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Please enter purchase price" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_row, { gutter: 16 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Units",
                                      style: { "row-gap": "0px", "margin-bottom": "12px" }
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, { placeholder: "Please select unit" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "xiao" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Xiaoxiao Fu")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "mao" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Maomao Zhou")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Tax Included",
                                      style: { "row-gap": "0px", "margin-bottom": "12px" }
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_switch, {
                                          checked: _ctx.checked,
                                          "onUpdate:checked": ($event) => _ctx.checked = $event
                                        }, null, 8, ["checked", "onUpdate:checked"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_row, { gutter: 16 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Opening stock",
                                      style: { "row-gap": "0px", "margin-bottom": "12px" }
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Enter count" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Low stock",
                                      style: { "row-gap": "0px", "margin-bottom": "12px" }
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Enter low count" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_row, { gutter: 16 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "HSN Code" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Enter HSN code" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "GST %" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          placeholder: "Enter GST %",
                                          onClick: ($event) => _ctx.gstShowing ^= true
                                        }, {
                                          suffix: withCtx(() => [
                                            createVNode(_component_DownOutlined, { style: { "color": "rgba(0, 0, 0, 0.25)", "font-size": "12px" } })
                                          ]),
                                          _: 1
                                        }, 8, ["onClick"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            withDirectives(createVNode(_component_a_list, {
                              "item-layout": "horizontal",
                              "data-source": _ctx.data,
                              style: { "margin-bottom": "16px" }
                            }, {
                              renderItem: withCtx(({ item }) => [
                                createVNode(_component_a_list_item, null, {
                                  actions: withCtx(() => [
                                    createVNode(_component_a_radio, {
                                      checked: _ctx.checked,
                                      "onUpdate:checked": ($event) => _ctx.checked = $event
                                    }, null, 8, ["checked", "onUpdate:checked"])
                                  ]),
                                  default: withCtx(() => [
                                    createVNode(_component_a_list_item_meta, {
                                      description: item.description
                                    }, {
                                      title: withCtx(() => [
                                        createTextVNode(toDisplayString(item.title), 1)
                                      ]),
                                      _: 2
                                    }, 1032, ["description"])
                                  ]),
                                  _: 2
                                }, 1024)
                              ]),
                              default: withCtx(() => [
                                createVNode("p", {
                                  style: { "margin-bottom": "20px", "cursor": "pointer", "color": "#1890ff" },
                                  onClick: ($event) => _ctx.addcustom ^= true
                                }, [
                                  createVNode(_component_PlusCircleOutlined),
                                  createTextVNode(" Add Custom Tax")
                                ], 8, ["onClick"]),
                                withDirectives(createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                                  name: "nest-messages",
                                  "validate-messages": _ctx.validateMessages,
                                  onFinish: _ctx.submit
                                }), {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "CUSTOM TAX %",
                                      style: { "margin-bottom": "70px" }
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input_group, { size: "medium" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_row, { gutter: 8 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_col, { span: 8 }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, { placeholder: "GST" })
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_col, { span: 8 }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, { placeholder: "CESS" })
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_col, { span: 8 }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_button, {
                                                      type: "primary",
                                                      "html-type": "submit"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Save")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 16, ["model", "validate-messages", "onFinish"]), [
                                  [vShow, _ctx.addcustom]
                                ])
                              ]),
                              _: 1
                            }, 8, ["data-source"]), [
                              [vShow, _ctx.gstShowing]
                            ]),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, { type: "primary" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Add Item")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_button, { style: { "margin-left": "10px" } }, {
                                  default: withCtx(() => [
                                    createTextVNode("Cancel")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_row, {
                        type: "flex",
                        style: { "margin-bottom": "15px" }
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, { flex: "auto" }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input_search, {
                                value: _ctx.value,
                                "onUpdate:value": ($event) => _ctx.value = $event,
                                placeholder: "Search for any items in your inventory ",
                                "enter-button": ""
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            flex: "45px",
                            style: { "margin-left": "5px" }
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                size: _ctx.size
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_AlignLeftOutlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode("sort ")
                                ]),
                                _: 1
                              }, 8, ["size"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_button, {
                        type: "primary",
                        onClick: ($event) => _ctx.isShowing ^= true,
                        style: { "margin-bottom": "10px" }
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_PlusOutlined),
                          createTextVNode("Add New Item")
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_list, {
                        "item-layout": "horizontal",
                        "data-source": _ctx.datas
                      }, {
                        renderItem: withCtx(({ item }) => [
                          createVNode(_component_a_list_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_list_item_meta, null, {
                                title: withCtx(() => [
                                  createTextVNode(" Oil ")
                                ]),
                                description: withCtx(() => [
                                  createVNode(_component_a_row, { style: { "margin-top": "10px" } }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, { span: 8 }, {
                                        default: withCtx(() => [
                                          createTextVNode(" PURCHASE PRICE")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 8 }, {
                                        default: withCtx(() => [
                                          createTextVNode("STOCK")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 8 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_button, {
                                            type: "primary",
                                            style: { "margin-bottom": "0px" }
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_PlusOutlined),
                                              createTextVNode("Add")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_row, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, { span: 8 }, {
                                        default: withCtx(() => [
                                          createTextVNode("2")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 8 }, {
                                        default: withCtx(() => [
                                          createTextVNode("2")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["data-source"]),
                      withDirectives(createVNode(_component_a_form, {
                        model: _ctx.formState,
                        "label-col": _ctx.labelCol,
                        "wrapper-col": _ctx.wrapperCol,
                        rules: _ctx.rules,
                        layout: "vertical"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, {
                            label: "Item name",
                            style: { "row-gap": "0px", "margin-bottom": "12px" }
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, { placeholder: "Enter Item name here (Eg, Milk, Bulb, Mobile)" })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_row, { gutter: 16 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Sale price",
                                    style: { "row-gap": "0px", "margin-bottom": "12px" }
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Please enter sale price" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Purchase price",
                                    style: { "row-gap": "0px", "margin-bottom": "12px" }
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Please enter purchase price" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_row, { gutter: 16 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Units",
                                    style: { "row-gap": "0px", "margin-bottom": "12px" }
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, { placeholder: "Please select unit" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "xiao" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Xiaoxiao Fu")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "mao" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Maomao Zhou")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Tax Included",
                                    style: { "row-gap": "0px", "margin-bottom": "12px" }
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_switch, {
                                        checked: _ctx.checked,
                                        "onUpdate:checked": ($event) => _ctx.checked = $event
                                      }, null, 8, ["checked", "onUpdate:checked"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_row, { gutter: 16 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Opening stock",
                                    style: { "row-gap": "0px", "margin-bottom": "12px" }
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Enter count" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Low stock",
                                    style: { "row-gap": "0px", "margin-bottom": "12px" }
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Enter low count" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_row, { gutter: 16 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "HSN Code" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Enter HSN code" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "GST %" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        placeholder: "Enter GST %",
                                        onClick: ($event) => _ctx.gstShowing ^= true
                                      }, {
                                        suffix: withCtx(() => [
                                          createVNode(_component_DownOutlined, { style: { "color": "rgba(0, 0, 0, 0.25)", "font-size": "12px" } })
                                        ]),
                                        _: 1
                                      }, 8, ["onClick"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          withDirectives(createVNode(_component_a_list, {
                            "item-layout": "horizontal",
                            "data-source": _ctx.data,
                            style: { "margin-bottom": "16px" }
                          }, {
                            renderItem: withCtx(({ item }) => [
                              createVNode(_component_a_list_item, null, {
                                actions: withCtx(() => [
                                  createVNode(_component_a_radio, {
                                    checked: _ctx.checked,
                                    "onUpdate:checked": ($event) => _ctx.checked = $event
                                  }, null, 8, ["checked", "onUpdate:checked"])
                                ]),
                                default: withCtx(() => [
                                  createVNode(_component_a_list_item_meta, {
                                    description: item.description
                                  }, {
                                    title: withCtx(() => [
                                      createTextVNode(toDisplayString(item.title), 1)
                                    ]),
                                    _: 2
                                  }, 1032, ["description"])
                                ]),
                                _: 2
                              }, 1024)
                            ]),
                            default: withCtx(() => [
                              createVNode("p", {
                                style: { "margin-bottom": "20px", "cursor": "pointer", "color": "#1890ff" },
                                onClick: ($event) => _ctx.addcustom ^= true
                              }, [
                                createVNode(_component_PlusCircleOutlined),
                                createTextVNode(" Add Custom Tax")
                              ], 8, ["onClick"]),
                              withDirectives(createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                                name: "nest-messages",
                                "validate-messages": _ctx.validateMessages,
                                onFinish: _ctx.submit
                              }), {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "CUSTOM TAX %",
                                    style: { "margin-bottom": "70px" }
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input_group, { size: "medium" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_row, { gutter: 8 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_col, { span: 8 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, { placeholder: "GST" })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 8 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, { placeholder: "CESS" })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 8 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_button, {
                                                    type: "primary",
                                                    "html-type": "submit"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Save")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 16, ["model", "validate-messages", "onFinish"]), [
                                [vShow, _ctx.addcustom]
                              ])
                            ]),
                            _: 1
                          }, 8, ["data-source"]), [
                            [vShow, _ctx.gstShowing]
                          ]),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, { type: "primary" }, {
                                default: withCtx(() => [
                                  createTextVNode("Add Item")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_button, { style: { "margin-left": "10px" } }, {
                                default: withCtx(() => [
                                  createTextVNode("Cancel")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["model", "label-col", "wrapper-col", "rules"]), [
                        [vShow, _ctx.isShowing]
                      ])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode("h5", {
                  "wrapper-col": { span: 12, offset: 6 },
                  style: { "margin-bottom": "20px", "font-size": "14px", "margin-top": "10px" }
                }, "ITEMS ON THE PURCHASE"),
                createVNode(_component_a_table, {
                  columns: _ctx.columns,
                  dataSource: _ctx.dataSource,
                  pagination: _ctx.pagination,
                  loading: _ctx.loading,
                  onChange: _ctx.handleTableChange,
                  bordered: ""
                }, {
                  headerCell: withCtx(({ column }) => [
                    column.key === "discount" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                      createVNode("span", { style: { "margin-right": "15px" } }, " Discount "),
                      createVNode(_component_EditOutlined)
                    ], 64)) : createCommentVNode("", true),
                    column.key === "tax" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                      createVNode("span", { style: { "margin-right": "50px" } }, " Tax "),
                      createVNode(_component_EditOutlined)
                    ], 64)) : createCommentVNode("", true)
                  ]),
                  bodyCell: withCtx(({ column, text, record, index }) => [
                    createVNode("template", null, [
                      createTextVNode(toDisplayString(text ?? "-"), 1)
                    ]),
                    column.key === "name" ? (openBlock(), createBlock(_component_a_button, {
                      style: { "margin-top": "12px" },
                      key: "1",
                      type: "primary",
                      onClick: withModifiers(() => {
                        _ctx.invdrawer_visible = true;
                      }, ["stop"])
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Select Items from Inventory")
                      ]),
                      _: 1
                    }, 8, ["onClick"])) : createCommentVNode("", true),
                    column.key === "hsn_mat" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                      createTextVNode(toDisplayString(text), 1)
                    ], 64)) : createCommentVNode("", true),
                    column.key === "sno" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                      createTextVNode(toDisplayString(index + 1), 1)
                    ], 64)) : createCommentVNode("", true)
                  ]),
                  _: 1
                }, 8, ["columns", "dataSource", "pagination", "loading", "onChange"]),
                createVNode(_component_a_button, {
                  class: "editable-add-btn",
                  type: "primary",
                  style: { "margin-top": "12px" },
                  onClick: _ctx.handleAdd
                }, {
                  default: withCtx(() => [
                    createTextVNode("Add Rows")
                  ]),
                  _: 1
                }, 8, ["onClick"]),
                createVNode(_component_a_card, { style: { "width": "350px", "float": "right", "margin-top": "12px" } }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                      name: "nest-messages",
                      "validate-messages": _ctx.validateMessages,
                      onFinish: _ctx.submit
                    }), {
                      default: withCtx(() => [
                        createVNode(_component_a_form_item, {
                          label: "Sub Total",
                          name: "area_loc"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, { placeholder: "" })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, {
                          label: "Paid Amount",
                          name: "area_loc"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, { placeholder: "" })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, {
                          label: "Grand Total",
                          name: "area_loc"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, { placeholder: "" })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 16, ["model", "validate-messages", "onFinish"])
                  ]),
                  _: 1
                }),
                createVNode(_component_a_drawer, {
                  title: "Create a new account",
                  width: 620,
                  closable: true,
                  visible: _ctx.invdrawer_visible,
                  onClose: ($event) => _ctx.invdrawer_visible = false
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_row, {
                      type: "flex",
                      style: { "margin-bottom": "15px" }
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_col, { flex: "auto" }, {
                          default: withCtx(() => [
                            createVNode(_component_a_input_search, {
                              value: _ctx.value,
                              "onUpdate:value": ($event) => _ctx.value = $event,
                              placeholder: "Search for any items in your inventory ",
                              "enter-button": ""
                            }, null, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_col, {
                          flex: "45px",
                          style: { "margin-left": "5px" }
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              size: _ctx.size
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_AlignLeftOutlined)
                              ]),
                              default: withCtx(() => [
                                createTextVNode("sort ")
                              ]),
                              _: 1
                            }, 8, ["size"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_button, {
                      type: "primary",
                      onClick: ($event) => _ctx.isShowing ^= true,
                      style: { "margin-bottom": "10px" }
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_PlusOutlined),
                        createTextVNode("Add New Item")
                      ]),
                      _: 1
                    }, 8, ["onClick"]),
                    createVNode(_component_a_list, {
                      "item-layout": "horizontal",
                      "data-source": _ctx.datas
                    }, {
                      renderItem: withCtx(({ item }) => [
                        createVNode(_component_a_list_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_list_item_meta, null, {
                              title: withCtx(() => [
                                createTextVNode(" Oil ")
                              ]),
                              description: withCtx(() => [
                                createVNode(_component_a_row, { style: { "margin-top": "10px" } }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { span: 8 }, {
                                      default: withCtx(() => [
                                        createTextVNode(" PURCHASE PRICE")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, { span: 8 }, {
                                      default: withCtx(() => [
                                        createTextVNode("STOCK")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, { span: 8 }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          style: { "margin-bottom": "0px" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_PlusOutlined),
                                            createTextVNode("Add")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_row, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { span: 8 }, {
                                      default: withCtx(() => [
                                        createTextVNode("2")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, { span: 8 }, {
                                      default: withCtx(() => [
                                        createTextVNode("2")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["data-source"]),
                    withDirectives(createVNode(_component_a_form, {
                      model: _ctx.formState,
                      "label-col": _ctx.labelCol,
                      "wrapper-col": _ctx.wrapperCol,
                      rules: _ctx.rules,
                      layout: "vertical"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form_item, {
                          label: "Item name",
                          style: { "row-gap": "0px", "margin-bottom": "12px" }
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, { placeholder: "Enter Item name here (Eg, Milk, Bulb, Mobile)" })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_row, { gutter: 16 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Sale price",
                                  style: { "row-gap": "0px", "margin-bottom": "12px" }
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Please enter sale price" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Purchase price",
                                  style: { "row-gap": "0px", "margin-bottom": "12px" }
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Please enter purchase price" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_row, { gutter: 16 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Units",
                                  style: { "row-gap": "0px", "margin-bottom": "12px" }
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, { placeholder: "Please select unit" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, { value: "xiao" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Xiaoxiao Fu")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "mao" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Maomao Zhou")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Tax Included",
                                  style: { "row-gap": "0px", "margin-bottom": "12px" }
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_switch, {
                                      checked: _ctx.checked,
                                      "onUpdate:checked": ($event) => _ctx.checked = $event
                                    }, null, 8, ["checked", "onUpdate:checked"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_row, { gutter: 16 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Opening stock",
                                  style: { "row-gap": "0px", "margin-bottom": "12px" }
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Enter count" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Low stock",
                                  style: { "row-gap": "0px", "margin-bottom": "12px" }
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Enter low count" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_row, { gutter: 16 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "HSN Code" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Enter HSN code" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "GST %" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      placeholder: "Enter GST %",
                                      onClick: ($event) => _ctx.gstShowing ^= true
                                    }, {
                                      suffix: withCtx(() => [
                                        createVNode(_component_DownOutlined, { style: { "color": "rgba(0, 0, 0, 0.25)", "font-size": "12px" } })
                                      ]),
                                      _: 1
                                    }, 8, ["onClick"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        withDirectives(createVNode(_component_a_list, {
                          "item-layout": "horizontal",
                          "data-source": _ctx.data,
                          style: { "margin-bottom": "16px" }
                        }, {
                          renderItem: withCtx(({ item }) => [
                            createVNode(_component_a_list_item, null, {
                              actions: withCtx(() => [
                                createVNode(_component_a_radio, {
                                  checked: _ctx.checked,
                                  "onUpdate:checked": ($event) => _ctx.checked = $event
                                }, null, 8, ["checked", "onUpdate:checked"])
                              ]),
                              default: withCtx(() => [
                                createVNode(_component_a_list_item_meta, {
                                  description: item.description
                                }, {
                                  title: withCtx(() => [
                                    createTextVNode(toDisplayString(item.title), 1)
                                  ]),
                                  _: 2
                                }, 1032, ["description"])
                              ]),
                              _: 2
                            }, 1024)
                          ]),
                          default: withCtx(() => [
                            createVNode("p", {
                              style: { "margin-bottom": "20px", "cursor": "pointer", "color": "#1890ff" },
                              onClick: ($event) => _ctx.addcustom ^= true
                            }, [
                              createVNode(_component_PlusCircleOutlined),
                              createTextVNode(" Add Custom Tax")
                            ], 8, ["onClick"]),
                            withDirectives(createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                              name: "nest-messages",
                              "validate-messages": _ctx.validateMessages,
                              onFinish: _ctx.submit
                            }), {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "CUSTOM TAX %",
                                  style: { "margin-bottom": "70px" }
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input_group, { size: "medium" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_row, { gutter: 8 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_col, { span: 8 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, { placeholder: "GST" })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 8 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, { placeholder: "CESS" })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 8 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_button, {
                                                  type: "primary",
                                                  "html-type": "submit"
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Save")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 16, ["model", "validate-messages", "onFinish"]), [
                              [vShow, _ctx.addcustom]
                            ])
                          ]),
                          _: 1
                        }, 8, ["data-source"]), [
                          [vShow, _ctx.gstShowing]
                        ]),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, { type: "primary" }, {
                              default: withCtx(() => [
                                createTextVNode("Add Item")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_button, { style: { "margin-left": "10px" } }, {
                              default: withCtx(() => [
                                createTextVNode("Cancel")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["model", "label-col", "wrapper-col", "rules"]), [
                      [vShow, _ctx.isShowing]
                    ])
                  ]),
                  _: 1
                }, 8, ["visible", "onClose"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_affix, { "offset-top": 0 }, {
            default: withCtx(() => [
              createVNode(_component_a_page_header, {
                ghost: false,
                title: "Add Purchase",
                onBack: () => _ctx.$inertia.visit(_ctx.route("purchase.index"))
              }, {
                extra: withCtx(() => [
                  createVNode(_component_a_button, {
                    key: "1",
                    type: "primary"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Save")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["onBack"])
            ]),
            _: 1
          }),
          createVNode(_component_a_row, null, {
            default: withCtx(() => [
              createVNode(_component_a_col, {
                span: 12,
                offset: 0
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_card, { style: { "padding": "0px", "background": "#fff", "minHeight": "2px", "margin-top": "16px", "margin-bottom": "12px", "margin-left": "16px", "height": "270px" } }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                        name: "nest-messages",
                        "validate-messages": _ctx.validateMessages,
                        onFinish: _ctx.submit
                      }), {
                        default: withCtx(() => [
                          createVNode("h3", {
                            "wrapper-col": { span: 12, offset: 6 },
                            style: { "margin-bottom": "20px", "font-size": "14px", "margin-top": "10px" }
                          }, "PARTY DETAILS"),
                          createVNode(_component_a_input_group, { size: "medium" }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "PO Number",
                                name: "po_number"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "PO Number" })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Add Party",
                                name: "po_number"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, { placeholder: "Party Name" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, {
                                        value: "undefined",
                                        onClick: withModifiers(() => {
                                          _ctx.showmodel_visible = true;
                                        }, ["stop"])
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_PlusCircleOutlined),
                                          createTextVNode(" Add New Party")
                                        ]),
                                        _: 1
                                      }, 8, ["onClick"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_modal, {
                            title: "Add New Party",
                            closable: true,
                            visible: _ctx.showmodel_visible,
                            "onUpdate:visible": ($event) => _ctx.showmodel_visible = $event,
                            onClose: ($event) => _ctx.showmodel_visible = false
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form, mergeProps({ model: _ctx.formParty }, _ctx.layout, {
                                name: "nest-messages",
                                "validate-messages": _ctx.validateMessages,
                                onFinish: _ctx.partySubmit
                              }), {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Party Name",
                                    name: "partyname",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.formParty.partyname,
                                        "onUpdate:value": ($event) => _ctx.formParty.partyname = $event,
                                        placeholder: "Enter Party Name"
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Mobile Number",
                                    name: "mobile"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.formParty.mobile,
                                        "onUpdate:value": ($event) => _ctx.formParty.mobile = $event,
                                        placeholder: "Enter Mobile Number"
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Who are they?",
                                    name: "who_r_they"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_radio_group, {
                                        value: _ctx.formParty.who_r_they,
                                        "onUpdate:value": ($event) => _ctx.formParty.who_r_they = $event
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_radio, { value: "customer" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Customer")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_radio, { value: "supplier" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Supplier")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "GSTIN",
                                    name: "gstin",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.formParty.gstin,
                                        "onUpdate:value": ($event) => _ctx.formParty.gstin = $event,
                                        placeholder: "Enter GSTIN"
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_menu, {
                                    id: "dddddd",
                                    style: { "width": "100%" },
                                    mode: "inline",
                                    onClick: withModifiers(() => {
                                      _ctx.menu_visible = true;
                                    }, ["stop"])
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_sub_menu, {
                                        key: "sub1",
                                        visible: _ctx.menu_visible,
                                        onClose: ($event) => _ctx.menu_visible = false
                                      }, {
                                        title: withCtx(() => [
                                          createTextVNode("Add GSTIN & Address (Optional)")
                                        ]),
                                        default: withCtx(() => [
                                          createVNode("h5", {
                                            "wrapper-col": { span: 12, offset: 6 },
                                            style: { "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" }
                                          }, "Shipping Address"),
                                          createVNode("br"),
                                          createVNode("br"),
                                          createVNode(_component_a_form_item, {
                                            label: "Flat / Building Number",
                                            name: "flat_no"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.formParty.flat_no,
                                                "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                                placeholder: "Enter Flat / Building Number"
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_form_item, {
                                            label: "Area / Locality",
                                            name: "area_loc"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.formParty.area_loc,
                                                "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                                placeholder: "Enter Area / Locality"
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_form_item, {
                                            label: "PIN Code",
                                            name: "pincode"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.formParty.pincode,
                                                "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                                placeholder: "Enter PIN Code"
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_form_item, {
                                            label: "City",
                                            name: "city"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.formParty.city,
                                                "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                                placeholder: "Enter City"
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_form_item, {
                                            label: "State",
                                            name: "state"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.formParty.state,
                                                "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                                placeholder: "Enter State"
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_form_item, { name: "same_ship" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_checkbox, {
                                                checked: _ctx.formParty.same_ship,
                                                "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Shipping address same as billing address")
                                                ]),
                                                _: 1
                                              }, 8, ["checked", "onUpdate:checked"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["visible", "onClose"])
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"]),
                                  createVNode(_component_a_form_item, {
                                    "wrapper-col": { span: 12, offset: 6 },
                                    style: { "margin-top": "19px", "margin-left": "100px" }
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit"
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Save")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 16, ["model", "validate-messages", "onFinish"])
                            ]),
                            _: 1
                          }, 8, ["visible", "onUpdate:visible", "onClose"])
                        ]),
                        _: 1
                      }, 16, ["model", "validate-messages", "onFinish"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(_component_a_col, { span: 12 }, {
                default: withCtx(() => [
                  createVNode(_component_a_card, { style: { "margin-top": "16px", "margin-bottom": "12px", "margin-left": "12px", "margin-right": "16px", "padding": "0px", "background": "#fff", "minHeight": "2px" } }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                        name: "nest-messages",
                        "validate-messages": _ctx.validateMessages,
                        onFinish: _ctx.submit
                      }), {
                        default: withCtx(() => [
                          createVNode("h3", {
                            "wrapper-col": { span: 12, offset: 6 },
                            style: { "margin-bottom": "20px", "font-size": "14px", "margin-top": "10px" }
                          }, "PURCHASE DETAILS"),
                          createVNode(_component_a_input_group, { size: "medium" }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Bill Number",
                                name: "bill_no",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: _ctx.value,
                                    "onUpdate:value": ($event) => _ctx.value = $event,
                                    placeholder: "Bill Number"
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Bill Date",
                                name: "date",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_date_picker, {
                                    "value-format": "YYYY-MM-DD",
                                    style: { "width": "100%" }
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Delivery Date",
                                name: "date"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_date_picker, {
                                    "value-format": "YYYY-MM-DD",
                                    style: { "width": "100%" }
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 16, ["model", "validate-messages", "onFinish"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_a_layout_content, { style: { margin: "5px 16px", padding: "24px", background: "#fff", minHeight: "calc(100vh - 115px)" } }, {
            default: withCtx(() => [
              createVNode("h5", {
                "wrapper-col": { span: 12, offset: 6 },
                style: { "margin-bottom": "20px", "font-size": "14px", "margin-top": "10px" }
              }, "ITEMS ON THE PURCHASE"),
              createVNode(_component_a_table, {
                columns: _ctx.columns,
                dataSource: _ctx.dataSource,
                pagination: _ctx.pagination,
                loading: _ctx.loading,
                onChange: _ctx.handleTableChange,
                bordered: ""
              }, {
                headerCell: withCtx(({ column }) => [
                  column.key === "discount" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                    createVNode("span", { style: { "margin-right": "15px" } }, " Discount "),
                    createVNode(_component_EditOutlined)
                  ], 64)) : createCommentVNode("", true),
                  column.key === "tax" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                    createVNode("span", { style: { "margin-right": "50px" } }, " Tax "),
                    createVNode(_component_EditOutlined)
                  ], 64)) : createCommentVNode("", true)
                ]),
                bodyCell: withCtx(({ column, text, record, index }) => [
                  createVNode("template", null, [
                    createTextVNode(toDisplayString(text ?? "-"), 1)
                  ]),
                  column.key === "name" ? (openBlock(), createBlock(_component_a_button, {
                    style: { "margin-top": "12px" },
                    key: "1",
                    type: "primary",
                    onClick: withModifiers(() => {
                      _ctx.invdrawer_visible = true;
                    }, ["stop"])
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Select Items from Inventory")
                    ]),
                    _: 1
                  }, 8, ["onClick"])) : createCommentVNode("", true),
                  column.key === "hsn_mat" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                    createTextVNode(toDisplayString(text), 1)
                  ], 64)) : createCommentVNode("", true),
                  column.key === "sno" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                    createTextVNode(toDisplayString(index + 1), 1)
                  ], 64)) : createCommentVNode("", true)
                ]),
                _: 1
              }, 8, ["columns", "dataSource", "pagination", "loading", "onChange"]),
              createVNode(_component_a_button, {
                class: "editable-add-btn",
                type: "primary",
                style: { "margin-top": "12px" },
                onClick: _ctx.handleAdd
              }, {
                default: withCtx(() => [
                  createTextVNode("Add Rows")
                ]),
                _: 1
              }, 8, ["onClick"]),
              createVNode(_component_a_card, { style: { "width": "350px", "float": "right", "margin-top": "12px" } }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                    name: "nest-messages",
                    "validate-messages": _ctx.validateMessages,
                    onFinish: _ctx.submit
                  }), {
                    default: withCtx(() => [
                      createVNode(_component_a_form_item, {
                        label: "Sub Total",
                        name: "area_loc"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, { placeholder: "" })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, {
                        label: "Paid Amount",
                        name: "area_loc"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, { placeholder: "" })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, {
                        label: "Grand Total",
                        name: "area_loc"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, { placeholder: "" })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 16, ["model", "validate-messages", "onFinish"])
                ]),
                _: 1
              }),
              createVNode(_component_a_drawer, {
                title: "Create a new account",
                width: 620,
                closable: true,
                visible: _ctx.invdrawer_visible,
                onClose: ($event) => _ctx.invdrawer_visible = false
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_row, {
                    type: "flex",
                    style: { "margin-bottom": "15px" }
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_col, { flex: "auto" }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input_search, {
                            value: _ctx.value,
                            "onUpdate:value": ($event) => _ctx.value = $event,
                            placeholder: "Search for any items in your inventory ",
                            "enter-button": ""
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_col, {
                        flex: "45px",
                        style: { "margin-left": "5px" }
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            size: _ctx.size
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_AlignLeftOutlined)
                            ]),
                            default: withCtx(() => [
                              createTextVNode("sort ")
                            ]),
                            _: 1
                          }, 8, ["size"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_button, {
                    type: "primary",
                    onClick: ($event) => _ctx.isShowing ^= true,
                    style: { "margin-bottom": "10px" }
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_PlusOutlined),
                      createTextVNode("Add New Item")
                    ]),
                    _: 1
                  }, 8, ["onClick"]),
                  createVNode(_component_a_list, {
                    "item-layout": "horizontal",
                    "data-source": _ctx.datas
                  }, {
                    renderItem: withCtx(({ item }) => [
                      createVNode(_component_a_list_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_list_item_meta, null, {
                            title: withCtx(() => [
                              createTextVNode(" Oil ")
                            ]),
                            description: withCtx(() => [
                              createVNode(_component_a_row, { style: { "margin-top": "10px" } }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, { span: 8 }, {
                                    default: withCtx(() => [
                                      createTextVNode(" PURCHASE PRICE")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 8 }, {
                                    default: withCtx(() => [
                                      createTextVNode("STOCK")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 8 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        style: { "margin-bottom": "0px" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_PlusOutlined),
                                          createTextVNode("Add")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_row, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, { span: 8 }, {
                                    default: withCtx(() => [
                                      createTextVNode("2")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 8 }, {
                                    default: withCtx(() => [
                                      createTextVNode("2")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["data-source"]),
                  withDirectives(createVNode(_component_a_form, {
                    model: _ctx.formState,
                    "label-col": _ctx.labelCol,
                    "wrapper-col": _ctx.wrapperCol,
                    rules: _ctx.rules,
                    layout: "vertical"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form_item, {
                        label: "Item name",
                        style: { "row-gap": "0px", "margin-bottom": "12px" }
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, { placeholder: "Enter Item name here (Eg, Milk, Bulb, Mobile)" })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_row, { gutter: 16 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Sale price",
                                style: { "row-gap": "0px", "margin-bottom": "12px" }
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Please enter sale price" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Purchase price",
                                style: { "row-gap": "0px", "margin-bottom": "12px" }
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Please enter purchase price" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_row, { gutter: 16 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Units",
                                style: { "row-gap": "0px", "margin-bottom": "12px" }
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, { placeholder: "Please select unit" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, { value: "xiao" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Xiaoxiao Fu")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "mao" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Maomao Zhou")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Tax Included",
                                style: { "row-gap": "0px", "margin-bottom": "12px" }
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_switch, {
                                    checked: _ctx.checked,
                                    "onUpdate:checked": ($event) => _ctx.checked = $event
                                  }, null, 8, ["checked", "onUpdate:checked"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_row, { gutter: 16 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Opening stock",
                                style: { "row-gap": "0px", "margin-bottom": "12px" }
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Enter count" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Low stock",
                                style: { "row-gap": "0px", "margin-bottom": "12px" }
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Enter low count" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_row, { gutter: 16 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "HSN Code" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Enter HSN code" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "GST %" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    placeholder: "Enter GST %",
                                    onClick: ($event) => _ctx.gstShowing ^= true
                                  }, {
                                    suffix: withCtx(() => [
                                      createVNode(_component_DownOutlined, { style: { "color": "rgba(0, 0, 0, 0.25)", "font-size": "12px" } })
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      withDirectives(createVNode(_component_a_list, {
                        "item-layout": "horizontal",
                        "data-source": _ctx.data,
                        style: { "margin-bottom": "16px" }
                      }, {
                        renderItem: withCtx(({ item }) => [
                          createVNode(_component_a_list_item, null, {
                            actions: withCtx(() => [
                              createVNode(_component_a_radio, {
                                checked: _ctx.checked,
                                "onUpdate:checked": ($event) => _ctx.checked = $event
                              }, null, 8, ["checked", "onUpdate:checked"])
                            ]),
                            default: withCtx(() => [
                              createVNode(_component_a_list_item_meta, {
                                description: item.description
                              }, {
                                title: withCtx(() => [
                                  createTextVNode(toDisplayString(item.title), 1)
                                ]),
                                _: 2
                              }, 1032, ["description"])
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        default: withCtx(() => [
                          createVNode("p", {
                            style: { "margin-bottom": "20px", "cursor": "pointer", "color": "#1890ff" },
                            onClick: ($event) => _ctx.addcustom ^= true
                          }, [
                            createVNode(_component_PlusCircleOutlined),
                            createTextVNode(" Add Custom Tax")
                          ], 8, ["onClick"]),
                          withDirectives(createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                            name: "nest-messages",
                            "validate-messages": _ctx.validateMessages,
                            onFinish: _ctx.submit
                          }), {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "CUSTOM TAX %",
                                style: { "margin-bottom": "70px" }
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input_group, { size: "medium" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_row, { gutter: 8 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_col, { span: 8 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, { placeholder: "GST" })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 8 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, { placeholder: "CESS" })
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 8 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_button, {
                                                type: "primary",
                                                "html-type": "submit"
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Save")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 16, ["model", "validate-messages", "onFinish"]), [
                            [vShow, _ctx.addcustom]
                          ])
                        ]),
                        _: 1
                      }, 8, ["data-source"]), [
                        [vShow, _ctx.gstShowing]
                      ]),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, { type: "primary" }, {
                            default: withCtx(() => [
                              createTextVNode("Add Item")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_button, { style: { "margin-left": "10px" } }, {
                            default: withCtx(() => [
                              createTextVNode("Cancel")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["model", "label-col", "wrapper-col", "rules"]), [
                    [vShow, _ctx.isShowing]
                  ])
                ]),
                _: 1
              }, 8, ["visible", "onClose"])
            ]),
            _: 1
          }, 8, ["style"])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Purchase/Create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Create = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Create as default
};
