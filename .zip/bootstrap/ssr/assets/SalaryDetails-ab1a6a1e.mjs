import { resolveComponent, withCtx, createTextVNode, createVNode, toDisplayString, withModifiers, mergeProps, openBlock, createBlock, createCommentVNode, Fragment, renderList, useSSRContext } from "vue";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import { Head, useForm, router } from "@inertiajs/vue3";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
import "@ant-design/icons-vue";
const _sfc_main = {
  inject: ["validateMessages"],
  components: {
    AuthenticatedLayout: _sfc_main$1,
    Head
  },
  props: {
    employee: Object,
    errors: Object
  },
  setup(props) {
    const layout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 16 }
    };
    const formState = useForm({
      salary_type: props.employee.salarydetail != null ? props.employee.salarydetail.salary_type : "Month",
      salary_amount: props.employee.salarydetail != null ? props.employee.salarydetail.salary_amount : "",
      allowances: props.employee.salarydetail != null ? props.employee.salarydetail.allowances : {},
      pf_detail: props.employee.salarydetail != null ? props.employee.salarydetail.pf_detail : "",
      esi_detail: props.employee.salarydetail != null ? props.employee.salarydetail.esi_detail : "",
      pf_amount: props.employee.salarydetail != null ? props.employee.salarydetail.pf_amount : "",
      esi_amount: props.employee.salarydetail != null ? props.employee.salarydetail.esi_amount : "",
      ctc: props.employee.salarydetail != null ? props.employee.salarydetail.ctc : ""
    });
    const OtformState = useForm({
      weekoff_pay: props.employee.otsettings != null ? props.employee.otsettings.weekoff_pay : "0",
      publicholiday_pay: props.employee.otsettings != null ? props.employee.otsettings.publicholiday_pay : "0",
      extra_hours_pay: props.employee.otsettings != null ? props.employee.otsettings.extra_hours_pay : "0",
      grace_period: props.employee.otsettings != null ? props.employee.otsettings.grace_period : ""
    });
    const LateformState = useForm({
      allowed_days: props.employee.latepenalty_setting != null ? props.employee.latepenalty_setting.allowed_days : "",
      grace_period: props.employee.latepenalty_setting != null ? props.employee.latepenalty_setting.grace_period : "",
      deduction_type: props.employee.latepenalty_setting != null ? props.employee.latepenalty_setting.deduction_type : "",
      deduction_rate: props.employee.latepenalty_setting != null ? props.employee.latepenalty_setting.deduction_rate : ""
    });
    return {
      formState,
      OtformState,
      LateformState,
      layout
    };
  },
  data() {
    return {
      otdrawer_visible: false,
      latedrawer_visible: false
    };
  },
  methods: {
    addAllowances(label) {
      this.formState.allowances[label] = "";
    },
    removeAllowance(label) {
      delete this.formState.allowances[label];
    },
    submit() {
      this.formState.post(route("employees.update_salary_info", this.employee.id));
    },
    calcCTC() {
      if (this.formState.salary_type == "Day" || this.formState.salary_type == "Hour") {
        this.formState.ctc = this.formState.salary_amount;
      } else {
        var ctc = 0;
        var pf_amount = 0;
        var esi_amount = 0;
        ctc += parseInt(this.formState.salary_amount);
        var allowances_sum = Object.values(this.formState.allowances).reduce((a, b) => b == "" ? a : parseInt(a) + parseInt(b), 0);
        ctc += parseInt(allowances_sum);
        if (this.formState.pf_detail == "2") {
          pf_amount = this.formState.salary_amount * (12 / 100);
        } else if (this.formState.pf_detail == "1") {
          pf_amount = this.formState.salary_amount * (12 / 100);
          pf_amount = pf_amount <= 1800 ? pf_amount : 1800;
        }
        ctc -= parseInt(pf_amount);
        if (this.formState.esi_detail == "1") {
          esi_amount = this.formState.salary_amount * (0.75 / 100);
        }
        ctc -= parseInt(esi_amount);
        this.formState.pf_amount = Math.round(pf_amount);
        this.formState.esi_amount = Math.round(esi_amount);
        this.formState.ctc = Math.round(ctc);
      }
    },
    OTsubmit() {
      router.post(route("employees.update_ot_info", this.employee.id), this.OtformState, {
        onSuccess: (page) => {
        },
        onError: (errors) => {
        },
        onFinish: (visit) => {
          this.otdrawer_visible = false;
        }
      });
    },
    lateSubmit() {
      router.post(route("employees.update_latepenalty_info", this.employee.id), this.LateformState, {
        onSuccess: (page) => {
        },
        onError: (errors) => {
        },
        onFinish: (visit) => {
          this.latedrawer_visible = false;
        }
      });
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_affix = resolveComponent("a-affix");
  const _component_a_page_header = resolveComponent("a-page-header");
  const _component_a_button = resolveComponent("a-button");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_select_option = resolveComponent("a-select-option");
  const _component_a_input_number = resolveComponent("a-input-number");
  const _component_a_dropdown = resolveComponent("a-dropdown");
  const _component_DownOutlined = resolveComponent("DownOutlined");
  const _component_a_menu = resolveComponent("a-menu");
  const _component_a_menu_item = resolveComponent("a-menu-item");
  const _component_a_drawer = resolveComponent("a-drawer");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_radio_group = resolveComponent("a-radio-group");
  const _component_a_radio = resolveComponent("a-radio");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Employees" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_affix, { "offset-top": 0 }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_page_header, {
                ghost: false,
                title: $props.employee.name + " Salary Info",
                onBack: () => _ctx.$inertia.visit(_ctx.route("employees.index"))
              }, {
                extra: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(`<h4${_scopeId3}>Total CTC: <span class="currency"${_scopeId3}>₹</span> ${ssrInterpolate(this.formState.ctc)}</h4>`);
                    _push4(ssrRenderComponent(_component_a_button, {
                      key: "1",
                      type: "primary",
                      onClick: () => {
                        $data.otdrawer_visible = true;
                      }
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`OT settings`);
                        } else {
                          return [
                            createTextVNode("OT settings")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_button, {
                      key: "1",
                      type: "primary",
                      onClick: () => {
                        $data.latedrawer_visible = true;
                      }
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`Late Penalty Settings`);
                        } else {
                          return [
                            createTextVNode("Late Penalty Settings")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode("h4", null, [
                        createTextVNode("Total CTC: "),
                        createVNode("span", { class: "currency" }, "₹"),
                        createTextVNode(" " + toDisplayString(this.formState.ctc), 1)
                      ]),
                      createVNode(_component_a_button, {
                        key: "1",
                        type: "primary",
                        onClick: withModifiers(() => {
                          $data.otdrawer_visible = true;
                        }, ["stop"])
                      }, {
                        default: withCtx(() => [
                          createTextVNode("OT settings")
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_button, {
                        key: "1",
                        type: "primary",
                        onClick: withModifiers(() => {
                          $data.latedrawer_visible = true;
                        }, ["stop"])
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Late Penalty Settings")
                        ]),
                        _: 1
                      }, 8, ["onClick"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_page_header, {
                  ghost: false,
                  title: $props.employee.name + " Salary Info",
                  onBack: () => _ctx.$inertia.visit(_ctx.route("employees.index"))
                }, {
                  extra: withCtx(() => [
                    createVNode("h4", null, [
                      createTextVNode("Total CTC: "),
                      createVNode("span", { class: "currency" }, "₹"),
                      createTextVNode(" " + toDisplayString(this.formState.ctc), 1)
                    ]),
                    createVNode(_component_a_button, {
                      key: "1",
                      type: "primary",
                      onClick: withModifiers(() => {
                        $data.otdrawer_visible = true;
                      }, ["stop"])
                    }, {
                      default: withCtx(() => [
                        createTextVNode("OT settings")
                      ]),
                      _: 1
                    }, 8, ["onClick"]),
                    createVNode(_component_a_button, {
                      key: "1",
                      type: "primary",
                      onClick: withModifiers(() => {
                        $data.latedrawer_visible = true;
                      }, ["stop"])
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Late Penalty Settings")
                      ]),
                      _: 1
                    }, 8, ["onClick"])
                  ]),
                  _: 1
                }, 8, ["title", "onBack"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_layout_content, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_row, null, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_col, {
                      span: 12,
                      offset: 5
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                            name: "nest-messages",
                            "validate-messages": $options.validateMessages,
                            onFinish: $options.submit
                          }), {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Salary Type",
                                  name: "salary_type",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_select, {
                                        placeholder: "Select Salary Type",
                                        value: $setup.formState.salary_type,
                                        "onUpdate:value": ($event) => $setup.formState.salary_type = $event,
                                        onChange: ($event) => $options.calcCTC()
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Month" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Per Month`);
                                                } else {
                                                  return [
                                                    createTextVNode("Per Month")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Day" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Per Day`);
                                                } else {
                                                  return [
                                                    createTextVNode("Per Day")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Hour" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Per Hour`);
                                                } else {
                                                  return [
                                                    createTextVNode("Per Hour")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select_option, { value: "Month" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Per Month")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Day" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Per Day")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Hour" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Per Hour")
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_select, {
                                          placeholder: "Select Salary Type",
                                          value: $setup.formState.salary_type,
                                          "onUpdate:value": ($event) => $setup.formState.salary_type = $event,
                                          onChange: ($event) => $options.calcCTC()
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "Month" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Per Month")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Day" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Per Day")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Hour" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Per Hour")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["value", "onUpdate:value", "onChange"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                if ($setup.formState.salary_type == "Day") {
                                  _push6(ssrRenderComponent(_component_a_form_item, {
                                    label: "Salary Amount",
                                    name: "salary_amount",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_a_input_number, {
                                          prefix: "₹",
                                          "addon-after": "/ Day",
                                          style: { width: "100%" },
                                          value: $setup.formState.salary_amount,
                                          "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                          onKeyup: ($event) => $options.calcCTC()
                                        }, null, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_a_input_number, {
                                            prefix: "₹",
                                            "addon-after": "/ Day",
                                            style: { width: "100%" },
                                            value: $setup.formState.salary_amount,
                                            "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                            onKeyup: ($event) => $options.calcCTC()
                                          }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                        ];
                                      }
                                    }),
                                    _: 1
                                  }, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                                if ($setup.formState.salary_type == "Hour") {
                                  _push6(ssrRenderComponent(_component_a_form_item, {
                                    label: "Salary Amount",
                                    name: "salary_amount",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_a_input_number, {
                                          prefix: "₹",
                                          "addon-after": "/ Hour",
                                          style: { width: "100%" },
                                          value: $setup.formState.salary_amount,
                                          "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                          onKeyup: ($event) => $options.calcCTC()
                                        }, null, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_a_input_number, {
                                            prefix: "₹",
                                            "addon-after": "/ Hour",
                                            style: { width: "100%" },
                                            value: $setup.formState.salary_amount,
                                            "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                            onKeyup: ($event) => $options.calcCTC()
                                          }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                        ];
                                      }
                                    }),
                                    _: 1
                                  }, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                                if ($setup.formState.salary_type == "Month") {
                                  _push6(`<div${_scopeId5}>`);
                                  _push6(ssrRenderComponent(_component_a_form_item, {
                                    label: "Basic",
                                    name: "salary_amount",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_a_input_number, {
                                          prefix: "₹",
                                          style: { width: "100%" },
                                          value: $setup.formState.salary_amount,
                                          "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                          onKeyup: ($event) => $options.calcCTC()
                                        }, null, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_a_input_number, {
                                            prefix: "₹",
                                            style: { width: "100%" },
                                            value: $setup.formState.salary_amount,
                                            "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                            onKeyup: ($event) => $options.calcCTC()
                                          }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                        ];
                                      }
                                    }),
                                    _: 1
                                  }, _parent6, _scopeId5));
                                  _push6(`<!--[-->`);
                                  ssrRenderList($setup.formState.allowances, (allowance, index) => {
                                    _push6(ssrRenderComponent(_component_a_form_item, {
                                      label: index,
                                      name: index
                                    }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(_component_a_row, { type: "flex" }, {
                                            default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                              if (_push8) {
                                                _push8(ssrRenderComponent(_component_a_col, { flex: "auto" }, {
                                                  default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                    if (_push9) {
                                                      _push9(ssrRenderComponent(_component_a_input_number, {
                                                        prefix: "₹",
                                                        style: { width: "100%" },
                                                        value: $setup.formState.allowances[index],
                                                        "onUpdate:value": ($event) => $setup.formState.allowances[index] = $event,
                                                        onKeyup: ($event) => $options.calcCTC()
                                                      }, null, _parent9, _scopeId8));
                                                    } else {
                                                      return [
                                                        createVNode(_component_a_input_number, {
                                                          prefix: "₹",
                                                          style: { width: "100%" },
                                                          value: $setup.formState.allowances[index],
                                                          "onUpdate:value": ($event) => $setup.formState.allowances[index] = $event,
                                                          onKeyup: ($event) => $options.calcCTC()
                                                        }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                                      ];
                                                    }
                                                  }),
                                                  _: 2
                                                }, _parent8, _scopeId7));
                                                _push8(ssrRenderComponent(_component_a_col, {
                                                  flex: "80px",
                                                  style: { "text-align": "right" }
                                                }, {
                                                  default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                    if (_push9) {
                                                      _push9(`<a${_scopeId8}>Remove</a>`);
                                                    } else {
                                                      return [
                                                        createVNode("a", {
                                                          onClick: ($event) => $options.removeAllowance(index)
                                                        }, "Remove", 8, ["onClick"])
                                                      ];
                                                    }
                                                  }),
                                                  _: 2
                                                }, _parent8, _scopeId7));
                                              } else {
                                                return [
                                                  createVNode(_component_a_col, { flex: "auto" }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input_number, {
                                                        prefix: "₹",
                                                        style: { width: "100%" },
                                                        value: $setup.formState.allowances[index],
                                                        "onUpdate:value": ($event) => $setup.formState.allowances[index] = $event,
                                                        onKeyup: ($event) => $options.calcCTC()
                                                      }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                                    ]),
                                                    _: 2
                                                  }, 1024),
                                                  createVNode(_component_a_col, {
                                                    flex: "80px",
                                                    style: { "text-align": "right" }
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode("a", {
                                                        onClick: ($event) => $options.removeAllowance(index)
                                                      }, "Remove", 8, ["onClick"])
                                                    ]),
                                                    _: 2
                                                  }, 1024)
                                                ];
                                              }
                                            }),
                                            _: 2
                                          }, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode(_component_a_row, { type: "flex" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_col, { flex: "auto" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input_number, {
                                                      prefix: "₹",
                                                      style: { width: "100%" },
                                                      value: $setup.formState.allowances[index],
                                                      "onUpdate:value": ($event) => $setup.formState.allowances[index] = $event,
                                                      onKeyup: ($event) => $options.calcCTC()
                                                    }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                                  ]),
                                                  _: 2
                                                }, 1024),
                                                createVNode(_component_a_col, {
                                                  flex: "80px",
                                                  style: { "text-align": "right" }
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode("a", {
                                                      onClick: ($event) => $options.removeAllowance(index)
                                                    }, "Remove", 8, ["onClick"])
                                                  ]),
                                                  _: 2
                                                }, 1024)
                                              ]),
                                              _: 2
                                            }, 1024)
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                  });
                                  _push6(`<!--]-->`);
                                  _push6(ssrRenderComponent(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                    default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_a_dropdown, { trigger: ["click"] }, {
                                          overlay: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(ssrRenderComponent(_component_a_menu, null, {
                                                default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                  if (_push9) {
                                                    if (!("HRA" in $setup.formState.allowances)) {
                                                      _push9(ssrRenderComponent(_component_a_menu_item, { key: "0" }, {
                                                        default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                          if (_push10) {
                                                            _push10(`<a${_scopeId9}>HRA</a>`);
                                                          } else {
                                                            return [
                                                              createVNode("a", {
                                                                onClick: ($event) => $options.addAllowances("HRA")
                                                              }, "HRA", 8, ["onClick"])
                                                            ];
                                                          }
                                                        }),
                                                        _: 1
                                                      }, _parent9, _scopeId8));
                                                    } else {
                                                      _push9(`<!---->`);
                                                    }
                                                    if (!("Dearness Allowance" in $setup.formState.allowances)) {
                                                      _push9(ssrRenderComponent(_component_a_menu_item, { key: "1" }, {
                                                        default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                          if (_push10) {
                                                            _push10(`<a${_scopeId9}>Dearness Allowance</a>`);
                                                          } else {
                                                            return [
                                                              createVNode("a", {
                                                                onClick: ($event) => $options.addAllowances("Dearness Allowance")
                                                              }, "Dearness Allowance", 8, ["onClick"])
                                                            ];
                                                          }
                                                        }),
                                                        _: 1
                                                      }, _parent9, _scopeId8));
                                                    } else {
                                                      _push9(`<!---->`);
                                                    }
                                                    if (!("Travel Allowance" in $setup.formState.allowances)) {
                                                      _push9(ssrRenderComponent(_component_a_menu_item, { key: "2" }, {
                                                        default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                          if (_push10) {
                                                            _push10(`<a${_scopeId9}>Travel Allowance</a>`);
                                                          } else {
                                                            return [
                                                              createVNode("a", {
                                                                onClick: ($event) => $options.addAllowances("Travel Allowance")
                                                              }, "Travel Allowance", 8, ["onClick"])
                                                            ];
                                                          }
                                                        }),
                                                        _: 1
                                                      }, _parent9, _scopeId8));
                                                    } else {
                                                      _push9(`<!---->`);
                                                    }
                                                    if (!("Meal Allowance" in $setup.formState.allowances)) {
                                                      _push9(ssrRenderComponent(_component_a_menu_item, { key: "3" }, {
                                                        default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                          if (_push10) {
                                                            _push10(`<a${_scopeId9}>Meal Allowance</a>`);
                                                          } else {
                                                            return [
                                                              createVNode("a", {
                                                                onClick: ($event) => $options.addAllowances("Meal Allowance")
                                                              }, "Meal Allowance", 8, ["onClick"])
                                                            ];
                                                          }
                                                        }),
                                                        _: 1
                                                      }, _parent9, _scopeId8));
                                                    } else {
                                                      _push9(`<!---->`);
                                                    }
                                                    if (!("Medical Allowance" in $setup.formState.allowances)) {
                                                      _push9(ssrRenderComponent(_component_a_menu_item, { key: "4" }, {
                                                        default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                          if (_push10) {
                                                            _push10(`<a${_scopeId9}>Medical Allowance</a>`);
                                                          } else {
                                                            return [
                                                              createVNode("a", {
                                                                onClick: ($event) => $options.addAllowances("Medical Allowance")
                                                              }, "Medical Allowance", 8, ["onClick"])
                                                            ];
                                                          }
                                                        }),
                                                        _: 1
                                                      }, _parent9, _scopeId8));
                                                    } else {
                                                      _push9(`<!---->`);
                                                    }
                                                    if (!("Special Allowance" in $setup.formState.allowances)) {
                                                      _push9(ssrRenderComponent(_component_a_menu_item, { key: "5" }, {
                                                        default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                          if (_push10) {
                                                            _push10(`<a${_scopeId9}>Special Allowance</a>`);
                                                          } else {
                                                            return [
                                                              createVNode("a", {
                                                                onClick: ($event) => $options.addAllowances("Special Allowance")
                                                              }, "Special Allowance", 8, ["onClick"])
                                                            ];
                                                          }
                                                        }),
                                                        _: 1
                                                      }, _parent9, _scopeId8));
                                                    } else {
                                                      _push9(`<!---->`);
                                                    }
                                                  } else {
                                                    return [
                                                      !("HRA" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "0" }, {
                                                        default: withCtx(() => [
                                                          createVNode("a", {
                                                            onClick: ($event) => $options.addAllowances("HRA")
                                                          }, "HRA", 8, ["onClick"])
                                                        ]),
                                                        _: 1
                                                      })) : createCommentVNode("", true),
                                                      !("Dearness Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "1" }, {
                                                        default: withCtx(() => [
                                                          createVNode("a", {
                                                            onClick: ($event) => $options.addAllowances("Dearness Allowance")
                                                          }, "Dearness Allowance", 8, ["onClick"])
                                                        ]),
                                                        _: 1
                                                      })) : createCommentVNode("", true),
                                                      !("Travel Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "2" }, {
                                                        default: withCtx(() => [
                                                          createVNode("a", {
                                                            onClick: ($event) => $options.addAllowances("Travel Allowance")
                                                          }, "Travel Allowance", 8, ["onClick"])
                                                        ]),
                                                        _: 1
                                                      })) : createCommentVNode("", true),
                                                      !("Meal Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "3" }, {
                                                        default: withCtx(() => [
                                                          createVNode("a", {
                                                            onClick: ($event) => $options.addAllowances("Meal Allowance")
                                                          }, "Meal Allowance", 8, ["onClick"])
                                                        ]),
                                                        _: 1
                                                      })) : createCommentVNode("", true),
                                                      !("Medical Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "4" }, {
                                                        default: withCtx(() => [
                                                          createVNode("a", {
                                                            onClick: ($event) => $options.addAllowances("Medical Allowance")
                                                          }, "Medical Allowance", 8, ["onClick"])
                                                        ]),
                                                        _: 1
                                                      })) : createCommentVNode("", true),
                                                      !("Special Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "5" }, {
                                                        default: withCtx(() => [
                                                          createVNode("a", {
                                                            onClick: ($event) => $options.addAllowances("Special Allowance")
                                                          }, "Special Allowance", 8, ["onClick"])
                                                        ]),
                                                        _: 1
                                                      })) : createCommentVNode("", true)
                                                    ];
                                                  }
                                                }),
                                                _: 1
                                              }, _parent8, _scopeId7));
                                            } else {
                                              return [
                                                createVNode(_component_a_menu, null, {
                                                  default: withCtx(() => [
                                                    !("HRA" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "0" }, {
                                                      default: withCtx(() => [
                                                        createVNode("a", {
                                                          onClick: ($event) => $options.addAllowances("HRA")
                                                        }, "HRA", 8, ["onClick"])
                                                      ]),
                                                      _: 1
                                                    })) : createCommentVNode("", true),
                                                    !("Dearness Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "1" }, {
                                                      default: withCtx(() => [
                                                        createVNode("a", {
                                                          onClick: ($event) => $options.addAllowances("Dearness Allowance")
                                                        }, "Dearness Allowance", 8, ["onClick"])
                                                      ]),
                                                      _: 1
                                                    })) : createCommentVNode("", true),
                                                    !("Travel Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "2" }, {
                                                      default: withCtx(() => [
                                                        createVNode("a", {
                                                          onClick: ($event) => $options.addAllowances("Travel Allowance")
                                                        }, "Travel Allowance", 8, ["onClick"])
                                                      ]),
                                                      _: 1
                                                    })) : createCommentVNode("", true),
                                                    !("Meal Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "3" }, {
                                                      default: withCtx(() => [
                                                        createVNode("a", {
                                                          onClick: ($event) => $options.addAllowances("Meal Allowance")
                                                        }, "Meal Allowance", 8, ["onClick"])
                                                      ]),
                                                      _: 1
                                                    })) : createCommentVNode("", true),
                                                    !("Medical Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "4" }, {
                                                      default: withCtx(() => [
                                                        createVNode("a", {
                                                          onClick: ($event) => $options.addAllowances("Medical Allowance")
                                                        }, "Medical Allowance", 8, ["onClick"])
                                                      ]),
                                                      _: 1
                                                    })) : createCommentVNode("", true),
                                                    !("Special Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "5" }, {
                                                      default: withCtx(() => [
                                                        createVNode("a", {
                                                          onClick: ($event) => $options.addAllowances("Special Allowance")
                                                        }, "Special Allowance", 8, ["onClick"])
                                                      ]),
                                                      _: 1
                                                    })) : createCommentVNode("", true)
                                                  ]),
                                                  _: 1
                                                })
                                              ];
                                            }
                                          }),
                                          default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(`<a class="ant-dropdown-link"${_scopeId7}> + Add Allowance `);
                                              _push8(ssrRenderComponent(_component_DownOutlined, null, null, _parent8, _scopeId7));
                                              _push8(`</a>`);
                                            } else {
                                              return [
                                                createVNode("a", {
                                                  class: "ant-dropdown-link",
                                                  onClick: withModifiers(() => {
                                                  }, ["prevent"])
                                                }, [
                                                  createTextVNode(" + Add Allowance "),
                                                  createVNode(_component_DownOutlined)
                                                ], 8, ["onClick"])
                                              ];
                                            }
                                          }),
                                          _: 1
                                        }, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_a_dropdown, { trigger: ["click"] }, {
                                            overlay: withCtx(() => [
                                              createVNode(_component_a_menu, null, {
                                                default: withCtx(() => [
                                                  !("HRA" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "0" }, {
                                                    default: withCtx(() => [
                                                      createVNode("a", {
                                                        onClick: ($event) => $options.addAllowances("HRA")
                                                      }, "HRA", 8, ["onClick"])
                                                    ]),
                                                    _: 1
                                                  })) : createCommentVNode("", true),
                                                  !("Dearness Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "1" }, {
                                                    default: withCtx(() => [
                                                      createVNode("a", {
                                                        onClick: ($event) => $options.addAllowances("Dearness Allowance")
                                                      }, "Dearness Allowance", 8, ["onClick"])
                                                    ]),
                                                    _: 1
                                                  })) : createCommentVNode("", true),
                                                  !("Travel Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "2" }, {
                                                    default: withCtx(() => [
                                                      createVNode("a", {
                                                        onClick: ($event) => $options.addAllowances("Travel Allowance")
                                                      }, "Travel Allowance", 8, ["onClick"])
                                                    ]),
                                                    _: 1
                                                  })) : createCommentVNode("", true),
                                                  !("Meal Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "3" }, {
                                                    default: withCtx(() => [
                                                      createVNode("a", {
                                                        onClick: ($event) => $options.addAllowances("Meal Allowance")
                                                      }, "Meal Allowance", 8, ["onClick"])
                                                    ]),
                                                    _: 1
                                                  })) : createCommentVNode("", true),
                                                  !("Medical Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "4" }, {
                                                    default: withCtx(() => [
                                                      createVNode("a", {
                                                        onClick: ($event) => $options.addAllowances("Medical Allowance")
                                                      }, "Medical Allowance", 8, ["onClick"])
                                                    ]),
                                                    _: 1
                                                  })) : createCommentVNode("", true),
                                                  !("Special Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "5" }, {
                                                    default: withCtx(() => [
                                                      createVNode("a", {
                                                        onClick: ($event) => $options.addAllowances("Special Allowance")
                                                      }, "Special Allowance", 8, ["onClick"])
                                                    ]),
                                                    _: 1
                                                  })) : createCommentVNode("", true)
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            default: withCtx(() => [
                                              createVNode("a", {
                                                class: "ant-dropdown-link",
                                                onClick: withModifiers(() => {
                                                }, ["prevent"])
                                              }, [
                                                createTextVNode(" + Add Allowance "),
                                                createVNode(_component_DownOutlined)
                                              ], 8, ["onClick"])
                                            ]),
                                            _: 1
                                          })
                                        ];
                                      }
                                    }),
                                    _: 1
                                  }, _parent6, _scopeId5));
                                  _push6(ssrRenderComponent(_component_a_form_item, {
                                    label: "Employee PF",
                                    name: "pf_detail"
                                  }, {
                                    default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_a_row, { type: "flex" }, {
                                          default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(ssrRenderComponent(_component_a_col, { flex: "auto" }, {
                                                default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                  if (_push9) {
                                                    _push9(ssrRenderComponent(_component_a_select, {
                                                      placeholder: "Select Salary Type",
                                                      onChange: ($event) => $options.calcCTC(),
                                                      value: $setup.formState.pf_detail,
                                                      "onUpdate:value": ($event) => $setup.formState.pf_detail = $event,
                                                      style: { "width": "100%" }
                                                    }, {
                                                      default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                        if (_push10) {
                                                          _push10(ssrRenderComponent(_component_a_select_option, { value: "0" }, {
                                                            default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                              if (_push11) {
                                                                _push11(`None`);
                                                              } else {
                                                                return [
                                                                  createTextVNode("None")
                                                                ];
                                                              }
                                                            }),
                                                            _: 1
                                                          }, _parent10, _scopeId9));
                                                          _push10(ssrRenderComponent(_component_a_select_option, { value: "1" }, {
                                                            default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                              if (_push11) {
                                                                _push11(`1800 Limit`);
                                                              } else {
                                                                return [
                                                                  createTextVNode("1800 Limit")
                                                                ];
                                                              }
                                                            }),
                                                            _: 1
                                                          }, _parent10, _scopeId9));
                                                          _push10(ssrRenderComponent(_component_a_select_option, { value: "2" }, {
                                                            default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                              if (_push11) {
                                                                _push11(`12%`);
                                                              } else {
                                                                return [
                                                                  createTextVNode("12%")
                                                                ];
                                                              }
                                                            }),
                                                            _: 1
                                                          }, _parent10, _scopeId9));
                                                        } else {
                                                          return [
                                                            createVNode(_component_a_select_option, { value: "0" }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("None")
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode(_component_a_select_option, { value: "1" }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("1800 Limit")
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode(_component_a_select_option, { value: "2" }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("12%")
                                                              ]),
                                                              _: 1
                                                            })
                                                          ];
                                                        }
                                                      }),
                                                      _: 1
                                                    }, _parent9, _scopeId8));
                                                  } else {
                                                    return [
                                                      createVNode(_component_a_select, {
                                                        placeholder: "Select Salary Type",
                                                        onChange: ($event) => $options.calcCTC(),
                                                        value: $setup.formState.pf_detail,
                                                        "onUpdate:value": ($event) => $setup.formState.pf_detail = $event,
                                                        style: { "width": "100%" }
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_select_option, { value: "0" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("None")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_select_option, { value: "1" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("1800 Limit")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_select_option, { value: "2" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("12%")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      }, 8, ["onChange", "value", "onUpdate:value"])
                                                    ];
                                                  }
                                                }),
                                                _: 1
                                              }, _parent8, _scopeId7));
                                              _push8(ssrRenderComponent(_component_a_col, {
                                                flex: "80px",
                                                style: { "text-align": "right" }
                                              }, {
                                                default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                  if (_push9) {
                                                    _push9(`<span${_scopeId8}>₹ ${ssrInterpolate(this.formState.pf_amount)}</span>`);
                                                  } else {
                                                    return [
                                                      createVNode("span", null, "₹ " + toDisplayString(this.formState.pf_amount), 1)
                                                    ];
                                                  }
                                                }),
                                                _: 1
                                              }, _parent8, _scopeId7));
                                            } else {
                                              return [
                                                createVNode(_component_a_col, { flex: "auto" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_select, {
                                                      placeholder: "Select Salary Type",
                                                      onChange: ($event) => $options.calcCTC(),
                                                      value: $setup.formState.pf_detail,
                                                      "onUpdate:value": ($event) => $setup.formState.pf_detail = $event,
                                                      style: { "width": "100%" }
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_select_option, { value: "0" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("None")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_select_option, { value: "1" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("1800 Limit")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_select_option, { value: "2" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("12%")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }, 8, ["onChange", "value", "onUpdate:value"])
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_col, {
                                                  flex: "80px",
                                                  style: { "text-align": "right" }
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode("span", null, "₹ " + toDisplayString(this.formState.pf_amount), 1)
                                                  ]),
                                                  _: 1
                                                })
                                              ];
                                            }
                                          }),
                                          _: 1
                                        }, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_a_row, { type: "flex" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_col, { flex: "auto" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select, {
                                                    placeholder: "Select Salary Type",
                                                    onChange: ($event) => $options.calcCTC(),
                                                    value: $setup.formState.pf_detail,
                                                    "onUpdate:value": ($event) => $setup.formState.pf_detail = $event,
                                                    style: { "width": "100%" }
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_select_option, { value: "0" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("None")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_select_option, { value: "1" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("1800 Limit")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_select_option, { value: "2" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("12%")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }, 8, ["onChange", "value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, {
                                                flex: "80px",
                                                style: { "text-align": "right" }
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode("span", null, "₹ " + toDisplayString(this.formState.pf_amount), 1)
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ];
                                      }
                                    }),
                                    _: 1
                                  }, _parent6, _scopeId5));
                                  _push6(ssrRenderComponent(_component_a_form_item, {
                                    label: "Employee ESI",
                                    name: "esi_detail"
                                  }, {
                                    default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_a_row, { type: "flex" }, {
                                          default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(ssrRenderComponent(_component_a_col, { flex: "auto" }, {
                                                default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                  if (_push9) {
                                                    _push9(ssrRenderComponent(_component_a_select, {
                                                      placeholder: "Select Salary Type",
                                                      onChange: ($event) => $options.calcCTC(),
                                                      value: $setup.formState.esi_detail,
                                                      "onUpdate:value": ($event) => $setup.formState.esi_detail = $event,
                                                      style: { "width": "100%" }
                                                    }, {
                                                      default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                        if (_push10) {
                                                          _push10(ssrRenderComponent(_component_a_select_option, { value: "0" }, {
                                                            default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                              if (_push11) {
                                                                _push11(`None`);
                                                              } else {
                                                                return [
                                                                  createTextVNode("None")
                                                                ];
                                                              }
                                                            }),
                                                            _: 1
                                                          }, _parent10, _scopeId9));
                                                          _push10(ssrRenderComponent(_component_a_select_option, { value: "1" }, {
                                                            default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                              if (_push11) {
                                                                _push11(`0.75%`);
                                                              } else {
                                                                return [
                                                                  createTextVNode("0.75%")
                                                                ];
                                                              }
                                                            }),
                                                            _: 1
                                                          }, _parent10, _scopeId9));
                                                        } else {
                                                          return [
                                                            createVNode(_component_a_select_option, { value: "0" }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("None")
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode(_component_a_select_option, { value: "1" }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("0.75%")
                                                              ]),
                                                              _: 1
                                                            })
                                                          ];
                                                        }
                                                      }),
                                                      _: 1
                                                    }, _parent9, _scopeId8));
                                                  } else {
                                                    return [
                                                      createVNode(_component_a_select, {
                                                        placeholder: "Select Salary Type",
                                                        onChange: ($event) => $options.calcCTC(),
                                                        value: $setup.formState.esi_detail,
                                                        "onUpdate:value": ($event) => $setup.formState.esi_detail = $event,
                                                        style: { "width": "100%" }
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_select_option, { value: "0" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("None")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_select_option, { value: "1" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("0.75%")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      }, 8, ["onChange", "value", "onUpdate:value"])
                                                    ];
                                                  }
                                                }),
                                                _: 1
                                              }, _parent8, _scopeId7));
                                              _push8(ssrRenderComponent(_component_a_col, {
                                                flex: "80px",
                                                style: { "text-align": "right" }
                                              }, {
                                                default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                  if (_push9) {
                                                    _push9(`<span${_scopeId8}>₹ ${ssrInterpolate(this.formState.esi_amount)}</span>`);
                                                  } else {
                                                    return [
                                                      createVNode("span", null, "₹ " + toDisplayString(this.formState.esi_amount), 1)
                                                    ];
                                                  }
                                                }),
                                                _: 1
                                              }, _parent8, _scopeId7));
                                            } else {
                                              return [
                                                createVNode(_component_a_col, { flex: "auto" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_select, {
                                                      placeholder: "Select Salary Type",
                                                      onChange: ($event) => $options.calcCTC(),
                                                      value: $setup.formState.esi_detail,
                                                      "onUpdate:value": ($event) => $setup.formState.esi_detail = $event,
                                                      style: { "width": "100%" }
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_select_option, { value: "0" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("None")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_select_option, { value: "1" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("0.75%")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }, 8, ["onChange", "value", "onUpdate:value"])
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_col, {
                                                  flex: "80px",
                                                  style: { "text-align": "right" }
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode("span", null, "₹ " + toDisplayString(this.formState.esi_amount), 1)
                                                  ]),
                                                  _: 1
                                                })
                                              ];
                                            }
                                          }),
                                          _: 1
                                        }, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_a_row, { type: "flex" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_col, { flex: "auto" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select, {
                                                    placeholder: "Select Salary Type",
                                                    onChange: ($event) => $options.calcCTC(),
                                                    value: $setup.formState.esi_detail,
                                                    "onUpdate:value": ($event) => $setup.formState.esi_detail = $event,
                                                    style: { "width": "100%" }
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_select_option, { value: "0" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("None")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_select_option, { value: "1" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("0.75%")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }, 8, ["onChange", "value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, {
                                                flex: "80px",
                                                style: { "text-align": "right" }
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode("span", null, "₹ " + toDisplayString(this.formState.esi_amount), 1)
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ];
                                      }
                                    }),
                                    _: 1
                                  }, _parent6, _scopeId5));
                                  _push6(`</div>`);
                                } else {
                                  _push6(`<!---->`);
                                }
                                _push6(ssrRenderComponent(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`Save`);
                                          } else {
                                            return [
                                              createTextVNode("Save")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          "html-type": "submit"
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("Save")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_form_item, {
                                    label: "Salary Type",
                                    name: "salary_type",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        placeholder: "Select Salary Type",
                                        value: $setup.formState.salary_type,
                                        "onUpdate:value": ($event) => $setup.formState.salary_type = $event,
                                        onChange: ($event) => $options.calcCTC()
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "Month" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Per Month")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Day" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Per Day")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Hour" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Per Hour")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["value", "onUpdate:value", "onChange"])
                                    ]),
                                    _: 1
                                  }),
                                  $setup.formState.salary_type == "Day" ? (openBlock(), createBlock(_component_a_form_item, {
                                    key: 0,
                                    label: "Salary Amount",
                                    name: "salary_amount",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input_number, {
                                        prefix: "₹",
                                        "addon-after": "/ Day",
                                        style: { width: "100%" },
                                        value: $setup.formState.salary_amount,
                                        "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                        onKeyup: ($event) => $options.calcCTC()
                                      }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                    ]),
                                    _: 1
                                  })) : createCommentVNode("", true),
                                  $setup.formState.salary_type == "Hour" ? (openBlock(), createBlock(_component_a_form_item, {
                                    key: 1,
                                    label: "Salary Amount",
                                    name: "salary_amount",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input_number, {
                                        prefix: "₹",
                                        "addon-after": "/ Hour",
                                        style: { width: "100%" },
                                        value: $setup.formState.salary_amount,
                                        "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                        onKeyup: ($event) => $options.calcCTC()
                                      }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                    ]),
                                    _: 1
                                  })) : createCommentVNode("", true),
                                  $setup.formState.salary_type == "Month" ? (openBlock(), createBlock("div", { key: 2 }, [
                                    createVNode(_component_a_form_item, {
                                      label: "Basic",
                                      name: "salary_amount",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input_number, {
                                          prefix: "₹",
                                          style: { width: "100%" },
                                          value: $setup.formState.salary_amount,
                                          "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                          onKeyup: ($event) => $options.calcCTC()
                                        }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                      ]),
                                      _: 1
                                    }),
                                    (openBlock(true), createBlock(Fragment, null, renderList($setup.formState.allowances, (allowance, index) => {
                                      return openBlock(), createBlock(_component_a_form_item, {
                                        label: index,
                                        name: index
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_row, { type: "flex" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_col, { flex: "auto" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input_number, {
                                                    prefix: "₹",
                                                    style: { width: "100%" },
                                                    value: $setup.formState.allowances[index],
                                                    "onUpdate:value": ($event) => $setup.formState.allowances[index] = $event,
                                                    onKeyup: ($event) => $options.calcCTC()
                                                  }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                                ]),
                                                _: 2
                                              }, 1024),
                                              createVNode(_component_a_col, {
                                                flex: "80px",
                                                style: { "text-align": "right" }
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode("a", {
                                                    onClick: ($event) => $options.removeAllowance(index)
                                                  }, "Remove", 8, ["onClick"])
                                                ]),
                                                _: 2
                                              }, 1024)
                                            ]),
                                            _: 2
                                          }, 1024)
                                        ]),
                                        _: 2
                                      }, 1032, ["label", "name"]);
                                    }), 256)),
                                    createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_dropdown, { trigger: ["click"] }, {
                                          overlay: withCtx(() => [
                                            createVNode(_component_a_menu, null, {
                                              default: withCtx(() => [
                                                !("HRA" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "0" }, {
                                                  default: withCtx(() => [
                                                    createVNode("a", {
                                                      onClick: ($event) => $options.addAllowances("HRA")
                                                    }, "HRA", 8, ["onClick"])
                                                  ]),
                                                  _: 1
                                                })) : createCommentVNode("", true),
                                                !("Dearness Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "1" }, {
                                                  default: withCtx(() => [
                                                    createVNode("a", {
                                                      onClick: ($event) => $options.addAllowances("Dearness Allowance")
                                                    }, "Dearness Allowance", 8, ["onClick"])
                                                  ]),
                                                  _: 1
                                                })) : createCommentVNode("", true),
                                                !("Travel Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "2" }, {
                                                  default: withCtx(() => [
                                                    createVNode("a", {
                                                      onClick: ($event) => $options.addAllowances("Travel Allowance")
                                                    }, "Travel Allowance", 8, ["onClick"])
                                                  ]),
                                                  _: 1
                                                })) : createCommentVNode("", true),
                                                !("Meal Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "3" }, {
                                                  default: withCtx(() => [
                                                    createVNode("a", {
                                                      onClick: ($event) => $options.addAllowances("Meal Allowance")
                                                    }, "Meal Allowance", 8, ["onClick"])
                                                  ]),
                                                  _: 1
                                                })) : createCommentVNode("", true),
                                                !("Medical Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "4" }, {
                                                  default: withCtx(() => [
                                                    createVNode("a", {
                                                      onClick: ($event) => $options.addAllowances("Medical Allowance")
                                                    }, "Medical Allowance", 8, ["onClick"])
                                                  ]),
                                                  _: 1
                                                })) : createCommentVNode("", true),
                                                !("Special Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "5" }, {
                                                  default: withCtx(() => [
                                                    createVNode("a", {
                                                      onClick: ($event) => $options.addAllowances("Special Allowance")
                                                    }, "Special Allowance", 8, ["onClick"])
                                                  ]),
                                                  _: 1
                                                })) : createCommentVNode("", true)
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          default: withCtx(() => [
                                            createVNode("a", {
                                              class: "ant-dropdown-link",
                                              onClick: withModifiers(() => {
                                              }, ["prevent"])
                                            }, [
                                              createTextVNode(" + Add Allowance "),
                                              createVNode(_component_DownOutlined)
                                            ], 8, ["onClick"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_form_item, {
                                      label: "Employee PF",
                                      name: "pf_detail"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_row, { type: "flex" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_col, { flex: "auto" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select, {
                                                  placeholder: "Select Salary Type",
                                                  onChange: ($event) => $options.calcCTC(),
                                                  value: $setup.formState.pf_detail,
                                                  "onUpdate:value": ($event) => $setup.formState.pf_detail = $event,
                                                  style: { "width": "100%" }
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_select_option, { value: "0" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("None")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, { value: "1" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("1800 Limit")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, { value: "2" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("12%")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }, 8, ["onChange", "value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, {
                                              flex: "80px",
                                              style: { "text-align": "right" }
                                            }, {
                                              default: withCtx(() => [
                                                createVNode("span", null, "₹ " + toDisplayString(this.formState.pf_amount), 1)
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_form_item, {
                                      label: "Employee ESI",
                                      name: "esi_detail"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_row, { type: "flex" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_col, { flex: "auto" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select, {
                                                  placeholder: "Select Salary Type",
                                                  onChange: ($event) => $options.calcCTC(),
                                                  value: $setup.formState.esi_detail,
                                                  "onUpdate:value": ($event) => $setup.formState.esi_detail = $event,
                                                  style: { "width": "100%" }
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_select_option, { value: "0" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("None")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, { value: "1" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("0.75%")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }, 8, ["onChange", "value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, {
                                              flex: "80px",
                                              style: { "text-align": "right" }
                                            }, {
                                              default: withCtx(() => [
                                                createVNode("span", null, "₹ " + toDisplayString(this.formState.esi_amount), 1)
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ])) : createCommentVNode("", true),
                                  createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit"
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Save")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                              name: "nest-messages",
                              "validate-messages": $options.validateMessages,
                              onFinish: $options.submit
                            }), {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Salary Type",
                                  name: "salary_type",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      placeholder: "Select Salary Type",
                                      value: $setup.formState.salary_type,
                                      "onUpdate:value": ($event) => $setup.formState.salary_type = $event,
                                      onChange: ($event) => $options.calcCTC()
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, { value: "Month" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Per Month")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "Day" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Per Day")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "Hour" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Per Hour")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["value", "onUpdate:value", "onChange"])
                                  ]),
                                  _: 1
                                }),
                                $setup.formState.salary_type == "Day" ? (openBlock(), createBlock(_component_a_form_item, {
                                  key: 0,
                                  label: "Salary Amount",
                                  name: "salary_amount",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input_number, {
                                      prefix: "₹",
                                      "addon-after": "/ Day",
                                      style: { width: "100%" },
                                      value: $setup.formState.salary_amount,
                                      "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                      onKeyup: ($event) => $options.calcCTC()
                                    }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                  ]),
                                  _: 1
                                })) : createCommentVNode("", true),
                                $setup.formState.salary_type == "Hour" ? (openBlock(), createBlock(_component_a_form_item, {
                                  key: 1,
                                  label: "Salary Amount",
                                  name: "salary_amount",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input_number, {
                                      prefix: "₹",
                                      "addon-after": "/ Hour",
                                      style: { width: "100%" },
                                      value: $setup.formState.salary_amount,
                                      "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                      onKeyup: ($event) => $options.calcCTC()
                                    }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                  ]),
                                  _: 1
                                })) : createCommentVNode("", true),
                                $setup.formState.salary_type == "Month" ? (openBlock(), createBlock("div", { key: 2 }, [
                                  createVNode(_component_a_form_item, {
                                    label: "Basic",
                                    name: "salary_amount",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input_number, {
                                        prefix: "₹",
                                        style: { width: "100%" },
                                        value: $setup.formState.salary_amount,
                                        "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                        onKeyup: ($event) => $options.calcCTC()
                                      }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                    ]),
                                    _: 1
                                  }),
                                  (openBlock(true), createBlock(Fragment, null, renderList($setup.formState.allowances, (allowance, index) => {
                                    return openBlock(), createBlock(_component_a_form_item, {
                                      label: index,
                                      name: index
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_row, { type: "flex" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_col, { flex: "auto" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input_number, {
                                                  prefix: "₹",
                                                  style: { width: "100%" },
                                                  value: $setup.formState.allowances[index],
                                                  "onUpdate:value": ($event) => $setup.formState.allowances[index] = $event,
                                                  onKeyup: ($event) => $options.calcCTC()
                                                }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                              ]),
                                              _: 2
                                            }, 1024),
                                            createVNode(_component_a_col, {
                                              flex: "80px",
                                              style: { "text-align": "right" }
                                            }, {
                                              default: withCtx(() => [
                                                createVNode("a", {
                                                  onClick: ($event) => $options.removeAllowance(index)
                                                }, "Remove", 8, ["onClick"])
                                              ]),
                                              _: 2
                                            }, 1024)
                                          ]),
                                          _: 2
                                        }, 1024)
                                      ]),
                                      _: 2
                                    }, 1032, ["label", "name"]);
                                  }), 256)),
                                  createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_dropdown, { trigger: ["click"] }, {
                                        overlay: withCtx(() => [
                                          createVNode(_component_a_menu, null, {
                                            default: withCtx(() => [
                                              !("HRA" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "0" }, {
                                                default: withCtx(() => [
                                                  createVNode("a", {
                                                    onClick: ($event) => $options.addAllowances("HRA")
                                                  }, "HRA", 8, ["onClick"])
                                                ]),
                                                _: 1
                                              })) : createCommentVNode("", true),
                                              !("Dearness Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "1" }, {
                                                default: withCtx(() => [
                                                  createVNode("a", {
                                                    onClick: ($event) => $options.addAllowances("Dearness Allowance")
                                                  }, "Dearness Allowance", 8, ["onClick"])
                                                ]),
                                                _: 1
                                              })) : createCommentVNode("", true),
                                              !("Travel Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "2" }, {
                                                default: withCtx(() => [
                                                  createVNode("a", {
                                                    onClick: ($event) => $options.addAllowances("Travel Allowance")
                                                  }, "Travel Allowance", 8, ["onClick"])
                                                ]),
                                                _: 1
                                              })) : createCommentVNode("", true),
                                              !("Meal Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "3" }, {
                                                default: withCtx(() => [
                                                  createVNode("a", {
                                                    onClick: ($event) => $options.addAllowances("Meal Allowance")
                                                  }, "Meal Allowance", 8, ["onClick"])
                                                ]),
                                                _: 1
                                              })) : createCommentVNode("", true),
                                              !("Medical Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "4" }, {
                                                default: withCtx(() => [
                                                  createVNode("a", {
                                                    onClick: ($event) => $options.addAllowances("Medical Allowance")
                                                  }, "Medical Allowance", 8, ["onClick"])
                                                ]),
                                                _: 1
                                              })) : createCommentVNode("", true),
                                              !("Special Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "5" }, {
                                                default: withCtx(() => [
                                                  createVNode("a", {
                                                    onClick: ($event) => $options.addAllowances("Special Allowance")
                                                  }, "Special Allowance", 8, ["onClick"])
                                                ]),
                                                _: 1
                                              })) : createCommentVNode("", true)
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        default: withCtx(() => [
                                          createVNode("a", {
                                            class: "ant-dropdown-link",
                                            onClick: withModifiers(() => {
                                            }, ["prevent"])
                                          }, [
                                            createTextVNode(" + Add Allowance "),
                                            createVNode(_component_DownOutlined)
                                          ], 8, ["onClick"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Employee PF",
                                    name: "pf_detail"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_row, { type: "flex" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_col, { flex: "auto" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select, {
                                                placeholder: "Select Salary Type",
                                                onChange: ($event) => $options.calcCTC(),
                                                value: $setup.formState.pf_detail,
                                                "onUpdate:value": ($event) => $setup.formState.pf_detail = $event,
                                                style: { "width": "100%" }
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select_option, { value: "0" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("None")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, { value: "1" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("1800 Limit")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, { value: "2" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("12%")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }, 8, ["onChange", "value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, {
                                            flex: "80px",
                                            style: { "text-align": "right" }
                                          }, {
                                            default: withCtx(() => [
                                              createVNode("span", null, "₹ " + toDisplayString(this.formState.pf_amount), 1)
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Employee ESI",
                                    name: "esi_detail"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_row, { type: "flex" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_col, { flex: "auto" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select, {
                                                placeholder: "Select Salary Type",
                                                onChange: ($event) => $options.calcCTC(),
                                                value: $setup.formState.esi_detail,
                                                "onUpdate:value": ($event) => $setup.formState.esi_detail = $event,
                                                style: { "width": "100%" }
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select_option, { value: "0" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("None")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, { value: "1" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("0.75%")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }, 8, ["onChange", "value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, {
                                            flex: "80px",
                                            style: { "text-align": "right" }
                                          }, {
                                            default: withCtx(() => [
                                              createVNode("span", null, "₹ " + toDisplayString(this.formState.esi_amount), 1)
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ])) : createCommentVNode("", true),
                                createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      "html-type": "submit"
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Save")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 16, ["model", "validate-messages", "onFinish"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_col, {
                        span: 12,
                        offset: 5
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                            name: "nest-messages",
                            "validate-messages": $options.validateMessages,
                            onFinish: $options.submit
                          }), {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Salary Type",
                                name: "salary_type",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    placeholder: "Select Salary Type",
                                    value: $setup.formState.salary_type,
                                    "onUpdate:value": ($event) => $setup.formState.salary_type = $event,
                                    onChange: ($event) => $options.calcCTC()
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, { value: "Month" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Per Month")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "Day" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Per Day")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "Hour" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Per Hour")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["value", "onUpdate:value", "onChange"])
                                ]),
                                _: 1
                              }),
                              $setup.formState.salary_type == "Day" ? (openBlock(), createBlock(_component_a_form_item, {
                                key: 0,
                                label: "Salary Amount",
                                name: "salary_amount",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input_number, {
                                    prefix: "₹",
                                    "addon-after": "/ Day",
                                    style: { width: "100%" },
                                    value: $setup.formState.salary_amount,
                                    "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                    onKeyup: ($event) => $options.calcCTC()
                                  }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                ]),
                                _: 1
                              })) : createCommentVNode("", true),
                              $setup.formState.salary_type == "Hour" ? (openBlock(), createBlock(_component_a_form_item, {
                                key: 1,
                                label: "Salary Amount",
                                name: "salary_amount",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input_number, {
                                    prefix: "₹",
                                    "addon-after": "/ Hour",
                                    style: { width: "100%" },
                                    value: $setup.formState.salary_amount,
                                    "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                    onKeyup: ($event) => $options.calcCTC()
                                  }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                ]),
                                _: 1
                              })) : createCommentVNode("", true),
                              $setup.formState.salary_type == "Month" ? (openBlock(), createBlock("div", { key: 2 }, [
                                createVNode(_component_a_form_item, {
                                  label: "Basic",
                                  name: "salary_amount",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input_number, {
                                      prefix: "₹",
                                      style: { width: "100%" },
                                      value: $setup.formState.salary_amount,
                                      "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                      onKeyup: ($event) => $options.calcCTC()
                                    }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                  ]),
                                  _: 1
                                }),
                                (openBlock(true), createBlock(Fragment, null, renderList($setup.formState.allowances, (allowance, index) => {
                                  return openBlock(), createBlock(_component_a_form_item, {
                                    label: index,
                                    name: index
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_row, { type: "flex" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_col, { flex: "auto" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input_number, {
                                                prefix: "₹",
                                                style: { width: "100%" },
                                                value: $setup.formState.allowances[index],
                                                "onUpdate:value": ($event) => $setup.formState.allowances[index] = $event,
                                                onKeyup: ($event) => $options.calcCTC()
                                              }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                            ]),
                                            _: 2
                                          }, 1024),
                                          createVNode(_component_a_col, {
                                            flex: "80px",
                                            style: { "text-align": "right" }
                                          }, {
                                            default: withCtx(() => [
                                              createVNode("a", {
                                                onClick: ($event) => $options.removeAllowance(index)
                                              }, "Remove", 8, ["onClick"])
                                            ]),
                                            _: 2
                                          }, 1024)
                                        ]),
                                        _: 2
                                      }, 1024)
                                    ]),
                                    _: 2
                                  }, 1032, ["label", "name"]);
                                }), 256)),
                                createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_dropdown, { trigger: ["click"] }, {
                                      overlay: withCtx(() => [
                                        createVNode(_component_a_menu, null, {
                                          default: withCtx(() => [
                                            !("HRA" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "0" }, {
                                              default: withCtx(() => [
                                                createVNode("a", {
                                                  onClick: ($event) => $options.addAllowances("HRA")
                                                }, "HRA", 8, ["onClick"])
                                              ]),
                                              _: 1
                                            })) : createCommentVNode("", true),
                                            !("Dearness Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "1" }, {
                                              default: withCtx(() => [
                                                createVNode("a", {
                                                  onClick: ($event) => $options.addAllowances("Dearness Allowance")
                                                }, "Dearness Allowance", 8, ["onClick"])
                                              ]),
                                              _: 1
                                            })) : createCommentVNode("", true),
                                            !("Travel Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "2" }, {
                                              default: withCtx(() => [
                                                createVNode("a", {
                                                  onClick: ($event) => $options.addAllowances("Travel Allowance")
                                                }, "Travel Allowance", 8, ["onClick"])
                                              ]),
                                              _: 1
                                            })) : createCommentVNode("", true),
                                            !("Meal Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "3" }, {
                                              default: withCtx(() => [
                                                createVNode("a", {
                                                  onClick: ($event) => $options.addAllowances("Meal Allowance")
                                                }, "Meal Allowance", 8, ["onClick"])
                                              ]),
                                              _: 1
                                            })) : createCommentVNode("", true),
                                            !("Medical Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "4" }, {
                                              default: withCtx(() => [
                                                createVNode("a", {
                                                  onClick: ($event) => $options.addAllowances("Medical Allowance")
                                                }, "Medical Allowance", 8, ["onClick"])
                                              ]),
                                              _: 1
                                            })) : createCommentVNode("", true),
                                            !("Special Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "5" }, {
                                              default: withCtx(() => [
                                                createVNode("a", {
                                                  onClick: ($event) => $options.addAllowances("Special Allowance")
                                                }, "Special Allowance", 8, ["onClick"])
                                              ]),
                                              _: 1
                                            })) : createCommentVNode("", true)
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      default: withCtx(() => [
                                        createVNode("a", {
                                          class: "ant-dropdown-link",
                                          onClick: withModifiers(() => {
                                          }, ["prevent"])
                                        }, [
                                          createTextVNode(" + Add Allowance "),
                                          createVNode(_component_DownOutlined)
                                        ], 8, ["onClick"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Employee PF",
                                  name: "pf_detail"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_row, { type: "flex" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_col, { flex: "auto" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              placeholder: "Select Salary Type",
                                              onChange: ($event) => $options.calcCTC(),
                                              value: $setup.formState.pf_detail,
                                              "onUpdate:value": ($event) => $setup.formState.pf_detail = $event,
                                              style: { "width": "100%" }
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select_option, { value: "0" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("None")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_select_option, { value: "1" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("1800 Limit")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_select_option, { value: "2" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("12%")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }, 8, ["onChange", "value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          flex: "80px",
                                          style: { "text-align": "right" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode("span", null, "₹ " + toDisplayString(this.formState.pf_amount), 1)
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Employee ESI",
                                  name: "esi_detail"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_row, { type: "flex" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_col, { flex: "auto" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              placeholder: "Select Salary Type",
                                              onChange: ($event) => $options.calcCTC(),
                                              value: $setup.formState.esi_detail,
                                              "onUpdate:value": ($event) => $setup.formState.esi_detail = $event,
                                              style: { "width": "100%" }
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select_option, { value: "0" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("None")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_select_option, { value: "1" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("0.75%")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }, 8, ["onChange", "value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          flex: "80px",
                                          style: { "text-align": "right" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode("span", null, "₹ " + toDisplayString(this.formState.esi_amount), 1)
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ])) : createCommentVNode("", true),
                              createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Save")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 16, ["model", "validate-messages", "onFinish"])
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_a_col, {
                      span: 12,
                      offset: 5
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                          name: "nest-messages",
                          "validate-messages": $options.validateMessages,
                          onFinish: $options.submit
                        }), {
                          default: withCtx(() => [
                            createVNode(_component_a_form_item, {
                              label: "Salary Type",
                              name: "salary_type",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_select, {
                                  placeholder: "Select Salary Type",
                                  value: $setup.formState.salary_type,
                                  "onUpdate:value": ($event) => $setup.formState.salary_type = $event,
                                  onChange: ($event) => $options.calcCTC()
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select_option, { value: "Month" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Per Month")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Day" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Per Day")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Hour" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Per Hour")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["value", "onUpdate:value", "onChange"])
                              ]),
                              _: 1
                            }),
                            $setup.formState.salary_type == "Day" ? (openBlock(), createBlock(_component_a_form_item, {
                              key: 0,
                              label: "Salary Amount",
                              name: "salary_amount",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input_number, {
                                  prefix: "₹",
                                  "addon-after": "/ Day",
                                  style: { width: "100%" },
                                  value: $setup.formState.salary_amount,
                                  "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                  onKeyup: ($event) => $options.calcCTC()
                                }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                              ]),
                              _: 1
                            })) : createCommentVNode("", true),
                            $setup.formState.salary_type == "Hour" ? (openBlock(), createBlock(_component_a_form_item, {
                              key: 1,
                              label: "Salary Amount",
                              name: "salary_amount",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input_number, {
                                  prefix: "₹",
                                  "addon-after": "/ Hour",
                                  style: { width: "100%" },
                                  value: $setup.formState.salary_amount,
                                  "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                  onKeyup: ($event) => $options.calcCTC()
                                }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                              ]),
                              _: 1
                            })) : createCommentVNode("", true),
                            $setup.formState.salary_type == "Month" ? (openBlock(), createBlock("div", { key: 2 }, [
                              createVNode(_component_a_form_item, {
                                label: "Basic",
                                name: "salary_amount",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input_number, {
                                    prefix: "₹",
                                    style: { width: "100%" },
                                    value: $setup.formState.salary_amount,
                                    "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                    onKeyup: ($event) => $options.calcCTC()
                                  }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                ]),
                                _: 1
                              }),
                              (openBlock(true), createBlock(Fragment, null, renderList($setup.formState.allowances, (allowance, index) => {
                                return openBlock(), createBlock(_component_a_form_item, {
                                  label: index,
                                  name: index
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_row, { type: "flex" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_col, { flex: "auto" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input_number, {
                                              prefix: "₹",
                                              style: { width: "100%" },
                                              value: $setup.formState.allowances[index],
                                              "onUpdate:value": ($event) => $setup.formState.allowances[index] = $event,
                                              onKeyup: ($event) => $options.calcCTC()
                                            }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                          ]),
                                          _: 2
                                        }, 1024),
                                        createVNode(_component_a_col, {
                                          flex: "80px",
                                          style: { "text-align": "right" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode("a", {
                                              onClick: ($event) => $options.removeAllowance(index)
                                            }, "Remove", 8, ["onClick"])
                                          ]),
                                          _: 2
                                        }, 1024)
                                      ]),
                                      _: 2
                                    }, 1024)
                                  ]),
                                  _: 2
                                }, 1032, ["label", "name"]);
                              }), 256)),
                              createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_dropdown, { trigger: ["click"] }, {
                                    overlay: withCtx(() => [
                                      createVNode(_component_a_menu, null, {
                                        default: withCtx(() => [
                                          !("HRA" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "0" }, {
                                            default: withCtx(() => [
                                              createVNode("a", {
                                                onClick: ($event) => $options.addAllowances("HRA")
                                              }, "HRA", 8, ["onClick"])
                                            ]),
                                            _: 1
                                          })) : createCommentVNode("", true),
                                          !("Dearness Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "1" }, {
                                            default: withCtx(() => [
                                              createVNode("a", {
                                                onClick: ($event) => $options.addAllowances("Dearness Allowance")
                                              }, "Dearness Allowance", 8, ["onClick"])
                                            ]),
                                            _: 1
                                          })) : createCommentVNode("", true),
                                          !("Travel Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "2" }, {
                                            default: withCtx(() => [
                                              createVNode("a", {
                                                onClick: ($event) => $options.addAllowances("Travel Allowance")
                                              }, "Travel Allowance", 8, ["onClick"])
                                            ]),
                                            _: 1
                                          })) : createCommentVNode("", true),
                                          !("Meal Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "3" }, {
                                            default: withCtx(() => [
                                              createVNode("a", {
                                                onClick: ($event) => $options.addAllowances("Meal Allowance")
                                              }, "Meal Allowance", 8, ["onClick"])
                                            ]),
                                            _: 1
                                          })) : createCommentVNode("", true),
                                          !("Medical Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "4" }, {
                                            default: withCtx(() => [
                                              createVNode("a", {
                                                onClick: ($event) => $options.addAllowances("Medical Allowance")
                                              }, "Medical Allowance", 8, ["onClick"])
                                            ]),
                                            _: 1
                                          })) : createCommentVNode("", true),
                                          !("Special Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "5" }, {
                                            default: withCtx(() => [
                                              createVNode("a", {
                                                onClick: ($event) => $options.addAllowances("Special Allowance")
                                              }, "Special Allowance", 8, ["onClick"])
                                            ]),
                                            _: 1
                                          })) : createCommentVNode("", true)
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    default: withCtx(() => [
                                      createVNode("a", {
                                        class: "ant-dropdown-link",
                                        onClick: withModifiers(() => {
                                        }, ["prevent"])
                                      }, [
                                        createTextVNode(" + Add Allowance "),
                                        createVNode(_component_DownOutlined)
                                      ], 8, ["onClick"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Employee PF",
                                name: "pf_detail"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_row, { type: "flex" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, { flex: "auto" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            placeholder: "Select Salary Type",
                                            onChange: ($event) => $options.calcCTC(),
                                            value: $setup.formState.pf_detail,
                                            "onUpdate:value": ($event) => $setup.formState.pf_detail = $event,
                                            style: { "width": "100%" }
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select_option, { value: "0" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("None")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "1" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("1800 Limit")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "2" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("12%")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }, 8, ["onChange", "value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        flex: "80px",
                                        style: { "text-align": "right" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode("span", null, "₹ " + toDisplayString(this.formState.pf_amount), 1)
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Employee ESI",
                                name: "esi_detail"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_row, { type: "flex" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, { flex: "auto" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            placeholder: "Select Salary Type",
                                            onChange: ($event) => $options.calcCTC(),
                                            value: $setup.formState.esi_detail,
                                            "onUpdate:value": ($event) => $setup.formState.esi_detail = $event,
                                            style: { "width": "100%" }
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select_option, { value: "0" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("None")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "1" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("0.75%")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }, 8, ["onChange", "value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        flex: "80px",
                                        style: { "text-align": "right" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode("span", null, "₹ " + toDisplayString(this.formState.esi_amount), 1)
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ])) : createCommentVNode("", true),
                            createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Save")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 16, ["model", "validate-messages", "onFinish"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_drawer, {
          width: 600,
          title: "OT Settings",
          placement: "right",
          closable: true,
          visible: $data.otdrawer_visible,
          onClose: ($event) => $data.otdrawer_visible = false
        }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_form, mergeProps({ model: $setup.OtformState }, $setup.layout, {
                name: "nest-messages",
                "validate-messages": $options.validateMessages,
                onFinish: $options.OTsubmit
              }), {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Week off Pay",
                      labelCol: { span: 8 },
                      name: "weekoff_pay",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_input, {
                            value: $setup.OtformState.weekoff_pay,
                            "onUpdate:value": ($event) => $setup.OtformState.weekoff_pay = $event,
                            prefix: "₹"
                          }, null, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_input, {
                              value: $setup.OtformState.weekoff_pay,
                              "onUpdate:value": ($event) => $setup.OtformState.weekoff_pay = $event,
                              prefix: "₹"
                            }, null, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Public Holiday Pay",
                      labelCol: { span: 8 },
                      name: "publicholiday_pay",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_input, {
                            value: $setup.OtformState.publicholiday_pay,
                            "onUpdate:value": ($event) => $setup.OtformState.publicholiday_pay = $event,
                            prefix: "₹"
                          }, null, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_input, {
                              value: $setup.OtformState.publicholiday_pay,
                              "onUpdate:value": ($event) => $setup.OtformState.publicholiday_pay = $event,
                              prefix: "₹"
                            }, null, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Extra Hours Pay",
                      labelCol: { span: 8 },
                      name: "extra_hours_pay",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_input, {
                            value: $setup.OtformState.extra_hours_pay,
                            "onUpdate:value": ($event) => $setup.OtformState.extra_hours_pay = $event,
                            prefix: "₹"
                          }, null, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_input, {
                              value: $setup.OtformState.extra_hours_pay,
                              "onUpdate:value": ($event) => $setup.OtformState.extra_hours_pay = $event,
                              prefix: "₹"
                            }, null, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Grace Period",
                      name: "grace_period",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_input, {
                            value: $setup.OtformState.grace_period,
                            "onUpdate:value": ($event) => $setup.OtformState.grace_period = $event,
                            "addon-after": "Minutes"
                          }, null, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_input, {
                              value: $setup.OtformState.grace_period,
                              "onUpdate:value": ($event) => $setup.OtformState.grace_period = $event,
                              "addon-after": "Minutes"
                            }, null, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Save`);
                              } else {
                                return [
                                  createTextVNode("Save")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Save")
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(`s `);
                  } else {
                    return [
                      createVNode(_component_a_form_item, {
                        label: "Week off Pay",
                        labelCol: { span: 8 },
                        name: "weekoff_pay",
                        rules: [{ required: true }]
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            value: $setup.OtformState.weekoff_pay,
                            "onUpdate:value": ($event) => $setup.OtformState.weekoff_pay = $event,
                            prefix: "₹"
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, {
                        label: "Public Holiday Pay",
                        labelCol: { span: 8 },
                        name: "publicholiday_pay",
                        rules: [{ required: true }]
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            value: $setup.OtformState.publicholiday_pay,
                            "onUpdate:value": ($event) => $setup.OtformState.publicholiday_pay = $event,
                            prefix: "₹"
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, {
                        label: "Extra Hours Pay",
                        labelCol: { span: 8 },
                        name: "extra_hours_pay",
                        rules: [{ required: true }]
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            value: $setup.OtformState.extra_hours_pay,
                            "onUpdate:value": ($event) => $setup.OtformState.extra_hours_pay = $event,
                            prefix: "₹"
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, {
                        label: "Grace Period",
                        name: "grace_period",
                        rules: [{ required: true }]
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            value: $setup.OtformState.grace_period,
                            "onUpdate:value": ($event) => $setup.OtformState.grace_period = $event,
                            "addon-after": "Minutes"
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Save")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createTextVNode("s ")
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_form, mergeProps({ model: $setup.OtformState }, $setup.layout, {
                  name: "nest-messages",
                  "validate-messages": $options.validateMessages,
                  onFinish: $options.OTsubmit
                }), {
                  default: withCtx(() => [
                    createVNode(_component_a_form_item, {
                      label: "Week off Pay",
                      labelCol: { span: 8 },
                      name: "weekoff_pay",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_input, {
                          value: $setup.OtformState.weekoff_pay,
                          "onUpdate:value": ($event) => $setup.OtformState.weekoff_pay = $event,
                          prefix: "₹"
                        }, null, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, {
                      label: "Public Holiday Pay",
                      labelCol: { span: 8 },
                      name: "publicholiday_pay",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_input, {
                          value: $setup.OtformState.publicholiday_pay,
                          "onUpdate:value": ($event) => $setup.OtformState.publicholiday_pay = $event,
                          prefix: "₹"
                        }, null, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, {
                      label: "Extra Hours Pay",
                      labelCol: { span: 8 },
                      name: "extra_hours_pay",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_input, {
                          value: $setup.OtformState.extra_hours_pay,
                          "onUpdate:value": ($event) => $setup.OtformState.extra_hours_pay = $event,
                          prefix: "₹"
                        }, null, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, {
                      label: "Grace Period",
                      name: "grace_period",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_input, {
                          value: $setup.OtformState.grace_period,
                          "onUpdate:value": ($event) => $setup.OtformState.grace_period = $event,
                          "addon-after": "Minutes"
                        }, null, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                      default: withCtx(() => [
                        createVNode(_component_a_button, {
                          type: "primary",
                          "html-type": "submit"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Save")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createTextVNode("s ")
                  ]),
                  _: 1
                }, 16, ["model", "validate-messages", "onFinish"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_drawer, {
          width: 600,
          title: "Late Penalty Settings",
          placement: "right",
          closable: true,
          visible: $data.latedrawer_visible,
          onClose: ($event) => $data.latedrawer_visible = false
        }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_form, mergeProps({ model: $setup.LateformState }, $setup.layout, {
                name: "nest-messages",
                "validate-messages": $options.validateMessages,
                onFinish: $options.lateSubmit
              }), {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Allowed Days",
                      labelCol: { span: 8 },
                      name: "allowed_days",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_input_number, {
                            value: $setup.LateformState.allowed_days,
                            "onUpdate:value": ($event) => $setup.LateformState.allowed_days = $event
                          }, null, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_input_number, {
                              value: $setup.LateformState.allowed_days,
                              "onUpdate:value": ($event) => $setup.LateformState.allowed_days = $event
                            }, null, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Grace Period",
                      name: "grace_period",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_input, {
                            value: $setup.LateformState.grace_period,
                            "onUpdate:value": ($event) => $setup.LateformState.grace_period = $event,
                            "addon-after": "Minutes"
                          }, null, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_input, {
                              value: $setup.LateformState.grace_period,
                              "onUpdate:value": ($event) => $setup.LateformState.grace_period = $event,
                              "addon-after": "Minutes"
                            }, null, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Deduction Type",
                      name: "deduction_type",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_radio_group, {
                            value: $setup.LateformState.deduction_type,
                            "onUpdate:value": ($event) => $setup.LateformState.deduction_type = $event,
                            name: "deduction_type"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_radio, { value: "Day" }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`Day`);
                                    } else {
                                      return [
                                        createTextVNode("Day")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_radio, { value: "Hour" }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`Hour`);
                                    } else {
                                      return [
                                        createTextVNode("Hour")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_radio, { value: "Day" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Day")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_radio, { value: "Hour" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Hour")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_radio_group, {
                              value: $setup.LateformState.deduction_type,
                              "onUpdate:value": ($event) => $setup.LateformState.deduction_type = $event,
                              name: "deduction_type"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_radio, { value: "Day" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Day")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_radio, { value: "Hour" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Hour")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Deductin Rate",
                      labelCol: { span: 8 },
                      name: "deduction_rate",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_input_number, {
                            value: $setup.LateformState.deduction_rate,
                            "onUpdate:value": ($event) => $setup.LateformState.deduction_rate = $event,
                            prefix: "₹"
                          }, null, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_input_number, {
                              value: $setup.LateformState.deduction_rate,
                              "onUpdate:value": ($event) => $setup.LateformState.deduction_rate = $event,
                              prefix: "₹"
                            }, null, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Save`);
                              } else {
                                return [
                                  createTextVNode("Save")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Save")
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(`s `);
                  } else {
                    return [
                      createVNode(_component_a_form_item, {
                        label: "Allowed Days",
                        labelCol: { span: 8 },
                        name: "allowed_days",
                        rules: [{ required: true }]
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input_number, {
                            value: $setup.LateformState.allowed_days,
                            "onUpdate:value": ($event) => $setup.LateformState.allowed_days = $event
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, {
                        label: "Grace Period",
                        name: "grace_period",
                        rules: [{ required: true }]
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            value: $setup.LateformState.grace_period,
                            "onUpdate:value": ($event) => $setup.LateformState.grace_period = $event,
                            "addon-after": "Minutes"
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, {
                        label: "Deduction Type",
                        name: "deduction_type",
                        rules: [{ required: true }]
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_radio_group, {
                            value: $setup.LateformState.deduction_type,
                            "onUpdate:value": ($event) => $setup.LateformState.deduction_type = $event,
                            name: "deduction_type"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_radio, { value: "Day" }, {
                                default: withCtx(() => [
                                  createTextVNode("Day")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_radio, { value: "Hour" }, {
                                default: withCtx(() => [
                                  createTextVNode("Hour")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, {
                        label: "Deductin Rate",
                        labelCol: { span: 8 },
                        name: "deduction_rate",
                        rules: [{ required: true }]
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input_number, {
                            value: $setup.LateformState.deduction_rate,
                            "onUpdate:value": ($event) => $setup.LateformState.deduction_rate = $event,
                            prefix: "₹"
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Save")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createTextVNode("s ")
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_form, mergeProps({ model: $setup.LateformState }, $setup.layout, {
                  name: "nest-messages",
                  "validate-messages": $options.validateMessages,
                  onFinish: $options.lateSubmit
                }), {
                  default: withCtx(() => [
                    createVNode(_component_a_form_item, {
                      label: "Allowed Days",
                      labelCol: { span: 8 },
                      name: "allowed_days",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_input_number, {
                          value: $setup.LateformState.allowed_days,
                          "onUpdate:value": ($event) => $setup.LateformState.allowed_days = $event
                        }, null, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, {
                      label: "Grace Period",
                      name: "grace_period",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_input, {
                          value: $setup.LateformState.grace_period,
                          "onUpdate:value": ($event) => $setup.LateformState.grace_period = $event,
                          "addon-after": "Minutes"
                        }, null, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, {
                      label: "Deduction Type",
                      name: "deduction_type",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_radio_group, {
                          value: $setup.LateformState.deduction_type,
                          "onUpdate:value": ($event) => $setup.LateformState.deduction_type = $event,
                          name: "deduction_type"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_radio, { value: "Day" }, {
                              default: withCtx(() => [
                                createTextVNode("Day")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_radio, { value: "Hour" }, {
                              default: withCtx(() => [
                                createTextVNode("Hour")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, {
                      label: "Deductin Rate",
                      labelCol: { span: 8 },
                      name: "deduction_rate",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_input_number, {
                          value: $setup.LateformState.deduction_rate,
                          "onUpdate:value": ($event) => $setup.LateformState.deduction_rate = $event,
                          prefix: "₹"
                        }, null, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                      default: withCtx(() => [
                        createVNode(_component_a_button, {
                          type: "primary",
                          "html-type": "submit"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Save")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createTextVNode("s ")
                  ]),
                  _: 1
                }, 16, ["model", "validate-messages", "onFinish"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_affix, { "offset-top": 0 }, {
            default: withCtx(() => [
              createVNode(_component_a_page_header, {
                ghost: false,
                title: $props.employee.name + " Salary Info",
                onBack: () => _ctx.$inertia.visit(_ctx.route("employees.index"))
              }, {
                extra: withCtx(() => [
                  createVNode("h4", null, [
                    createTextVNode("Total CTC: "),
                    createVNode("span", { class: "currency" }, "₹"),
                    createTextVNode(" " + toDisplayString(this.formState.ctc), 1)
                  ]),
                  createVNode(_component_a_button, {
                    key: "1",
                    type: "primary",
                    onClick: withModifiers(() => {
                      $data.otdrawer_visible = true;
                    }, ["stop"])
                  }, {
                    default: withCtx(() => [
                      createTextVNode("OT settings")
                    ]),
                    _: 1
                  }, 8, ["onClick"]),
                  createVNode(_component_a_button, {
                    key: "1",
                    type: "primary",
                    onClick: withModifiers(() => {
                      $data.latedrawer_visible = true;
                    }, ["stop"])
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Late Penalty Settings")
                    ]),
                    _: 1
                  }, 8, ["onClick"])
                ]),
                _: 1
              }, 8, ["title", "onBack"])
            ]),
            _: 1
          }),
          createVNode(_component_a_layout_content, null, {
            default: withCtx(() => [
              createVNode(_component_a_row, null, {
                default: withCtx(() => [
                  createVNode(_component_a_col, {
                    span: 12,
                    offset: 5
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                        name: "nest-messages",
                        "validate-messages": $options.validateMessages,
                        onFinish: $options.submit
                      }), {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, {
                            label: "Salary Type",
                            name: "salary_type",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_select, {
                                placeholder: "Select Salary Type",
                                value: $setup.formState.salary_type,
                                "onUpdate:value": ($event) => $setup.formState.salary_type = $event,
                                onChange: ($event) => $options.calcCTC()
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select_option, { value: "Month" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Per Month")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Day" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Per Day")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Hour" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Per Hour")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["value", "onUpdate:value", "onChange"])
                            ]),
                            _: 1
                          }),
                          $setup.formState.salary_type == "Day" ? (openBlock(), createBlock(_component_a_form_item, {
                            key: 0,
                            label: "Salary Amount",
                            name: "salary_amount",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input_number, {
                                prefix: "₹",
                                "addon-after": "/ Day",
                                style: { width: "100%" },
                                value: $setup.formState.salary_amount,
                                "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                onKeyup: ($event) => $options.calcCTC()
                              }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                            ]),
                            _: 1
                          })) : createCommentVNode("", true),
                          $setup.formState.salary_type == "Hour" ? (openBlock(), createBlock(_component_a_form_item, {
                            key: 1,
                            label: "Salary Amount",
                            name: "salary_amount",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input_number, {
                                prefix: "₹",
                                "addon-after": "/ Hour",
                                style: { width: "100%" },
                                value: $setup.formState.salary_amount,
                                "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                onKeyup: ($event) => $options.calcCTC()
                              }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                            ]),
                            _: 1
                          })) : createCommentVNode("", true),
                          $setup.formState.salary_type == "Month" ? (openBlock(), createBlock("div", { key: 2 }, [
                            createVNode(_component_a_form_item, {
                              label: "Basic",
                              name: "salary_amount",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input_number, {
                                  prefix: "₹",
                                  style: { width: "100%" },
                                  value: $setup.formState.salary_amount,
                                  "onUpdate:value": ($event) => $setup.formState.salary_amount = $event,
                                  onKeyup: ($event) => $options.calcCTC()
                                }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                              ]),
                              _: 1
                            }),
                            (openBlock(true), createBlock(Fragment, null, renderList($setup.formState.allowances, (allowance, index) => {
                              return openBlock(), createBlock(_component_a_form_item, {
                                label: index,
                                name: index
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_row, { type: "flex" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, { flex: "auto" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input_number, {
                                            prefix: "₹",
                                            style: { width: "100%" },
                                            value: $setup.formState.allowances[index],
                                            "onUpdate:value": ($event) => $setup.formState.allowances[index] = $event,
                                            onKeyup: ($event) => $options.calcCTC()
                                          }, null, 8, ["value", "onUpdate:value", "onKeyup"])
                                        ]),
                                        _: 2
                                      }, 1024),
                                      createVNode(_component_a_col, {
                                        flex: "80px",
                                        style: { "text-align": "right" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode("a", {
                                            onClick: ($event) => $options.removeAllowance(index)
                                          }, "Remove", 8, ["onClick"])
                                        ]),
                                        _: 2
                                      }, 1024)
                                    ]),
                                    _: 2
                                  }, 1024)
                                ]),
                                _: 2
                              }, 1032, ["label", "name"]);
                            }), 256)),
                            createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_dropdown, { trigger: ["click"] }, {
                                  overlay: withCtx(() => [
                                    createVNode(_component_a_menu, null, {
                                      default: withCtx(() => [
                                        !("HRA" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "0" }, {
                                          default: withCtx(() => [
                                            createVNode("a", {
                                              onClick: ($event) => $options.addAllowances("HRA")
                                            }, "HRA", 8, ["onClick"])
                                          ]),
                                          _: 1
                                        })) : createCommentVNode("", true),
                                        !("Dearness Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "1" }, {
                                          default: withCtx(() => [
                                            createVNode("a", {
                                              onClick: ($event) => $options.addAllowances("Dearness Allowance")
                                            }, "Dearness Allowance", 8, ["onClick"])
                                          ]),
                                          _: 1
                                        })) : createCommentVNode("", true),
                                        !("Travel Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "2" }, {
                                          default: withCtx(() => [
                                            createVNode("a", {
                                              onClick: ($event) => $options.addAllowances("Travel Allowance")
                                            }, "Travel Allowance", 8, ["onClick"])
                                          ]),
                                          _: 1
                                        })) : createCommentVNode("", true),
                                        !("Meal Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "3" }, {
                                          default: withCtx(() => [
                                            createVNode("a", {
                                              onClick: ($event) => $options.addAllowances("Meal Allowance")
                                            }, "Meal Allowance", 8, ["onClick"])
                                          ]),
                                          _: 1
                                        })) : createCommentVNode("", true),
                                        !("Medical Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "4" }, {
                                          default: withCtx(() => [
                                            createVNode("a", {
                                              onClick: ($event) => $options.addAllowances("Medical Allowance")
                                            }, "Medical Allowance", 8, ["onClick"])
                                          ]),
                                          _: 1
                                        })) : createCommentVNode("", true),
                                        !("Special Allowance" in $setup.formState.allowances) ? (openBlock(), createBlock(_component_a_menu_item, { key: "5" }, {
                                          default: withCtx(() => [
                                            createVNode("a", {
                                              onClick: ($event) => $options.addAllowances("Special Allowance")
                                            }, "Special Allowance", 8, ["onClick"])
                                          ]),
                                          _: 1
                                        })) : createCommentVNode("", true)
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  default: withCtx(() => [
                                    createVNode("a", {
                                      class: "ant-dropdown-link",
                                      onClick: withModifiers(() => {
                                      }, ["prevent"])
                                    }, [
                                      createTextVNode(" + Add Allowance "),
                                      createVNode(_component_DownOutlined)
                                    ], 8, ["onClick"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Employee PF",
                              name: "pf_detail"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_row, { type: "flex" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { flex: "auto" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          placeholder: "Select Salary Type",
                                          onChange: ($event) => $options.calcCTC(),
                                          value: $setup.formState.pf_detail,
                                          "onUpdate:value": ($event) => $setup.formState.pf_detail = $event,
                                          style: { "width": "100%" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "0" }, {
                                              default: withCtx(() => [
                                                createTextVNode("None")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "1" }, {
                                              default: withCtx(() => [
                                                createTextVNode("1800 Limit")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "2" }, {
                                              default: withCtx(() => [
                                                createTextVNode("12%")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["onChange", "value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      flex: "80px",
                                      style: { "text-align": "right" }
                                    }, {
                                      default: withCtx(() => [
                                        createVNode("span", null, "₹ " + toDisplayString(this.formState.pf_amount), 1)
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Employee ESI",
                              name: "esi_detail"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_row, { type: "flex" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { flex: "auto" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          placeholder: "Select Salary Type",
                                          onChange: ($event) => $options.calcCTC(),
                                          value: $setup.formState.esi_detail,
                                          "onUpdate:value": ($event) => $setup.formState.esi_detail = $event,
                                          style: { "width": "100%" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "0" }, {
                                              default: withCtx(() => [
                                                createTextVNode("None")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "1" }, {
                                              default: withCtx(() => [
                                                createTextVNode("0.75%")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["onChange", "value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      flex: "80px",
                                      style: { "text-align": "right" }
                                    }, {
                                      default: withCtx(() => [
                                        createVNode("span", null, "₹ " + toDisplayString(this.formState.esi_amount), 1)
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ])) : createCommentVNode("", true),
                          createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Save")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 16, ["model", "validate-messages", "onFinish"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_a_drawer, {
            width: 600,
            title: "OT Settings",
            placement: "right",
            closable: true,
            visible: $data.otdrawer_visible,
            onClose: ($event) => $data.otdrawer_visible = false
          }, {
            default: withCtx(() => [
              createVNode(_component_a_form, mergeProps({ model: $setup.OtformState }, $setup.layout, {
                name: "nest-messages",
                "validate-messages": $options.validateMessages,
                onFinish: $options.OTsubmit
              }), {
                default: withCtx(() => [
                  createVNode(_component_a_form_item, {
                    label: "Week off Pay",
                    labelCol: { span: 8 },
                    name: "weekoff_pay",
                    rules: [{ required: true }]
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_input, {
                        value: $setup.OtformState.weekoff_pay,
                        "onUpdate:value": ($event) => $setup.OtformState.weekoff_pay = $event,
                        prefix: "₹"
                      }, null, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, {
                    label: "Public Holiday Pay",
                    labelCol: { span: 8 },
                    name: "publicholiday_pay",
                    rules: [{ required: true }]
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_input, {
                        value: $setup.OtformState.publicholiday_pay,
                        "onUpdate:value": ($event) => $setup.OtformState.publicholiday_pay = $event,
                        prefix: "₹"
                      }, null, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, {
                    label: "Extra Hours Pay",
                    labelCol: { span: 8 },
                    name: "extra_hours_pay",
                    rules: [{ required: true }]
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_input, {
                        value: $setup.OtformState.extra_hours_pay,
                        "onUpdate:value": ($event) => $setup.OtformState.extra_hours_pay = $event,
                        prefix: "₹"
                      }, null, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, {
                    label: "Grace Period",
                    name: "grace_period",
                    rules: [{ required: true }]
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_input, {
                        value: $setup.OtformState.grace_period,
                        "onUpdate:value": ($event) => $setup.OtformState.grace_period = $event,
                        "addon-after": "Minutes"
                      }, null, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                    default: withCtx(() => [
                      createVNode(_component_a_button, {
                        type: "primary",
                        "html-type": "submit"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Save")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createTextVNode("s ")
                ]),
                _: 1
              }, 16, ["model", "validate-messages", "onFinish"])
            ]),
            _: 1
          }, 8, ["visible", "onClose"]),
          createVNode(_component_a_drawer, {
            width: 600,
            title: "Late Penalty Settings",
            placement: "right",
            closable: true,
            visible: $data.latedrawer_visible,
            onClose: ($event) => $data.latedrawer_visible = false
          }, {
            default: withCtx(() => [
              createVNode(_component_a_form, mergeProps({ model: $setup.LateformState }, $setup.layout, {
                name: "nest-messages",
                "validate-messages": $options.validateMessages,
                onFinish: $options.lateSubmit
              }), {
                default: withCtx(() => [
                  createVNode(_component_a_form_item, {
                    label: "Allowed Days",
                    labelCol: { span: 8 },
                    name: "allowed_days",
                    rules: [{ required: true }]
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_input_number, {
                        value: $setup.LateformState.allowed_days,
                        "onUpdate:value": ($event) => $setup.LateformState.allowed_days = $event
                      }, null, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, {
                    label: "Grace Period",
                    name: "grace_period",
                    rules: [{ required: true }]
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_input, {
                        value: $setup.LateformState.grace_period,
                        "onUpdate:value": ($event) => $setup.LateformState.grace_period = $event,
                        "addon-after": "Minutes"
                      }, null, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, {
                    label: "Deduction Type",
                    name: "deduction_type",
                    rules: [{ required: true }]
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_radio_group, {
                        value: $setup.LateformState.deduction_type,
                        "onUpdate:value": ($event) => $setup.LateformState.deduction_type = $event,
                        name: "deduction_type"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_radio, { value: "Day" }, {
                            default: withCtx(() => [
                              createTextVNode("Day")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_radio, { value: "Hour" }, {
                            default: withCtx(() => [
                              createTextVNode("Hour")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, {
                    label: "Deductin Rate",
                    labelCol: { span: 8 },
                    name: "deduction_rate",
                    rules: [{ required: true }]
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_input_number, {
                        value: $setup.LateformState.deduction_rate,
                        "onUpdate:value": ($event) => $setup.LateformState.deduction_rate = $event,
                        prefix: "₹"
                      }, null, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                    default: withCtx(() => [
                      createVNode(_component_a_button, {
                        type: "primary",
                        "html-type": "submit"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Save")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createTextVNode("s ")
                ]),
                _: 1
              }, 16, ["model", "validate-messages", "onFinish"])
            ]),
            _: 1
          }, 8, ["visible", "onClose"])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Employees/SalaryDetails.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const SalaryDetails = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  SalaryDetails as default
};
