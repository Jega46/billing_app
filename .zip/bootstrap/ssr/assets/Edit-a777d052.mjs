import { defineComponent, ref, resolveComponent, withCtx, createTextVNode, createVNode, mergeProps, useSSRContext } from "vue";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import { Head, useForm } from "@inertiajs/vue3";
import "dayjs";
import { ssrRenderComponent } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
import "@ant-design/icons-vue";
const _sfc_main = defineComponent({
  inject: ["validateMessages"],
  components: {
    AuthenticatedLayout: _sfc_main$1,
    Head
  },
  props: {
    expensetype: Object
  },
  setup(props) {
    const visible = ref(false);
    const showModal = () => {
      visible.value = true;
    };
    const handleOk = (e) => {
      console.log(e);
      visible.value = false;
    };
    const handleCancel = () => {
      visible.value = false;
    };
    const layout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 16 }
    };
    const formState = useForm({
      name: props.expensetype.name,
      expensetype: props.expensetype.expensetype,
      amount: props.expensetype.amount,
      method: props.expensetype.method,
      date: props.expensetype.date,
      description: props.expensetype.description
    });
    return {
      formState,
      layout,
      visible,
      showModal,
      handleOk,
      handleCancel
    };
  },
  mounted() {
  },
  methods: {
    triggerSubmit() {
      const btn = this.$refs.submitss;
      console.log(btn);
      btn.click();
    },
    submit() {
      this.formState.put(route("expensetype.update", this.expensetype.id));
    }
  }
});
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_affix = resolveComponent("a-affix");
  const _component_a_page_header = resolveComponent("a-page-header");
  const _component_a_button = resolveComponent("a-button");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_input = resolveComponent("a-input");
  const _component_user_outlined = resolveComponent("user-outlined");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_select_option = resolveComponent("a-select-option");
  const _component_a_date_picker = resolveComponent("a-date-picker");
  const _component_a_textarea = resolveComponent("a-textarea");
  const _component_a_modal = resolveComponent("a-modal");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Employees" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_affix, { "offset-top": 0 }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_page_header, {
                ghost: false,
                title: _ctx.expensetype.name,
                onBack: () => _ctx.$inertia.visit(_ctx.route("expensetype.index"))
              }, {
                extra: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_button, {
                      key: "1",
                      type: "primary",
                      onClick: ($event) => _ctx.triggerSubmit()
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`Save`);
                        } else {
                          return [
                            createTextVNode("Save")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_button, {
                        key: "1",
                        type: "primary",
                        onClick: ($event) => _ctx.triggerSubmit()
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Save")
                        ]),
                        _: 1
                      }, 8, ["onClick"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_page_header, {
                  ghost: false,
                  title: _ctx.expensetype.name,
                  onBack: () => _ctx.$inertia.visit(_ctx.route("expensetype.index"))
                }, {
                  extra: withCtx(() => [
                    createVNode(_component_a_button, {
                      key: "1",
                      type: "primary",
                      onClick: ($event) => _ctx.triggerSubmit()
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Save")
                      ]),
                      _: 1
                    }, 8, ["onClick"])
                  ]),
                  _: 1
                }, 8, ["title", "onBack"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_layout_content, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_row, null, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_col, {
                      span: 12,
                      offset: 6
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                            name: "nest-messages",
                            "validate-messages": _ctx.validateMessages,
                            onFinish: _ctx.submit
                          }), {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Name",
                                  name: "name",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: _ctx.formState.name,
                                        "onUpdate:value": ($event) => _ctx.formState.name = $event
                                      }, {
                                        prefix: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_user_outlined, { type: "user" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_user_outlined, { type: "user" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: _ctx.formState.name,
                                          "onUpdate:value": ($event) => _ctx.formState.name = $event
                                        }, {
                                          prefix: withCtx(() => [
                                            createVNode(_component_user_outlined, { type: "user" })
                                          ]),
                                          _: 1
                                        }, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Expense Type",
                                  name: "expensetype",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_select, {
                                        value: _ctx.formState.expensetype,
                                        "onUpdate:value": ($event) => _ctx.formState.expensetype = $event
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Utility expenses" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Utility expenses`);
                                                } else {
                                                  return [
                                                    createTextVNode("Utility expenses")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Administration expenses" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Administration expenses`);
                                                } else {
                                                  return [
                                                    createTextVNode("Administration expenses")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "IT and Internet Expense" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`IT and Internet Expense`);
                                                } else {
                                                  return [
                                                    createTextVNode("IT and Internet Expense")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Office Supplies" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Office Supplies`);
                                                } else {
                                                  return [
                                                    createTextVNode("Office Supplies")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Office Supplies" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Health Care`);
                                                } else {
                                                  return [
                                                    createTextVNode("Health Care")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, {
                                              value: "undefined",
                                              disabled: ""
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_button, {
                                                    type: "primary",
                                                    onClick: _ctx.showModal
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(`Add More`);
                                                      } else {
                                                        return [
                                                          createTextVNode("Add More")
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_button, {
                                                      type: "primary",
                                                      onClick: _ctx.showModal
                                                    }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Add More")
                                                      ]),
                                                      _: 1
                                                    }, 8, ["onClick"])
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select_option, { value: "Utility expenses" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Utility expenses")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Administration expenses" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Administration expenses")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "IT and Internet Expense" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("IT and Internet Expense")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Office Supplies" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Office Supplies")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Office Supplies" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Health Care")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, {
                                                value: "undefined",
                                                disabled: ""
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_button, {
                                                    type: "primary",
                                                    onClick: _ctx.showModal
                                                  }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Add More")
                                                    ]),
                                                    _: 1
                                                  }, 8, ["onClick"])
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_select, {
                                          value: _ctx.formState.expensetype,
                                          "onUpdate:value": ($event) => _ctx.formState.expensetype = $event
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "Utility expenses" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Utility expenses")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Administration expenses" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Administration expenses")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "IT and Internet Expense" }, {
                                              default: withCtx(() => [
                                                createTextVNode("IT and Internet Expense")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Office Supplies" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Office Supplies")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Office Supplies" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Health Care")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, {
                                              value: "undefined",
                                              disabled: ""
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_button, {
                                                  type: "primary",
                                                  onClick: _ctx.showModal
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Add More")
                                                  ]),
                                                  _: 1
                                                }, 8, ["onClick"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Amount",
                                  name: "amount",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: _ctx.formState.amount,
                                        "onUpdate:value": ($event) => _ctx.formState.amount = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: _ctx.formState.amount,
                                          "onUpdate:value": ($event) => _ctx.formState.amount = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Method",
                                  name: "method",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_select, {
                                        value: _ctx.formState.method,
                                        "onUpdate:value": ($event) => _ctx.formState.method = $event
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Bank Transfer" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Bank Transfer`);
                                                } else {
                                                  return [
                                                    createTextVNode("Bank Transfer")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Cash Payment" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Cash Payment`);
                                                } else {
                                                  return [
                                                    createTextVNode("Cash Payment")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Cheque Payment" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Cheque Payment`);
                                                } else {
                                                  return [
                                                    createTextVNode("Cheque Payment")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Online Payments" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Online Payments`);
                                                } else {
                                                  return [
                                                    createTextVNode("Online Payments")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select_option, { value: "Bank Transfer" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Bank Transfer")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Cash Payment" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Cash Payment")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Cheque Payment" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Cheque Payment")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Online Payments" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Online Payments")
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_select, {
                                          value: _ctx.formState.method,
                                          "onUpdate:value": ($event) => _ctx.formState.method = $event
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "Bank Transfer" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Bank Transfer")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Cash Payment" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Cash Payment")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Cheque Payment" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Cheque Payment")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Online Payments" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Online Payments")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Date",
                                  name: "date",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_date_picker, {
                                        "value-format": "YYYY-MM-DD",
                                        style: { "width": "100%" },
                                        value: _ctx.formState.date,
                                        "onUpdate:value": ($event) => _ctx.formState.date = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_date_picker, {
                                          "value-format": "YYYY-MM-DD",
                                          style: { "width": "100%" },
                                          value: _ctx.formState.date,
                                          "onUpdate:value": ($event) => _ctx.formState.date = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Description",
                                  name: "description",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_textarea, {
                                        value: _ctx.formState.description,
                                        "onUpdate:value": ($event) => _ctx.formState.description = $event,
                                        placeholder: "Enter Description",
                                        rows: 4
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_textarea, {
                                          value: _ctx.formState.description,
                                          "onUpdate:value": ($event) => _ctx.formState.description = $event,
                                          placeholder: "Enter Description",
                                          rows: 4
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        ref: "submitss",
                                        type: "primary",
                                        "html-type": "submit"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`Save`);
                                          } else {
                                            return [
                                              createTextVNode("Save")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          ref: "submitss",
                                          type: "primary",
                                          "html-type": "submit"
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("Save")
                                          ]),
                                          _: 1
                                        }, 512)
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_modal, {
                                  visible: _ctx.visible,
                                  "onUpdate:visible": ($event) => _ctx.visible = $event,
                                  title: "Add Expense Type",
                                  onOk: _ctx.handleOk
                                }, {
                                  footer: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        key: "back",
                                        onClick: _ctx.handleCancel
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`Cancel`);
                                          } else {
                                            return [
                                              createTextVNode("Cancel")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        key: "submit",
                                        type: "primary",
                                        loading: _ctx.loading,
                                        onClick: _ctx.handleOk
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`Save`);
                                          } else {
                                            return [
                                              createTextVNode("Save")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          key: "back",
                                          onClick: _ctx.handleCancel
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("Cancel")
                                          ]),
                                          _: 1
                                        }, 8, ["onClick"]),
                                        createVNode(_component_a_button, {
                                          key: "submit",
                                          type: "primary",
                                          loading: _ctx.loading,
                                          onClick: _ctx.handleOk
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("Save")
                                          ]),
                                          _: 1
                                        }, 8, ["loading", "onClick"])
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Expense Type",
                                        name: "expensetype",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: _ctx.formState.expensetype,
                                              "onUpdate:value": ($event) => _ctx.formState.expensetype = $event,
                                              placeholder: "Enter Expense Type"
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: _ctx.formState.expensetype,
                                                "onUpdate:value": ($event) => _ctx.formState.expensetype = $event,
                                                placeholder: "Enter Expense Type"
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Expense Type",
                                          name: "expensetype",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: _ctx.formState.expensetype,
                                              "onUpdate:value": ($event) => _ctx.formState.expensetype = $event,
                                              placeholder: "Enter Expense Type"
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_form_item, {
                                    label: "Name",
                                    name: "name",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.formState.name,
                                        "onUpdate:value": ($event) => _ctx.formState.name = $event
                                      }, {
                                        prefix: withCtx(() => [
                                          createVNode(_component_user_outlined, { type: "user" })
                                        ]),
                                        _: 1
                                      }, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Expense Type",
                                    name: "expensetype",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        value: _ctx.formState.expensetype,
                                        "onUpdate:value": ($event) => _ctx.formState.expensetype = $event
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "Utility expenses" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Utility expenses")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Administration expenses" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Administration expenses")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "IT and Internet Expense" }, {
                                            default: withCtx(() => [
                                              createTextVNode("IT and Internet Expense")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Office Supplies" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Office Supplies")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Office Supplies" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Health Care")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, {
                                            value: "undefined",
                                            disabled: ""
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_button, {
                                                type: "primary",
                                                onClick: _ctx.showModal
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Add More")
                                                ]),
                                                _: 1
                                              }, 8, ["onClick"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Amount",
                                    name: "amount",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.formState.amount,
                                        "onUpdate:value": ($event) => _ctx.formState.amount = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Method",
                                    name: "method",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        value: _ctx.formState.method,
                                        "onUpdate:value": ($event) => _ctx.formState.method = $event
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "Bank Transfer" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Bank Transfer")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Cash Payment" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Cash Payment")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Cheque Payment" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Cheque Payment")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Online Payments" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Online Payments")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Date",
                                    name: "date",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_date_picker, {
                                        "value-format": "YYYY-MM-DD",
                                        style: { "width": "100%" },
                                        value: _ctx.formState.date,
                                        "onUpdate:value": ($event) => _ctx.formState.date = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Description",
                                    name: "description",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_textarea, {
                                        value: _ctx.formState.description,
                                        "onUpdate:value": ($event) => _ctx.formState.description = $event,
                                        placeholder: "Enter Description",
                                        rows: 4
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        ref: "submitss",
                                        type: "primary",
                                        "html-type": "submit"
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Save")
                                        ]),
                                        _: 1
                                      }, 512)
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_modal, {
                                    visible: _ctx.visible,
                                    "onUpdate:visible": ($event) => _ctx.visible = $event,
                                    title: "Add Expense Type",
                                    onOk: _ctx.handleOk
                                  }, {
                                    footer: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        key: "back",
                                        onClick: _ctx.handleCancel
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Cancel")
                                        ]),
                                        _: 1
                                      }, 8, ["onClick"]),
                                      createVNode(_component_a_button, {
                                        key: "submit",
                                        type: "primary",
                                        loading: _ctx.loading,
                                        onClick: _ctx.handleOk
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Save")
                                        ]),
                                        _: 1
                                      }, 8, ["loading", "onClick"])
                                    ]),
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Expense Type",
                                        name: "expensetype",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: _ctx.formState.expensetype,
                                            "onUpdate:value": ($event) => _ctx.formState.expensetype = $event,
                                            placeholder: "Enter Expense Type"
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["visible", "onUpdate:visible", "onOk"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                              name: "nest-messages",
                              "validate-messages": _ctx.validateMessages,
                              onFinish: _ctx.submit
                            }), {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Name",
                                  name: "name",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: _ctx.formState.name,
                                      "onUpdate:value": ($event) => _ctx.formState.name = $event
                                    }, {
                                      prefix: withCtx(() => [
                                        createVNode(_component_user_outlined, { type: "user" })
                                      ]),
                                      _: 1
                                    }, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Expense Type",
                                  name: "expensetype",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      value: _ctx.formState.expensetype,
                                      "onUpdate:value": ($event) => _ctx.formState.expensetype = $event
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, { value: "Utility expenses" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Utility expenses")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "Administration expenses" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Administration expenses")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "IT and Internet Expense" }, {
                                          default: withCtx(() => [
                                            createTextVNode("IT and Internet Expense")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "Office Supplies" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Office Supplies")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "Office Supplies" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Health Care")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, {
                                          value: "undefined",
                                          disabled: ""
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_button, {
                                              type: "primary",
                                              onClick: _ctx.showModal
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode("Add More")
                                              ]),
                                              _: 1
                                            }, 8, ["onClick"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Amount",
                                  name: "amount",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: _ctx.formState.amount,
                                      "onUpdate:value": ($event) => _ctx.formState.amount = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Method",
                                  name: "method",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      value: _ctx.formState.method,
                                      "onUpdate:value": ($event) => _ctx.formState.method = $event
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, { value: "Bank Transfer" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Bank Transfer")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "Cash Payment" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Cash Payment")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "Cheque Payment" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Cheque Payment")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "Online Payments" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Online Payments")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Date",
                                  name: "date",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_date_picker, {
                                      "value-format": "YYYY-MM-DD",
                                      style: { "width": "100%" },
                                      value: _ctx.formState.date,
                                      "onUpdate:value": ($event) => _ctx.formState.date = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Description",
                                  name: "description",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_textarea, {
                                      value: _ctx.formState.description,
                                      "onUpdate:value": ($event) => _ctx.formState.description = $event,
                                      placeholder: "Enter Description",
                                      rows: 4
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      ref: "submitss",
                                      type: "primary",
                                      "html-type": "submit"
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Save")
                                      ]),
                                      _: 1
                                    }, 512)
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_modal, {
                                  visible: _ctx.visible,
                                  "onUpdate:visible": ($event) => _ctx.visible = $event,
                                  title: "Add Expense Type",
                                  onOk: _ctx.handleOk
                                }, {
                                  footer: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      key: "back",
                                      onClick: _ctx.handleCancel
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Cancel")
                                      ]),
                                      _: 1
                                    }, 8, ["onClick"]),
                                    createVNode(_component_a_button, {
                                      key: "submit",
                                      type: "primary",
                                      loading: _ctx.loading,
                                      onClick: _ctx.handleOk
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Save")
                                      ]),
                                      _: 1
                                    }, 8, ["loading", "onClick"])
                                  ]),
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Expense Type",
                                      name: "expensetype",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: _ctx.formState.expensetype,
                                          "onUpdate:value": ($event) => _ctx.formState.expensetype = $event,
                                          placeholder: "Enter Expense Type"
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["visible", "onUpdate:visible", "onOk"])
                              ]),
                              _: 1
                            }, 16, ["model", "validate-messages", "onFinish"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_col, {
                        span: 12,
                        offset: 6
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                            name: "nest-messages",
                            "validate-messages": _ctx.validateMessages,
                            onFinish: _ctx.submit
                          }), {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Name",
                                name: "name",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: _ctx.formState.name,
                                    "onUpdate:value": ($event) => _ctx.formState.name = $event
                                  }, {
                                    prefix: withCtx(() => [
                                      createVNode(_component_user_outlined, { type: "user" })
                                    ]),
                                    _: 1
                                  }, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Expense Type",
                                name: "expensetype",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    value: _ctx.formState.expensetype,
                                    "onUpdate:value": ($event) => _ctx.formState.expensetype = $event
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, { value: "Utility expenses" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Utility expenses")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "Administration expenses" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Administration expenses")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "IT and Internet Expense" }, {
                                        default: withCtx(() => [
                                          createTextVNode("IT and Internet Expense")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "Office Supplies" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Office Supplies")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "Office Supplies" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Health Care")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, {
                                        value: "undefined",
                                        disabled: ""
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_button, {
                                            type: "primary",
                                            onClick: _ctx.showModal
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode("Add More")
                                            ]),
                                            _: 1
                                          }, 8, ["onClick"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Amount",
                                name: "amount",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: _ctx.formState.amount,
                                    "onUpdate:value": ($event) => _ctx.formState.amount = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Method",
                                name: "method",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    value: _ctx.formState.method,
                                    "onUpdate:value": ($event) => _ctx.formState.method = $event
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, { value: "Bank Transfer" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Bank Transfer")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "Cash Payment" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Cash Payment")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "Cheque Payment" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Cheque Payment")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "Online Payments" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Online Payments")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Date",
                                name: "date",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_date_picker, {
                                    "value-format": "YYYY-MM-DD",
                                    style: { "width": "100%" },
                                    value: _ctx.formState.date,
                                    "onUpdate:value": ($event) => _ctx.formState.date = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Description",
                                name: "description",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_textarea, {
                                    value: _ctx.formState.description,
                                    "onUpdate:value": ($event) => _ctx.formState.description = $event,
                                    placeholder: "Enter Description",
                                    rows: 4
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    ref: "submitss",
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Save")
                                    ]),
                                    _: 1
                                  }, 512)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_modal, {
                                visible: _ctx.visible,
                                "onUpdate:visible": ($event) => _ctx.visible = $event,
                                title: "Add Expense Type",
                                onOk: _ctx.handleOk
                              }, {
                                footer: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    key: "back",
                                    onClick: _ctx.handleCancel
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Cancel")
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"]),
                                  createVNode(_component_a_button, {
                                    key: "submit",
                                    type: "primary",
                                    loading: _ctx.loading,
                                    onClick: _ctx.handleOk
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Save")
                                    ]),
                                    _: 1
                                  }, 8, ["loading", "onClick"])
                                ]),
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Expense Type",
                                    name: "expensetype",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.formState.expensetype,
                                        "onUpdate:value": ($event) => _ctx.formState.expensetype = $event,
                                        placeholder: "Enter Expense Type"
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["visible", "onUpdate:visible", "onOk"])
                            ]),
                            _: 1
                          }, 16, ["model", "validate-messages", "onFinish"])
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_a_col, {
                      span: 12,
                      offset: 6
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                          name: "nest-messages",
                          "validate-messages": _ctx.validateMessages,
                          onFinish: _ctx.submit
                        }), {
                          default: withCtx(() => [
                            createVNode(_component_a_form_item, {
                              label: "Name",
                              name: "name",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: _ctx.formState.name,
                                  "onUpdate:value": ($event) => _ctx.formState.name = $event
                                }, {
                                  prefix: withCtx(() => [
                                    createVNode(_component_user_outlined, { type: "user" })
                                  ]),
                                  _: 1
                                }, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Expense Type",
                              name: "expensetype",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_select, {
                                  value: _ctx.formState.expensetype,
                                  "onUpdate:value": ($event) => _ctx.formState.expensetype = $event
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select_option, { value: "Utility expenses" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Utility expenses")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Administration expenses" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Administration expenses")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "IT and Internet Expense" }, {
                                      default: withCtx(() => [
                                        createTextVNode("IT and Internet Expense")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Office Supplies" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Office Supplies")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Office Supplies" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Health Care")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, {
                                      value: "undefined",
                                      disabled: ""
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          onClick: _ctx.showModal
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("Add More")
                                          ]),
                                          _: 1
                                        }, 8, ["onClick"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Amount",
                              name: "amount",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: _ctx.formState.amount,
                                  "onUpdate:value": ($event) => _ctx.formState.amount = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Method",
                              name: "method",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_select, {
                                  value: _ctx.formState.method,
                                  "onUpdate:value": ($event) => _ctx.formState.method = $event
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select_option, { value: "Bank Transfer" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Bank Transfer")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Cash Payment" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Cash Payment")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Cheque Payment" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Cheque Payment")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Online Payments" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Online Payments")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Date",
                              name: "date",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_date_picker, {
                                  "value-format": "YYYY-MM-DD",
                                  style: { "width": "100%" },
                                  value: _ctx.formState.date,
                                  "onUpdate:value": ($event) => _ctx.formState.date = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Description",
                              name: "description",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_textarea, {
                                  value: _ctx.formState.description,
                                  "onUpdate:value": ($event) => _ctx.formState.description = $event,
                                  placeholder: "Enter Description",
                                  rows: 4
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  ref: "submitss",
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Save")
                                  ]),
                                  _: 1
                                }, 512)
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_modal, {
                              visible: _ctx.visible,
                              "onUpdate:visible": ($event) => _ctx.visible = $event,
                              title: "Add Expense Type",
                              onOk: _ctx.handleOk
                            }, {
                              footer: withCtx(() => [
                                createVNode(_component_a_button, {
                                  key: "back",
                                  onClick: _ctx.handleCancel
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Cancel")
                                  ]),
                                  _: 1
                                }, 8, ["onClick"]),
                                createVNode(_component_a_button, {
                                  key: "submit",
                                  type: "primary",
                                  loading: _ctx.loading,
                                  onClick: _ctx.handleOk
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Save")
                                  ]),
                                  _: 1
                                }, 8, ["loading", "onClick"])
                              ]),
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Expense Type",
                                  name: "expensetype",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: _ctx.formState.expensetype,
                                      "onUpdate:value": ($event) => _ctx.formState.expensetype = $event,
                                      placeholder: "Enter Expense Type"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["visible", "onUpdate:visible", "onOk"])
                          ]),
                          _: 1
                        }, 16, ["model", "validate-messages", "onFinish"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_affix, { "offset-top": 0 }, {
            default: withCtx(() => [
              createVNode(_component_a_page_header, {
                ghost: false,
                title: _ctx.expensetype.name,
                onBack: () => _ctx.$inertia.visit(_ctx.route("expensetype.index"))
              }, {
                extra: withCtx(() => [
                  createVNode(_component_a_button, {
                    key: "1",
                    type: "primary",
                    onClick: ($event) => _ctx.triggerSubmit()
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Save")
                    ]),
                    _: 1
                  }, 8, ["onClick"])
                ]),
                _: 1
              }, 8, ["title", "onBack"])
            ]),
            _: 1
          }),
          createVNode(_component_a_layout_content, null, {
            default: withCtx(() => [
              createVNode(_component_a_row, null, {
                default: withCtx(() => [
                  createVNode(_component_a_col, {
                    span: 12,
                    offset: 6
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                        name: "nest-messages",
                        "validate-messages": _ctx.validateMessages,
                        onFinish: _ctx.submit
                      }), {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, {
                            label: "Name",
                            name: "name",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: _ctx.formState.name,
                                "onUpdate:value": ($event) => _ctx.formState.name = $event
                              }, {
                                prefix: withCtx(() => [
                                  createVNode(_component_user_outlined, { type: "user" })
                                ]),
                                _: 1
                              }, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Expense Type",
                            name: "expensetype",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_select, {
                                value: _ctx.formState.expensetype,
                                "onUpdate:value": ($event) => _ctx.formState.expensetype = $event
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select_option, { value: "Utility expenses" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Utility expenses")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Administration expenses" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Administration expenses")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "IT and Internet Expense" }, {
                                    default: withCtx(() => [
                                      createTextVNode("IT and Internet Expense")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Office Supplies" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Office Supplies")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Office Supplies" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Health Care")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, {
                                    value: "undefined",
                                    disabled: ""
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        onClick: _ctx.showModal
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Add More")
                                        ]),
                                        _: 1
                                      }, 8, ["onClick"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Amount",
                            name: "amount",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: _ctx.formState.amount,
                                "onUpdate:value": ($event) => _ctx.formState.amount = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Method",
                            name: "method",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_select, {
                                value: _ctx.formState.method,
                                "onUpdate:value": ($event) => _ctx.formState.method = $event
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select_option, { value: "Bank Transfer" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Bank Transfer")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Cash Payment" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Cash Payment")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Cheque Payment" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Cheque Payment")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Online Payments" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Online Payments")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Date",
                            name: "date",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_date_picker, {
                                "value-format": "YYYY-MM-DD",
                                style: { "width": "100%" },
                                value: _ctx.formState.date,
                                "onUpdate:value": ($event) => _ctx.formState.date = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Description",
                            name: "description",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_textarea, {
                                value: _ctx.formState.description,
                                "onUpdate:value": ($event) => _ctx.formState.description = $event,
                                placeholder: "Enter Description",
                                rows: 4
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                ref: "submitss",
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Save")
                                ]),
                                _: 1
                              }, 512)
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_modal, {
                            visible: _ctx.visible,
                            "onUpdate:visible": ($event) => _ctx.visible = $event,
                            title: "Add Expense Type",
                            onOk: _ctx.handleOk
                          }, {
                            footer: withCtx(() => [
                              createVNode(_component_a_button, {
                                key: "back",
                                onClick: _ctx.handleCancel
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Cancel")
                                ]),
                                _: 1
                              }, 8, ["onClick"]),
                              createVNode(_component_a_button, {
                                key: "submit",
                                type: "primary",
                                loading: _ctx.loading,
                                onClick: _ctx.handleOk
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Save")
                                ]),
                                _: 1
                              }, 8, ["loading", "onClick"])
                            ]),
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Expense Type",
                                name: "expensetype",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: _ctx.formState.expensetype,
                                    "onUpdate:value": ($event) => _ctx.formState.expensetype = $event,
                                    placeholder: "Enter Expense Type"
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["visible", "onUpdate:visible", "onOk"])
                        ]),
                        _: 1
                      }, 16, ["model", "validate-messages", "onFinish"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Expensetype/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Edit = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Edit as default
};
