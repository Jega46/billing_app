import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import "vue-request";
import { resolveComponent, withCtx, createVNode, createTextVNode, openBlock, createBlock, toDisplayString, createCommentVNode, mergeProps, useSSRContext } from "vue";
import { Head, Link, useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./InputError-6d616b1a.mjs";
import { DownloadOutlined, UploadOutlined, PlusCircleOutlined, MoreOutlined, PlusOutlined } from "@ant-design/icons-vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
const columns = [
  {
    title: "Vendor Name",
    key: "vendor_name",
    dataIndex: "vendor_name",
    width: "5%"
  },
  {
    title: "Company Name",
    key: "company_name",
    dataIndex: "company_name",
    width: "5%"
  },
  {
    title: "Work Phone",
    key: "work_phone",
    dataIndex: "work_phone",
    width: "5%"
  },
  {
    title: "Email",
    key: "email",
    dataIndex: "email",
    width: "5%"
  },
  {
    title: "GSTIN",
    key: "gstin",
    dataIndex: "gstin",
    width: "5%"
  },
  {
    title: "Action",
    key: "action",
    fixed: "right",
    width: "2%"
  }
];
const vendors = [
  {
    key: "1",
    vendor_name: "John Brown",
    work_phone: 9876543210,
    email: "test@gmail.com",
    company_name: "ABC Company",
    gstin: "GSTIN12345"
  },
  {
    key: "2",
    vendor_name: "Jim Green",
    work_phone: 9876543210,
    email: "test2@gmail.com",
    company_name: "XYZ Company",
    gstin: "GSTIN12345"
  },
  {
    key: "3",
    vendor_name: "Joe Black",
    work_phone: 9876543210,
    email: "",
    company_name: "ABC Company",
    gstin: "GSTIN12345"
  },
  {
    key: "4",
    vendor_name: "John Brown",
    work_phone: 9876543210,
    email: "",
    company_name: "ABC Company",
    gstin: "GSTIN12345"
  }
];
const pagination = {
  current: 1,
  pageSize: 10,
  total: 14,
  showSizeChanger: true,
  showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} items`
};
const invoicetransactions_column = [
  {
    title: "Date",
    key: "date",
    dataIndex: "date",
    width: "15%"
  },
  {
    title: "Invoice Number",
    key: "invoice_number",
    dataIndex: "invoice_number",
    width: "15%"
  },
  {
    title: "Vendor Name",
    key: "vendor_name",
    dataIndex: "vendor_name",
    width: "2%"
  },
  {
    title: "Quantity Sold",
    key: "quantity_sold",
    dataIndex: "quantity_sold",
    width: "10%"
  },
  {
    title: "Price",
    key: "price",
    dataIndex: "price",
    width: "2%"
  },
  {
    title: "Total",
    key: "total",
    dataIndex: "total",
    width: "2%"
  },
  {
    title: "Status",
    key: "status",
    dataIndex: "status",
    width: "2%"
  }
];
const invoicetransactions = [
  {
    key: "1",
    date: "10-10-2023",
    invoice_number: "INV-0001",
    quantity_sold: 1,
    vendor_name: "John",
    price: 12e3,
    total: 12e3,
    status: "Open"
  },
  {
    key: "2",
    date: "10-10-2023",
    invoice_number: "INV-0002",
    quantity_sold: 1,
    vendor_name: "John",
    price: 12e3,
    total: 12e3,
    status: "Open"
  }
];
const _sfc_main = {
  components: { AuthenticatedLayout: _sfc_main$1, DownloadOutlined, UploadOutlined, PlusCircleOutlined, MoreOutlined, Head, Link, InputError: _sfc_main$2, PlusOutlined },
  props: {},
  setup(props) {
    return {
      columns,
      vendors,
      pagination,
      invoicetransactions_column,
      invoicetransactions
    };
  },
  data() {
    const loading = false;
    const searchformState = useForm({
      term: ""
    });
    const layout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 24 }
    };
    const formState = useForm({});
    return {
      createvisible: false,
      showdetail: false,
      formState,
      layout,
      searchformState,
      loading
    };
  },
  methods: {
    showDrawer() {
      this.createvisible = true;
    },
    showVendorDetailDrawer() {
      this.showdetail = true;
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_space = resolveComponent("a-space");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_button = resolveComponent("a-button");
  const _component_plus_circle_outlined = resolveComponent("plus-circle-outlined");
  const _component_a_table = resolveComponent("a-table");
  const _component_a_dropdown = resolveComponent("a-dropdown");
  const _component_more_outlined = resolveComponent("more-outlined");
  const _component_a_menu = resolveComponent("a-menu");
  const _component_a_menu_item = resolveComponent("a-menu-item");
  const _component_edit_outlined = resolveComponent("edit-outlined");
  const _component_delete_outlined = resolveComponent("delete-outlined");
  const _component_a_drawer = resolveComponent("a-drawer");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_tabs = resolveComponent("a-tabs");
  const _component_a_tab_pane = resolveComponent("a-tab-pane");
  const _component_a_descriptions = resolveComponent("a-descriptions");
  const _component_a_descriptions_item = resolveComponent("a-descriptions-item");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_select_option = resolveComponent("a-select-option");
  const _component_PlusOutlined = resolveComponent("PlusOutlined");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Vendors" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_layout_content, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, {
                      name: "nest-messages",
                      model: $data.searchformState,
                      layout: "inline",
                      onFinish: _ctx.search,
                      class: "searchForm"
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input, {
                                  placeholder: "Search by vendor name",
                                  "allow-clear": true,
                                  value: $data.searchformState.term,
                                  "onUpdate:value": ($event) => $data.searchformState.term = $event
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input, {
                                    placeholder: "Search by vendor name",
                                    "allow-clear": true,
                                    value: $data.searchformState.term,
                                    "onUpdate:value": ($event) => $data.searchformState.term = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Search `);
                                    } else {
                                      return [
                                        createTextVNode(" Search ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Search ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_plus_circle_outlined)
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Add New Vendor `);
                                    } else {
                                      return [
                                        createTextVNode(" Add New Vendor ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    shape: "round",
                                    onClick: $options.showDrawer
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Add New Vendor ")
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  placeholder: "Search by vendor name",
                                  "allow-clear": true,
                                  value: $data.searchformState.term,
                                  "onUpdate:value": ($event) => $data.searchformState.term = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Search ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Add New Vendor ")
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_table, {
                      columns: $setup.columns,
                      "data-source": $setup.vendors,
                      pagination: $setup.pagination
                    }, {
                      bodyCell: withCtx(({ column, record }, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          if (column.key === "vendor_name") {
                            _push5(`<a href="javascript:;"${_scopeId4}>${ssrInterpolate(record.vendor_name)}</a>`);
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "action") {
                            _push5(ssrRenderComponent(_component_a_dropdown, null, {
                              overlay: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(ssrRenderComponent(_component_a_menu, null, {
                                    default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_a_menu_item, null, {
                                          default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(`<a href="javascript:;"${_scopeId7}>`);
                                              _push8(ssrRenderComponent(_component_edit_outlined, null, null, _parent8, _scopeId7));
                                              _push8(` Edit </a>`);
                                            } else {
                                              return [
                                                createVNode("a", { href: "javascript:;" }, [
                                                  createVNode(_component_edit_outlined),
                                                  createTextVNode(" Edit ")
                                                ])
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                        _push7(ssrRenderComponent(_component_a_menu_item, null, {
                                          default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(`<a href="javascript:;"${_scopeId7}>`);
                                              _push8(ssrRenderComponent(_component_delete_outlined, null, null, _parent8, _scopeId7));
                                              _push8(` Delete </a>`);
                                            } else {
                                              return [
                                                createVNode("a", { href: "javascript:;" }, [
                                                  createVNode(_component_delete_outlined),
                                                  createTextVNode(" Delete ")
                                                ])
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_a_menu_item, null, {
                                            default: withCtx(() => [
                                              createVNode("a", { href: "javascript:;" }, [
                                                createVNode(_component_edit_outlined),
                                                createTextVNode(" Edit ")
                                              ])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_menu_item, null, {
                                            default: withCtx(() => [
                                              createVNode("a", { href: "javascript:;" }, [
                                                createVNode(_component_delete_outlined),
                                                createTextVNode(" Delete ")
                                              ])
                                            ]),
                                            _: 1
                                          })
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  return [
                                    createVNode(_component_a_menu, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_menu_item, null, {
                                          default: withCtx(() => [
                                            createVNode("a", { href: "javascript:;" }, [
                                              createVNode(_component_edit_outlined),
                                              createTextVNode(" Edit ")
                                            ])
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_menu_item, null, {
                                          default: withCtx(() => [
                                            createVNode("a", { href: "javascript:;" }, [
                                              createVNode(_component_delete_outlined),
                                              createTextVNode(" Delete ")
                                            ])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ];
                                }
                              }),
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(ssrRenderComponent(_component_a_button, {
                                    type: "primary",
                                    size: _ctx.size,
                                    class: "ant-dropdown-link",
                                    shape: "circle"
                                  }, {
                                    icon: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_more_outlined, null, null, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_more_outlined)
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  return [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      size: _ctx.size,
                                      class: "ant-dropdown-link",
                                      shape: "circle"
                                    }, {
                                      icon: withCtx(() => [
                                        createVNode(_component_more_outlined)
                                      ]),
                                      _: 1
                                    }, 8, ["size"])
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                          } else {
                            _push5(`<!---->`);
                          }
                        } else {
                          return [
                            column.key === "vendor_name" ? (openBlock(), createBlock("a", {
                              key: 0,
                              href: "javascript:;",
                              onClick: $options.showVendorDetailDrawer
                            }, toDisplayString(record.vendor_name), 9, ["onClick"])) : createCommentVNode("", true),
                            column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 1 }, {
                              overlay: withCtx(() => [
                                createVNode(_component_a_menu, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, null, {
                                      default: withCtx(() => [
                                        createVNode("a", { href: "javascript:;" }, [
                                          createVNode(_component_edit_outlined),
                                          createTextVNode(" Edit ")
                                        ])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_menu_item, null, {
                                      default: withCtx(() => [
                                        createVNode("a", { href: "javascript:;" }, [
                                          createVNode(_component_delete_outlined),
                                          createTextVNode(" Delete ")
                                        ])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  size: _ctx.size,
                                  class: "ant-dropdown-link",
                                  shape: "circle"
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_more_outlined)
                                  ]),
                                  _: 1
                                }, 8, ["size"])
                              ]),
                              _: 1
                            })) : createCommentVNode("", true)
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, {
                        name: "nest-messages",
                        model: $data.searchformState,
                        layout: "inline",
                        onFinish: _ctx.search,
                        class: "searchForm"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                placeholder: "Search by vendor name",
                                "allow-clear": true,
                                value: $data.searchformState.term,
                                "onUpdate:value": ($event) => $data.searchformState.term = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Search ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                shape: "round",
                                onClick: $options.showDrawer
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Add New Vendor ")
                                ]),
                                _: 1
                              }, 8, ["onClick"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["model", "onFinish"]),
                      createVNode(_component_a_table, {
                        columns: $setup.columns,
                        "data-source": $setup.vendors,
                        pagination: $setup.pagination
                      }, {
                        bodyCell: withCtx(({ column, record }) => [
                          column.key === "vendor_name" ? (openBlock(), createBlock("a", {
                            key: 0,
                            href: "javascript:;",
                            onClick: $options.showVendorDetailDrawer
                          }, toDisplayString(record.vendor_name), 9, ["onClick"])) : createCommentVNode("", true),
                          column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 1 }, {
                            overlay: withCtx(() => [
                              createVNode(_component_a_menu, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, null, {
                                    default: withCtx(() => [
                                      createVNode("a", { href: "javascript:;" }, [
                                        createVNode(_component_edit_outlined),
                                        createTextVNode(" Edit ")
                                      ])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_menu_item, null, {
                                    default: withCtx(() => [
                                      createVNode("a", { href: "javascript:;" }, [
                                        createVNode(_component_delete_outlined),
                                        createTextVNode(" Delete ")
                                      ])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                size: _ctx.size,
                                class: "ant-dropdown-link",
                                shape: "circle"
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_more_outlined)
                                ]),
                                _: 1
                              }, 8, ["size"])
                            ]),
                            _: 1
                          })) : createCommentVNode("", true)
                        ]),
                        _: 1
                      }, 8, ["columns", "data-source", "pagination"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_drawer, {
                visible: $data.createvisible,
                "onUpdate:visible": ($event) => $data.createvisible = $event,
                class: "custom-class",
                title: "New Vendor",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, mergeProps($data.layout, {
                      name: "nest-messages",
                      "label-col": { span: 24 }
                    }), {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Vendor Name",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Vendor Name" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Vendor Name" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Vendor Name",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Vendor Name" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "Company Name" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Company Name" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Company Name" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "Company Name" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Company Name" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Work Phone",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Work Phone" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Work Phone" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Work Phone",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Work Phone" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Mobile Number",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Mobile Number" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Mobile Number" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Mobile Number",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Mobile Number" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "Email" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Email" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Email" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "Email" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Email" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "GSTIN" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "GSTIN" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "GSTIN" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "GSTIN" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "GSTIN" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "Contact Person Name" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Contact Person Name" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Contact Person Name" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "Contact Person Name" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Contact Person Name" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "Contact Person Mobile" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Contact Person Mobile" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Contact Person Mobile" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "Contact Person Mobile" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Contact Person Mobile" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Vendor Name",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Vendor Name" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "Company Name" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Company Name" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Work Phone",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Work Phone" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Mobile Number",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Mobile Number" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "Email" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Email" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "GSTIN" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "GSTIN" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "Contact Person Name" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Contact Person Name" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "Contact Person Mobile" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Contact Person Mobile" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<h4 class="t1"${_scopeId4}>Billing Address</h4>`);
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "Address" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Address" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Address" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "Address" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Address" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "City" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "City" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "City" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "City" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "City" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "State" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "State" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "State" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "State" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "State" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "Pincode" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Pincode" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Pincode" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "Pincode" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Pincode" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "Address" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Address" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "City" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "City" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "State" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "State" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "Pincode" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Pincode" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<h4 class="t1"${_scopeId4}>Shipping Address</h4>`);
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "Address" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Address" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Address" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "Address" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Address" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "City" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "City" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "City" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "City" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "City" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "State" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "State" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "State" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "State" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "State" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "Pincode" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Pincode" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Pincode" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "Pincode" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Pincode" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "Address" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Address" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "City" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "City" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "State" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "State" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "Pincode" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Pincode" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`SUBMIT`);
                                    } else {
                                      return [
                                        createTextVNode("SUBMIT")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("SUBMIT")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_row, { gutter: 24 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Vendor Name",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Vendor Name" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "Company Name" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Company Name" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Work Phone",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Work Phone" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Mobile Number",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Mobile Number" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "Email" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Email" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "GSTIN" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "GSTIN" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "Contact Person Name" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Contact Person Name" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "Contact Person Mobile" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Contact Person Mobile" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("h4", { class: "t1" }, "Billing Address"),
                            createVNode(_component_a_row, { gutter: 24 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "Address" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Address" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "City" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "City" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "State" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "State" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "Pincode" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Pincode" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("h4", { class: "t1" }, "Shipping Address"),
                            createVNode(_component_a_row, { gutter: 24 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "Address" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Address" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "City" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "City" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "State" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "State" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "Pincode" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Pincode" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("SUBMIT")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, mergeProps($data.layout, {
                        name: "nest-messages",
                        "label-col": { span: 24 }
                      }), {
                        default: withCtx(() => [
                          createVNode(_component_a_row, { gutter: 24 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Vendor Name",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Vendor Name" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "Company Name" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Company Name" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Work Phone",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Work Phone" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Mobile Number",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Mobile Number" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "Email" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Email" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "GSTIN" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "GSTIN" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "Contact Person Name" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Contact Person Name" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "Contact Person Mobile" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Contact Person Mobile" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("h4", { class: "t1" }, "Billing Address"),
                          createVNode(_component_a_row, { gutter: 24 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "Address" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Address" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "City" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "City" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "State" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "State" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "Pincode" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Pincode" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("h4", { class: "t1" }, "Shipping Address"),
                          createVNode(_component_a_row, { gutter: 24 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "Address" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Address" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "City" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "City" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "State" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "State" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "Pincode" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Pincode" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("SUBMIT")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 16)
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_drawer, {
                visible: $data.showdetail,
                "onUpdate:visible": ($event) => $data.showdetail = $event,
                class: "custom-class",
                title: "John Brown",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                extra: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_space, null, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Edit`);
                              } else {
                                return [
                                  createTextVNode("Edit")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_button, {
                            type: "primary",
                            onClick: _ctx.onClose
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Delete`);
                              } else {
                                return [
                                  createTextVNode("Delete")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_dropdown, null, {
                            overlay: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_menu_item, { key: "1" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(` Invoice `);
                                          } else {
                                            return [
                                              createTextVNode(" Invoice ")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_menu_item, { key: "2" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(` Quote `);
                                          } else {
                                            return [
                                              createTextVNode(" Quote ")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_menu_item, { key: "3" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(` Sales Order `);
                                          } else {
                                            return [
                                              createTextVNode(" Sales Order ")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_menu_item, { key: "3" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(` Payment `);
                                          } else {
                                            return [
                                              createTextVNode(" Payment ")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_menu_item, { key: "1" }, {
                                          default: withCtx(() => [
                                            createTextVNode(" Invoice ")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_menu_item, { key: "2" }, {
                                          default: withCtx(() => [
                                            createTextVNode(" Quote ")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_menu_item, { key: "3" }, {
                                          default: withCtx(() => [
                                            createTextVNode(" Sales Order ")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_menu_item, { key: "3" }, {
                                          default: withCtx(() => [
                                            createTextVNode(" Payment ")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_menu_item, { key: "1" }, {
                                        default: withCtx(() => [
                                          createTextVNode(" Invoice ")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_menu_item, { key: "2" }, {
                                        default: withCtx(() => [
                                          createTextVNode(" Quote ")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_menu_item, { key: "3" }, {
                                        default: withCtx(() => [
                                          createTextVNode(" Sales Order ")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_menu_item, { key: "3" }, {
                                        default: withCtx(() => [
                                          createTextVNode(" Payment ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ];
                              }
                            }),
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, null, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` New Transaction `);
                                      _push7(ssrRenderComponent(_component_PlusOutlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createTextVNode(" New Transaction "),
                                        createVNode(_component_PlusOutlined)
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, null, {
                                    default: withCtx(() => [
                                      createTextVNode(" New Transaction "),
                                      createVNode(_component_PlusOutlined)
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                              default: withCtx(() => [
                                createTextVNode("Edit")
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(_component_a_button, {
                              type: "primary",
                              onClick: _ctx.onClose
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Delete")
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(_component_a_dropdown, null, {
                              overlay: withCtx(() => [
                                createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "1" }, {
                                      default: withCtx(() => [
                                        createTextVNode(" Invoice ")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_menu_item, { key: "2" }, {
                                      default: withCtx(() => [
                                        createTextVNode(" Quote ")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_menu_item, { key: "3" }, {
                                      default: withCtx(() => [
                                        createTextVNode(" Sales Order ")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_menu_item, { key: "3" }, {
                                      default: withCtx(() => [
                                        createTextVNode(" Payment ")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])
                              ]),
                              default: withCtx(() => [
                                createVNode(_component_a_button, null, {
                                  default: withCtx(() => [
                                    createTextVNode(" New Transaction "),
                                    createVNode(_component_PlusOutlined)
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_space, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx(() => [
                              createTextVNode("Edit")
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(_component_a_button, {
                            type: "primary",
                            onClick: _ctx.onClose
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Delete")
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(_component_a_dropdown, null, {
                            overlay: withCtx(() => [
                              createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "1" }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Invoice ")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_menu_item, { key: "2" }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Quote ")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_menu_item, { key: "3" }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Sales Order ")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_menu_item, { key: "3" }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Payment ")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["onClick"])
                            ]),
                            default: withCtx(() => [
                              createVNode(_component_a_button, null, {
                                default: withCtx(() => [
                                  createTextVNode(" New Transaction "),
                                  createVNode(_component_PlusOutlined)
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_tabs, {
                      activeKey: _ctx.activeKey,
                      "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_tab_pane, {
                            key: "Overview",
                            tab: "Overview"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_descriptions, { size: _ctx.size }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_descriptions_item, {
                                        label: "Vendor Name",
                                        span: 4
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`John Brown`);
                                          } else {
                                            return [
                                              createTextVNode("John Brown")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_descriptions_item, { label: "Mobile Number" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`+91 9876543210`);
                                          } else {
                                            return [
                                              createTextVNode("+91 9876543210")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_descriptions_item, { label: "Email ID" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`mona.azhagesan@gmail.com`);
                                          } else {
                                            return [
                                              createTextVNode("mona.azhagesan@gmail.com")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_descriptions_item, {
                                          label: "Vendor Name",
                                          span: 4
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("John Brown")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, { label: "Mobile Number" }, {
                                          default: withCtx(() => [
                                            createTextVNode("+91 9876543210")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, { label: "Email ID" }, {
                                          default: withCtx(() => [
                                            createTextVNode("mona.azhagesan@gmail.com")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_descriptions, { size: _ctx.size }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_descriptions_item, {
                                        label: "Vendor Name",
                                        span: 4
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("John Brown")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, { label: "Mobile Number" }, {
                                        default: withCtx(() => [
                                          createTextVNode("+91 9876543210")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, { label: "Email ID" }, {
                                        default: withCtx(() => [
                                          createTextVNode("mona.azhagesan@gmail.com")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["size"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_tab_pane, {
                            key: "Transactions",
                            tab: "Transactions",
                            "force-render": ""
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_space, null, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_select, {
                                        ref: "select",
                                        placeholder: "Filter By"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "jack" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Invoice`);
                                                } else {
                                                  return [
                                                    createTextVNode("Invoice")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "lucy" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Sales Order`);
                                                } else {
                                                  return [
                                                    createTextVNode("Sales Order")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "disabled" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Quote`);
                                                } else {
                                                  return [
                                                    createTextVNode("Quote")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Yiminghe" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Purchase Order`);
                                                } else {
                                                  return [
                                                    createTextVNode("Purchase Order")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select_option, { value: "jack" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Invoice")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "lucy" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Sales Order")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "disabled" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Quote")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Purchase Order")
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_select, {
                                        ref: "select",
                                        placeholder: "Status"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "jack" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`All`);
                                                } else {
                                                  return [
                                                    createTextVNode("All")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "lucy" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Draft`);
                                                } else {
                                                  return [
                                                    createTextVNode("Draft")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select_option, { value: "jack" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("All")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "lucy" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Draft")
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_select, {
                                          ref: "select",
                                          placeholder: "Filter By"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "jack" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Invoice")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "lucy" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Sales Order")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "disabled" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Quote")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Purchase Order")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 512),
                                        createVNode(_component_a_select, {
                                          ref: "select",
                                          placeholder: "Status"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "jack" }, {
                                              default: withCtx(() => [
                                                createTextVNode("All")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "lucy" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Draft")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 512)
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_table, {
                                  columns: $setup.invoicetransactions_column,
                                  "data-source": $setup.invoicetransactions
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_space, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        ref: "select",
                                        placeholder: "Filter By"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "jack" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Invoice")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "lucy" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Sales Order")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "disabled" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Quote")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Purchase Order")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 512),
                                      createVNode(_component_a_select, {
                                        ref: "select",
                                        placeholder: "Status"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "jack" }, {
                                            default: withCtx(() => [
                                              createTextVNode("All")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "lucy" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Draft")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 512)
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_table, {
                                    columns: $setup.invoicetransactions_column,
                                    "data-source": $setup.invoicetransactions
                                  }, null, 8, ["columns", "data-source"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_tab_pane, {
                              key: "Overview",
                              tab: "Overview"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_descriptions, { size: _ctx.size }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_descriptions_item, {
                                      label: "Vendor Name",
                                      span: 4
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("John Brown")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_descriptions_item, { label: "Mobile Number" }, {
                                      default: withCtx(() => [
                                        createTextVNode("+91 9876543210")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_descriptions_item, { label: "Email ID" }, {
                                      default: withCtx(() => [
                                        createTextVNode("mona.azhagesan@gmail.com")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["size"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_tab_pane, {
                              key: "Transactions",
                              tab: "Transactions",
                              "force-render": ""
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_space, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      ref: "select",
                                      placeholder: "Filter By"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, { value: "jack" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Invoice")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "lucy" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Sales Order")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "disabled" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Quote")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Purchase Order")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 512),
                                    createVNode(_component_a_select, {
                                      ref: "select",
                                      placeholder: "Status"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, { value: "jack" }, {
                                          default: withCtx(() => [
                                            createTextVNode("All")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "lucy" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Draft")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 512)
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_table, {
                                  columns: $setup.invoicetransactions_column,
                                  "data-source": $setup.invoicetransactions
                                }, null, 8, ["columns", "data-source"])
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_tabs, {
                        activeKey: _ctx.activeKey,
                        "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_tab_pane, {
                            key: "Overview",
                            tab: "Overview"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_descriptions, { size: _ctx.size }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_descriptions_item, {
                                    label: "Vendor Name",
                                    span: 4
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("John Brown")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_descriptions_item, { label: "Mobile Number" }, {
                                    default: withCtx(() => [
                                      createTextVNode("+91 9876543210")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_descriptions_item, { label: "Email ID" }, {
                                    default: withCtx(() => [
                                      createTextVNode("mona.azhagesan@gmail.com")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["size"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_tab_pane, {
                            key: "Transactions",
                            tab: "Transactions",
                            "force-render": ""
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_space, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    ref: "select",
                                    placeholder: "Filter By"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, { value: "jack" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Invoice")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "lucy" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Sales Order")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "disabled" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Quote")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Purchase Order")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 512),
                                  createVNode(_component_a_select, {
                                    ref: "select",
                                    placeholder: "Status"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, { value: "jack" }, {
                                        default: withCtx(() => [
                                          createTextVNode("All")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "lucy" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Draft")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 512)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_table, {
                                columns: $setup.invoicetransactions_column,
                                "data-source": $setup.invoicetransactions
                              }, null, 8, ["columns", "data-source"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["activeKey", "onUpdate:activeKey"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_space, {
                  direction: "vertical",
                  style: { width: "100%" }
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, {
                      name: "nest-messages",
                      model: $data.searchformState,
                      layout: "inline",
                      onFinish: _ctx.search,
                      class: "searchForm"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, {
                              placeholder: "Search by vendor name",
                              "allow-clear": true,
                              value: $data.searchformState.term,
                              "onUpdate:value": ($event) => $data.searchformState.term = $event
                            }, null, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Search ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              shape: "round",
                              onClick: $options.showDrawer
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_plus_circle_outlined)
                              ]),
                              default: withCtx(() => [
                                createTextVNode(" Add New Vendor ")
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["model", "onFinish"]),
                    createVNode(_component_a_table, {
                      columns: $setup.columns,
                      "data-source": $setup.vendors,
                      pagination: $setup.pagination
                    }, {
                      bodyCell: withCtx(({ column, record }) => [
                        column.key === "vendor_name" ? (openBlock(), createBlock("a", {
                          key: 0,
                          href: "javascript:;",
                          onClick: $options.showVendorDetailDrawer
                        }, toDisplayString(record.vendor_name), 9, ["onClick"])) : createCommentVNode("", true),
                        column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 1 }, {
                          overlay: withCtx(() => [
                            createVNode(_component_a_menu, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, null, {
                                  default: withCtx(() => [
                                    createVNode("a", { href: "javascript:;" }, [
                                      createVNode(_component_edit_outlined),
                                      createTextVNode(" Edit ")
                                    ])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_menu_item, null, {
                                  default: withCtx(() => [
                                    createVNode("a", { href: "javascript:;" }, [
                                      createVNode(_component_delete_outlined),
                                      createTextVNode(" Delete ")
                                    ])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              size: _ctx.size,
                              class: "ant-dropdown-link",
                              shape: "circle"
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_more_outlined)
                              ]),
                              _: 1
                            }, 8, ["size"])
                          ]),
                          _: 1
                        })) : createCommentVNode("", true)
                      ]),
                      _: 1
                    }, 8, ["columns", "data-source", "pagination"])
                  ]),
                  _: 1
                }),
                createVNode(_component_a_drawer, {
                  visible: $data.createvisible,
                  "onUpdate:visible": ($event) => $data.createvisible = $event,
                  class: "custom-class",
                  title: "New Vendor",
                  size: "large",
                  placement: "right",
                  onAfterVisibleChange: _ctx.afterVisibleChange
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, mergeProps($data.layout, {
                      name: "nest-messages",
                      "label-col": { span: 24 }
                    }), {
                      default: withCtx(() => [
                        createVNode(_component_a_row, { gutter: 24 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Vendor Name",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Vendor Name" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "Company Name" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Company Name" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Work Phone",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Work Phone" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Mobile Number",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Mobile Number" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "Email" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Email" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "GSTIN" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "GSTIN" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "Contact Person Name" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Contact Person Name" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "Contact Person Mobile" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Contact Person Mobile" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode("h4", { class: "t1" }, "Billing Address"),
                        createVNode(_component_a_row, { gutter: 24 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "Address" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Address" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "City" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "City" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "State" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "State" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "Pincode" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Pincode" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode("h4", { class: "t1" }, "Shipping Address"),
                        createVNode(_component_a_row, { gutter: 24 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "Address" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Address" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "City" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "City" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "State" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "State" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "Pincode" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Pincode" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("SUBMIT")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 16)
                  ]),
                  _: 1
                }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"]),
                createVNode(_component_a_drawer, {
                  visible: $data.showdetail,
                  "onUpdate:visible": ($event) => $data.showdetail = $event,
                  class: "custom-class",
                  title: "John Brown",
                  size: "large",
                  placement: "right",
                  onAfterVisibleChange: _ctx.afterVisibleChange
                }, {
                  extra: withCtx(() => [
                    createVNode(_component_a_space, null, {
                      default: withCtx(() => [
                        createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                          default: withCtx(() => [
                            createTextVNode("Edit")
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_component_a_button, {
                          type: "primary",
                          onClick: _ctx.onClose
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Delete")
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_component_a_dropdown, null, {
                          overlay: withCtx(() => [
                            createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "1" }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Invoice ")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_menu_item, { key: "2" }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Quote ")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_menu_item, { key: "3" }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Sales Order ")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_menu_item, { key: "3" }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Payment ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ]),
                          default: withCtx(() => [
                            createVNode(_component_a_button, null, {
                              default: withCtx(() => [
                                createTextVNode(" New Transaction "),
                                createVNode(_component_PlusOutlined)
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  default: withCtx(() => [
                    createVNode(_component_a_tabs, {
                      activeKey: _ctx.activeKey,
                      "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_tab_pane, {
                          key: "Overview",
                          tab: "Overview"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_descriptions, { size: _ctx.size }, {
                              default: withCtx(() => [
                                createVNode(_component_a_descriptions_item, {
                                  label: "Vendor Name",
                                  span: 4
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("John Brown")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_descriptions_item, { label: "Mobile Number" }, {
                                  default: withCtx(() => [
                                    createTextVNode("+91 9876543210")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_descriptions_item, { label: "Email ID" }, {
                                  default: withCtx(() => [
                                    createTextVNode("mona.azhagesan@gmail.com")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["size"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_tab_pane, {
                          key: "Transactions",
                          tab: "Transactions",
                          "force-render": ""
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_space, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_select, {
                                  ref: "select",
                                  placeholder: "Filter By"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select_option, { value: "jack" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Invoice")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "lucy" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Sales Order")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "disabled" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Quote")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Purchase Order")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 512),
                                createVNode(_component_a_select, {
                                  ref: "select",
                                  placeholder: "Status"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select_option, { value: "jack" }, {
                                      default: withCtx(() => [
                                        createTextVNode("All")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "lucy" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Draft")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 512)
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_table, {
                              columns: $setup.invoicetransactions_column,
                              "data-source": $setup.invoicetransactions
                            }, null, 8, ["columns", "data-source"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["activeKey", "onUpdate:activeKey"])
                  ]),
                  _: 1
                }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_layout_content, null, {
            default: withCtx(() => [
              createVNode(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, {
                    name: "nest-messages",
                    model: $data.searchformState,
                    layout: "inline",
                    onFinish: _ctx.search,
                    class: "searchForm"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            placeholder: "Search by vendor name",
                            "allow-clear": true,
                            value: $data.searchformState.term,
                            "onUpdate:value": ($event) => $data.searchformState.term = $event
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Search ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            shape: "round",
                            onClick: $options.showDrawer
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_plus_circle_outlined)
                            ]),
                            default: withCtx(() => [
                              createTextVNode(" Add New Vendor ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["model", "onFinish"]),
                  createVNode(_component_a_table, {
                    columns: $setup.columns,
                    "data-source": $setup.vendors,
                    pagination: $setup.pagination
                  }, {
                    bodyCell: withCtx(({ column, record }) => [
                      column.key === "vendor_name" ? (openBlock(), createBlock("a", {
                        key: 0,
                        href: "javascript:;",
                        onClick: $options.showVendorDetailDrawer
                      }, toDisplayString(record.vendor_name), 9, ["onClick"])) : createCommentVNode("", true),
                      column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 1 }, {
                        overlay: withCtx(() => [
                          createVNode(_component_a_menu, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, null, {
                                default: withCtx(() => [
                                  createVNode("a", { href: "javascript:;" }, [
                                    createVNode(_component_edit_outlined),
                                    createTextVNode(" Edit ")
                                  ])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_menu_item, null, {
                                default: withCtx(() => [
                                  createVNode("a", { href: "javascript:;" }, [
                                    createVNode(_component_delete_outlined),
                                    createTextVNode(" Delete ")
                                  ])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            size: _ctx.size,
                            class: "ant-dropdown-link",
                            shape: "circle"
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_more_outlined)
                            ]),
                            _: 1
                          }, 8, ["size"])
                        ]),
                        _: 1
                      })) : createCommentVNode("", true)
                    ]),
                    _: 1
                  }, 8, ["columns", "data-source", "pagination"])
                ]),
                _: 1
              }),
              createVNode(_component_a_drawer, {
                visible: $data.createvisible,
                "onUpdate:visible": ($event) => $data.createvisible = $event,
                class: "custom-class",
                title: "New Vendor",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, mergeProps($data.layout, {
                    name: "nest-messages",
                    "label-col": { span: 24 }
                  }), {
                    default: withCtx(() => [
                      createVNode(_component_a_row, { gutter: 24 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Vendor Name",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Vendor Name" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "Company Name" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Company Name" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Work Phone",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Work Phone" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Mobile Number",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Mobile Number" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "Email" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Email" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "GSTIN" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "GSTIN" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "Contact Person Name" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Contact Person Name" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "Contact Person Mobile" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Contact Person Mobile" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode("h4", { class: "t1" }, "Billing Address"),
                      createVNode(_component_a_row, { gutter: 24 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "Address" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Address" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "City" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "City" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "State" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "State" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "Pincode" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Pincode" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode("h4", { class: "t1" }, "Shipping Address"),
                      createVNode(_component_a_row, { gutter: 24 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "Address" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Address" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "City" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "City" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "State" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "State" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "Pincode" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Pincode" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode("SUBMIT")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 16)
                ]),
                _: 1
              }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"]),
              createVNode(_component_a_drawer, {
                visible: $data.showdetail,
                "onUpdate:visible": ($event) => $data.showdetail = $event,
                class: "custom-class",
                title: "John Brown",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                extra: withCtx(() => [
                  createVNode(_component_a_space, null, {
                    default: withCtx(() => [
                      createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                        default: withCtx(() => [
                          createTextVNode("Edit")
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_button, {
                        type: "primary",
                        onClick: _ctx.onClose
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Delete")
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_dropdown, null, {
                        overlay: withCtx(() => [
                          createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "1" }, {
                                default: withCtx(() => [
                                  createTextVNode(" Invoice ")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_menu_item, { key: "2" }, {
                                default: withCtx(() => [
                                  createTextVNode(" Quote ")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_menu_item, { key: "3" }, {
                                default: withCtx(() => [
                                  createTextVNode(" Sales Order ")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_menu_item, { key: "3" }, {
                                default: withCtx(() => [
                                  createTextVNode(" Payment ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        default: withCtx(() => [
                          createVNode(_component_a_button, null, {
                            default: withCtx(() => [
                              createTextVNode(" New Transaction "),
                              createVNode(_component_PlusOutlined)
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                default: withCtx(() => [
                  createVNode(_component_a_tabs, {
                    activeKey: _ctx.activeKey,
                    "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_tab_pane, {
                        key: "Overview",
                        tab: "Overview"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_descriptions, { size: _ctx.size }, {
                            default: withCtx(() => [
                              createVNode(_component_a_descriptions_item, {
                                label: "Vendor Name",
                                span: 4
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("John Brown")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_descriptions_item, { label: "Mobile Number" }, {
                                default: withCtx(() => [
                                  createTextVNode("+91 9876543210")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_descriptions_item, { label: "Email ID" }, {
                                default: withCtx(() => [
                                  createTextVNode("mona.azhagesan@gmail.com")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["size"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_tab_pane, {
                        key: "Transactions",
                        tab: "Transactions",
                        "force-render": ""
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_space, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_select, {
                                ref: "select",
                                placeholder: "Filter By"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select_option, { value: "jack" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Invoice")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "lucy" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Sales Order")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "disabled" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Quote")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Purchase Order")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 512),
                              createVNode(_component_a_select, {
                                ref: "select",
                                placeholder: "Status"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select_option, { value: "jack" }, {
                                    default: withCtx(() => [
                                      createTextVNode("All")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "lucy" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Draft")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 512)
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_table, {
                            columns: $setup.invoicetransactions_column,
                            "data-source": $setup.invoicetransactions
                          }, null, 8, ["columns", "data-source"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["activeKey", "onUpdate:activeKey"])
                ]),
                _: 1
              }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"])
            ]),
            _: 1
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Vendor/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Index as default
};
