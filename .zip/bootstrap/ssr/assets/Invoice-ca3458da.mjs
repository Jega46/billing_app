import { defineComponent, ref, resolveComponent, withCtx, createTextVNode, createVNode, toDisplayString, withModifiers, openBlock, createBlock, createCommentVNode, useSSRContext } from "vue";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import { Head, useForm } from "@inertiajs/vue3";
import { MailOutlined, EditOutlined, CopyOutlined, DownloadOutlined, DisconnectOutlined, ShareAltOutlined, FileTextOutlined, PaperClipOutlined, PrinterOutlined } from "@ant-design/icons-vue";
import { ssrRenderComponent, ssrRenderStyle, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
const Invoice_vue_vue_type_style_index_0_lang = "";
const columns = [
  {
    title: "Description",
    dataIndex: "description",
    key: "description",
    slots: {
      customRender: "description"
    },
    width: "35%"
  },
  {
    title: "Price/Rate",
    dataIndex: "price",
    key: "price",
    width: "20%"
  },
  {
    title: "Tax",
    dataIndex: "tax",
    key: "tax",
    width: "16%"
  },
  {
    title: "Subtotal",
    dataIndex: "subtotal",
    key: "subtotal",
    width: "30%"
  }
];
const data = [
  {
    key: "1",
    description: "test",
    price: 120,
    tax: "0.00",
    subtotal: 120
  }
];
const _sfc_main = defineComponent({
  inject: ["validateMessages"],
  props: {
    pagination: Object,
    errors: Object
  },
  components: {
    AuthenticatedLayout: _sfc_main$1,
    Head,
    MailOutlined,
    EditOutlined,
    CopyOutlined,
    DownloadOutlined,
    DisconnectOutlined,
    ShareAltOutlined,
    FileTextOutlined,
    PaperClipOutlined,
    PrinterOutlined
  },
  setup(props) {
    const visible = ref(true);
    const handleClose = () => {
      visible.value = false;
    };
    const layout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 16 }
    };
    const formState = useForm({});
    return {
      formState,
      layout,
      visible,
      handleClose,
      data,
      columns
    };
  },
  mounted() {
  },
  data() {
    return {
      menu_visible: false,
      download_visible: false
    };
  },
  methods: {
    exportToPDF() {
      html2pdf(document.getElementById("element-to-convert"), {
        margin: 1,
        filename: "invoice.pdf"
      });
    }
  }
});
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_affix = resolveComponent("a-affix");
  const _component_a_page_header = resolveComponent("a-page-header");
  const _component_a_button = resolveComponent("a-button");
  const _component_a_tag = resolveComponent("a-tag");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_alert = resolveComponent("a-alert");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_table = resolveComponent("a-table");
  const _component_a_card = resolveComponent("a-card");
  const _component_a_divider = resolveComponent("a-divider");
  const _component_a_steps = resolveComponent("a-steps");
  const _component_a_step = resolveComponent("a-step");
  const _component_a_modal = resolveComponent("a-modal");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_date_picker = resolveComponent("a-date-picker");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_select_option = resolveComponent("a-select-option");
  const _component_MailOutlined = resolveComponent("MailOutlined");
  const _component_EditOutlined = resolveComponent("EditOutlined");
  const _component_CopyOutlined = resolveComponent("CopyOutlined");
  const _component_DownloadOutlined = resolveComponent("DownloadOutlined");
  const _component_DisconnectOutlined = resolveComponent("DisconnectOutlined");
  const _component_PrinterOutlined = resolveComponent("PrinterOutlined");
  const _component_ShareAltOutlined = resolveComponent("ShareAltOutlined");
  const _component_FileTextOutlined = resolveComponent("FileTextOutlined");
  const _component_PaperClipOutlined = resolveComponent("PaperClipOutlined");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Employees" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_affix, { "offset-top": 0 }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_page_header, {
                ghost: false,
                title: "Sales Invoice",
                onBack: () => _ctx.$inertia.visit(_ctx.route("sales.create"))
              }, {
                extra: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_button, { type: "primary" }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`Save`);
                        } else {
                          return [
                            createTextVNode("Save")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_button, { type: "primary" }, {
                        default: withCtx(() => [
                          createTextVNode("Save")
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                tags: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_tag, { color: "" }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`AWAITING PAYMENT`);
                        } else {
                          return [
                            createTextVNode("AWAITING PAYMENT")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_tag, { color: "" }, {
                        default: withCtx(() => [
                          createTextVNode("AWAITING PAYMENT")
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(` <p style="${ssrRenderStyle({ "margin-left": "34px" })}"${_scopeId3}> View, edit or manage your Sales Invoice. </p>`);
                    _push4(ssrRenderComponent(_component_a_row, { class: "content" }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`<div style="${ssrRenderStyle({ "flex": "1" })}"${_scopeId4}></div>`);
                        } else {
                          return [
                            createVNode("div", { style: { "flex": "1" } })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createTextVNode(),
                      createVNode("p", { style: { "margin-left": "34px" } }, " View, edit or manage your Sales Invoice. "),
                      createVNode(_component_a_row, { class: "content" }, {
                        default: withCtx(() => [
                          createVNode("div", { style: { "flex": "1" } })
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_page_header, {
                  ghost: false,
                  title: "Sales Invoice",
                  onBack: () => _ctx.$inertia.visit(_ctx.route("sales.create"))
                }, {
                  extra: withCtx(() => [
                    createVNode(_component_a_button, { type: "primary" }, {
                      default: withCtx(() => [
                        createTextVNode("Save")
                      ]),
                      _: 1
                    })
                  ]),
                  tags: withCtx(() => [
                    createVNode(_component_a_tag, { color: "" }, {
                      default: withCtx(() => [
                        createTextVNode("AWAITING PAYMENT")
                      ]),
                      _: 1
                    })
                  ]),
                  default: withCtx(() => [
                    createTextVNode(),
                    createVNode("p", { style: { "margin-left": "34px" } }, " View, edit or manage your Sales Invoice. "),
                    createVNode(_component_a_row, { class: "content" }, {
                      default: withCtx(() => [
                        createVNode("div", { style: { "flex": "1" } })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }, 8, ["onBack"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        if (_ctx.visible) {
          _push2(ssrRenderComponent(_component_a_alert, {
            message: "Great! Invoice Created",
            type: "success",
            closable: "",
            "after-close": _ctx.handleClose,
            style: { margin: "12px 12px", width: "65%" }
          }, null, _parent2, _scopeId));
        } else {
          _push2(`<!---->`);
        }
        _push2(ssrRenderComponent(_component_a_row, { type: "flex" }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_col, { style: { margin: "5px 16px", padding: "24px", background: "#fff", minHeight: "calc(100vh - 115px)", width: "65%" } }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(`<div id="element-to-convert"${_scopeId3}>`);
                    _push4(ssrRenderComponent(_component_a_layout_content, null, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_row, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, { span: 24 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<p${_scopeId6}><b${_scopeId6}>To:</b> uini(vgvvgvgvg123)</p>`);
                                    } else {
                                      return [
                                        createVNode("p", null, [
                                          createVNode("b", null, "To:"),
                                          createTextVNode(" uini(vgvvgvgvg123)")
                                        ])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, { span: 24 }, {
                                    default: withCtx(() => [
                                      createVNode("p", null, [
                                        createVNode("b", null, "To:"),
                                        createTextVNode(" uini(vgvvgvgvg123)")
                                      ])
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_row, { style: { "width": "500px" } }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, { span: 8 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<b${_scopeId6}>Invoice Address</b><p style="${ssrRenderStyle({ "margin-bottom": "0px" })}"${_scopeId6}>xcx</p><p style="${ssrRenderStyle({ "margin-bottom": "0px" })}"${_scopeId6}>xc</p><p style="${ssrRenderStyle({ "margin-bottom": "0px" })}"${_scopeId6}>xc xc 625007</p><p${_scopeId6}>India</p>`);
                                    } else {
                                      return [
                                        createVNode("b", null, "Invoice Address"),
                                        createVNode("p", { style: { "margin-bottom": "0px" } }, "xcx"),
                                        createVNode("p", { style: { "margin-bottom": "0px" } }, "xc"),
                                        createVNode("p", { style: { "margin-bottom": "0px" } }, "xc xc 625007"),
                                        createVNode("p", null, "India")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 8 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<b${_scopeId6}>Invoice Date</b><p style="${ssrRenderStyle({ "margin-bottom": "0px" })}"${_scopeId6}>Feb 28,2023</p>`);
                                    } else {
                                      return [
                                        createVNode("b", null, "Invoice Date"),
                                        createVNode("p", { style: { "margin-bottom": "0px" } }, "Feb 28,2023")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 8 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<b${_scopeId6}>Due Date</b><p style="${ssrRenderStyle({ "margin-bottom": "0px" })}"${_scopeId6}>Mar 30,2023</p><p style="${ssrRenderStyle({ "margin-bottom": "0px" })}"${_scopeId6}>Due in 30 days</p>`);
                                    } else {
                                      return [
                                        createVNode("b", null, "Due Date"),
                                        createVNode("p", { style: { "margin-bottom": "0px" } }, "Mar 30,2023"),
                                        createVNode("p", { style: { "margin-bottom": "0px" } }, "Due in 30 days")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, { span: 8 }, {
                                    default: withCtx(() => [
                                      createVNode("b", null, "Invoice Address"),
                                      createVNode("p", { style: { "margin-bottom": "0px" } }, "xcx"),
                                      createVNode("p", { style: { "margin-bottom": "0px" } }, "xc"),
                                      createVNode("p", { style: { "margin-bottom": "0px" } }, "xc xc 625007"),
                                      createVNode("p", null, "India")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 8 }, {
                                    default: withCtx(() => [
                                      createVNode("b", null, "Invoice Date"),
                                      createVNode("p", { style: { "margin-bottom": "0px" } }, "Feb 28,2023")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 8 }, {
                                    default: withCtx(() => [
                                      createVNode("b", null, "Due Date"),
                                      createVNode("p", { style: { "margin-bottom": "0px" } }, "Mar 30,2023"),
                                      createVNode("p", { style: { "margin-bottom": "0px" } }, "Due in 30 days")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_table, {
                            columns: _ctx.columns,
                            "data-source": _ctx.data,
                            bordered: ""
                          }, {
                            name: withCtx(({ text }, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`<a${_scopeId5}>${ssrInterpolate(text)}</a>`);
                              } else {
                                return [
                                  createVNode("a", null, toDisplayString(text), 1)
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_card, {
                            style: { "width": "380px", "float": "right", "margin-top": "15px" },
                            bordered: ""
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_row, null, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`<b${_scopeId7}>Sub Total</b>`);
                                          } else {
                                            return [
                                              createVNode("b", null, "Sub Total")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`₹ 120.00`);
                                          } else {
                                            return [
                                              createTextVNode("₹ 120.00")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode("b", null, "Sub Total")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createTextVNode("₹ 120.00")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_row, { style: { "margin-top": "15px", "margin-bottom": "15px" } }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`<b${_scopeId7}>Tax Breakdown</b><p style="${ssrRenderStyle({ "margin-bottom": "0px" })}"${_scopeId7}>No Tax: 120.00 @ 0.00%</p>`);
                                          } else {
                                            return [
                                              createVNode("b", null, "Tax Breakdown"),
                                              createVNode("p", { style: { "margin-bottom": "0px" } }, "No Tax: 120.00 @ 0.00%")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`0.00`);
                                          } else {
                                            return [
                                              createTextVNode("0.00")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode("b", null, "Tax Breakdown"),
                                            createVNode("p", { style: { "margin-bottom": "0px" } }, "No Tax: 120.00 @ 0.00%")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createTextVNode("0.00")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_divider, { style: { "height": "2px", "background-color": "#A9A9A9" } }, null, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_row, null, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`<b${_scopeId7}>Total</b>`);
                                          } else {
                                            return [
                                              createVNode("b", null, "Total")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`<b${_scopeId7}>₹ 120.00</b>`);
                                          } else {
                                            return [
                                              createVNode("b", null, "₹ 120.00")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode("b", null, "Total")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode("b", null, "₹ 120.00")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_divider, { style: { "height": "2px", "background-color": "#A9A9A9" } }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_row, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode("b", null, "Sub Total")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createTextVNode("₹ 120.00")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_row, { style: { "margin-top": "15px", "margin-bottom": "15px" } }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode("b", null, "Tax Breakdown"),
                                          createVNode("p", { style: { "margin-bottom": "0px" } }, "No Tax: 120.00 @ 0.00%")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createTextVNode("0.00")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_divider, { style: { "height": "2px", "background-color": "#A9A9A9" } }),
                                  createVNode(_component_a_row, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode("b", null, "Total")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode("b", null, "₹ 120.00")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_divider, { style: { "height": "2px", "background-color": "#A9A9A9" } })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_row, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 24 }, {
                                  default: withCtx(() => [
                                    createVNode("p", null, [
                                      createVNode("b", null, "To:"),
                                      createTextVNode(" uini(vgvvgvgvg123)")
                                    ])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_row, { style: { "width": "500px" } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 8 }, {
                                  default: withCtx(() => [
                                    createVNode("b", null, "Invoice Address"),
                                    createVNode("p", { style: { "margin-bottom": "0px" } }, "xcx"),
                                    createVNode("p", { style: { "margin-bottom": "0px" } }, "xc"),
                                    createVNode("p", { style: { "margin-bottom": "0px" } }, "xc xc 625007"),
                                    createVNode("p", null, "India")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 8 }, {
                                  default: withCtx(() => [
                                    createVNode("b", null, "Invoice Date"),
                                    createVNode("p", { style: { "margin-bottom": "0px" } }, "Feb 28,2023")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 8 }, {
                                  default: withCtx(() => [
                                    createVNode("b", null, "Due Date"),
                                    createVNode("p", { style: { "margin-bottom": "0px" } }, "Mar 30,2023"),
                                    createVNode("p", { style: { "margin-bottom": "0px" } }, "Due in 30 days")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_table, {
                              columns: _ctx.columns,
                              "data-source": _ctx.data,
                              bordered: ""
                            }, {
                              name: withCtx(({ text }) => [
                                createVNode("a", null, toDisplayString(text), 1)
                              ]),
                              _: 1
                            }, 8, ["columns", "data-source"]),
                            createVNode(_component_a_card, {
                              style: { "width": "380px", "float": "right", "margin-top": "15px" },
                              bordered: ""
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_row, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode("b", null, "Sub Total")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createTextVNode("₹ 120.00")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_row, { style: { "margin-top": "15px", "margin-bottom": "15px" } }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode("b", null, "Tax Breakdown"),
                                        createVNode("p", { style: { "margin-bottom": "0px" } }, "No Tax: 120.00 @ 0.00%")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createTextVNode("0.00")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_divider, { style: { "height": "2px", "background-color": "#A9A9A9" } }),
                                createVNode(_component_a_row, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode("b", null, "Total")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode("b", null, "₹ 120.00")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_divider, { style: { "height": "2px", "background-color": "#A9A9A9" } })
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(`</div>`);
                  } else {
                    return [
                      createVNode("div", { id: "element-to-convert" }, [
                        createVNode(_component_a_layout_content, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_row, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 24 }, {
                                  default: withCtx(() => [
                                    createVNode("p", null, [
                                      createVNode("b", null, "To:"),
                                      createTextVNode(" uini(vgvvgvgvg123)")
                                    ])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_row, { style: { "width": "500px" } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 8 }, {
                                  default: withCtx(() => [
                                    createVNode("b", null, "Invoice Address"),
                                    createVNode("p", { style: { "margin-bottom": "0px" } }, "xcx"),
                                    createVNode("p", { style: { "margin-bottom": "0px" } }, "xc"),
                                    createVNode("p", { style: { "margin-bottom": "0px" } }, "xc xc 625007"),
                                    createVNode("p", null, "India")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 8 }, {
                                  default: withCtx(() => [
                                    createVNode("b", null, "Invoice Date"),
                                    createVNode("p", { style: { "margin-bottom": "0px" } }, "Feb 28,2023")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 8 }, {
                                  default: withCtx(() => [
                                    createVNode("b", null, "Due Date"),
                                    createVNode("p", { style: { "margin-bottom": "0px" } }, "Mar 30,2023"),
                                    createVNode("p", { style: { "margin-bottom": "0px" } }, "Due in 30 days")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_table, {
                              columns: _ctx.columns,
                              "data-source": _ctx.data,
                              bordered: ""
                            }, {
                              name: withCtx(({ text }) => [
                                createVNode("a", null, toDisplayString(text), 1)
                              ]),
                              _: 1
                            }, 8, ["columns", "data-source"]),
                            createVNode(_component_a_card, {
                              style: { "width": "380px", "float": "right", "margin-top": "15px" },
                              bordered: ""
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_row, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode("b", null, "Sub Total")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createTextVNode("₹ 120.00")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_row, { style: { "margin-top": "15px", "margin-bottom": "15px" } }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode("b", null, "Tax Breakdown"),
                                        createVNode("p", { style: { "margin-bottom": "0px" } }, "No Tax: 120.00 @ 0.00%")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createTextVNode("0.00")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_divider, { style: { "height": "2px", "background-color": "#A9A9A9" } }),
                                createVNode(_component_a_row, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode("b", null, "Total")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode("b", null, "₹ 120.00")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_divider, { style: { "height": "2px", "background-color": "#A9A9A9" } })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_col, { flex: "0 1 300px" }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_card, { style: { "width": "360px", "margin-top": "4px" } }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_steps, {
                            current: 1,
                            size: "small",
                            style: { "margin-bottom": "42px" }
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_step, { title: "Created" }, null, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_step, { title: "Send" }, null, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_step, { title: "Viewed" }, null, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_step, { title: "Paid" }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_step, { title: "Created" }),
                                  createVNode(_component_a_step, { title: "Send" }),
                                  createVNode(_component_a_step, { title: "Viewed" }),
                                  createVNode(_component_a_step, { title: "Paid" })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_row, { style: { "margin-top": "20px" } }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<b${_scopeId6}>Amount Paid</b><p${_scopeId6}>0.00</p>`);
                                    } else {
                                      return [
                                        createVNode("b", null, "Amount Paid"),
                                        createVNode("p", null, "0.00")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<b${_scopeId6}>Amount Outstanding</b><p${_scopeId6}>0.00</p>`);
                                    } else {
                                      return [
                                        createVNode("b", null, "Amount Outstanding"),
                                        createVNode("p", null, "0.00")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("b", null, "Amount Paid"),
                                      createVNode("p", null, "0.00")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("b", null, "Amount Outstanding"),
                                      createVNode("p", null, "0.00")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_button, {
                            style: { "width": "100%", "margin-top": "15px" },
                            type: "primary",
                            onClick: () => {
                              _ctx.menu_visible = true;
                            }
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Record Payment`);
                              } else {
                                return [
                                  createTextVNode("Record Payment")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_modal, {
                            visible: _ctx.menu_visible,
                            "onUpdate:visible": ($event) => _ctx.menu_visible = $event,
                            onClose: ($event) => _ctx.menu_visible = false,
                            title: "Record Payment",
                            onOk: _ctx.handleOk
                          }, {
                            footer: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  key: "submit",
                                  type: "primary",
                                  loading: _ctx.loading,
                                  onClick: _ctx.handleOk
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`Record`);
                                    } else {
                                      return [
                                        createTextVNode("Record")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    key: "submit",
                                    type: "primary",
                                    loading: _ctx.loading,
                                    onClick: _ctx.handleOk
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Record")
                                    ]),
                                    _: 1
                                  }, 8, ["loading", "onClick"])
                                ];
                              }
                            }),
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_card, { style: { "width": "470px", "height": "140px" } }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_row, null, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`<b${_scopeId8}>Amount received</b><p style="${ssrRenderStyle({ "margin-bottom": "0px" })}"${_scopeId8}>Remaining balance ₹0.00</p>`);
                                                } else {
                                                  return [
                                                    createVNode("b", null, "Amount received"),
                                                    createVNode("p", { style: { "margin-bottom": "0px" } }, "Remaining balance ₹0.00")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, { name: "area_loc" }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_input, {
                                                          value: _ctx.value,
                                                          "onUpdate:value": ($event) => _ctx.value = $event,
                                                          placeholder: ""
                                                        }, null, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_input, {
                                                            value: _ctx.value,
                                                            "onUpdate:value": ($event) => _ctx.value = $event,
                                                            placeholder: ""
                                                          }, null, 8, ["value", "onUpdate:value"])
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, {
                                                          value: _ctx.value,
                                                          "onUpdate:value": ($event) => _ctx.value = $event,
                                                          placeholder: ""
                                                        }, null, 8, ["value", "onUpdate:value"])
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_col, { span: 12 }, {
                                                default: withCtx(() => [
                                                  createVNode("b", null, "Amount received"),
                                                  createVNode("p", { style: { "margin-bottom": "0px" } }, "Remaining balance ₹0.00")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 12 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, {
                                                        value: _ctx.value,
                                                        "onUpdate:value": ($event) => _ctx.value = $event,
                                                        placeholder: ""
                                                      }, null, 8, ["value", "onUpdate:value"])
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_row, null, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`<b${_scopeId8}>Discount</b>`);
                                                } else {
                                                  return [
                                                    createVNode("b", null, "Discount")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, { name: "area_loc" }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_input, {
                                                          value: _ctx.value,
                                                          "onUpdate:value": ($event) => _ctx.value = $event,
                                                          placeholder: ""
                                                        }, null, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_input, {
                                                            value: _ctx.value,
                                                            "onUpdate:value": ($event) => _ctx.value = $event,
                                                            placeholder: ""
                                                          }, null, 8, ["value", "onUpdate:value"])
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, {
                                                          value: _ctx.value,
                                                          "onUpdate:value": ($event) => _ctx.value = $event,
                                                          placeholder: ""
                                                        }, null, 8, ["value", "onUpdate:value"])
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_col, { span: 12 }, {
                                                default: withCtx(() => [
                                                  createVNode("b", null, "Discount")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 12 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, {
                                                        value: _ctx.value,
                                                        "onUpdate:value": ($event) => _ctx.value = $event,
                                                        placeholder: ""
                                                      }, null, 8, ["value", "onUpdate:value"])
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_row, null, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_col, { span: 12 }, {
                                              default: withCtx(() => [
                                                createVNode("b", null, "Amount received"),
                                                createVNode("p", { style: { "margin-bottom": "0px" } }, "Remaining balance ₹0.00")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 12 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.value,
                                                      "onUpdate:value": ($event) => _ctx.value = $event,
                                                      placeholder: ""
                                                    }, null, 8, ["value", "onUpdate:value"])
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_row, null, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_col, { span: 12 }, {
                                              default: withCtx(() => [
                                                createVNode("b", null, "Discount")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 12 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.value,
                                                      "onUpdate:value": ($event) => _ctx.value = $event,
                                                      placeholder: ""
                                                    }, null, 8, ["value", "onUpdate:value"])
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_card, { style: { "width": "470px", "margin-top": "12px", "height": "260px" } }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_row, null, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`<b${_scopeId8}>Payment Date</b>`);
                                                } else {
                                                  return [
                                                    createVNode("b", null, "Payment Date")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, { name: "area_loc" }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_date_picker, {
                                                          "value-format": "YYYY-MM-DD",
                                                          style: { "width": "100%" },
                                                          "\\\\v-model:value": "formState.doj"
                                                        }, null, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_date_picker, {
                                                            "value-format": "YYYY-MM-DD",
                                                            style: { "width": "100%" },
                                                            "\\\\v-model:value": "formState.doj"
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_date_picker, {
                                                          "value-format": "YYYY-MM-DD",
                                                          style: { "width": "100%" },
                                                          "\\\\v-model:value": "formState.doj"
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_col, { span: 12 }, {
                                                default: withCtx(() => [
                                                  createVNode("b", null, "Payment Date")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 12 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_date_picker, {
                                                        "value-format": "YYYY-MM-DD",
                                                        style: { "width": "100%" },
                                                        "\\\\v-model:value": "formState.doj"
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_row, null, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`<b${_scopeId8}>Paid Into</b>`);
                                                } else {
                                                  return [
                                                    createVNode("b", null, "Paid Into")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, { name: "area_loc" }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_input, {
                                                          value: _ctx.value,
                                                          "onUpdate:value": ($event) => _ctx.value = $event,
                                                          placeholder: ""
                                                        }, null, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_input, {
                                                            value: _ctx.value,
                                                            "onUpdate:value": ($event) => _ctx.value = $event,
                                                            placeholder: ""
                                                          }, null, 8, ["value", "onUpdate:value"])
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, {
                                                          value: _ctx.value,
                                                          "onUpdate:value": ($event) => _ctx.value = $event,
                                                          placeholder: ""
                                                        }, null, 8, ["value", "onUpdate:value"])
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_col, { span: 12 }, {
                                                default: withCtx(() => [
                                                  createVNode("b", null, "Paid Into")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 12 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, {
                                                        value: _ctx.value,
                                                        "onUpdate:value": ($event) => _ctx.value = $event,
                                                        placeholder: ""
                                                      }, null, 8, ["value", "onUpdate:value"])
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_row, null, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`<b${_scopeId8}>Method</b>`);
                                                } else {
                                                  return [
                                                    createVNode("b", null, "Method")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, { name: "gender" }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_select, { placeholder: "Select Method" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(ssrRenderComponent(_component_a_select_option, { value: "Cash" }, {
                                                                default: withCtx((_11, _push12, _parent12, _scopeId11) => {
                                                                  if (_push12) {
                                                                    _push12(`Cash`);
                                                                  } else {
                                                                    return [
                                                                      createTextVNode("Cash")
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 1
                                                              }, _parent11, _scopeId10));
                                                              _push11(ssrRenderComponent(_component_a_select_option, { value: "Check" }, {
                                                                default: withCtx((_11, _push12, _parent12, _scopeId11) => {
                                                                  if (_push12) {
                                                                    _push12(`Check`);
                                                                  } else {
                                                                    return [
                                                                      createTextVNode("Check")
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 1
                                                              }, _parent11, _scopeId10));
                                                              _push11(ssrRenderComponent(_component_a_select_option, { value: "Electronic" }, {
                                                                default: withCtx((_11, _push12, _parent12, _scopeId11) => {
                                                                  if (_push12) {
                                                                    _push12(`Electronic`);
                                                                  } else {
                                                                    return [
                                                                      createTextVNode("Electronic")
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 1
                                                              }, _parent11, _scopeId10));
                                                              _push11(ssrRenderComponent(_component_a_select_option, { value: "creditcard" }, {
                                                                default: withCtx((_11, _push12, _parent12, _scopeId11) => {
                                                                  if (_push12) {
                                                                    _push12(`Credit/Debit Card`);
                                                                  } else {
                                                                    return [
                                                                      createTextVNode("Credit/Debit Card")
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 1
                                                              }, _parent11, _scopeId10));
                                                            } else {
                                                              return [
                                                                createVNode(_component_a_select_option, { value: "Cash" }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode("Cash")
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode(_component_a_select_option, { value: "Check" }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode("Check")
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode(_component_a_select_option, { value: "Electronic" }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode("Electronic")
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode(_component_a_select_option, { value: "creditcard" }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode("Credit/Debit Card")
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_select, { placeholder: "Select Method" }, {
                                                            default: withCtx(() => [
                                                              createVNode(_component_a_select_option, { value: "Cash" }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode("Cash")
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode(_component_a_select_option, { value: "Check" }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode("Check")
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode(_component_a_select_option, { value: "Electronic" }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode("Electronic")
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode(_component_a_select_option, { value: "creditcard" }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode("Credit/Debit Card")
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, { name: "gender" }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_select, { placeholder: "Select Method" }, {
                                                          default: withCtx(() => [
                                                            createVNode(_component_a_select_option, { value: "Cash" }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("Cash")
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode(_component_a_select_option, { value: "Check" }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("Check")
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode(_component_a_select_option, { value: "Electronic" }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("Electronic")
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode(_component_a_select_option, { value: "creditcard" }, {
                                                              default: withCtx(() => [
                                                                createTextVNode("Credit/Debit Card")
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_col, { span: 12 }, {
                                                default: withCtx(() => [
                                                  createVNode("b", null, "Method")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 12 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, { name: "gender" }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_select, { placeholder: "Select Method" }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_a_select_option, { value: "Cash" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Cash")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_select_option, { value: "Check" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Check")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_select_option, { value: "Electronic" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Electronic")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_select_option, { value: "creditcard" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Credit/Debit Card")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_row, null, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`<b${_scopeId8}>Reference(optional)</b>`);
                                                } else {
                                                  return [
                                                    createVNode("b", null, "Reference(optional)")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_form_item, { name: "area_loc" }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_input, {
                                                          value: _ctx.value,
                                                          "onUpdate:value": ($event) => _ctx.value = $event,
                                                          placeholder: ""
                                                        }, null, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_input, {
                                                            value: _ctx.value,
                                                            "onUpdate:value": ($event) => _ctx.value = $event,
                                                            placeholder: ""
                                                          }, null, 8, ["value", "onUpdate:value"])
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, {
                                                          value: _ctx.value,
                                                          "onUpdate:value": ($event) => _ctx.value = $event,
                                                          placeholder: ""
                                                        }, null, 8, ["value", "onUpdate:value"])
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_col, { span: 12 }, {
                                                default: withCtx(() => [
                                                  createVNode("b", null, "Reference(optional)")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_col, { span: 12 }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, {
                                                        value: _ctx.value,
                                                        "onUpdate:value": ($event) => _ctx.value = $event,
                                                        placeholder: ""
                                                      }, null, 8, ["value", "onUpdate:value"])
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_row, null, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_col, { span: 12 }, {
                                              default: withCtx(() => [
                                                createVNode("b", null, "Payment Date")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 12 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_date_picker, {
                                                      "value-format": "YYYY-MM-DD",
                                                      style: { "width": "100%" },
                                                      "\\\\v-model:value": "formState.doj"
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_row, null, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_col, { span: 12 }, {
                                              default: withCtx(() => [
                                                createVNode("b", null, "Paid Into")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 12 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.value,
                                                      "onUpdate:value": ($event) => _ctx.value = $event,
                                                      placeholder: ""
                                                    }, null, 8, ["value", "onUpdate:value"])
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_row, null, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_col, { span: 12 }, {
                                              default: withCtx(() => [
                                                createVNode("b", null, "Method")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 12 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, { name: "gender" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_select, { placeholder: "Select Method" }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_select_option, { value: "Cash" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Cash")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_select_option, { value: "Check" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Check")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_select_option, { value: "Electronic" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Electronic")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_select_option, { value: "creditcard" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Credit/Debit Card")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_row, null, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_col, { span: 12 }, {
                                              default: withCtx(() => [
                                                createVNode("b", null, "Reference(optional)")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_col, { span: 12 }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.value,
                                                      "onUpdate:value": ($event) => _ctx.value = $event,
                                                      placeholder: ""
                                                    }, null, 8, ["value", "onUpdate:value"])
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_card, { style: { "width": "470px", "height": "140px" } }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_row, null, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_col, { span: 12 }, {
                                            default: withCtx(() => [
                                              createVNode("b", null, "Amount received"),
                                              createVNode("p", { style: { "margin-bottom": "0px" } }, "Remaining balance ₹0.00")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 12 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.value,
                                                    "onUpdate:value": ($event) => _ctx.value = $event,
                                                    placeholder: ""
                                                  }, null, 8, ["value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_row, null, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_col, { span: 12 }, {
                                            default: withCtx(() => [
                                              createVNode("b", null, "Discount")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 12 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.value,
                                                    "onUpdate:value": ($event) => _ctx.value = $event,
                                                    placeholder: ""
                                                  }, null, 8, ["value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_card, { style: { "width": "470px", "margin-top": "12px", "height": "260px" } }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_row, null, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_col, { span: 12 }, {
                                            default: withCtx(() => [
                                              createVNode("b", null, "Payment Date")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 12 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_date_picker, {
                                                    "value-format": "YYYY-MM-DD",
                                                    style: { "width": "100%" },
                                                    "\\\\v-model:value": "formState.doj"
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_row, null, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_col, { span: 12 }, {
                                            default: withCtx(() => [
                                              createVNode("b", null, "Paid Into")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 12 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.value,
                                                    "onUpdate:value": ($event) => _ctx.value = $event,
                                                    placeholder: ""
                                                  }, null, 8, ["value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_row, null, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_col, { span: 12 }, {
                                            default: withCtx(() => [
                                              createVNode("b", null, "Method")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 12 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, { name: "gender" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select, { placeholder: "Select Method" }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_select_option, { value: "Cash" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Cash")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_select_option, { value: "Check" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Check")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_select_option, { value: "Electronic" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Electronic")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_select_option, { value: "creditcard" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Credit/Debit Card")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_row, null, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_col, { span: 12 }, {
                                            default: withCtx(() => [
                                              createVNode("b", null, "Reference(optional)")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_col, { span: 12 }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_form_item, { name: "area_loc" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.value,
                                                    "onUpdate:value": ($event) => _ctx.value = $event,
                                                    placeholder: ""
                                                  }, null, 8, ["value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_steps, {
                              current: 1,
                              size: "small",
                              style: { "margin-bottom": "42px" }
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_step, { title: "Created" }),
                                createVNode(_component_a_step, { title: "Send" }),
                                createVNode(_component_a_step, { title: "Viewed" }),
                                createVNode(_component_a_step, { title: "Paid" })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_row, { style: { "margin-top": "20px" } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode("b", null, "Amount Paid"),
                                    createVNode("p", null, "0.00")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode("b", null, "Amount Outstanding"),
                                    createVNode("p", null, "0.00")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_button, {
                              style: { "width": "100%", "margin-top": "15px" },
                              type: "primary",
                              onClick: withModifiers(() => {
                                _ctx.menu_visible = true;
                              }, ["stop"])
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Record Payment")
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(_component_a_modal, {
                              visible: _ctx.menu_visible,
                              "onUpdate:visible": ($event) => _ctx.menu_visible = $event,
                              onClose: ($event) => _ctx.menu_visible = false,
                              title: "Record Payment",
                              onOk: _ctx.handleOk
                            }, {
                              footer: withCtx(() => [
                                createVNode(_component_a_button, {
                                  key: "submit",
                                  type: "primary",
                                  loading: _ctx.loading,
                                  onClick: _ctx.handleOk
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Record")
                                  ]),
                                  _: 1
                                }, 8, ["loading", "onClick"])
                              ]),
                              default: withCtx(() => [
                                createVNode(_component_a_card, { style: { "width": "470px", "height": "140px" } }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_row, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode("b", null, "Amount received"),
                                            createVNode("p", { style: { "margin-bottom": "0px" } }, "Remaining balance ₹0.00")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, { name: "area_loc" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.value,
                                                  "onUpdate:value": ($event) => _ctx.value = $event,
                                                  placeholder: ""
                                                }, null, 8, ["value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_row, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode("b", null, "Discount")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, { name: "area_loc" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.value,
                                                  "onUpdate:value": ($event) => _ctx.value = $event,
                                                  placeholder: ""
                                                }, null, 8, ["value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_card, { style: { "width": "470px", "margin-top": "12px", "height": "260px" } }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_row, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode("b", null, "Payment Date")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, { name: "area_loc" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_date_picker, {
                                                  "value-format": "YYYY-MM-DD",
                                                  style: { "width": "100%" },
                                                  "\\\\v-model:value": "formState.doj"
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_row, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode("b", null, "Paid Into")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, { name: "area_loc" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.value,
                                                  "onUpdate:value": ($event) => _ctx.value = $event,
                                                  placeholder: ""
                                                }, null, 8, ["value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_row, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode("b", null, "Method")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, { name: "gender" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select, { placeholder: "Select Method" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_select_option, { value: "Cash" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Cash")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, { value: "Check" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Check")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, { value: "Electronic" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Electronic")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, { value: "creditcard" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Credit/Debit Card")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_row, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode("b", null, "Reference(optional)")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, { span: 12 }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, { name: "area_loc" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.value,
                                                  "onUpdate:value": ($event) => _ctx.value = $event,
                                                  placeholder: ""
                                                }, null, 8, ["value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["visible", "onUpdate:visible", "onClose", "onOk"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_card, { style: { "width": "360px", "margin-top": "4px" } }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_row, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<p${_scopeId6}>`);
                                      _push7(ssrRenderComponent(_component_MailOutlined, { style: { "margin-right": "12px" } }, null, _parent7, _scopeId6));
                                      _push7(`Email</p><p${_scopeId6}>`);
                                      _push7(ssrRenderComponent(_component_EditOutlined, { style: { "margin-right": "12px" } }, null, _parent7, _scopeId6));
                                      _push7(`Edit</p><p${_scopeId6}>`);
                                      _push7(ssrRenderComponent(_component_CopyOutlined, { style: { "margin-right": "12px" } }, null, _parent7, _scopeId6));
                                      _push7(`Copy</p><p style="${ssrRenderStyle({ "cursor": "pointer" })}"${_scopeId6}>`);
                                      _push7(ssrRenderComponent(_component_DownloadOutlined, { style: { "margin-right": "12px" } }, null, _parent7, _scopeId6));
                                      _push7(`Download</p><p${_scopeId6}>`);
                                      _push7(ssrRenderComponent(_component_DisconnectOutlined, { style: { "margin-right": "12px" } }, null, _parent7, _scopeId6));
                                      _push7(`Void</p>`);
                                    } else {
                                      return [
                                        createVNode("p", null, [
                                          createVNode(_component_MailOutlined, { style: { "margin-right": "12px" } }),
                                          createTextVNode("Email")
                                        ]),
                                        createVNode("p", null, [
                                          createVNode(_component_EditOutlined, { style: { "margin-right": "12px" } }),
                                          createTextVNode("Edit")
                                        ]),
                                        createVNode("p", null, [
                                          createVNode(_component_CopyOutlined, { style: { "margin-right": "12px" } }),
                                          createTextVNode("Copy")
                                        ]),
                                        createVNode("p", {
                                          style: { "cursor": "pointer" },
                                          onClick: withModifiers(() => {
                                            _ctx.download_visible = true;
                                          }, ["stop"])
                                        }, [
                                          createVNode(_component_DownloadOutlined, { style: { "margin-right": "12px" } }),
                                          createTextVNode("Download")
                                        ], 8, ["onClick"]),
                                        createVNode("p", null, [
                                          createVNode(_component_DisconnectOutlined, { style: { "margin-right": "12px" } }),
                                          createTextVNode("Void")
                                        ])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<p${_scopeId6}>`);
                                      _push7(ssrRenderComponent(_component_PrinterOutlined, { style: { "margin-right": "12px" } }, null, _parent7, _scopeId6));
                                      _push7(`Print Preview</p><p${_scopeId6}>`);
                                      _push7(ssrRenderComponent(_component_ShareAltOutlined, { style: { "margin-right": "12px" } }, null, _parent7, _scopeId6));
                                      _push7(`Share Link</p><p${_scopeId6}>`);
                                      _push7(ssrRenderComponent(_component_FileTextOutlined, { style: { "margin-right": "12px" } }, null, _parent7, _scopeId6));
                                      _push7(`Add Credit note</p><p${_scopeId6}>`);
                                      _push7(ssrRenderComponent(_component_PaperClipOutlined, { style: { "margin-right": "12px" } }, null, _parent7, _scopeId6));
                                      _push7(`Add File</p>`);
                                    } else {
                                      return [
                                        createVNode("p", null, [
                                          createVNode(_component_PrinterOutlined, { style: { "margin-right": "12px" } }),
                                          createTextVNode("Print Preview")
                                        ]),
                                        createVNode("p", null, [
                                          createVNode(_component_ShareAltOutlined, { style: { "margin-right": "12px" } }),
                                          createTextVNode("Share Link")
                                        ]),
                                        createVNode("p", null, [
                                          createVNode(_component_FileTextOutlined, { style: { "margin-right": "12px" } }),
                                          createTextVNode("Add Credit note")
                                        ]),
                                        createVNode("p", null, [
                                          createVNode(_component_PaperClipOutlined, { style: { "margin-right": "12px" } }),
                                          createTextVNode("Add File")
                                        ])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("p", null, [
                                        createVNode(_component_MailOutlined, { style: { "margin-right": "12px" } }),
                                        createTextVNode("Email")
                                      ]),
                                      createVNode("p", null, [
                                        createVNode(_component_EditOutlined, { style: { "margin-right": "12px" } }),
                                        createTextVNode("Edit")
                                      ]),
                                      createVNode("p", null, [
                                        createVNode(_component_CopyOutlined, { style: { "margin-right": "12px" } }),
                                        createTextVNode("Copy")
                                      ]),
                                      createVNode("p", {
                                        style: { "cursor": "pointer" },
                                        onClick: withModifiers(() => {
                                          _ctx.download_visible = true;
                                        }, ["stop"])
                                      }, [
                                        createVNode(_component_DownloadOutlined, { style: { "margin-right": "12px" } }),
                                        createTextVNode("Download")
                                      ], 8, ["onClick"]),
                                      createVNode("p", null, [
                                        createVNode(_component_DisconnectOutlined, { style: { "margin-right": "12px" } }),
                                        createTextVNode("Void")
                                      ])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("p", null, [
                                        createVNode(_component_PrinterOutlined, { style: { "margin-right": "12px" } }),
                                        createTextVNode("Print Preview")
                                      ]),
                                      createVNode("p", null, [
                                        createVNode(_component_ShareAltOutlined, { style: { "margin-right": "12px" } }),
                                        createTextVNode("Share Link")
                                      ]),
                                      createVNode("p", null, [
                                        createVNode(_component_FileTextOutlined, { style: { "margin-right": "12px" } }),
                                        createTextVNode("Add Credit note")
                                      ]),
                                      createVNode("p", null, [
                                        createVNode(_component_PaperClipOutlined, { style: { "margin-right": "12px" } }),
                                        createTextVNode("Add File")
                                      ])
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_row, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode("p", null, [
                                      createVNode(_component_MailOutlined, { style: { "margin-right": "12px" } }),
                                      createTextVNode("Email")
                                    ]),
                                    createVNode("p", null, [
                                      createVNode(_component_EditOutlined, { style: { "margin-right": "12px" } }),
                                      createTextVNode("Edit")
                                    ]),
                                    createVNode("p", null, [
                                      createVNode(_component_CopyOutlined, { style: { "margin-right": "12px" } }),
                                      createTextVNode("Copy")
                                    ]),
                                    createVNode("p", {
                                      style: { "cursor": "pointer" },
                                      onClick: withModifiers(() => {
                                        _ctx.download_visible = true;
                                      }, ["stop"])
                                    }, [
                                      createVNode(_component_DownloadOutlined, { style: { "margin-right": "12px" } }),
                                      createTextVNode("Download")
                                    ], 8, ["onClick"]),
                                    createVNode("p", null, [
                                      createVNode(_component_DisconnectOutlined, { style: { "margin-right": "12px" } }),
                                      createTextVNode("Void")
                                    ])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode("p", null, [
                                      createVNode(_component_PrinterOutlined, { style: { "margin-right": "12px" } }),
                                      createTextVNode("Print Preview")
                                    ]),
                                    createVNode("p", null, [
                                      createVNode(_component_ShareAltOutlined, { style: { "margin-right": "12px" } }),
                                      createTextVNode("Share Link")
                                    ]),
                                    createVNode("p", null, [
                                      createVNode(_component_FileTextOutlined, { style: { "margin-right": "12px" } }),
                                      createTextVNode("Add Credit note")
                                    ]),
                                    createVNode("p", null, [
                                      createVNode(_component_PaperClipOutlined, { style: { "margin-right": "12px" } }),
                                      createTextVNode("Add File")
                                    ])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_card, { style: { "width": "360px", "margin-top": "4px" } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_steps, {
                            current: 1,
                            size: "small",
                            style: { "margin-bottom": "42px" }
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_step, { title: "Created" }),
                              createVNode(_component_a_step, { title: "Send" }),
                              createVNode(_component_a_step, { title: "Viewed" }),
                              createVNode(_component_a_step, { title: "Paid" })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_row, { style: { "margin-top": "20px" } }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode("b", null, "Amount Paid"),
                                  createVNode("p", null, "0.00")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode("b", null, "Amount Outstanding"),
                                  createVNode("p", null, "0.00")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_button, {
                            style: { "width": "100%", "margin-top": "15px" },
                            type: "primary",
                            onClick: withModifiers(() => {
                              _ctx.menu_visible = true;
                            }, ["stop"])
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Record Payment")
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(_component_a_modal, {
                            visible: _ctx.menu_visible,
                            "onUpdate:visible": ($event) => _ctx.menu_visible = $event,
                            onClose: ($event) => _ctx.menu_visible = false,
                            title: "Record Payment",
                            onOk: _ctx.handleOk
                          }, {
                            footer: withCtx(() => [
                              createVNode(_component_a_button, {
                                key: "submit",
                                type: "primary",
                                loading: _ctx.loading,
                                onClick: _ctx.handleOk
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Record")
                                ]),
                                _: 1
                              }, 8, ["loading", "onClick"])
                            ]),
                            default: withCtx(() => [
                              createVNode(_component_a_card, { style: { "width": "470px", "height": "140px" } }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_row, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode("b", null, "Amount received"),
                                          createVNode("p", { style: { "margin-bottom": "0px" } }, "Remaining balance ₹0.00")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, { name: "area_loc" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.value,
                                                "onUpdate:value": ($event) => _ctx.value = $event,
                                                placeholder: ""
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_row, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode("b", null, "Discount")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, { name: "area_loc" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.value,
                                                "onUpdate:value": ($event) => _ctx.value = $event,
                                                placeholder: ""
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_card, { style: { "width": "470px", "margin-top": "12px", "height": "260px" } }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_row, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode("b", null, "Payment Date")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, { name: "area_loc" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_date_picker, {
                                                "value-format": "YYYY-MM-DD",
                                                style: { "width": "100%" },
                                                "\\\\v-model:value": "formState.doj"
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_row, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode("b", null, "Paid Into")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, { name: "area_loc" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.value,
                                                "onUpdate:value": ($event) => _ctx.value = $event,
                                                placeholder: ""
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_row, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode("b", null, "Method")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, { name: "gender" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select, { placeholder: "Select Method" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select_option, { value: "Cash" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Cash")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, { value: "Check" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Check")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, { value: "Electronic" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Electronic")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, { value: "creditcard" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Credit/Debit Card")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_row, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode("b", null, "Reference(optional)")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, { span: 12 }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, { name: "area_loc" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.value,
                                                "onUpdate:value": ($event) => _ctx.value = $event,
                                                placeholder: ""
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["visible", "onUpdate:visible", "onClose", "onOk"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_card, { style: { "width": "360px", "margin-top": "4px" } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_row, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode("p", null, [
                                    createVNode(_component_MailOutlined, { style: { "margin-right": "12px" } }),
                                    createTextVNode("Email")
                                  ]),
                                  createVNode("p", null, [
                                    createVNode(_component_EditOutlined, { style: { "margin-right": "12px" } }),
                                    createTextVNode("Edit")
                                  ]),
                                  createVNode("p", null, [
                                    createVNode(_component_CopyOutlined, { style: { "margin-right": "12px" } }),
                                    createTextVNode("Copy")
                                  ]),
                                  createVNode("p", {
                                    style: { "cursor": "pointer" },
                                    onClick: withModifiers(() => {
                                      _ctx.download_visible = true;
                                    }, ["stop"])
                                  }, [
                                    createVNode(_component_DownloadOutlined, { style: { "margin-right": "12px" } }),
                                    createTextVNode("Download")
                                  ], 8, ["onClick"]),
                                  createVNode("p", null, [
                                    createVNode(_component_DisconnectOutlined, { style: { "margin-right": "12px" } }),
                                    createTextVNode("Void")
                                  ])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode("p", null, [
                                    createVNode(_component_PrinterOutlined, { style: { "margin-right": "12px" } }),
                                    createTextVNode("Print Preview")
                                  ]),
                                  createVNode("p", null, [
                                    createVNode(_component_ShareAltOutlined, { style: { "margin-right": "12px" } }),
                                    createTextVNode("Share Link")
                                  ]),
                                  createVNode("p", null, [
                                    createVNode(_component_FileTextOutlined, { style: { "margin-right": "12px" } }),
                                    createTextVNode("Add Credit note")
                                  ]),
                                  createVNode("p", null, [
                                    createVNode(_component_PaperClipOutlined, { style: { "margin-right": "12px" } }),
                                    createTextVNode("Add File")
                                  ])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_col, { style: { margin: "5px 16px", padding: "24px", background: "#fff", minHeight: "calc(100vh - 115px)", width: "65%" } }, {
                  default: withCtx(() => [
                    createVNode("div", { id: "element-to-convert" }, [
                      createVNode(_component_a_layout_content, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_row, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, { span: 24 }, {
                                default: withCtx(() => [
                                  createVNode("p", null, [
                                    createVNode("b", null, "To:"),
                                    createTextVNode(" uini(vgvvgvgvg123)")
                                  ])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_row, { style: { "width": "500px" } }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, { span: 8 }, {
                                default: withCtx(() => [
                                  createVNode("b", null, "Invoice Address"),
                                  createVNode("p", { style: { "margin-bottom": "0px" } }, "xcx"),
                                  createVNode("p", { style: { "margin-bottom": "0px" } }, "xc"),
                                  createVNode("p", { style: { "margin-bottom": "0px" } }, "xc xc 625007"),
                                  createVNode("p", null, "India")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 8 }, {
                                default: withCtx(() => [
                                  createVNode("b", null, "Invoice Date"),
                                  createVNode("p", { style: { "margin-bottom": "0px" } }, "Feb 28,2023")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 8 }, {
                                default: withCtx(() => [
                                  createVNode("b", null, "Due Date"),
                                  createVNode("p", { style: { "margin-bottom": "0px" } }, "Mar 30,2023"),
                                  createVNode("p", { style: { "margin-bottom": "0px" } }, "Due in 30 days")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_table, {
                            columns: _ctx.columns,
                            "data-source": _ctx.data,
                            bordered: ""
                          }, {
                            name: withCtx(({ text }) => [
                              createVNode("a", null, toDisplayString(text), 1)
                            ]),
                            _: 1
                          }, 8, ["columns", "data-source"]),
                          createVNode(_component_a_card, {
                            style: { "width": "380px", "float": "right", "margin-top": "15px" },
                            bordered: ""
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_row, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("b", null, "Sub Total")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createTextVNode("₹ 120.00")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_row, { style: { "margin-top": "15px", "margin-bottom": "15px" } }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("b", null, "Tax Breakdown"),
                                      createVNode("p", { style: { "margin-bottom": "0px" } }, "No Tax: 120.00 @ 0.00%")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createTextVNode("0.00")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_divider, { style: { "height": "2px", "background-color": "#A9A9A9" } }),
                              createVNode(_component_a_row, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("b", null, "Total")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("b", null, "₹ 120.00")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_divider, { style: { "height": "2px", "background-color": "#A9A9A9" } })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  _: 1
                }, 8, ["style"]),
                createVNode(_component_a_col, { flex: "0 1 300px" }, {
                  default: withCtx(() => [
                    createVNode(_component_a_card, { style: { "width": "360px", "margin-top": "4px" } }, {
                      default: withCtx(() => [
                        createVNode(_component_a_steps, {
                          current: 1,
                          size: "small",
                          style: { "margin-bottom": "42px" }
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_step, { title: "Created" }),
                            createVNode(_component_a_step, { title: "Send" }),
                            createVNode(_component_a_step, { title: "Viewed" }),
                            createVNode(_component_a_step, { title: "Paid" })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_row, { style: { "margin-top": "20px" } }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode("b", null, "Amount Paid"),
                                createVNode("p", null, "0.00")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode("b", null, "Amount Outstanding"),
                                createVNode("p", null, "0.00")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_button, {
                          style: { "width": "100%", "margin-top": "15px" },
                          type: "primary",
                          onClick: withModifiers(() => {
                            _ctx.menu_visible = true;
                          }, ["stop"])
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Record Payment")
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_component_a_modal, {
                          visible: _ctx.menu_visible,
                          "onUpdate:visible": ($event) => _ctx.menu_visible = $event,
                          onClose: ($event) => _ctx.menu_visible = false,
                          title: "Record Payment",
                          onOk: _ctx.handleOk
                        }, {
                          footer: withCtx(() => [
                            createVNode(_component_a_button, {
                              key: "submit",
                              type: "primary",
                              loading: _ctx.loading,
                              onClick: _ctx.handleOk
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Record")
                              ]),
                              _: 1
                            }, 8, ["loading", "onClick"])
                          ]),
                          default: withCtx(() => [
                            createVNode(_component_a_card, { style: { "width": "470px", "height": "140px" } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_row, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode("b", null, "Amount received"),
                                        createVNode("p", { style: { "margin-bottom": "0px" } }, "Remaining balance ₹0.00")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, { name: "area_loc" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: _ctx.value,
                                              "onUpdate:value": ($event) => _ctx.value = $event,
                                              placeholder: ""
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_row, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode("b", null, "Discount")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, { name: "area_loc" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: _ctx.value,
                                              "onUpdate:value": ($event) => _ctx.value = $event,
                                              placeholder: ""
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_card, { style: { "width": "470px", "margin-top": "12px", "height": "260px" } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_row, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode("b", null, "Payment Date")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, { name: "area_loc" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_date_picker, {
                                              "value-format": "YYYY-MM-DD",
                                              style: { "width": "100%" },
                                              "\\\\v-model:value": "formState.doj"
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_row, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode("b", null, "Paid Into")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, { name: "area_loc" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: _ctx.value,
                                              "onUpdate:value": ($event) => _ctx.value = $event,
                                              placeholder: ""
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_row, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode("b", null, "Method")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, { name: "gender" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, { placeholder: "Select Method" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select_option, { value: "Cash" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Cash")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_select_option, { value: "Check" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Check")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_select_option, { value: "Electronic" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Electronic")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_select_option, { value: "creditcard" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Credit/Debit Card")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_row, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode("b", null, "Reference(optional)")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, { span: 12 }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, { name: "area_loc" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: _ctx.value,
                                              "onUpdate:value": ($event) => _ctx.value = $event,
                                              placeholder: ""
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 8, ["visible", "onUpdate:visible", "onClose", "onOk"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_card, { style: { "width": "360px", "margin-top": "4px" } }, {
                      default: withCtx(() => [
                        createVNode(_component_a_row, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode("p", null, [
                                  createVNode(_component_MailOutlined, { style: { "margin-right": "12px" } }),
                                  createTextVNode("Email")
                                ]),
                                createVNode("p", null, [
                                  createVNode(_component_EditOutlined, { style: { "margin-right": "12px" } }),
                                  createTextVNode("Edit")
                                ]),
                                createVNode("p", null, [
                                  createVNode(_component_CopyOutlined, { style: { "margin-right": "12px" } }),
                                  createTextVNode("Copy")
                                ]),
                                createVNode("p", {
                                  style: { "cursor": "pointer" },
                                  onClick: withModifiers(() => {
                                    _ctx.download_visible = true;
                                  }, ["stop"])
                                }, [
                                  createVNode(_component_DownloadOutlined, { style: { "margin-right": "12px" } }),
                                  createTextVNode("Download")
                                ], 8, ["onClick"]),
                                createVNode("p", null, [
                                  createVNode(_component_DisconnectOutlined, { style: { "margin-right": "12px" } }),
                                  createTextVNode("Void")
                                ])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode("p", null, [
                                  createVNode(_component_PrinterOutlined, { style: { "margin-right": "12px" } }),
                                  createTextVNode("Print Preview")
                                ]),
                                createVNode("p", null, [
                                  createVNode(_component_ShareAltOutlined, { style: { "margin-right": "12px" } }),
                                  createTextVNode("Share Link")
                                ]),
                                createVNode("p", null, [
                                  createVNode(_component_FileTextOutlined, { style: { "margin-right": "12px" } }),
                                  createTextVNode("Add Credit note")
                                ]),
                                createVNode("p", null, [
                                  createVNode(_component_PaperClipOutlined, { style: { "margin-right": "12px" } }),
                                  createTextVNode("Add File")
                                ])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_modal, {
          visible: _ctx.download_visible,
          "onUpdate:visible": ($event) => _ctx.download_visible = $event,
          onClose: ($event) => _ctx.download_visible = false,
          title: "Sending this invoice?",
          onOk: _ctx.handleOk
        }, {
          footer: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_button, {
                key: "submit",
                type: "primary",
                loading: _ctx.loading,
                onClick: _ctx.exportToPDF
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(`Make as sent`);
                  } else {
                    return [
                      createTextVNode("Make as sent")
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_button, {
                key: "back",
                onClick: ($event) => _ctx.download_visible = false
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(`Leave as unsent`);
                  } else {
                    return [
                      createTextVNode("Leave as unsent")
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_button, {
                  key: "submit",
                  type: "primary",
                  loading: _ctx.loading,
                  onClick: _ctx.exportToPDF
                }, {
                  default: withCtx(() => [
                    createTextVNode("Make as sent")
                  ]),
                  _: 1
                }, 8, ["loading", "onClick"]),
                createVNode(_component_a_button, {
                  key: "back",
                  onClick: ($event) => _ctx.download_visible = false
                }, {
                  default: withCtx(() => [
                    createTextVNode("Leave as unsent")
                  ]),
                  _: 1
                }, 8, ["onClick"])
              ];
            }
          }),
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(`<p${_scopeId2}>Would you like to make this invoice as sent?</p>`);
            } else {
              return [
                createVNode("p", null, "Would you like to make this invoice as sent?")
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_affix, { "offset-top": 0 }, {
            default: withCtx(() => [
              createVNode(_component_a_page_header, {
                ghost: false,
                title: "Sales Invoice",
                onBack: () => _ctx.$inertia.visit(_ctx.route("sales.create"))
              }, {
                extra: withCtx(() => [
                  createVNode(_component_a_button, { type: "primary" }, {
                    default: withCtx(() => [
                      createTextVNode("Save")
                    ]),
                    _: 1
                  })
                ]),
                tags: withCtx(() => [
                  createVNode(_component_a_tag, { color: "" }, {
                    default: withCtx(() => [
                      createTextVNode("AWAITING PAYMENT")
                    ]),
                    _: 1
                  })
                ]),
                default: withCtx(() => [
                  createTextVNode(),
                  createVNode("p", { style: { "margin-left": "34px" } }, " View, edit or manage your Sales Invoice. "),
                  createVNode(_component_a_row, { class: "content" }, {
                    default: withCtx(() => [
                      createVNode("div", { style: { "flex": "1" } })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["onBack"])
            ]),
            _: 1
          }),
          _ctx.visible ? (openBlock(), createBlock(_component_a_alert, {
            key: 0,
            message: "Great! Invoice Created",
            type: "success",
            closable: "",
            "after-close": _ctx.handleClose,
            style: { margin: "12px 12px", width: "65%" }
          }, null, 8, ["after-close"])) : createCommentVNode("", true),
          createVNode(_component_a_row, { type: "flex" }, {
            default: withCtx(() => [
              createVNode(_component_a_col, { style: { margin: "5px 16px", padding: "24px", background: "#fff", minHeight: "calc(100vh - 115px)", width: "65%" } }, {
                default: withCtx(() => [
                  createVNode("div", { id: "element-to-convert" }, [
                    createVNode(_component_a_layout_content, null, {
                      default: withCtx(() => [
                        createVNode(_component_a_row, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, { span: 24 }, {
                              default: withCtx(() => [
                                createVNode("p", null, [
                                  createVNode("b", null, "To:"),
                                  createTextVNode(" uini(vgvvgvgvg123)")
                                ])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_row, { style: { "width": "500px" } }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, { span: 8 }, {
                              default: withCtx(() => [
                                createVNode("b", null, "Invoice Address"),
                                createVNode("p", { style: { "margin-bottom": "0px" } }, "xcx"),
                                createVNode("p", { style: { "margin-bottom": "0px" } }, "xc"),
                                createVNode("p", { style: { "margin-bottom": "0px" } }, "xc xc 625007"),
                                createVNode("p", null, "India")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 8 }, {
                              default: withCtx(() => [
                                createVNode("b", null, "Invoice Date"),
                                createVNode("p", { style: { "margin-bottom": "0px" } }, "Feb 28,2023")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 8 }, {
                              default: withCtx(() => [
                                createVNode("b", null, "Due Date"),
                                createVNode("p", { style: { "margin-bottom": "0px" } }, "Mar 30,2023"),
                                createVNode("p", { style: { "margin-bottom": "0px" } }, "Due in 30 days")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_table, {
                          columns: _ctx.columns,
                          "data-source": _ctx.data,
                          bordered: ""
                        }, {
                          name: withCtx(({ text }) => [
                            createVNode("a", null, toDisplayString(text), 1)
                          ]),
                          _: 1
                        }, 8, ["columns", "data-source"]),
                        createVNode(_component_a_card, {
                          style: { "width": "380px", "float": "right", "margin-top": "15px" },
                          bordered: ""
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_row, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode("b", null, "Sub Total")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createTextVNode("₹ 120.00")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_row, { style: { "margin-top": "15px", "margin-bottom": "15px" } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode("b", null, "Tax Breakdown"),
                                    createVNode("p", { style: { "margin-bottom": "0px" } }, "No Tax: 120.00 @ 0.00%")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createTextVNode("0.00")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_divider, { style: { "height": "2px", "background-color": "#A9A9A9" } }),
                            createVNode(_component_a_row, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode("b", null, "Total")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode("b", null, "₹ 120.00")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_divider, { style: { "height": "2px", "background-color": "#A9A9A9" } })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }, 8, ["style"]),
              createVNode(_component_a_col, { flex: "0 1 300px" }, {
                default: withCtx(() => [
                  createVNode(_component_a_card, { style: { "width": "360px", "margin-top": "4px" } }, {
                    default: withCtx(() => [
                      createVNode(_component_a_steps, {
                        current: 1,
                        size: "small",
                        style: { "margin-bottom": "42px" }
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_step, { title: "Created" }),
                          createVNode(_component_a_step, { title: "Send" }),
                          createVNode(_component_a_step, { title: "Viewed" }),
                          createVNode(_component_a_step, { title: "Paid" })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_row, { style: { "margin-top": "20px" } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode("b", null, "Amount Paid"),
                              createVNode("p", null, "0.00")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode("b", null, "Amount Outstanding"),
                              createVNode("p", null, "0.00")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_button, {
                        style: { "width": "100%", "margin-top": "15px" },
                        type: "primary",
                        onClick: withModifiers(() => {
                          _ctx.menu_visible = true;
                        }, ["stop"])
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Record Payment")
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_modal, {
                        visible: _ctx.menu_visible,
                        "onUpdate:visible": ($event) => _ctx.menu_visible = $event,
                        onClose: ($event) => _ctx.menu_visible = false,
                        title: "Record Payment",
                        onOk: _ctx.handleOk
                      }, {
                        footer: withCtx(() => [
                          createVNode(_component_a_button, {
                            key: "submit",
                            type: "primary",
                            loading: _ctx.loading,
                            onClick: _ctx.handleOk
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Record")
                            ]),
                            _: 1
                          }, 8, ["loading", "onClick"])
                        ]),
                        default: withCtx(() => [
                          createVNode(_component_a_card, { style: { "width": "470px", "height": "140px" } }, {
                            default: withCtx(() => [
                              createVNode(_component_a_row, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("b", null, "Amount received"),
                                      createVNode("p", { style: { "margin-bottom": "0px" } }, "Remaining balance ₹0.00")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { name: "area_loc" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: _ctx.value,
                                            "onUpdate:value": ($event) => _ctx.value = $event,
                                            placeholder: ""
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_row, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("b", null, "Discount")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { name: "area_loc" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: _ctx.value,
                                            "onUpdate:value": ($event) => _ctx.value = $event,
                                            placeholder: ""
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_card, { style: { "width": "470px", "margin-top": "12px", "height": "260px" } }, {
                            default: withCtx(() => [
                              createVNode(_component_a_row, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("b", null, "Payment Date")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { name: "area_loc" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_date_picker, {
                                            "value-format": "YYYY-MM-DD",
                                            style: { "width": "100%" },
                                            "\\\\v-model:value": "formState.doj"
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_row, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("b", null, "Paid Into")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { name: "area_loc" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: _ctx.value,
                                            "onUpdate:value": ($event) => _ctx.value = $event,
                                            placeholder: ""
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_row, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("b", null, "Method")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { name: "gender" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, { placeholder: "Select Method" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select_option, { value: "Cash" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Cash")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Check" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Check")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Electronic" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Electronic")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "creditcard" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Credit/Debit Card")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_row, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("b", null, "Reference(optional)")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { name: "area_loc" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: _ctx.value,
                                            "onUpdate:value": ($event) => _ctx.value = $event,
                                            placeholder: ""
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["visible", "onUpdate:visible", "onClose", "onOk"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_card, { style: { "width": "360px", "margin-top": "4px" } }, {
                    default: withCtx(() => [
                      createVNode(_component_a_row, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode("p", null, [
                                createVNode(_component_MailOutlined, { style: { "margin-right": "12px" } }),
                                createTextVNode("Email")
                              ]),
                              createVNode("p", null, [
                                createVNode(_component_EditOutlined, { style: { "margin-right": "12px" } }),
                                createTextVNode("Edit")
                              ]),
                              createVNode("p", null, [
                                createVNode(_component_CopyOutlined, { style: { "margin-right": "12px" } }),
                                createTextVNode("Copy")
                              ]),
                              createVNode("p", {
                                style: { "cursor": "pointer" },
                                onClick: withModifiers(() => {
                                  _ctx.download_visible = true;
                                }, ["stop"])
                              }, [
                                createVNode(_component_DownloadOutlined, { style: { "margin-right": "12px" } }),
                                createTextVNode("Download")
                              ], 8, ["onClick"]),
                              createVNode("p", null, [
                                createVNode(_component_DisconnectOutlined, { style: { "margin-right": "12px" } }),
                                createTextVNode("Void")
                              ])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode("p", null, [
                                createVNode(_component_PrinterOutlined, { style: { "margin-right": "12px" } }),
                                createTextVNode("Print Preview")
                              ]),
                              createVNode("p", null, [
                                createVNode(_component_ShareAltOutlined, { style: { "margin-right": "12px" } }),
                                createTextVNode("Share Link")
                              ]),
                              createVNode("p", null, [
                                createVNode(_component_FileTextOutlined, { style: { "margin-right": "12px" } }),
                                createTextVNode("Add Credit note")
                              ]),
                              createVNode("p", null, [
                                createVNode(_component_PaperClipOutlined, { style: { "margin-right": "12px" } }),
                                createTextVNode("Add File")
                              ])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_a_modal, {
            visible: _ctx.download_visible,
            "onUpdate:visible": ($event) => _ctx.download_visible = $event,
            onClose: ($event) => _ctx.download_visible = false,
            title: "Sending this invoice?",
            onOk: _ctx.handleOk
          }, {
            footer: withCtx(() => [
              createVNode(_component_a_button, {
                key: "submit",
                type: "primary",
                loading: _ctx.loading,
                onClick: _ctx.exportToPDF
              }, {
                default: withCtx(() => [
                  createTextVNode("Make as sent")
                ]),
                _: 1
              }, 8, ["loading", "onClick"]),
              createVNode(_component_a_button, {
                key: "back",
                onClick: ($event) => _ctx.download_visible = false
              }, {
                default: withCtx(() => [
                  createTextVNode("Leave as unsent")
                ]),
                _: 1
              }, 8, ["onClick"])
            ]),
            default: withCtx(() => [
              createVNode("p", null, "Would you like to make this invoice as sent?")
            ]),
            _: 1
          }, 8, ["visible", "onUpdate:visible", "onClose", "onOk"])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Sales/Invoice.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Invoice = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Invoice as default
};
