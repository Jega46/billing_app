import { defineComponent, ref, resolveComponent, withCtx, createTextVNode, createVNode, mergeProps, useSSRContext } from "vue";
import { EditOutlined, PlusOutlined, DownOutlined, PlusCircleOutlined, AlignLeftOutlined } from "@ant-design/icons-vue";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import { Head, useForm } from "@inertiajs/vue3";
import { ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
const Create_vue_vue_type_style_index_0_lang = "";
const _sfc_main = defineComponent({
  inject: ["validateMessages"],
  props: {
    pagination: Object,
    errors: Object
  },
  components: {
    AuthenticatedLayout: _sfc_main$1,
    Head,
    EditOutlined,
    PlusOutlined,
    DownOutlined,
    PlusCircleOutlined,
    AlignLeftOutlined
  },
  setup(props) {
    const layout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 24 }
    };
    const checked = ref(false);
    const handleCancel = () => {
      showmodel_visible.value = false;
    };
    const formParty = useForm({
      partyname: "",
      mobile: "",
      who_r_they: "",
      gstin: "",
      flat_no: "",
      area_loc: "",
      pincode: "",
      city: "",
      state: "",
      same_ship: false
    });
    const formState = useForm({
      valuess: ""
    });
    return {
      formParty,
      formState,
      layout,
      handleCancel,
      checked
    };
  },
  mounted() {
  },
  data() {
    return {
      showmodel_visible: false,
      menu_visible: false,
      invdrawer_visible: false,
      isShowing: false,
      addcustom: false,
      gstShowing: false,
      options: ref([{
        value: "Burns Bay Road"
      }, {
        value: "Downing Street"
      }, {
        value: "Wall Street"
      }]),
      dataSource: [],
      columns: [
        {
          title: "Item",
          dataIndex: "item",
          key: "item"
        },
        {
          title: "Quantity",
          dataIndex: "quantity",
          key: "quantity"
        },
        {
          title: "Rate",
          dataIndex: "rate",
          key: "rate"
        },
        {
          title: "Tax",
          dataIndex: "tax",
          key: "tax"
        },
        {
          title: "Discount",
          dataIndex: "discount",
          key: "discount"
        },
        {
          title: "Amount",
          dataIndex: "amount",
          key: "amount"
        }
      ]
    };
  },
  methods: {
    partySubmit() {
      this.formParty.post(this.route("purchase.store"), {
        onError: (errors) => {
        },
        onFinish: (visit) => {
          this.showmodel_visible = false;
        }
      });
    },
    handleTableChange(val) {
      this.$inertia.get(
        "/purchase/index",
        { page: val.current },
        { preserveState: true }
      );
    }
  }
});
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_affix = resolveComponent("a-affix");
  const _component_a_page_header = resolveComponent("a-page-header");
  const _component_a_button = resolveComponent("a-button");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_auto_complete = resolveComponent("a-auto-complete");
  const _component_InputError = resolveComponent("InputError");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_select_option = resolveComponent("a-select-option");
  const _component_a_table = resolveComponent("a-table");
  const _component_a_textarea = resolveComponent("a-textarea");
  const _component_a_descriptions = resolveComponent("a-descriptions");
  const _component_a_descriptions_item = resolveComponent("a-descriptions-item");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Employees" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_affix, { "offset-top": 0 }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_page_header, {
                ghost: false,
                title: "New Sales Receipt",
                onBack: () => _ctx.$inertia.visit(_ctx.route("sales.index"))
              }, {
                extra: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(`<a${ssrRenderAttr("href", _ctx.route("sales.invoice"))}${_scopeId3}>`);
                    _push4(ssrRenderComponent(_component_a_button, { type: "primary" }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`Save`);
                        } else {
                          return [
                            createTextVNode("Save")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(`</a>`);
                  } else {
                    return [
                      createVNode("a", {
                        href: _ctx.route("sales.invoice")
                      }, [
                        createVNode(_component_a_button, { type: "primary" }, {
                          default: withCtx(() => [
                            createTextVNode("Save")
                          ]),
                          _: 1
                        })
                      ], 8, ["href"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_page_header, {
                  ghost: false,
                  title: "New Sales Receipt",
                  onBack: () => _ctx.$inertia.visit(_ctx.route("sales.index"))
                }, {
                  extra: withCtx(() => [
                    createVNode("a", {
                      href: _ctx.route("sales.invoice")
                    }, [
                      createVNode(_component_a_button, { type: "primary" }, {
                        default: withCtx(() => [
                          createTextVNode("Save")
                        ]),
                        _: 1
                      })
                    ], 8, ["href"])
                  ]),
                  _: 1
                }, 8, ["onBack"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_col, {
                class: "gutter-row",
                span: 16,
                offset: 4
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_layout_content, { style: { margin: "24px 16px", padding: "24px", background: "#fff" } }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                            name: "nest-messages",
                            "validate-messages": _ctx.validateMessages,
                            onFinish: _ctx.submit,
                            "label-col": { span: 24 }
                          }), {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_col, {
                                        class: "gutter-row",
                                        span: 8
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_form_item, {
                                              label: "Customer",
                                              name: "customer",
                                              rules: [{ required: true }]
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_auto_complete, {
                                                    value: _ctx.value,
                                                    "onUpdate:value": ($event) => _ctx.value = $event,
                                                    options: _ctx.options,
                                                    "filter-option": _ctx.filterOption
                                                  }, null, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_InputError, {
                                                    class: "mt-2",
                                                    message: _ctx.errors.customer
                                                  }, null, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_auto_complete, {
                                                      value: _ctx.value,
                                                      "onUpdate:value": ($event) => _ctx.value = $event,
                                                      options: _ctx.options,
                                                      "filter-option": _ctx.filterOption
                                                    }, null, 8, ["value", "onUpdate:value", "options", "filter-option"]),
                                                    createVNode(_component_InputError, {
                                                      class: "mt-2",
                                                      message: _ctx.errors.customer
                                                    }, null, 8, ["message"])
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_form_item, {
                                                label: "Customer",
                                                name: "customer",
                                                rules: [{ required: true }]
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_auto_complete, {
                                                    value: _ctx.value,
                                                    "onUpdate:value": ($event) => _ctx.value = $event,
                                                    options: _ctx.options,
                                                    "filter-option": _ctx.filterOption
                                                  }, null, 8, ["value", "onUpdate:value", "options", "filter-option"]),
                                                  createVNode(_component_InputError, {
                                                    class: "mt-2",
                                                    message: _ctx.errors.customer
                                                  }, null, 8, ["message"])
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_col, {
                                        class: "gutter-row",
                                        span: 8
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_form_item, {
                                              label: "Sales Receipt #",
                                              name: "number"
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_input, {
                                                    value: _ctx.formState.number,
                                                    "onUpdate:value": ($event) => _ctx.formState.number = $event
                                                  }, null, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_InputError, {
                                                    class: "mt-2",
                                                    message: _ctx.errors.number
                                                  }, null, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.formState.number,
                                                      "onUpdate:value": ($event) => _ctx.formState.number = $event
                                                    }, null, 8, ["value", "onUpdate:value"]),
                                                    createVNode(_component_InputError, {
                                                      class: "mt-2",
                                                      message: _ctx.errors.number
                                                    }, null, 8, ["message"])
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_form_item, {
                                                label: "Sales Receipt #",
                                                name: "number"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.formState.number,
                                                    "onUpdate:value": ($event) => _ctx.formState.number = $event
                                                  }, null, 8, ["value", "onUpdate:value"]),
                                                  createVNode(_component_InputError, {
                                                    class: "mt-2",
                                                    message: _ctx.errors.number
                                                  }, null, 8, ["message"])
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_col, {
                                        class: "gutter-row",
                                        span: 8
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_form_item, {
                                              label: "Date",
                                              name: "date",
                                              rules: [{ required: true }]
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_input, {
                                                    value: _ctx.formState.date,
                                                    "onUpdate:value": ($event) => _ctx.formState.date = $event
                                                  }, null, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_InputError, {
                                                    class: "mt-2",
                                                    message: _ctx.errors.date
                                                  }, null, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.formState.date,
                                                      "onUpdate:value": ($event) => _ctx.formState.date = $event
                                                    }, null, 8, ["value", "onUpdate:value"]),
                                                    createVNode(_component_InputError, {
                                                      class: "mt-2",
                                                      message: _ctx.errors.date
                                                    }, null, 8, ["message"])
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_form_item, {
                                                label: "Date",
                                                name: "date",
                                                rules: [{ required: true }]
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.formState.date,
                                                    "onUpdate:value": ($event) => _ctx.formState.date = $event
                                                  }, null, 8, ["value", "onUpdate:value"]),
                                                  createVNode(_component_InputError, {
                                                    class: "mt-2",
                                                    message: _ctx.errors.date
                                                  }, null, 8, ["message"])
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_col, {
                                        class: "gutter-row",
                                        span: 8
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_form_item, {
                                              label: "Payment Method",
                                              name: "payment_method",
                                              rules: [{ required: true }]
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_select, {
                                                    ref: "select",
                                                    value: _ctx.formState.payment_method,
                                                    "onUpdate:value": ($event) => _ctx.formState.payment_method = $event
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_select_option, { value: "jack" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`Jack`);
                                                            } else {
                                                              return [
                                                                createTextVNode("Jack")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                        _push10(ssrRenderComponent(_component_a_select_option, { value: "lucy" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`Lucy`);
                                                            } else {
                                                              return [
                                                                createTextVNode("Lucy")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                        _push10(ssrRenderComponent(_component_a_select_option, {
                                                          value: "disabled",
                                                          disabled: ""
                                                        }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`Disabled`);
                                                            } else {
                                                              return [
                                                                createTextVNode("Disabled")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                        _push10(ssrRenderComponent(_component_a_select_option, { value: "Yiminghe" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`yiminghe`);
                                                            } else {
                                                              return [
                                                                createTextVNode("yiminghe")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_select_option, { value: "jack" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Jack")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_select_option, { value: "lucy" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Lucy")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_select_option, {
                                                            value: "disabled",
                                                            disabled: ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Disabled")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("yiminghe")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_InputError, {
                                                    class: "mt-2",
                                                    message: _ctx.errors.payment_method
                                                  }, null, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_select, {
                                                      ref: "select",
                                                      value: _ctx.formState.payment_method,
                                                      "onUpdate:value": ($event) => _ctx.formState.payment_method = $event
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_select_option, { value: "jack" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Jack")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_select_option, { value: "lucy" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Lucy")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_select_option, {
                                                          value: "disabled",
                                                          disabled: ""
                                                        }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Disabled")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("yiminghe")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }, 8, ["value", "onUpdate:value"]),
                                                    createVNode(_component_InputError, {
                                                      class: "mt-2",
                                                      message: _ctx.errors.payment_method
                                                    }, null, 8, ["message"])
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_form_item, {
                                                label: "Payment Method",
                                                name: "payment_method",
                                                rules: [{ required: true }]
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select, {
                                                    ref: "select",
                                                    value: _ctx.formState.payment_method,
                                                    "onUpdate:value": ($event) => _ctx.formState.payment_method = $event
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_select_option, { value: "jack" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Jack")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_select_option, { value: "lucy" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Lucy")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_select_option, {
                                                        value: "disabled",
                                                        disabled: ""
                                                      }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Disabled")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("yiminghe")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }, 8, ["value", "onUpdate:value"]),
                                                  createVNode(_component_InputError, {
                                                    class: "mt-2",
                                                    message: _ctx.errors.payment_method
                                                  }, null, 8, ["message"])
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_col, {
                                        class: "gutter-row",
                                        span: 8
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_form_item, {
                                              label: "Shipping Method",
                                              name: "shipping_method",
                                              rules: [{ required: true }]
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_select, {
                                                    ref: "select",
                                                    value: _ctx.formState.shipping_method,
                                                    "onUpdate:value": ($event) => _ctx.formState.shipping_method = $event
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_select_option, { value: "jack" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`Jack`);
                                                            } else {
                                                              return [
                                                                createTextVNode("Jack")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                        _push10(ssrRenderComponent(_component_a_select_option, { value: "lucy" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`Lucy`);
                                                            } else {
                                                              return [
                                                                createTextVNode("Lucy")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                        _push10(ssrRenderComponent(_component_a_select_option, {
                                                          value: "disabled",
                                                          disabled: ""
                                                        }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`Disabled`);
                                                            } else {
                                                              return [
                                                                createTextVNode("Disabled")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                        _push10(ssrRenderComponent(_component_a_select_option, { value: "Yiminghe" }, {
                                                          default: withCtx((_10, _push11, _parent11, _scopeId10) => {
                                                            if (_push11) {
                                                              _push11(`yiminghe`);
                                                            } else {
                                                              return [
                                                                createTextVNode("yiminghe")
                                                              ];
                                                            }
                                                          }),
                                                          _: 1
                                                        }, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_select_option, { value: "jack" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Jack")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_select_option, { value: "lucy" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Lucy")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_select_option, {
                                                            value: "disabled",
                                                            disabled: ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("Disabled")
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                            default: withCtx(() => [
                                                              createTextVNode("yiminghe")
                                                            ]),
                                                            _: 1
                                                          })
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_InputError, {
                                                    class: "mt-2",
                                                    message: _ctx.errors.shipping_method
                                                  }, null, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_select, {
                                                      ref: "select",
                                                      value: _ctx.formState.shipping_method,
                                                      "onUpdate:value": ($event) => _ctx.formState.shipping_method = $event
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_select_option, { value: "jack" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Jack")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_select_option, { value: "lucy" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Lucy")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_select_option, {
                                                          value: "disabled",
                                                          disabled: ""
                                                        }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("Disabled")
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                          default: withCtx(() => [
                                                            createTextVNode("yiminghe")
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }, 8, ["value", "onUpdate:value"]),
                                                    createVNode(_component_InputError, {
                                                      class: "mt-2",
                                                      message: _ctx.errors.shipping_method
                                                    }, null, 8, ["message"])
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_form_item, {
                                                label: "Shipping Method",
                                                name: "shipping_method",
                                                rules: [{ required: true }]
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select, {
                                                    ref: "select",
                                                    value: _ctx.formState.shipping_method,
                                                    "onUpdate:value": ($event) => _ctx.formState.shipping_method = $event
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_select_option, { value: "jack" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Jack")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_select_option, { value: "lucy" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Lucy")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_select_option, {
                                                        value: "disabled",
                                                        disabled: ""
                                                      }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("Disabled")
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                        default: withCtx(() => [
                                                          createTextVNode("yiminghe")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }, 8, ["value", "onUpdate:value"]),
                                                  createVNode(_component_InputError, {
                                                    class: "mt-2",
                                                    message: _ctx.errors.shipping_method
                                                  }, null, 8, ["message"])
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 8
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Customer",
                                              name: "customer",
                                              rules: [{ required: true }]
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_auto_complete, {
                                                  value: _ctx.value,
                                                  "onUpdate:value": ($event) => _ctx.value = $event,
                                                  options: _ctx.options,
                                                  "filter-option": _ctx.filterOption
                                                }, null, 8, ["value", "onUpdate:value", "options", "filter-option"]),
                                                createVNode(_component_InputError, {
                                                  class: "mt-2",
                                                  message: _ctx.errors.customer
                                                }, null, 8, ["message"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 8
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Sales Receipt #",
                                              name: "number"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.formState.number,
                                                  "onUpdate:value": ($event) => _ctx.formState.number = $event
                                                }, null, 8, ["value", "onUpdate:value"]),
                                                createVNode(_component_InputError, {
                                                  class: "mt-2",
                                                  message: _ctx.errors.number
                                                }, null, 8, ["message"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 8
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Date",
                                              name: "date",
                                              rules: [{ required: true }]
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.formState.date,
                                                  "onUpdate:value": ($event) => _ctx.formState.date = $event
                                                }, null, 8, ["value", "onUpdate:value"]),
                                                createVNode(_component_InputError, {
                                                  class: "mt-2",
                                                  message: _ctx.errors.date
                                                }, null, 8, ["message"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 8
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Payment Method",
                                              name: "payment_method",
                                              rules: [{ required: true }]
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select, {
                                                  ref: "select",
                                                  value: _ctx.formState.payment_method,
                                                  "onUpdate:value": ($event) => _ctx.formState.payment_method = $event
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_select_option, { value: "jack" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Jack")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, { value: "lucy" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Lucy")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, {
                                                      value: "disabled",
                                                      disabled: ""
                                                    }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Disabled")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("yiminghe")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }, 8, ["value", "onUpdate:value"]),
                                                createVNode(_component_InputError, {
                                                  class: "mt-2",
                                                  message: _ctx.errors.payment_method
                                                }, null, 8, ["message"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 8
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_form_item, {
                                              label: "Shipping Method",
                                              name: "shipping_method",
                                              rules: [{ required: true }]
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select, {
                                                  ref: "select",
                                                  value: _ctx.formState.shipping_method,
                                                  "onUpdate:value": ($event) => _ctx.formState.shipping_method = $event
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_select_option, { value: "jack" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Jack")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, { value: "lucy" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Lucy")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, {
                                                      value: "disabled",
                                                      disabled: ""
                                                    }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Disabled")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("yiminghe")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }, 8, ["value", "onUpdate:value"]),
                                                createVNode(_component_InputError, {
                                                  class: "mt-2",
                                                  message: _ctx.errors.shipping_method
                                                }, null, 8, ["message"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(`<br${_scopeId5}>`);
                                _push6(ssrRenderComponent(_component_a_table, {
                                  dataSource: _ctx.dataSource,
                                  columns: _ctx.columns
                                }, null, _parent6, _scopeId5));
                                _push6(`<br${_scopeId5}>`);
                                _push6(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_col, {
                                        class: "gutter-row",
                                        span: 12
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_textarea, {
                                              value: _ctx.value2,
                                              "onUpdate:value": ($event) => _ctx.value2 = $event,
                                              placeholder: "Terms and conditions",
                                              "auto-size": { minRows: 2, maxRows: 5 }
                                            }, null, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_textarea, {
                                              value: _ctx.value2,
                                              "onUpdate:value": ($event) => _ctx.value2 = $event,
                                              placeholder: "Notes",
                                              "auto-size": { minRows: 2, maxRows: 5 }
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_textarea, {
                                                value: _ctx.value2,
                                                "onUpdate:value": ($event) => _ctx.value2 = $event,
                                                placeholder: "Terms and conditions",
                                                "auto-size": { minRows: 2, maxRows: 5 }
                                              }, null, 8, ["value", "onUpdate:value"]),
                                              createVNode(_component_a_textarea, {
                                                value: _ctx.value2,
                                                "onUpdate:value": ($event) => _ctx.value2 = $event,
                                                placeholder: "Notes",
                                                "auto-size": { minRows: 2, maxRows: 5 }
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_col, {
                                        class: "gutter-row",
                                        span: 12
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_descriptions, {
                                              bordered: "",
                                              size: "small",
                                              column: { xxl: 1, xl: 1, lg: 1, md: 1, sm: 1, xs: 1 }
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_descriptions_item, { label: "Sub Total" }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(` 90.00 `);
                                                      } else {
                                                        return [
                                                          createTextVNode(" 90.00 ")
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_a_descriptions_item, { label: "Discount" }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_input, {
                                                          value: _ctx.formState.date,
                                                          "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                          bordered: false
                                                        }, null, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_input, {
                                                            value: _ctx.formState.date,
                                                            "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                            bordered: false
                                                          }, null, 8, ["value", "onUpdate:value"])
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_a_descriptions_item, { label: "Shipping Cost" }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_a_input, {
                                                          value: _ctx.formState.date,
                                                          "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                          bordered: false
                                                        }, null, _parent10, _scopeId9));
                                                      } else {
                                                        return [
                                                          createVNode(_component_a_input, {
                                                            value: _ctx.formState.date,
                                                            "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                            bordered: false
                                                          }, null, 8, ["value", "onUpdate:value"])
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_a_descriptions_item, { label: "Total Inline Discount" }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(` 90.00 `);
                                                      } else {
                                                        return [
                                                          createTextVNode(" 90.00 ")
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_a_descriptions_item, { label: "Total Tax" }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(` 90.00 `);
                                                      } else {
                                                        return [
                                                          createTextVNode(" 90.00 ")
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                  _push9(ssrRenderComponent(_component_a_descriptions_item, { label: "Total" }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(` 90.00 `);
                                                      } else {
                                                        return [
                                                          createTextVNode(" 90.00 ")
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_descriptions_item, { label: "Sub Total" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode(" 90.00 ")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_descriptions_item, { label: "Discount" }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, {
                                                          value: _ctx.formState.date,
                                                          "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                          bordered: false
                                                        }, null, 8, ["value", "onUpdate:value"])
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_descriptions_item, { label: "Shipping Cost" }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_a_input, {
                                                          value: _ctx.formState.date,
                                                          "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                          bordered: false
                                                        }, null, 8, ["value", "onUpdate:value"])
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_descriptions_item, { label: "Total Inline Discount" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode(" 90.00 ")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_descriptions_item, { label: "Total Tax" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode(" 90.00 ")
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(_component_a_descriptions_item, { label: "Total" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode(" 90.00 ")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_descriptions, {
                                                bordered: "",
                                                size: "small",
                                                column: { xxl: 1, xl: 1, lg: 1, md: 1, sm: 1, xs: 1 }
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_descriptions_item, { label: "Sub Total" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode(" 90.00 ")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_descriptions_item, { label: "Discount" }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, {
                                                        value: _ctx.formState.date,
                                                        "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                        bordered: false
                                                      }, null, 8, ["value", "onUpdate:value"])
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_descriptions_item, { label: "Shipping Cost" }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_a_input, {
                                                        value: _ctx.formState.date,
                                                        "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                        bordered: false
                                                      }, null, 8, ["value", "onUpdate:value"])
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_descriptions_item, { label: "Total Inline Discount" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode(" 90.00 ")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_descriptions_item, { label: "Total Tax" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode(" 90.00 ")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_descriptions_item, { label: "Total" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode(" 90.00 ")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 12
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_textarea, {
                                              value: _ctx.value2,
                                              "onUpdate:value": ($event) => _ctx.value2 = $event,
                                              placeholder: "Terms and conditions",
                                              "auto-size": { minRows: 2, maxRows: 5 }
                                            }, null, 8, ["value", "onUpdate:value"]),
                                            createVNode(_component_a_textarea, {
                                              value: _ctx.value2,
                                              "onUpdate:value": ($event) => _ctx.value2 = $event,
                                              placeholder: "Notes",
                                              "auto-size": { minRows: 2, maxRows: 5 }
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_col, {
                                          class: "gutter-row",
                                          span: 12
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_descriptions, {
                                              bordered: "",
                                              size: "small",
                                              column: { xxl: 1, xl: 1, lg: 1, md: 1, sm: 1, xs: 1 }
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_descriptions_item, { label: "Sub Total" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode(" 90.00 ")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_descriptions_item, { label: "Discount" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.formState.date,
                                                      "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                      bordered: false
                                                    }, null, 8, ["value", "onUpdate:value"])
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_descriptions_item, { label: "Shipping Cost" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_input, {
                                                      value: _ctx.formState.date,
                                                      "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                      bordered: false
                                                    }, null, 8, ["value", "onUpdate:value"])
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_descriptions_item, { label: "Total Inline Discount" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode(" 90.00 ")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_descriptions_item, { label: "Total Tax" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode(" 90.00 ")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_descriptions_item, { label: "Total" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode(" 90.00 ")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(`<br${_scopeId5}>`);
                                _push6(ssrRenderComponent(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`SUBMIT`);
                                          } else {
                                            return [
                                              createTextVNode("SUBMIT")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          "html-type": "submit"
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("SUBMIT")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_row, { gutter: 24 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 8
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Customer",
                                            name: "customer",
                                            rules: [{ required: true }]
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_auto_complete, {
                                                value: _ctx.value,
                                                "onUpdate:value": ($event) => _ctx.value = $event,
                                                options: _ctx.options,
                                                "filter-option": _ctx.filterOption
                                              }, null, 8, ["value", "onUpdate:value", "options", "filter-option"]),
                                              createVNode(_component_InputError, {
                                                class: "mt-2",
                                                message: _ctx.errors.customer
                                              }, null, 8, ["message"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 8
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Sales Receipt #",
                                            name: "number"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.formState.number,
                                                "onUpdate:value": ($event) => _ctx.formState.number = $event
                                              }, null, 8, ["value", "onUpdate:value"]),
                                              createVNode(_component_InputError, {
                                                class: "mt-2",
                                                message: _ctx.errors.number
                                              }, null, 8, ["message"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 8
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Date",
                                            name: "date",
                                            rules: [{ required: true }]
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.formState.date,
                                                "onUpdate:value": ($event) => _ctx.formState.date = $event
                                              }, null, 8, ["value", "onUpdate:value"]),
                                              createVNode(_component_InputError, {
                                                class: "mt-2",
                                                message: _ctx.errors.date
                                              }, null, 8, ["message"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 8
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Payment Method",
                                            name: "payment_method",
                                            rules: [{ required: true }]
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select, {
                                                ref: "select",
                                                value: _ctx.formState.payment_method,
                                                "onUpdate:value": ($event) => _ctx.formState.payment_method = $event
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select_option, { value: "jack" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Jack")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, { value: "lucy" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Lucy")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, {
                                                    value: "disabled",
                                                    disabled: ""
                                                  }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Disabled")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("yiminghe")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }, 8, ["value", "onUpdate:value"]),
                                              createVNode(_component_InputError, {
                                                class: "mt-2",
                                                message: _ctx.errors.payment_method
                                              }, null, 8, ["message"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 8
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_form_item, {
                                            label: "Shipping Method",
                                            name: "shipping_method",
                                            rules: [{ required: true }]
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select, {
                                                ref: "select",
                                                value: _ctx.formState.shipping_method,
                                                "onUpdate:value": ($event) => _ctx.formState.shipping_method = $event
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select_option, { value: "jack" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Jack")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, { value: "lucy" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Lucy")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, {
                                                    value: "disabled",
                                                    disabled: ""
                                                  }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Disabled")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                    default: withCtx(() => [
                                                      createTextVNode("yiminghe")
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }, 8, ["value", "onUpdate:value"]),
                                              createVNode(_component_InputError, {
                                                class: "mt-2",
                                                message: _ctx.errors.shipping_method
                                              }, null, 8, ["message"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode("br"),
                                  createVNode(_component_a_table, {
                                    dataSource: _ctx.dataSource,
                                    columns: _ctx.columns
                                  }, null, 8, ["dataSource", "columns"]),
                                  createVNode("br"),
                                  createVNode(_component_a_row, { gutter: 24 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 12
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_textarea, {
                                            value: _ctx.value2,
                                            "onUpdate:value": ($event) => _ctx.value2 = $event,
                                            placeholder: "Terms and conditions",
                                            "auto-size": { minRows: 2, maxRows: 5 }
                                          }, null, 8, ["value", "onUpdate:value"]),
                                          createVNode(_component_a_textarea, {
                                            value: _ctx.value2,
                                            "onUpdate:value": ($event) => _ctx.value2 = $event,
                                            placeholder: "Notes",
                                            "auto-size": { minRows: 2, maxRows: 5 }
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_col, {
                                        class: "gutter-row",
                                        span: 12
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_descriptions, {
                                            bordered: "",
                                            size: "small",
                                            column: { xxl: 1, xl: 1, lg: 1, md: 1, sm: 1, xs: 1 }
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_descriptions_item, { label: "Sub Total" }, {
                                                default: withCtx(() => [
                                                  createTextVNode(" 90.00 ")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_descriptions_item, { label: "Discount" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.formState.date,
                                                    "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                    bordered: false
                                                  }, null, 8, ["value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_descriptions_item, { label: "Shipping Cost" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_input, {
                                                    value: _ctx.formState.date,
                                                    "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                    bordered: false
                                                  }, null, 8, ["value", "onUpdate:value"])
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_descriptions_item, { label: "Total Inline Discount" }, {
                                                default: withCtx(() => [
                                                  createTextVNode(" 90.00 ")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_descriptions_item, { label: "Total Tax" }, {
                                                default: withCtx(() => [
                                                  createTextVNode(" 90.00 ")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_descriptions_item, { label: "Total" }, {
                                                default: withCtx(() => [
                                                  createTextVNode(" 90.00 ")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode("br"),
                                  createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit"
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("SUBMIT")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                              name: "nest-messages",
                              "validate-messages": _ctx.validateMessages,
                              onFinish: _ctx.submit,
                              "label-col": { span: 24 }
                            }), {
                              default: withCtx(() => [
                                createVNode(_component_a_row, { gutter: 24 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 8
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Customer",
                                          name: "customer",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_auto_complete, {
                                              value: _ctx.value,
                                              "onUpdate:value": ($event) => _ctx.value = $event,
                                              options: _ctx.options,
                                              "filter-option": _ctx.filterOption
                                            }, null, 8, ["value", "onUpdate:value", "options", "filter-option"]),
                                            createVNode(_component_InputError, {
                                              class: "mt-2",
                                              message: _ctx.errors.customer
                                            }, null, 8, ["message"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 8
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Sales Receipt #",
                                          name: "number"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: _ctx.formState.number,
                                              "onUpdate:value": ($event) => _ctx.formState.number = $event
                                            }, null, 8, ["value", "onUpdate:value"]),
                                            createVNode(_component_InputError, {
                                              class: "mt-2",
                                              message: _ctx.errors.number
                                            }, null, 8, ["message"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 8
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Date",
                                          name: "date",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: _ctx.formState.date,
                                              "onUpdate:value": ($event) => _ctx.formState.date = $event
                                            }, null, 8, ["value", "onUpdate:value"]),
                                            createVNode(_component_InputError, {
                                              class: "mt-2",
                                              message: _ctx.errors.date
                                            }, null, 8, ["message"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 8
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Payment Method",
                                          name: "payment_method",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              ref: "select",
                                              value: _ctx.formState.payment_method,
                                              "onUpdate:value": ($event) => _ctx.formState.payment_method = $event
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select_option, { value: "jack" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Jack")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_select_option, { value: "lucy" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Lucy")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_select_option, {
                                                  value: "disabled",
                                                  disabled: ""
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Disabled")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("yiminghe")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }, 8, ["value", "onUpdate:value"]),
                                            createVNode(_component_InputError, {
                                              class: "mt-2",
                                              message: _ctx.errors.payment_method
                                            }, null, 8, ["message"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 8
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_form_item, {
                                          label: "Shipping Method",
                                          name: "shipping_method",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              ref: "select",
                                              value: _ctx.formState.shipping_method,
                                              "onUpdate:value": ($event) => _ctx.formState.shipping_method = $event
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select_option, { value: "jack" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Jack")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_select_option, { value: "lucy" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Lucy")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_select_option, {
                                                  value: "disabled",
                                                  disabled: ""
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Disabled")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("yiminghe")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }, 8, ["value", "onUpdate:value"]),
                                            createVNode(_component_InputError, {
                                              class: "mt-2",
                                              message: _ctx.errors.shipping_method
                                            }, null, 8, ["message"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode("br"),
                                createVNode(_component_a_table, {
                                  dataSource: _ctx.dataSource,
                                  columns: _ctx.columns
                                }, null, 8, ["dataSource", "columns"]),
                                createVNode("br"),
                                createVNode(_component_a_row, { gutter: 24 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 12
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_textarea, {
                                          value: _ctx.value2,
                                          "onUpdate:value": ($event) => _ctx.value2 = $event,
                                          placeholder: "Terms and conditions",
                                          "auto-size": { minRows: 2, maxRows: 5 }
                                        }, null, 8, ["value", "onUpdate:value"]),
                                        createVNode(_component_a_textarea, {
                                          value: _ctx.value2,
                                          "onUpdate:value": ($event) => _ctx.value2 = $event,
                                          placeholder: "Notes",
                                          "auto-size": { minRows: 2, maxRows: 5 }
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_col, {
                                      class: "gutter-row",
                                      span: 12
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_descriptions, {
                                          bordered: "",
                                          size: "small",
                                          column: { xxl: 1, xl: 1, lg: 1, md: 1, sm: 1, xs: 1 }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_descriptions_item, { label: "Sub Total" }, {
                                              default: withCtx(() => [
                                                createTextVNode(" 90.00 ")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_descriptions_item, { label: "Discount" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.formState.date,
                                                  "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                  bordered: false
                                                }, null, 8, ["value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_descriptions_item, { label: "Shipping Cost" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_input, {
                                                  value: _ctx.formState.date,
                                                  "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                  bordered: false
                                                }, null, 8, ["value", "onUpdate:value"])
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_descriptions_item, { label: "Total Inline Discount" }, {
                                              default: withCtx(() => [
                                                createTextVNode(" 90.00 ")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_descriptions_item, { label: "Total Tax" }, {
                                              default: withCtx(() => [
                                                createTextVNode(" 90.00 ")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_descriptions_item, { label: "Total" }, {
                                              default: withCtx(() => [
                                                createTextVNode(" 90.00 ")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode("br"),
                                createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      "html-type": "submit"
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("SUBMIT")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 16, ["model", "validate-messages", "onFinish"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_layout_content, { style: { margin: "24px 16px", padding: "24px", background: "#fff" } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                            name: "nest-messages",
                            "validate-messages": _ctx.validateMessages,
                            onFinish: _ctx.submit,
                            "label-col": { span: 24 }
                          }), {
                            default: withCtx(() => [
                              createVNode(_component_a_row, { gutter: 24 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 8
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Customer",
                                        name: "customer",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_auto_complete, {
                                            value: _ctx.value,
                                            "onUpdate:value": ($event) => _ctx.value = $event,
                                            options: _ctx.options,
                                            "filter-option": _ctx.filterOption
                                          }, null, 8, ["value", "onUpdate:value", "options", "filter-option"]),
                                          createVNode(_component_InputError, {
                                            class: "mt-2",
                                            message: _ctx.errors.customer
                                          }, null, 8, ["message"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 8
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Sales Receipt #",
                                        name: "number"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: _ctx.formState.number,
                                            "onUpdate:value": ($event) => _ctx.formState.number = $event
                                          }, null, 8, ["value", "onUpdate:value"]),
                                          createVNode(_component_InputError, {
                                            class: "mt-2",
                                            message: _ctx.errors.number
                                          }, null, 8, ["message"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 8
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Date",
                                        name: "date",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: _ctx.formState.date,
                                            "onUpdate:value": ($event) => _ctx.formState.date = $event
                                          }, null, 8, ["value", "onUpdate:value"]),
                                          createVNode(_component_InputError, {
                                            class: "mt-2",
                                            message: _ctx.errors.date
                                          }, null, 8, ["message"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 8
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Payment Method",
                                        name: "payment_method",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            ref: "select",
                                            value: _ctx.formState.payment_method,
                                            "onUpdate:value": ($event) => _ctx.formState.payment_method = $event
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select_option, { value: "jack" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Jack")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "lucy" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Lucy")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, {
                                                value: "disabled",
                                                disabled: ""
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Disabled")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("yiminghe")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }, 8, ["value", "onUpdate:value"]),
                                          createVNode(_component_InputError, {
                                            class: "mt-2",
                                            message: _ctx.errors.payment_method
                                          }, null, 8, ["message"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 8
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Shipping Method",
                                        name: "shipping_method",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            ref: "select",
                                            value: _ctx.formState.shipping_method,
                                            "onUpdate:value": ($event) => _ctx.formState.shipping_method = $event
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select_option, { value: "jack" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Jack")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "lucy" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Lucy")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, {
                                                value: "disabled",
                                                disabled: ""
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Disabled")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("yiminghe")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }, 8, ["value", "onUpdate:value"]),
                                          createVNode(_component_InputError, {
                                            class: "mt-2",
                                            message: _ctx.errors.shipping_method
                                          }, null, 8, ["message"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode("br"),
                              createVNode(_component_a_table, {
                                dataSource: _ctx.dataSource,
                                columns: _ctx.columns
                              }, null, 8, ["dataSource", "columns"]),
                              createVNode("br"),
                              createVNode(_component_a_row, { gutter: 24 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_textarea, {
                                        value: _ctx.value2,
                                        "onUpdate:value": ($event) => _ctx.value2 = $event,
                                        placeholder: "Terms and conditions",
                                        "auto-size": { minRows: 2, maxRows: 5 }
                                      }, null, 8, ["value", "onUpdate:value"]),
                                      createVNode(_component_a_textarea, {
                                        value: _ctx.value2,
                                        "onUpdate:value": ($event) => _ctx.value2 = $event,
                                        placeholder: "Notes",
                                        "auto-size": { minRows: 2, maxRows: 5 }
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_descriptions, {
                                        bordered: "",
                                        size: "small",
                                        column: { xxl: 1, xl: 1, lg: 1, md: 1, sm: 1, xs: 1 }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_descriptions_item, { label: "Sub Total" }, {
                                            default: withCtx(() => [
                                              createTextVNode(" 90.00 ")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_descriptions_item, { label: "Discount" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.formState.date,
                                                "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                bordered: false
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_descriptions_item, { label: "Shipping Cost" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_input, {
                                                value: _ctx.formState.date,
                                                "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                                bordered: false
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_descriptions_item, { label: "Total Inline Discount" }, {
                                            default: withCtx(() => [
                                              createTextVNode(" 90.00 ")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_descriptions_item, { label: "Total Tax" }, {
                                            default: withCtx(() => [
                                              createTextVNode(" 90.00 ")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_descriptions_item, { label: "Total" }, {
                                            default: withCtx(() => [
                                              createTextVNode(" 90.00 ")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode("br"),
                              createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("SUBMIT")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 16, ["model", "validate-messages", "onFinish"])
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_col, {
                  class: "gutter-row",
                  span: 16,
                  offset: 4
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_layout_content, { style: { margin: "24px 16px", padding: "24px", background: "#fff" } }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                          name: "nest-messages",
                          "validate-messages": _ctx.validateMessages,
                          onFinish: _ctx.submit,
                          "label-col": { span: 24 }
                        }), {
                          default: withCtx(() => [
                            createVNode(_component_a_row, { gutter: 24 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 8
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Customer",
                                      name: "customer",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_auto_complete, {
                                          value: _ctx.value,
                                          "onUpdate:value": ($event) => _ctx.value = $event,
                                          options: _ctx.options,
                                          "filter-option": _ctx.filterOption
                                        }, null, 8, ["value", "onUpdate:value", "options", "filter-option"]),
                                        createVNode(_component_InputError, {
                                          class: "mt-2",
                                          message: _ctx.errors.customer
                                        }, null, 8, ["message"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 8
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Sales Receipt #",
                                      name: "number"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: _ctx.formState.number,
                                          "onUpdate:value": ($event) => _ctx.formState.number = $event
                                        }, null, 8, ["value", "onUpdate:value"]),
                                        createVNode(_component_InputError, {
                                          class: "mt-2",
                                          message: _ctx.errors.number
                                        }, null, 8, ["message"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 8
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Date",
                                      name: "date",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: _ctx.formState.date,
                                          "onUpdate:value": ($event) => _ctx.formState.date = $event
                                        }, null, 8, ["value", "onUpdate:value"]),
                                        createVNode(_component_InputError, {
                                          class: "mt-2",
                                          message: _ctx.errors.date
                                        }, null, 8, ["message"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 8
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Payment Method",
                                      name: "payment_method",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          ref: "select",
                                          value: _ctx.formState.payment_method,
                                          "onUpdate:value": ($event) => _ctx.formState.payment_method = $event
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "jack" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Jack")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "lucy" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Lucy")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, {
                                              value: "disabled",
                                              disabled: ""
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode("Disabled")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                              default: withCtx(() => [
                                                createTextVNode("yiminghe")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["value", "onUpdate:value"]),
                                        createVNode(_component_InputError, {
                                          class: "mt-2",
                                          message: _ctx.errors.payment_method
                                        }, null, 8, ["message"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 8
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Shipping Method",
                                      name: "shipping_method",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          ref: "select",
                                          value: _ctx.formState.shipping_method,
                                          "onUpdate:value": ($event) => _ctx.formState.shipping_method = $event
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "jack" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Jack")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "lucy" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Lucy")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, {
                                              value: "disabled",
                                              disabled: ""
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode("Disabled")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                              default: withCtx(() => [
                                                createTextVNode("yiminghe")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["value", "onUpdate:value"]),
                                        createVNode(_component_InputError, {
                                          class: "mt-2",
                                          message: _ctx.errors.shipping_method
                                        }, null, 8, ["message"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("br"),
                            createVNode(_component_a_table, {
                              dataSource: _ctx.dataSource,
                              columns: _ctx.columns
                            }, null, 8, ["dataSource", "columns"]),
                            createVNode("br"),
                            createVNode(_component_a_row, { gutter: 24 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_textarea, {
                                      value: _ctx.value2,
                                      "onUpdate:value": ($event) => _ctx.value2 = $event,
                                      placeholder: "Terms and conditions",
                                      "auto-size": { minRows: 2, maxRows: 5 }
                                    }, null, 8, ["value", "onUpdate:value"]),
                                    createVNode(_component_a_textarea, {
                                      value: _ctx.value2,
                                      "onUpdate:value": ($event) => _ctx.value2 = $event,
                                      placeholder: "Notes",
                                      "auto-size": { minRows: 2, maxRows: 5 }
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_descriptions, {
                                      bordered: "",
                                      size: "small",
                                      column: { xxl: 1, xl: 1, lg: 1, md: 1, sm: 1, xs: 1 }
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_descriptions_item, { label: "Sub Total" }, {
                                          default: withCtx(() => [
                                            createTextVNode(" 90.00 ")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, { label: "Discount" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: _ctx.formState.date,
                                              "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                              bordered: false
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, { label: "Shipping Cost" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: _ctx.formState.date,
                                              "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                              bordered: false
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, { label: "Total Inline Discount" }, {
                                          default: withCtx(() => [
                                            createTextVNode(" 90.00 ")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, { label: "Total Tax" }, {
                                          default: withCtx(() => [
                                            createTextVNode(" 90.00 ")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, { label: "Total" }, {
                                          default: withCtx(() => [
                                            createTextVNode(" 90.00 ")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("br"),
                            createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("SUBMIT")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 16, ["model", "validate-messages", "onFinish"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_affix, { "offset-top": 0 }, {
            default: withCtx(() => [
              createVNode(_component_a_page_header, {
                ghost: false,
                title: "New Sales Receipt",
                onBack: () => _ctx.$inertia.visit(_ctx.route("sales.index"))
              }, {
                extra: withCtx(() => [
                  createVNode("a", {
                    href: _ctx.route("sales.invoice")
                  }, [
                    createVNode(_component_a_button, { type: "primary" }, {
                      default: withCtx(() => [
                        createTextVNode("Save")
                      ]),
                      _: 1
                    })
                  ], 8, ["href"])
                ]),
                _: 1
              }, 8, ["onBack"])
            ]),
            _: 1
          }),
          createVNode(_component_a_row, { gutter: 24 }, {
            default: withCtx(() => [
              createVNode(_component_a_col, {
                class: "gutter-row",
                span: 16,
                offset: 4
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_layout_content, { style: { margin: "24px 16px", padding: "24px", background: "#fff" } }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                        name: "nest-messages",
                        "validate-messages": _ctx.validateMessages,
                        onFinish: _ctx.submit,
                        "label-col": { span: 24 }
                      }), {
                        default: withCtx(() => [
                          createVNode(_component_a_row, { gutter: 24 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 8
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Customer",
                                    name: "customer",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_auto_complete, {
                                        value: _ctx.value,
                                        "onUpdate:value": ($event) => _ctx.value = $event,
                                        options: _ctx.options,
                                        "filter-option": _ctx.filterOption
                                      }, null, 8, ["value", "onUpdate:value", "options", "filter-option"]),
                                      createVNode(_component_InputError, {
                                        class: "mt-2",
                                        message: _ctx.errors.customer
                                      }, null, 8, ["message"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 8
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Sales Receipt #",
                                    name: "number"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.formState.number,
                                        "onUpdate:value": ($event) => _ctx.formState.number = $event
                                      }, null, 8, ["value", "onUpdate:value"]),
                                      createVNode(_component_InputError, {
                                        class: "mt-2",
                                        message: _ctx.errors.number
                                      }, null, 8, ["message"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 8
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Date",
                                    name: "date",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.formState.date,
                                        "onUpdate:value": ($event) => _ctx.formState.date = $event
                                      }, null, 8, ["value", "onUpdate:value"]),
                                      createVNode(_component_InputError, {
                                        class: "mt-2",
                                        message: _ctx.errors.date
                                      }, null, 8, ["message"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 8
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Payment Method",
                                    name: "payment_method",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        ref: "select",
                                        value: _ctx.formState.payment_method,
                                        "onUpdate:value": ($event) => _ctx.formState.payment_method = $event
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "jack" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Jack")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "lucy" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Lucy")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, {
                                            value: "disabled",
                                            disabled: ""
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode("Disabled")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                            default: withCtx(() => [
                                              createTextVNode("yiminghe")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["value", "onUpdate:value"]),
                                      createVNode(_component_InputError, {
                                        class: "mt-2",
                                        message: _ctx.errors.payment_method
                                      }, null, 8, ["message"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 8
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Shipping Method",
                                    name: "shipping_method",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        ref: "select",
                                        value: _ctx.formState.shipping_method,
                                        "onUpdate:value": ($event) => _ctx.formState.shipping_method = $event
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "jack" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Jack")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "lucy" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Lucy")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, {
                                            value: "disabled",
                                            disabled: ""
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode("Disabled")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                            default: withCtx(() => [
                                              createTextVNode("yiminghe")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["value", "onUpdate:value"]),
                                      createVNode(_component_InputError, {
                                        class: "mt-2",
                                        message: _ctx.errors.shipping_method
                                      }, null, 8, ["message"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("br"),
                          createVNode(_component_a_table, {
                            dataSource: _ctx.dataSource,
                            columns: _ctx.columns
                          }, null, 8, ["dataSource", "columns"]),
                          createVNode("br"),
                          createVNode(_component_a_row, { gutter: 24 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_textarea, {
                                    value: _ctx.value2,
                                    "onUpdate:value": ($event) => _ctx.value2 = $event,
                                    placeholder: "Terms and conditions",
                                    "auto-size": { minRows: 2, maxRows: 5 }
                                  }, null, 8, ["value", "onUpdate:value"]),
                                  createVNode(_component_a_textarea, {
                                    value: _ctx.value2,
                                    "onUpdate:value": ($event) => _ctx.value2 = $event,
                                    placeholder: "Notes",
                                    "auto-size": { minRows: 2, maxRows: 5 }
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_descriptions, {
                                    bordered: "",
                                    size: "small",
                                    column: { xxl: 1, xl: 1, lg: 1, md: 1, sm: 1, xs: 1 }
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_descriptions_item, { label: "Sub Total" }, {
                                        default: withCtx(() => [
                                          createTextVNode(" 90.00 ")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, { label: "Discount" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: _ctx.formState.date,
                                            "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                            bordered: false
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, { label: "Shipping Cost" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: _ctx.formState.date,
                                            "onUpdate:value": ($event) => _ctx.formState.date = $event,
                                            bordered: false
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, { label: "Total Inline Discount" }, {
                                        default: withCtx(() => [
                                          createTextVNode(" 90.00 ")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, { label: "Total Tax" }, {
                                        default: withCtx(() => [
                                          createTextVNode(" 90.00 ")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, { label: "Total" }, {
                                        default: withCtx(() => [
                                          createTextVNode(" 90.00 ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("br"),
                          createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("SUBMIT")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 16, ["model", "validate-messages", "onFinish"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Sales/Create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Create = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Create as default
};
