import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import "vue-request";
import { resolveComponent, withCtx, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, createCommentVNode, useSSRContext } from "vue";
import { Head, Link } from "@inertiajs/vue3";
import { DownloadOutlined, PlusCircleOutlined, MoreOutlined, DownOutlined } from "@ant-design/icons-vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
const Index_vue_vue_type_style_index_0_lang = "";
const columns = [
  {
    title: "Id",
    key: "",
    dataIndex: "",
    width: "5%"
  },
  {
    title: "Date",
    key: "",
    dataIndex: "",
    sorter: true,
    width: "10%"
  },
  {
    title: "Name",
    key: "",
    dataIndex: "",
    sorter: true,
    width: "10%"
  },
  {
    title: "Reference",
    key: "",
    dataIndex: "",
    sorter: true,
    width: "15%"
  },
  {
    title: "Paid from Bank Account",
    key: "",
    dataIndex: "",
    sorter: true,
    width: "15%"
  },
  {
    title: "Money In",
    key: "",
    dataIndex: "",
    sorter: true,
    width: "10%"
  },
  {
    title: "Money Out",
    key: "",
    dataIndex: "",
    sorter: true,
    width: "10%"
  },
  {
    title: "Repeat",
    key: "",
    dataIndex: "",
    sorter: true,
    width: "10%"
  }
];
const _sfc_main = {
  components: { AuthenticatedLayout: _sfc_main$1, DownloadOutlined, PlusCircleOutlined, MoreOutlined, Head, Link, DownOutlined },
  props: {
    sales: Object,
    pagination: Object,
    errors: Object
  },
  setup(props) {
    return {
      columns
    };
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_space = resolveComponent("a-space");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_date_picker = resolveComponent("a-date-picker");
  const _component_a_button = resolveComponent("a-button");
  const _component_a_dropdown = resolveComponent("a-dropdown");
  const _component_a_menu = resolveComponent("a-menu");
  const _component_Link = resolveComponent("Link");
  const _component_a_menu_item = resolveComponent("a-menu-item");
  const _component_DownOutlined = resolveComponent("DownOutlined");
  const _component_a_table = resolveComponent("a-table");
  const _component_a_avatar = resolveComponent("a-avatar");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Sales" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_layout_content, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, {
                      name: "nest-messages",
                      model: _ctx.formState,
                      layout: "inline",
                      onFinish: _ctx.search
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input, {
                                  placeholder: "Search by Name, Email, Phone...",
                                  value: _ctx.formState,
                                  "onUpdate:value": ($event) => _ctx.formState = $event
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input, {
                                    placeholder: "Search by Name, Email, Phone...",
                                    value: _ctx.formState,
                                    "onUpdate:value": ($event) => _ctx.formState = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_date_picker, {
                                  value: _ctx.date,
                                  "onUpdate:value": ($event) => _ctx.date = $event,
                                  format: "DD-MM-YYYY",
                                  "value-format": "YYYY-MM-DD"
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_date_picker, {
                                    value: _ctx.date,
                                    "onUpdate:value": ($event) => _ctx.date = $event,
                                    format: "DD-MM-YYYY",
                                    "value-format": "YYYY-MM-DD"
                                  }, null, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Search `);
                                    } else {
                                      return [
                                        createTextVNode(" Search ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Search ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_dropdown, null, {
                            overlay: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_menu, null, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_Link, {
                                        href: _ctx.route("cashbook.moneyin")
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_menu_item, { key: "1" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Money In `);
                                                } else {
                                                  return [
                                                    createTextVNode("Money In ")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_menu_item, { key: "1" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Money In ")
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_Link, {
                                        href: _ctx.route("cashbook.moneyout")
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_menu_item, { key: "2" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Money Out `);
                                                } else {
                                                  return [
                                                    createTextVNode("Money Out ")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_menu_item, { key: "2" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Money Out ")
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_Link, {
                                          href: _ctx.route("cashbook.moneyin")
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_menu_item, { key: "1" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Money In ")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["href"]),
                                        createVNode(_component_Link, {
                                          href: _ctx.route("cashbook.moneyout")
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_menu_item, { key: "2" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Money Out ")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["href"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_menu, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_Link, {
                                        href: _ctx.route("cashbook.moneyin")
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_menu_item, { key: "1" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Money In ")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["href"]),
                                      createVNode(_component_Link, {
                                        href: _ctx.route("cashbook.moneyout")
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_menu_item, { key: "2" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Money Out ")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["href"])
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  style: { "margin-left": "546px" }
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` New Entry `);
                                      _push7(ssrRenderComponent(_component_DownOutlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createTextVNode(" New Entry "),
                                        createVNode(_component_DownOutlined)
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    style: { "margin-left": "546px" }
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" New Entry "),
                                      createVNode(_component_DownOutlined)
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  placeholder: "Search by Name, Email, Phone...",
                                  value: _ctx.formState,
                                  "onUpdate:value": ($event) => _ctx.formState = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_date_picker, {
                                  value: _ctx.date,
                                  "onUpdate:value": ($event) => _ctx.date = $event,
                                  format: "DD-MM-YYYY",
                                  "value-format": "YYYY-MM-DD"
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Search ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_dropdown, null, {
                              overlay: withCtx(() => [
                                createVNode(_component_a_menu, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_Link, {
                                      href: _ctx.route("cashbook.moneyin")
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_menu_item, { key: "1" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Money In ")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["href"]),
                                    createVNode(_component_Link, {
                                      href: _ctx.route("cashbook.moneyout")
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_menu_item, { key: "2" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Money Out ")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["href"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  style: { "margin-left": "546px" }
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" New Entry "),
                                    createVNode(_component_DownOutlined)
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_table, {
                      columns: $setup.columns,
                      pagination: $props.pagination,
                      loading: _ctx.loading,
                      onChange: _ctx.handleTableChange
                    }, {
                      bodyCell: withCtx(({ column, text, record }, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`<template${_scopeId4}>${ssrInterpolate(text ?? "-")}</template>`);
                          if (column.key === "name") {
                            _push5(`<!--[-->`);
                            _push5(ssrRenderComponent(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(`${ssrInterpolate(text[0].toUpperCase())}`);
                                } else {
                                  return [
                                    createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                            _push5(`   ${ssrInterpolate(text)}<!--]-->`);
                          } else {
                            _push5(`<!---->`);
                          }
                        } else {
                          return [
                            createVNode("template", null, [
                              createTextVNode(toDisplayString(text ?? "-"), 1)
                            ]),
                            column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                              createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                                ]),
                                _: 2
                              }, 1024),
                              createTextVNode("   " + toDisplayString(text), 1)
                            ], 64)) : createCommentVNode("", true)
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, {
                        name: "nest-messages",
                        model: _ctx.formState,
                        layout: "inline",
                        onFinish: _ctx.search
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                placeholder: "Search by Name, Email, Phone...",
                                value: _ctx.formState,
                                "onUpdate:value": ($event) => _ctx.formState = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_date_picker, {
                                value: _ctx.date,
                                "onUpdate:value": ($event) => _ctx.date = $event,
                                format: "DD-MM-YYYY",
                                "value-format": "YYYY-MM-DD"
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Search ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_dropdown, null, {
                            overlay: withCtx(() => [
                              createVNode(_component_a_menu, null, {
                                default: withCtx(() => [
                                  createVNode(_component_Link, {
                                    href: _ctx.route("cashbook.moneyin")
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_menu_item, { key: "1" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Money In ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["href"]),
                                  createVNode(_component_Link, {
                                    href: _ctx.route("cashbook.moneyout")
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_menu_item, { key: "2" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Money Out ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["href"])
                                ]),
                                _: 1
                              })
                            ]),
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                style: { "margin-left": "546px" }
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" New Entry "),
                                  createVNode(_component_DownOutlined)
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["model", "onFinish"]),
                      createVNode(_component_a_table, {
                        columns: $setup.columns,
                        pagination: $props.pagination,
                        loading: _ctx.loading,
                        onChange: _ctx.handleTableChange
                      }, {
                        bodyCell: withCtx(({ column, text, record }) => [
                          createVNode("template", null, [
                            createTextVNode(toDisplayString(text ?? "-"), 1)
                          ]),
                          column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                            createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                              ]),
                              _: 2
                            }, 1024),
                            createTextVNode("   " + toDisplayString(text), 1)
                          ], 64)) : createCommentVNode("", true)
                        ]),
                        _: 1
                      }, 8, ["columns", "pagination", "loading", "onChange"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_space, {
                  direction: "vertical",
                  style: { width: "100%" }
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, {
                      name: "nest-messages",
                      model: _ctx.formState,
                      layout: "inline",
                      onFinish: _ctx.search
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, {
                              placeholder: "Search by Name, Email, Phone...",
                              value: _ctx.formState,
                              "onUpdate:value": ($event) => _ctx.formState = $event
                            }, null, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_date_picker, {
                              value: _ctx.date,
                              "onUpdate:value": ($event) => _ctx.date = $event,
                              format: "DD-MM-YYYY",
                              "value-format": "YYYY-MM-DD"
                            }, null, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Search ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_dropdown, null, {
                          overlay: withCtx(() => [
                            createVNode(_component_a_menu, null, {
                              default: withCtx(() => [
                                createVNode(_component_Link, {
                                  href: _ctx.route("cashbook.moneyin")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "1" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Money In ")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"]),
                                createVNode(_component_Link, {
                                  href: _ctx.route("cashbook.moneyout")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "2" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Money Out ")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["href"])
                              ]),
                              _: 1
                            })
                          ]),
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              style: { "margin-left": "546px" }
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" New Entry "),
                                createVNode(_component_DownOutlined)
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["model", "onFinish"]),
                    createVNode(_component_a_table, {
                      columns: $setup.columns,
                      pagination: $props.pagination,
                      loading: _ctx.loading,
                      onChange: _ctx.handleTableChange
                    }, {
                      bodyCell: withCtx(({ column, text, record }) => [
                        createVNode("template", null, [
                          createTextVNode(toDisplayString(text ?? "-"), 1)
                        ]),
                        column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                          createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                            ]),
                            _: 2
                          }, 1024),
                          createTextVNode("   " + toDisplayString(text), 1)
                        ], 64)) : createCommentVNode("", true)
                      ]),
                      _: 1
                    }, 8, ["columns", "pagination", "loading", "onChange"])
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_layout_content, null, {
            default: withCtx(() => [
              createVNode(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, {
                    name: "nest-messages",
                    model: _ctx.formState,
                    layout: "inline",
                    onFinish: _ctx.search
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            placeholder: "Search by Name, Email, Phone...",
                            value: _ctx.formState,
                            "onUpdate:value": ($event) => _ctx.formState = $event
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_date_picker, {
                            value: _ctx.date,
                            "onUpdate:value": ($event) => _ctx.date = $event,
                            format: "DD-MM-YYYY",
                            "value-format": "YYYY-MM-DD"
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Search ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_dropdown, null, {
                        overlay: withCtx(() => [
                          createVNode(_component_a_menu, null, {
                            default: withCtx(() => [
                              createVNode(_component_Link, {
                                href: _ctx.route("cashbook.moneyin")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "1" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Money In ")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(_component_Link, {
                                href: _ctx.route("cashbook.moneyout")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "2" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Money Out ")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          })
                        ]),
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            style: { "margin-left": "546px" }
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" New Entry "),
                              createVNode(_component_DownOutlined)
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["model", "onFinish"]),
                  createVNode(_component_a_table, {
                    columns: $setup.columns,
                    pagination: $props.pagination,
                    loading: _ctx.loading,
                    onChange: _ctx.handleTableChange
                  }, {
                    bodyCell: withCtx(({ column, text, record }) => [
                      createVNode("template", null, [
                        createTextVNode(toDisplayString(text ?? "-"), 1)
                      ]),
                      column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                        createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                          ]),
                          _: 2
                        }, 1024),
                        createTextVNode("   " + toDisplayString(text), 1)
                      ], 64)) : createCommentVNode("", true)
                    ]),
                    _: 1
                  }, 8, ["columns", "pagination", "loading", "onChange"])
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Cashbook/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Index as default
};
