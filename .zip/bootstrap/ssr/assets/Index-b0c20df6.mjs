import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import "vue-request";
import { resolveComponent, withCtx, createVNode, createTextVNode, mergeProps, useSSRContext } from "vue";
import { Head, Link, useForm } from "@inertiajs/vue3";
import { DownloadOutlined, PlusCircleOutlined, MoreOutlined, DownCircleOutlined, CloseCircleOutlined, EditOutlined, DeleteOutlined, MailOutlined, CheckOutlined, InteractionOutlined, FilePdfOutlined, PlusOutlined } from "@ant-design/icons-vue";
import { ssrRenderComponent, ssrRenderStyle } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
const columns = [
  {
    title: "Name",
    key: "name",
    dataIndex: "name"
  },
  {
    title: "Unit",
    key: "unit",
    dataIndex: "unit"
  },
  {
    title: "Price",
    key: "price",
    dataIndex: "price"
  },
  {
    title: "Tax Rate",
    key: "tax_rate",
    dataIndex: "tax_rate"
  },
  {
    title: "Default Supplier",
    key: "default_supplier",
    dataIndex: "default_supplier"
  },
  {
    title: "Default Inventory",
    key: "default_inventory",
    dataIndex: "default_inventory"
  },
  {
    title: "EAN",
    key: "ean",
    dataIndex: "ean"
  },
  {
    title: "Low stock level",
    key: "low_stock_level",
    dataIndex: "low_stock_level"
  }
];
const raw_materials = [
  {
    key: "1",
    name: "Raw material 1",
    unit: "PCS",
    price: "56.00",
    tax_rate: "23%",
    default_supplier: "Mona",
    default_inventory: "Shop Floor",
    ean: "BNMSGP00922",
    low_stock_level: "100"
  },
  {
    key: "1",
    name: "Raw material 1",
    unit: "PCS",
    price: "56.00",
    tax_rate: "23%",
    default_supplier: "Mona",
    default_inventory: "Shop Floor",
    ean: "BNMSGP00922",
    low_stock_level: "100"
  },
  {
    key: "1",
    name: "Raw material 1",
    unit: "PCS",
    price: "56.00",
    tax_rate: "23%",
    default_supplier: "Mona",
    default_inventory: "Shop Floor",
    ean: "BNMSGP00922",
    low_stock_level: "100"
  },
  {
    key: "1",
    name: "Raw material 1",
    unit: "PCS",
    price: "56.00",
    tax_rate: "23%",
    default_supplier: "Mona",
    default_inventory: "Shop Floor",
    ean: "BNMSGP00922",
    low_stock_level: "100"
  },
  {
    key: "1",
    name: "Raw material 1",
    unit: "PCS",
    price: "56.00",
    tax_rate: "23%",
    default_supplier: "Mona",
    default_inventory: "Shop Floor",
    ean: "BNMSGP00922",
    low_stock_level: "100"
  }
];
const purchase_ordercolumns = [{
  title: "Item Details",
  dataIndex: "item_details",
  key: "item_details",
  width: "40%"
}, {
  title: "Quantity",
  dataIndex: "quantity",
  key: "quantity",
  width: "10%"
}, {
  title: "Rate",
  dataIndex: "rate",
  key: "rate",
  width: "10%"
}, {
  title: "Amount",
  key: "amount",
  dataIndex: "amount",
  width: "10%"
}, {
  title: "Action",
  key: "action",
  width: "3%"
}];
const createPurchaseOrderItems = [
  {
    key: "1",
    item_details: "item 1",
    quantity: "1",
    rate: "0.00",
    amount: "1000.00",
    balance_due: "0.00",
    action: ""
  },
  {
    key: "2",
    item_details: "item 2",
    quantity: "1",
    rate: "0.00",
    amount: "1000.00",
    balance_due: "0.00",
    action: ""
  }
];
const _sfc_main = {
  components: {
    AuthenticatedLayout: _sfc_main$1,
    DownloadOutlined,
    PlusCircleOutlined,
    MoreOutlined,
    Head,
    Link,
    DownCircleOutlined,
    CloseCircleOutlined,
    EditOutlined,
    DeleteOutlined,
    MailOutlined,
    CheckOutlined,
    InteractionOutlined,
    FilePdfOutlined,
    PlusOutlined
  },
  props: {},
  setup(props) {
    return {
      columns,
      purchase_ordercolumns,
      raw_materials,
      createPurchaseOrderItems
    };
  },
  data() {
    const loading = false;
    const create_form_visible = false;
    const searchform = useForm({
      term: ""
    });
    const form = useForm({
      term: ""
    });
    return {
      create_form_visible,
      loading,
      searchform,
      form,
      showdetail: false
    };
  },
  methods: {
    showDrawer() {
      this.create_form_visible = true;
    },
    showDetailDrawer() {
      this.showdetail = true;
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_space = resolveComponent("a-space");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_button = resolveComponent("a-button");
  const _component_plus_circle_outlined = resolveComponent("plus-circle-outlined");
  const _component_a_table = resolveComponent("a-table");
  const _component_a_drawer = resolveComponent("a-drawer");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_select = resolveComponent("a-select");
  const _component_EditOutlined = resolveComponent("EditOutlined");
  const _component_DeleteOutlined = resolveComponent("DeleteOutlined");
  const _component_a_dropdown = resolveComponent("a-dropdown");
  const _component_a_menu = resolveComponent("a-menu");
  const _component_a_menu_item = resolveComponent("a-menu-item");
  const _component_FilePdfOutlined = resolveComponent("FilePdfOutlined");
  const _component_PlusOutlined = resolveComponent("PlusOutlined");
  const _component_MailOutlined = resolveComponent("MailOutlined");
  const _component_CheckOutlined = resolveComponent("CheckOutlined");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Raw materials" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_layout_content, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, {
                      name: "nest-messages",
                      model: $data.searchform,
                      layout: "inline",
                      onFinish: _ctx.search
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input, {
                                  placeholder: "Search",
                                  "allow-clear": true,
                                  value: $data.searchform.term,
                                  "onUpdate:value": ($event) => $data.searchform.term = $event
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input, {
                                    placeholder: "Search",
                                    "allow-clear": true,
                                    value: $data.searchform.term,
                                    "onUpdate:value": ($event) => $data.searchform.term = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Search `);
                                    } else {
                                      return [
                                        createTextVNode(" Search ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Search ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_plus_circle_outlined)
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Add `);
                                    } else {
                                      return [
                                        createTextVNode(" Add ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    shape: "round",
                                    onClick: $options.showDrawer
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Add ")
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  placeholder: "Search",
                                  "allow-clear": true,
                                  value: $data.searchform.term,
                                  "onUpdate:value": ($event) => $data.searchform.term = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Search ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Add ")
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_table, {
                      columns: $setup.columns,
                      "data-source": $setup.raw_materials
                    }, null, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, {
                        name: "nest-messages",
                        model: $data.searchform,
                        layout: "inline",
                        onFinish: _ctx.search
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                placeholder: "Search",
                                "allow-clear": true,
                                value: $data.searchform.term,
                                "onUpdate:value": ($event) => $data.searchform.term = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Search ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                shape: "round",
                                onClick: $options.showDrawer
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Add ")
                                ]),
                                _: 1
                              }, 8, ["onClick"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["model", "onFinish"]),
                      createVNode(_component_a_table, {
                        columns: $setup.columns,
                        "data-source": $setup.raw_materials
                      }, null, 8, ["columns", "data-source"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_drawer, {
                visible: $data.create_form_visible,
                "onUpdate:visible": ($event) => $data.create_form_visible = $event,
                class: "sales-bill",
                size: "large",
                style: { "color": "red" },
                width: "60%",
                title: "New raw material",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, mergeProps({ model: $data.form }, _ctx.layout, {
                      name: "nest-messages",
                      "validate-messages": _ctx.validateMessages,
                      onFinish: _ctx.submit,
                      "label-col": { span: 24 },
                      style: { "min-height": "100%" }
                    }), {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "Name",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: $data.form.name,
                                                "onUpdate:value": ($event) => $data.form.name = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "Name",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "Unit",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select, {
                                              value: $data.form.unit,
                                              "onUpdate:value": ($event) => $data.form.unit = $event,
                                              "show-search": "",
                                              placeholder: "Unit",
                                              style: { "width": "100%" },
                                              "default-active-first-option": false,
                                              "not-found-content": _ctx.value
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select, {
                                                value: $data.form.unit,
                                                "onUpdate:value": ($event) => $data.form.unit = $event,
                                                "show-search": "",
                                                placeholder: "Unit",
                                                style: { "width": "100%" },
                                                "default-active-first-option": false,
                                                "not-found-content": _ctx.value
                                              }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "Unit",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              value: $data.form.unit,
                                              "onUpdate:value": ($event) => $data.form.unit = $event,
                                              "show-search": "",
                                              placeholder: "Unit",
                                              style: { "width": "100%" },
                                              "default-active-first-option": false,
                                              "not-found-content": _ctx.value
                                            }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "price",
                                        label: "Price"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: $data.form.price,
                                              "onUpdate:value": ($event) => $data.form.price = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: $data.form.price,
                                                "onUpdate:value": ($event) => $data.form.price = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "price",
                                          label: "Price"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: $data.form.price,
                                              "onUpdate:value": ($event) => $data.form.price = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "Tax rates"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select, {
                                              value: $data.form.tax,
                                              "onUpdate:value": ($event) => $data.form.tax = $event,
                                              "show-search": "",
                                              placeholder: "Tax rates",
                                              style: { "width": "100%" },
                                              "default-active-first-option": false,
                                              "not-found-content": _ctx.value
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select, {
                                                value: $data.form.tax,
                                                "onUpdate:value": ($event) => $data.form.tax = $event,
                                                "show-search": "",
                                                placeholder: "Tax rates",
                                                style: { "width": "100%" },
                                                "default-active-first-option": false,
                                                "not-found-content": _ctx.value
                                              }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "Tax rates"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              value: $data.form.tax,
                                              "onUpdate:value": ($event) => $data.form.tax = $event,
                                              "show-search": "",
                                              placeholder: "Tax rates",
                                              style: { "width": "100%" },
                                              "default-active-first-option": false,
                                              "not-found-content": _ctx.value
                                            }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "Default Suppliers"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select, {
                                              value: $data.form.tax,
                                              "onUpdate:value": ($event) => $data.form.tax = $event,
                                              "show-search": "",
                                              placeholder: "Default Suppliers",
                                              style: { "width": "100%" },
                                              "default-active-first-option": false,
                                              "not-found-content": _ctx.value
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select, {
                                                value: $data.form.tax,
                                                "onUpdate:value": ($event) => $data.form.tax = $event,
                                                "show-search": "",
                                                placeholder: "Default Suppliers",
                                                style: { "width": "100%" },
                                                "default-active-first-option": false,
                                                "not-found-content": _ctx.value
                                              }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "Default Suppliers"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              value: $data.form.tax,
                                              "onUpdate:value": ($event) => $data.form.tax = $event,
                                              "show-search": "",
                                              placeholder: "Default Suppliers",
                                              style: { "width": "100%" },
                                              "default-active-first-option": false,
                                              "not-found-content": _ctx.value
                                            }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "Default Inventory"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select, {
                                              value: $data.form.tax,
                                              "onUpdate:value": ($event) => $data.form.tax = $event,
                                              "show-search": "",
                                              placeholder: "Default Inventory",
                                              style: { "width": "100%" },
                                              "default-active-first-option": false,
                                              "not-found-content": _ctx.value
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select, {
                                                value: $data.form.tax,
                                                "onUpdate:value": ($event) => $data.form.tax = $event,
                                                "show-search": "",
                                                placeholder: "Default Inventory",
                                                style: { "width": "100%" },
                                                "default-active-first-option": false,
                                                "not-found-content": _ctx.value
                                              }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "Default Inventory"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              value: $data.form.tax,
                                              "onUpdate:value": ($event) => $data.form.tax = $event,
                                              "show-search": "",
                                              placeholder: "Default Inventory",
                                              style: { "width": "100%" },
                                              "default-active-first-option": false,
                                              "not-found-content": _ctx.value
                                            }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "EAN"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: $data.form.name,
                                                "onUpdate:value": ($event) => $data.form.name = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "EAN"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "Optimal Stock Level"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: $data.form.name,
                                                "onUpdate:value": ($event) => $data.form.name = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "Optimal Stock Level"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "name",
                                        label: "Low Stock Level"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: $data.form.name,
                                                "onUpdate:value": ($event) => $data.form.name = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "name",
                                          label: "Low Stock Level"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: $data.form.name,
                                              "onUpdate:value": ($event) => $data.form.name = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "Name",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: $data.form.name,
                                            "onUpdate:value": ($event) => $data.form.name = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "Unit",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            value: $data.form.unit,
                                            "onUpdate:value": ($event) => $data.form.unit = $event,
                                            "show-search": "",
                                            placeholder: "Unit",
                                            style: { "width": "100%" },
                                            "default-active-first-option": false,
                                            "not-found-content": _ctx.value
                                          }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "price",
                                        label: "Price"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: $data.form.price,
                                            "onUpdate:value": ($event) => $data.form.price = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "Tax rates"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            value: $data.form.tax,
                                            "onUpdate:value": ($event) => $data.form.tax = $event,
                                            "show-search": "",
                                            placeholder: "Tax rates",
                                            style: { "width": "100%" },
                                            "default-active-first-option": false,
                                            "not-found-content": _ctx.value
                                          }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "Default Suppliers"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            value: $data.form.tax,
                                            "onUpdate:value": ($event) => $data.form.tax = $event,
                                            "show-search": "",
                                            placeholder: "Default Suppliers",
                                            style: { "width": "100%" },
                                            "default-active-first-option": false,
                                            "not-found-content": _ctx.value
                                          }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "Default Inventory"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            value: $data.form.tax,
                                            "onUpdate:value": ($event) => $data.form.tax = $event,
                                            "show-search": "",
                                            placeholder: "Default Inventory",
                                            style: { "width": "100%" },
                                            "default-active-first-option": false,
                                            "not-found-content": _ctx.value
                                          }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "EAN"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: $data.form.name,
                                            "onUpdate:value": ($event) => $data.form.name = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "Optimal Stock Level"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: $data.form.name,
                                            "onUpdate:value": ($event) => $data.form.name = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "name",
                                        label: "Low Stock Level"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: $data.form.name,
                                            "onUpdate:value": ($event) => $data.form.name = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "4"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit",
                                        disabled: $data.form.processing,
                                        block: ""
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`SAVE`);
                                          } else {
                                            return [
                                              createTextVNode("SAVE")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          "html-type": "submit",
                                          disabled: $data.form.processing,
                                          block: ""
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("SAVE")
                                          ]),
                                          _: 1
                                        }, 8, ["disabled"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "4"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit",
                                        disabled: $data.form.processing,
                                        block: ""
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("SAVE")
                                        ]),
                                        _: 1
                                      }, 8, ["disabled"])
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_row, { gutter: 24 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "Name",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: $data.form.name,
                                          "onUpdate:value": ($event) => $data.form.name = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "Unit",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          value: $data.form.unit,
                                          "onUpdate:value": ($event) => $data.form.unit = $event,
                                          "show-search": "",
                                          placeholder: "Unit",
                                          style: { "width": "100%" },
                                          "default-active-first-option": false,
                                          "not-found-content": _ctx.value
                                        }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "price",
                                      label: "Price"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: $data.form.price,
                                          "onUpdate:value": ($event) => $data.form.price = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "Tax rates"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          value: $data.form.tax,
                                          "onUpdate:value": ($event) => $data.form.tax = $event,
                                          "show-search": "",
                                          placeholder: "Tax rates",
                                          style: { "width": "100%" },
                                          "default-active-first-option": false,
                                          "not-found-content": _ctx.value
                                        }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "Default Suppliers"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          value: $data.form.tax,
                                          "onUpdate:value": ($event) => $data.form.tax = $event,
                                          "show-search": "",
                                          placeholder: "Default Suppliers",
                                          style: { "width": "100%" },
                                          "default-active-first-option": false,
                                          "not-found-content": _ctx.value
                                        }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "Default Inventory"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          value: $data.form.tax,
                                          "onUpdate:value": ($event) => $data.form.tax = $event,
                                          "show-search": "",
                                          placeholder: "Default Inventory",
                                          style: { "width": "100%" },
                                          "default-active-first-option": false,
                                          "not-found-content": _ctx.value
                                        }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "EAN"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: $data.form.name,
                                          "onUpdate:value": ($event) => $data.form.name = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "Optimal Stock Level"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: $data.form.name,
                                          "onUpdate:value": ($event) => $data.form.name = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "name",
                                      label: "Low Stock Level"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: $data.form.name,
                                          "onUpdate:value": ($event) => $data.form.name = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_row, { gutter: 24 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "4"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      "html-type": "submit",
                                      disabled: $data.form.processing,
                                      block: ""
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("SAVE")
                                      ]),
                                      _: 1
                                    }, 8, ["disabled"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, mergeProps({ model: $data.form }, _ctx.layout, {
                        name: "nest-messages",
                        "validate-messages": _ctx.validateMessages,
                        onFinish: _ctx.submit,
                        "label-col": { span: 24 },
                        style: { "min-height": "100%" }
                      }), {
                        default: withCtx(() => [
                          createVNode(_component_a_row, { gutter: 24 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "Name",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $data.form.name,
                                        "onUpdate:value": ($event) => $data.form.name = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "Unit",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        value: $data.form.unit,
                                        "onUpdate:value": ($event) => $data.form.unit = $event,
                                        "show-search": "",
                                        placeholder: "Unit",
                                        style: { "width": "100%" },
                                        "default-active-first-option": false,
                                        "not-found-content": _ctx.value
                                      }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "price",
                                    label: "Price"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $data.form.price,
                                        "onUpdate:value": ($event) => $data.form.price = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "Tax rates"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        value: $data.form.tax,
                                        "onUpdate:value": ($event) => $data.form.tax = $event,
                                        "show-search": "",
                                        placeholder: "Tax rates",
                                        style: { "width": "100%" },
                                        "default-active-first-option": false,
                                        "not-found-content": _ctx.value
                                      }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "Default Suppliers"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        value: $data.form.tax,
                                        "onUpdate:value": ($event) => $data.form.tax = $event,
                                        "show-search": "",
                                        placeholder: "Default Suppliers",
                                        style: { "width": "100%" },
                                        "default-active-first-option": false,
                                        "not-found-content": _ctx.value
                                      }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "Default Inventory"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        value: $data.form.tax,
                                        "onUpdate:value": ($event) => $data.form.tax = $event,
                                        "show-search": "",
                                        placeholder: "Default Inventory",
                                        style: { "width": "100%" },
                                        "default-active-first-option": false,
                                        "not-found-content": _ctx.value
                                      }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "EAN"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $data.form.name,
                                        "onUpdate:value": ($event) => $data.form.name = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "Optimal Stock Level"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $data.form.name,
                                        "onUpdate:value": ($event) => $data.form.name = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "name",
                                    label: "Low Stock Level"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $data.form.name,
                                        "onUpdate:value": ($event) => $data.form.name = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_row, { gutter: 24 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "4"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit",
                                    disabled: $data.form.processing,
                                    block: ""
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("SAVE")
                                    ]),
                                    _: 1
                                  }, 8, ["disabled"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 16, ["model", "validate-messages", "onFinish"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_drawer, {
                visible: $data.showdetail,
                "onUpdate:visible": ($event) => $data.showdetail = $event,
                class: "custom-class",
                title: "PO-000001",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange,
                width: "60%"
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_space, { style: { "margin-bottom": "10px" } }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_EditOutlined, null, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_EditOutlined)
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_button, {
                            type: "primary",
                            onClick: _ctx.onClose
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_DeleteOutlined, null, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_DeleteOutlined)
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_dropdown, null, {
                            overlay: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_menu_item, { key: "1" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(` PDF `);
                                          } else {
                                            return [
                                              createTextVNode(" PDF ")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_menu_item, { key: "2" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(` Print `);
                                          } else {
                                            return [
                                              createTextVNode(" Print ")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_menu_item, { key: "1" }, {
                                          default: withCtx(() => [
                                            createTextVNode(" PDF ")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_menu_item, { key: "2" }, {
                                          default: withCtx(() => [
                                            createTextVNode(" Print ")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_menu_item, { key: "1" }, {
                                        default: withCtx(() => [
                                          createTextVNode(" PDF ")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_menu_item, { key: "2" }, {
                                        default: withCtx(() => [
                                          createTextVNode(" Print ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ];
                              }
                            }),
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, null, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_FilePdfOutlined, null, null, _parent7, _scopeId6));
                                      _push7(` PDF / Print `);
                                    } else {
                                      return [
                                        createVNode(_component_FilePdfOutlined),
                                        createTextVNode(" PDF / Print ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_FilePdfOutlined),
                                      createTextVNode(" PDF / Print ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_PlusOutlined, null, null, _parent6, _scopeId5));
                                _push6(` Convert To Bill `);
                              } else {
                                return [
                                  createVNode(_component_PlusOutlined),
                                  createTextVNode(" Convert To Bill ")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_MailOutlined, null, null, _parent6, _scopeId5));
                                _push6(` Send Purchase Order `);
                              } else {
                                return [
                                  createVNode(_component_MailOutlined),
                                  createTextVNode(" Send Purchase Order ")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_CheckOutlined, null, null, _parent6, _scopeId5));
                                _push6(` Mark As Sent `);
                              } else {
                                return [
                                  createVNode(_component_CheckOutlined),
                                  createTextVNode(" Mark As Sent ")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                              default: withCtx(() => [
                                createVNode(_component_EditOutlined)
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(_component_a_button, {
                              type: "primary",
                              onClick: _ctx.onClose
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_DeleteOutlined)
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(_component_a_dropdown, null, {
                              overlay: withCtx(() => [
                                createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "1" }, {
                                      default: withCtx(() => [
                                        createTextVNode(" PDF ")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_menu_item, { key: "2" }, {
                                      default: withCtx(() => [
                                        createTextVNode(" Print ")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])
                              ]),
                              default: withCtx(() => [
                                createVNode(_component_a_button, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_FilePdfOutlined),
                                    createTextVNode(" PDF / Print ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                              default: withCtx(() => [
                                createVNode(_component_PlusOutlined),
                                createTextVNode(" Convert To Bill ")
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                              default: withCtx(() => [
                                createVNode(_component_MailOutlined),
                                createTextVNode(" Send Purchase Order ")
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                              default: withCtx(() => [
                                createVNode(_component_CheckOutlined),
                                createTextVNode(" Mark As Sent ")
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(`<div class="quote-template"${_scopeId3}><table style="${ssrRenderStyle({ "width": "100%" })}" class="quote-table"${_scopeId3}><tr${_scopeId3}><td colspan="2"${_scopeId3}><h2${_scopeId3}>PURCHASE ORDER</h2><p${_scopeId3}><b${_scopeId3}>lynchpin</b></p><p${_scopeId3}>Tamil Nadu </p><p${_scopeId3}>India</p><p${_scopeId3}>mohana.lynchpin@gmail.com</p></td><td colspan="2" align="right"${_scopeId3}><img src="/images/logo-2.png" style="${ssrRenderStyle({ "max-width": "200px" })}"${_scopeId3}></td></tr><tr class="highlight"${_scopeId3}><td colspan="2"${_scopeId3}><p${_scopeId3}>PO Number : PO-000001</p></td><td colspan="2" align="right"${_scopeId3}><p${_scopeId3}>Date : 10/10/2023</p></td></tr><tr${_scopeId3}><td colspan="2"${_scopeId3}><p${_scopeId3}><b${_scopeId3}>Deliver To: </b></p><p${_scopeId3}>Mr John Doe</p><p${_scopeId3}>KK nagar</p><p${_scopeId3}>+91 9876543210</p><br${_scopeId3}></td><td colspan="2" align="right"${_scopeId3}><p${_scopeId3}><b${_scopeId3}>Vendor: </b></p><p${_scopeId3}>Mr John Doe</p><p${_scopeId3}>KK nagar</p><p${_scopeId3}>+91 9876543210</p><br${_scopeId3}></td></tr></table><table style="${ssrRenderStyle({ "width": "100%" })}" class="quote-table border"${_scopeId3}><tr${_scopeId3}><th align="left"${_scopeId3}>Item Details</th><th${_scopeId3}>Quantity</th><th${_scopeId3}>Rate</th><th width="100px" align="right"${_scopeId3}>Amount</th></tr><tr${_scopeId3}><td${_scopeId3}> item 1 <p${_scopeId3}>shopify Application development and service</p></td><td${_scopeId3}>1</td><td${_scopeId3}>0.00</td><td align="right"${_scopeId3}>0.00</td></tr><tr${_scopeId3}><td${_scopeId3}>item 2 <p${_scopeId3}>shopify Application development and service</p></td><td${_scopeId3}>1</td><td${_scopeId3}>0.00</td><td align="right"${_scopeId3}>0.00</td></tr><tr${_scopeId3}><td colspan="2"${_scopeId3}><div style="${ssrRenderStyle({ "margin-right": "20px" })}"${_scopeId3}><h5${_scopeId3}>Terms &amp; Conditions</h5><p${_scopeId3}>1. Payment should be made within 30 days from the date of purchase_order.</p><p${_scopeId3}>2. Goods once sold will not be taken back.</p><p${_scopeId3}>3. Interest @ 24% will be charged for the delay in payment.</p></div><br${_scopeId3}><br${_scopeId3}><p${_scopeId3}>Authorized Signature </p><br${_scopeId3}><br${_scopeId3}><hr class="signature-hr"${_scopeId3}></td><td colspan="2" style="${ssrRenderStyle({ "padding": "0" })}"${_scopeId3}><table style="${ssrRenderStyle({ "width": "100%" })}"${_scopeId3}><tr${_scopeId3}><td colspan="3"${_scopeId3}>Sub Total</td><td width="100px" align="right"${_scopeId3}>0.00</td></tr><tr${_scopeId3}><td colspan="3"${_scopeId3}>Discount</td><td align="right"${_scopeId3}>0.00</td></tr><tr${_scopeId3}><td colspan="3"${_scopeId3}>Tax</td><td align="right"${_scopeId3}>0.00</td></tr><tr${_scopeId3}><td colspan="3"${_scopeId3}>Adjustment</td><td align="right"${_scopeId3}>0.00</td></tr><tr${_scopeId3}><td colspan="3"${_scopeId3}>Total</td><td align="right"${_scopeId3}>0.00</td></tr></table></td></tr></table></div>`);
                  } else {
                    return [
                      createVNode(_component_a_space, { style: { "margin-bottom": "10px" } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx(() => [
                              createVNode(_component_EditOutlined)
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(_component_a_button, {
                            type: "primary",
                            onClick: _ctx.onClose
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_DeleteOutlined)
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(_component_a_dropdown, null, {
                            overlay: withCtx(() => [
                              createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "1" }, {
                                    default: withCtx(() => [
                                      createTextVNode(" PDF ")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_menu_item, { key: "2" }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Print ")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["onClick"])
                            ]),
                            default: withCtx(() => [
                              createVNode(_component_a_button, null, {
                                default: withCtx(() => [
                                  createVNode(_component_FilePdfOutlined),
                                  createTextVNode(" PDF / Print ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx(() => [
                              createVNode(_component_PlusOutlined),
                              createTextVNode(" Convert To Bill ")
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx(() => [
                              createVNode(_component_MailOutlined),
                              createTextVNode(" Send Purchase Order ")
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx(() => [
                              createVNode(_component_CheckOutlined),
                              createTextVNode(" Mark As Sent ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        _: 1
                      }),
                      createVNode("div", { class: "quote-template" }, [
                        createVNode("table", {
                          style: { "width": "100%" },
                          class: "quote-table"
                        }, [
                          createVNode("tr", null, [
                            createVNode("td", { colspan: "2" }, [
                              createVNode("h2", null, "PURCHASE ORDER"),
                              createVNode("p", null, [
                                createVNode("b", null, "lynchpin")
                              ]),
                              createVNode("p", null, "Tamil Nadu "),
                              createVNode("p", null, "India"),
                              createVNode("p", null, "mohana.lynchpin@gmail.com")
                            ]),
                            createVNode("td", {
                              colspan: "2",
                              align: "right"
                            }, [
                              createVNode("img", {
                                src: "/images/logo-2.png",
                                style: { "max-width": "200px" }
                              })
                            ])
                          ]),
                          createVNode("tr", { class: "highlight" }, [
                            createVNode("td", { colspan: "2" }, [
                              createVNode("p", null, "PO Number : PO-000001")
                            ]),
                            createVNode("td", {
                              colspan: "2",
                              align: "right"
                            }, [
                              createVNode("p", null, "Date : 10/10/2023")
                            ])
                          ]),
                          createVNode("tr", null, [
                            createVNode("td", { colspan: "2" }, [
                              createVNode("p", null, [
                                createVNode("b", null, "Deliver To: ")
                              ]),
                              createVNode("p", null, "Mr John Doe"),
                              createVNode("p", null, "KK nagar"),
                              createVNode("p", null, "+91 9876543210"),
                              createVNode("br")
                            ]),
                            createVNode("td", {
                              colspan: "2",
                              align: "right"
                            }, [
                              createVNode("p", null, [
                                createVNode("b", null, "Vendor: ")
                              ]),
                              createVNode("p", null, "Mr John Doe"),
                              createVNode("p", null, "KK nagar"),
                              createVNode("p", null, "+91 9876543210"),
                              createVNode("br")
                            ])
                          ])
                        ]),
                        createVNode("table", {
                          style: { "width": "100%" },
                          class: "quote-table border"
                        }, [
                          createVNode("tr", null, [
                            createVNode("th", { align: "left" }, "Item Details"),
                            createVNode("th", null, "Quantity"),
                            createVNode("th", null, "Rate"),
                            createVNode("th", {
                              width: "100px",
                              align: "right"
                            }, "Amount")
                          ]),
                          createVNode("tr", null, [
                            createVNode("td", null, [
                              createTextVNode(" item 1 "),
                              createVNode("p", null, "shopify Application development and service")
                            ]),
                            createVNode("td", null, "1"),
                            createVNode("td", null, "0.00"),
                            createVNode("td", { align: "right" }, "0.00")
                          ]),
                          createVNode("tr", null, [
                            createVNode("td", null, [
                              createTextVNode("item 2 "),
                              createVNode("p", null, "shopify Application development and service")
                            ]),
                            createVNode("td", null, "1"),
                            createVNode("td", null, "0.00"),
                            createVNode("td", { align: "right" }, "0.00")
                          ]),
                          createVNode("tr", null, [
                            createVNode("td", { colspan: "2" }, [
                              createVNode("div", { style: { "margin-right": "20px" } }, [
                                createVNode("h5", null, "Terms & Conditions"),
                                createVNode("p", null, "1. Payment should be made within 30 days from the date of purchase_order."),
                                createVNode("p", null, "2. Goods once sold will not be taken back."),
                                createVNode("p", null, "3. Interest @ 24% will be charged for the delay in payment.")
                              ]),
                              createVNode("br"),
                              createVNode("br"),
                              createVNode("p", null, "Authorized Signature "),
                              createVNode("br"),
                              createVNode("br"),
                              createVNode("hr", { class: "signature-hr" })
                            ]),
                            createVNode("td", {
                              colspan: "2",
                              style: { "padding": "0" }
                            }, [
                              createVNode("table", { style: { "width": "100%" } }, [
                                createVNode("tr", null, [
                                  createVNode("td", { colspan: "3" }, "Sub Total"),
                                  createVNode("td", {
                                    width: "100px",
                                    align: "right"
                                  }, "0.00")
                                ]),
                                createVNode("tr", null, [
                                  createVNode("td", { colspan: "3" }, "Discount"),
                                  createVNode("td", { align: "right" }, "0.00")
                                ]),
                                createVNode("tr", null, [
                                  createVNode("td", { colspan: "3" }, "Tax"),
                                  createVNode("td", { align: "right" }, "0.00")
                                ]),
                                createVNode("tr", null, [
                                  createVNode("td", { colspan: "3" }, "Adjustment"),
                                  createVNode("td", { align: "right" }, "0.00")
                                ]),
                                createVNode("tr", null, [
                                  createVNode("td", { colspan: "3" }, "Total"),
                                  createVNode("td", { align: "right" }, "0.00")
                                ])
                              ])
                            ])
                          ])
                        ])
                      ])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_space, {
                  direction: "vertical",
                  style: { width: "100%" }
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, {
                      name: "nest-messages",
                      model: $data.searchform,
                      layout: "inline",
                      onFinish: _ctx.search
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, {
                              placeholder: "Search",
                              "allow-clear": true,
                              value: $data.searchform.term,
                              "onUpdate:value": ($event) => $data.searchform.term = $event
                            }, null, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Search ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              shape: "round",
                              onClick: $options.showDrawer
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_plus_circle_outlined)
                              ]),
                              default: withCtx(() => [
                                createTextVNode(" Add ")
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["model", "onFinish"]),
                    createVNode(_component_a_table, {
                      columns: $setup.columns,
                      "data-source": $setup.raw_materials
                    }, null, 8, ["columns", "data-source"])
                  ]),
                  _: 1
                }),
                createVNode(_component_a_drawer, {
                  visible: $data.create_form_visible,
                  "onUpdate:visible": ($event) => $data.create_form_visible = $event,
                  class: "sales-bill",
                  size: "large",
                  style: { "color": "red" },
                  width: "60%",
                  title: "New raw material",
                  placement: "right",
                  onAfterVisibleChange: _ctx.afterVisibleChange
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, mergeProps({ model: $data.form }, _ctx.layout, {
                      name: "nest-messages",
                      "validate-messages": _ctx.validateMessages,
                      onFinish: _ctx.submit,
                      "label-col": { span: 24 },
                      style: { "min-height": "100%" }
                    }), {
                      default: withCtx(() => [
                        createVNode(_component_a_row, { gutter: 24 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "Name",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $data.form.name,
                                      "onUpdate:value": ($event) => $data.form.name = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "Unit",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      value: $data.form.unit,
                                      "onUpdate:value": ($event) => $data.form.unit = $event,
                                      "show-search": "",
                                      placeholder: "Unit",
                                      style: { "width": "100%" },
                                      "default-active-first-option": false,
                                      "not-found-content": _ctx.value
                                    }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "price",
                                  label: "Price"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $data.form.price,
                                      "onUpdate:value": ($event) => $data.form.price = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "Tax rates"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      value: $data.form.tax,
                                      "onUpdate:value": ($event) => $data.form.tax = $event,
                                      "show-search": "",
                                      placeholder: "Tax rates",
                                      style: { "width": "100%" },
                                      "default-active-first-option": false,
                                      "not-found-content": _ctx.value
                                    }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "Default Suppliers"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      value: $data.form.tax,
                                      "onUpdate:value": ($event) => $data.form.tax = $event,
                                      "show-search": "",
                                      placeholder: "Default Suppliers",
                                      style: { "width": "100%" },
                                      "default-active-first-option": false,
                                      "not-found-content": _ctx.value
                                    }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "Default Inventory"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      value: $data.form.tax,
                                      "onUpdate:value": ($event) => $data.form.tax = $event,
                                      "show-search": "",
                                      placeholder: "Default Inventory",
                                      style: { "width": "100%" },
                                      "default-active-first-option": false,
                                      "not-found-content": _ctx.value
                                    }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "EAN"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $data.form.name,
                                      "onUpdate:value": ($event) => $data.form.name = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "Optimal Stock Level"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $data.form.name,
                                      "onUpdate:value": ($event) => $data.form.name = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "name",
                                  label: "Low Stock Level"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $data.form.name,
                                      "onUpdate:value": ($event) => $data.form.name = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_row, { gutter: 24 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "4"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit",
                                  disabled: $data.form.processing,
                                  block: ""
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("SAVE")
                                  ]),
                                  _: 1
                                }, 8, ["disabled"])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 16, ["model", "validate-messages", "onFinish"])
                  ]),
                  _: 1
                }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"]),
                createVNode(_component_a_drawer, {
                  visible: $data.showdetail,
                  "onUpdate:visible": ($event) => $data.showdetail = $event,
                  class: "custom-class",
                  title: "PO-000001",
                  size: "large",
                  placement: "right",
                  onAfterVisibleChange: _ctx.afterVisibleChange,
                  width: "60%"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_space, { style: { "margin-bottom": "10px" } }, {
                      default: withCtx(() => [
                        createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                          default: withCtx(() => [
                            createVNode(_component_EditOutlined)
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_component_a_button, {
                          type: "primary",
                          onClick: _ctx.onClose
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_DeleteOutlined)
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_component_a_dropdown, null, {
                          overlay: withCtx(() => [
                            createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "1" }, {
                                  default: withCtx(() => [
                                    createTextVNode(" PDF ")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_menu_item, { key: "2" }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Print ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ]),
                          default: withCtx(() => [
                            createVNode(_component_a_button, null, {
                              default: withCtx(() => [
                                createVNode(_component_FilePdfOutlined),
                                createTextVNode(" PDF / Print ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                          default: withCtx(() => [
                            createVNode(_component_PlusOutlined),
                            createTextVNode(" Convert To Bill ")
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                          default: withCtx(() => [
                            createVNode(_component_MailOutlined),
                            createTextVNode(" Send Purchase Order ")
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                          default: withCtx(() => [
                            createVNode(_component_CheckOutlined),
                            createTextVNode(" Mark As Sent ")
                          ]),
                          _: 1
                        }, 8, ["onClick"])
                      ]),
                      _: 1
                    }),
                    createVNode("div", { class: "quote-template" }, [
                      createVNode("table", {
                        style: { "width": "100%" },
                        class: "quote-table"
                      }, [
                        createVNode("tr", null, [
                          createVNode("td", { colspan: "2" }, [
                            createVNode("h2", null, "PURCHASE ORDER"),
                            createVNode("p", null, [
                              createVNode("b", null, "lynchpin")
                            ]),
                            createVNode("p", null, "Tamil Nadu "),
                            createVNode("p", null, "India"),
                            createVNode("p", null, "mohana.lynchpin@gmail.com")
                          ]),
                          createVNode("td", {
                            colspan: "2",
                            align: "right"
                          }, [
                            createVNode("img", {
                              src: "/images/logo-2.png",
                              style: { "max-width": "200px" }
                            })
                          ])
                        ]),
                        createVNode("tr", { class: "highlight" }, [
                          createVNode("td", { colspan: "2" }, [
                            createVNode("p", null, "PO Number : PO-000001")
                          ]),
                          createVNode("td", {
                            colspan: "2",
                            align: "right"
                          }, [
                            createVNode("p", null, "Date : 10/10/2023")
                          ])
                        ]),
                        createVNode("tr", null, [
                          createVNode("td", { colspan: "2" }, [
                            createVNode("p", null, [
                              createVNode("b", null, "Deliver To: ")
                            ]),
                            createVNode("p", null, "Mr John Doe"),
                            createVNode("p", null, "KK nagar"),
                            createVNode("p", null, "+91 9876543210"),
                            createVNode("br")
                          ]),
                          createVNode("td", {
                            colspan: "2",
                            align: "right"
                          }, [
                            createVNode("p", null, [
                              createVNode("b", null, "Vendor: ")
                            ]),
                            createVNode("p", null, "Mr John Doe"),
                            createVNode("p", null, "KK nagar"),
                            createVNode("p", null, "+91 9876543210"),
                            createVNode("br")
                          ])
                        ])
                      ]),
                      createVNode("table", {
                        style: { "width": "100%" },
                        class: "quote-table border"
                      }, [
                        createVNode("tr", null, [
                          createVNode("th", { align: "left" }, "Item Details"),
                          createVNode("th", null, "Quantity"),
                          createVNode("th", null, "Rate"),
                          createVNode("th", {
                            width: "100px",
                            align: "right"
                          }, "Amount")
                        ]),
                        createVNode("tr", null, [
                          createVNode("td", null, [
                            createTextVNode(" item 1 "),
                            createVNode("p", null, "shopify Application development and service")
                          ]),
                          createVNode("td", null, "1"),
                          createVNode("td", null, "0.00"),
                          createVNode("td", { align: "right" }, "0.00")
                        ]),
                        createVNode("tr", null, [
                          createVNode("td", null, [
                            createTextVNode("item 2 "),
                            createVNode("p", null, "shopify Application development and service")
                          ]),
                          createVNode("td", null, "1"),
                          createVNode("td", null, "0.00"),
                          createVNode("td", { align: "right" }, "0.00")
                        ]),
                        createVNode("tr", null, [
                          createVNode("td", { colspan: "2" }, [
                            createVNode("div", { style: { "margin-right": "20px" } }, [
                              createVNode("h5", null, "Terms & Conditions"),
                              createVNode("p", null, "1. Payment should be made within 30 days from the date of purchase_order."),
                              createVNode("p", null, "2. Goods once sold will not be taken back."),
                              createVNode("p", null, "3. Interest @ 24% will be charged for the delay in payment.")
                            ]),
                            createVNode("br"),
                            createVNode("br"),
                            createVNode("p", null, "Authorized Signature "),
                            createVNode("br"),
                            createVNode("br"),
                            createVNode("hr", { class: "signature-hr" })
                          ]),
                          createVNode("td", {
                            colspan: "2",
                            style: { "padding": "0" }
                          }, [
                            createVNode("table", { style: { "width": "100%" } }, [
                              createVNode("tr", null, [
                                createVNode("td", { colspan: "3" }, "Sub Total"),
                                createVNode("td", {
                                  width: "100px",
                                  align: "right"
                                }, "0.00")
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", { colspan: "3" }, "Discount"),
                                createVNode("td", { align: "right" }, "0.00")
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", { colspan: "3" }, "Tax"),
                                createVNode("td", { align: "right" }, "0.00")
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", { colspan: "3" }, "Adjustment"),
                                createVNode("td", { align: "right" }, "0.00")
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", { colspan: "3" }, "Total"),
                                createVNode("td", { align: "right" }, "0.00")
                              ])
                            ])
                          ])
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_layout_content, null, {
            default: withCtx(() => [
              createVNode(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, {
                    name: "nest-messages",
                    model: $data.searchform,
                    layout: "inline",
                    onFinish: _ctx.search
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            placeholder: "Search",
                            "allow-clear": true,
                            value: $data.searchform.term,
                            "onUpdate:value": ($event) => $data.searchform.term = $event
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Search ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            shape: "round",
                            onClick: $options.showDrawer
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_plus_circle_outlined)
                            ]),
                            default: withCtx(() => [
                              createTextVNode(" Add ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["model", "onFinish"]),
                  createVNode(_component_a_table, {
                    columns: $setup.columns,
                    "data-source": $setup.raw_materials
                  }, null, 8, ["columns", "data-source"])
                ]),
                _: 1
              }),
              createVNode(_component_a_drawer, {
                visible: $data.create_form_visible,
                "onUpdate:visible": ($event) => $data.create_form_visible = $event,
                class: "sales-bill",
                size: "large",
                style: { "color": "red" },
                width: "60%",
                title: "New raw material",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, mergeProps({ model: $data.form }, _ctx.layout, {
                    name: "nest-messages",
                    "validate-messages": _ctx.validateMessages,
                    onFinish: _ctx.submit,
                    "label-col": { span: 24 },
                    style: { "min-height": "100%" }
                  }), {
                    default: withCtx(() => [
                      createVNode(_component_a_row, { gutter: 24 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "Name",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $data.form.name,
                                    "onUpdate:value": ($event) => $data.form.name = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "Unit",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    value: $data.form.unit,
                                    "onUpdate:value": ($event) => $data.form.unit = $event,
                                    "show-search": "",
                                    placeholder: "Unit",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    "not-found-content": _ctx.value
                                  }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "price",
                                label: "Price"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $data.form.price,
                                    "onUpdate:value": ($event) => $data.form.price = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "Tax rates"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    value: $data.form.tax,
                                    "onUpdate:value": ($event) => $data.form.tax = $event,
                                    "show-search": "",
                                    placeholder: "Tax rates",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    "not-found-content": _ctx.value
                                  }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "Default Suppliers"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    value: $data.form.tax,
                                    "onUpdate:value": ($event) => $data.form.tax = $event,
                                    "show-search": "",
                                    placeholder: "Default Suppliers",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    "not-found-content": _ctx.value
                                  }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "Default Inventory"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    value: $data.form.tax,
                                    "onUpdate:value": ($event) => $data.form.tax = $event,
                                    "show-search": "",
                                    placeholder: "Default Inventory",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    "not-found-content": _ctx.value
                                  }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "EAN"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $data.form.name,
                                    "onUpdate:value": ($event) => $data.form.name = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "Optimal Stock Level"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $data.form.name,
                                    "onUpdate:value": ($event) => $data.form.name = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "name",
                                label: "Low Stock Level"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $data.form.name,
                                    "onUpdate:value": ($event) => $data.form.name = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_row, { gutter: 24 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "4"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit",
                                disabled: $data.form.processing,
                                block: ""
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("SAVE")
                                ]),
                                _: 1
                              }, 8, ["disabled"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 16, ["model", "validate-messages", "onFinish"])
                ]),
                _: 1
              }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"]),
              createVNode(_component_a_drawer, {
                visible: $data.showdetail,
                "onUpdate:visible": ($event) => $data.showdetail = $event,
                class: "custom-class",
                title: "PO-000001",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange,
                width: "60%"
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_space, { style: { "margin-bottom": "10px" } }, {
                    default: withCtx(() => [
                      createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                        default: withCtx(() => [
                          createVNode(_component_EditOutlined)
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_button, {
                        type: "primary",
                        onClick: _ctx.onClose
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_DeleteOutlined)
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_dropdown, null, {
                        overlay: withCtx(() => [
                          createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "1" }, {
                                default: withCtx(() => [
                                  createTextVNode(" PDF ")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_menu_item, { key: "2" }, {
                                default: withCtx(() => [
                                  createTextVNode(" Print ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        default: withCtx(() => [
                          createVNode(_component_a_button, null, {
                            default: withCtx(() => [
                              createVNode(_component_FilePdfOutlined),
                              createTextVNode(" PDF / Print ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                        default: withCtx(() => [
                          createVNode(_component_PlusOutlined),
                          createTextVNode(" Convert To Bill ")
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                        default: withCtx(() => [
                          createVNode(_component_MailOutlined),
                          createTextVNode(" Send Purchase Order ")
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                        default: withCtx(() => [
                          createVNode(_component_CheckOutlined),
                          createTextVNode(" Mark As Sent ")
                        ]),
                        _: 1
                      }, 8, ["onClick"])
                    ]),
                    _: 1
                  }),
                  createVNode("div", { class: "quote-template" }, [
                    createVNode("table", {
                      style: { "width": "100%" },
                      class: "quote-table"
                    }, [
                      createVNode("tr", null, [
                        createVNode("td", { colspan: "2" }, [
                          createVNode("h2", null, "PURCHASE ORDER"),
                          createVNode("p", null, [
                            createVNode("b", null, "lynchpin")
                          ]),
                          createVNode("p", null, "Tamil Nadu "),
                          createVNode("p", null, "India"),
                          createVNode("p", null, "mohana.lynchpin@gmail.com")
                        ]),
                        createVNode("td", {
                          colspan: "2",
                          align: "right"
                        }, [
                          createVNode("img", {
                            src: "/images/logo-2.png",
                            style: { "max-width": "200px" }
                          })
                        ])
                      ]),
                      createVNode("tr", { class: "highlight" }, [
                        createVNode("td", { colspan: "2" }, [
                          createVNode("p", null, "PO Number : PO-000001")
                        ]),
                        createVNode("td", {
                          colspan: "2",
                          align: "right"
                        }, [
                          createVNode("p", null, "Date : 10/10/2023")
                        ])
                      ]),
                      createVNode("tr", null, [
                        createVNode("td", { colspan: "2" }, [
                          createVNode("p", null, [
                            createVNode("b", null, "Deliver To: ")
                          ]),
                          createVNode("p", null, "Mr John Doe"),
                          createVNode("p", null, "KK nagar"),
                          createVNode("p", null, "+91 9876543210"),
                          createVNode("br")
                        ]),
                        createVNode("td", {
                          colspan: "2",
                          align: "right"
                        }, [
                          createVNode("p", null, [
                            createVNode("b", null, "Vendor: ")
                          ]),
                          createVNode("p", null, "Mr John Doe"),
                          createVNode("p", null, "KK nagar"),
                          createVNode("p", null, "+91 9876543210"),
                          createVNode("br")
                        ])
                      ])
                    ]),
                    createVNode("table", {
                      style: { "width": "100%" },
                      class: "quote-table border"
                    }, [
                      createVNode("tr", null, [
                        createVNode("th", { align: "left" }, "Item Details"),
                        createVNode("th", null, "Quantity"),
                        createVNode("th", null, "Rate"),
                        createVNode("th", {
                          width: "100px",
                          align: "right"
                        }, "Amount")
                      ]),
                      createVNode("tr", null, [
                        createVNode("td", null, [
                          createTextVNode(" item 1 "),
                          createVNode("p", null, "shopify Application development and service")
                        ]),
                        createVNode("td", null, "1"),
                        createVNode("td", null, "0.00"),
                        createVNode("td", { align: "right" }, "0.00")
                      ]),
                      createVNode("tr", null, [
                        createVNode("td", null, [
                          createTextVNode("item 2 "),
                          createVNode("p", null, "shopify Application development and service")
                        ]),
                        createVNode("td", null, "1"),
                        createVNode("td", null, "0.00"),
                        createVNode("td", { align: "right" }, "0.00")
                      ]),
                      createVNode("tr", null, [
                        createVNode("td", { colspan: "2" }, [
                          createVNode("div", { style: { "margin-right": "20px" } }, [
                            createVNode("h5", null, "Terms & Conditions"),
                            createVNode("p", null, "1. Payment should be made within 30 days from the date of purchase_order."),
                            createVNode("p", null, "2. Goods once sold will not be taken back."),
                            createVNode("p", null, "3. Interest @ 24% will be charged for the delay in payment.")
                          ]),
                          createVNode("br"),
                          createVNode("br"),
                          createVNode("p", null, "Authorized Signature "),
                          createVNode("br"),
                          createVNode("br"),
                          createVNode("hr", { class: "signature-hr" })
                        ]),
                        createVNode("td", {
                          colspan: "2",
                          style: { "padding": "0" }
                        }, [
                          createVNode("table", { style: { "width": "100%" } }, [
                            createVNode("tr", null, [
                              createVNode("td", { colspan: "3" }, "Sub Total"),
                              createVNode("td", {
                                width: "100px",
                                align: "right"
                              }, "0.00")
                            ]),
                            createVNode("tr", null, [
                              createVNode("td", { colspan: "3" }, "Discount"),
                              createVNode("td", { align: "right" }, "0.00")
                            ]),
                            createVNode("tr", null, [
                              createVNode("td", { colspan: "3" }, "Tax"),
                              createVNode("td", { align: "right" }, "0.00")
                            ]),
                            createVNode("tr", null, [
                              createVNode("td", { colspan: "3" }, "Adjustment"),
                              createVNode("td", { align: "right" }, "0.00")
                            ]),
                            createVNode("tr", null, [
                              createVNode("td", { colspan: "3" }, "Total"),
                              createVNode("td", { align: "right" }, "0.00")
                            ])
                          ])
                        ])
                      ])
                    ])
                  ])
                ]),
                _: 1
              }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"])
            ]),
            _: 1
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Rawmaterial/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Index as default
};
