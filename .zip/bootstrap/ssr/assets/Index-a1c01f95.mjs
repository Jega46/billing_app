import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import "vue-request";
import { resolveComponent, withCtx, createVNode, createTextVNode, openBlock, createBlock, toDisplayString, createCommentVNode, mergeProps, Fragment, useSSRContext } from "vue";
import { Head, Link, useForm } from "@inertiajs/vue3";
import { DownloadOutlined, PlusCircleOutlined, MoreOutlined, DownCircleOutlined, CloseCircleOutlined, EditOutlined, DeleteOutlined, MailOutlined, CheckOutlined, InteractionOutlined, FilePdfOutlined, PlusOutlined } from "@ant-design/icons-vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
const columns = [
  {
    title: "Order Number",
    key: "job_order_number",
    dataIndex: "job_order_number"
  },
  {
    title: "Product",
    key: "product",
    dataIndex: "product"
  },
  {
    title: "External Order ID",
    key: "external_order_id",
    dataIndex: "external_order_id"
  },
  {
    title: "Due Date",
    key: "due_date",
    dataIndex: "due_date"
  },
  {
    title: "Client",
    key: "client",
    dataIndex: "client"
  },
  {
    title: "Status",
    key: "status",
    dataIndex: "status"
  }
];
const job_orders = [
  {
    key: "1",
    job_order_number: "job_order-0001",
    product: "Computer",
    external_order_id: "1242",
    status: "Draft",
    due_date: "10-10-2023",
    client: "Mona",
    status: "New"
  },
  {
    key: "1",
    job_order_number: "job_order-0001",
    product: "Computer",
    external_order_id: "1242",
    status: "Draft",
    due_date: "10-10-2023",
    client: "Mona",
    status: "New"
  },
  {
    key: "1",
    job_order_number: "job_order-0001",
    product: "Computer",
    external_order_id: "1242",
    status: "Draft",
    due_date: "10-10-2023",
    client: "Mona",
    status: "PLANNED"
  }
];
const job_ordercolumns = [{
  title: "Product",
  dataIndex: "product",
  key: "product",
  width: "40%"
}, {
  title: "Quantity",
  dataIndex: "quantity",
  key: "quantity",
  width: "10%"
}, {
  title: "Inventory",
  dataIndex: "inventory",
  key: "inventory",
  width: "10%"
}, {
  title: "Action",
  key: "action",
  width: "3%"
}];
const createPurchaseOrderItems = [
  {
    key: "1",
    item_details: "item 1",
    quantity: "1",
    rate: "0.00",
    amount: "1000.00",
    balance_due: "0.00",
    action: ""
  },
  {
    key: "2",
    item_details: "item 2",
    quantity: "1",
    rate: "0.00",
    amount: "1000.00",
    balance_due: "0.00",
    action: ""
  }
];
const _sfc_main = {
  components: {
    AuthenticatedLayout: _sfc_main$1,
    DownloadOutlined,
    PlusCircleOutlined,
    MoreOutlined,
    Head,
    Link,
    DownCircleOutlined,
    CloseCircleOutlined,
    EditOutlined,
    DeleteOutlined,
    MailOutlined,
    CheckOutlined,
    InteractionOutlined,
    FilePdfOutlined,
    PlusOutlined
  },
  props: {},
  setup(props) {
    return {
      columns,
      job_ordercolumns,
      job_orders,
      createPurchaseOrderItems
    };
  },
  data() {
    const loading = false;
    const create_form_visible = false;
    const searchform = useForm({
      term: ""
    });
    const form = useForm({
      term: ""
    });
    return {
      create_form_visible,
      loading,
      searchform,
      form,
      showdetail: false
    };
  },
  methods: {
    showDrawer() {
      this.create_form_visible = true;
    },
    showDetailDrawer() {
      this.showdetail = true;
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_space = resolveComponent("a-space");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_button = resolveComponent("a-button");
  const _component_plus_circle_outlined = resolveComponent("plus-circle-outlined");
  const _component_a_table = resolveComponent("a-table");
  const _component_a_drawer = resolveComponent("a-drawer");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_textarea = resolveComponent("a-textarea");
  const _component_a_dropdown_button = resolveComponent("a-dropdown-button");
  const _component_MoreOutlined = resolveComponent("MoreOutlined");
  const _component_a_menu = resolveComponent("a-menu");
  const _component_a_menu_item = resolveComponent("a-menu-item");
  const _component_UserOutlined = resolveComponent("UserOutlined");
  const _component_a_tabs = resolveComponent("a-tabs");
  const _component_a_tab_pane = resolveComponent("a-tab-pane");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Bill Of Materials" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_layout_content, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, {
                      name: "nest-messages",
                      model: $data.searchform,
                      layout: "inline",
                      onFinish: _ctx.search
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input, {
                                  placeholder: "Search by Job Order Number",
                                  "allow-clear": true,
                                  value: $data.searchform.term,
                                  "onUpdate:value": ($event) => $data.searchform.term = $event
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input, {
                                    placeholder: "Search by Job Order Number",
                                    "allow-clear": true,
                                    value: $data.searchform.term,
                                    "onUpdate:value": ($event) => $data.searchform.term = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Search `);
                                    } else {
                                      return [
                                        createTextVNode(" Search ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Search ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_plus_circle_outlined)
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` New BOM `);
                                    } else {
                                      return [
                                        createTextVNode(" New BOM ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    shape: "round",
                                    onClick: $options.showDrawer
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" New BOM ")
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  placeholder: "Search by Job Order Number",
                                  "allow-clear": true,
                                  value: $data.searchform.term,
                                  "onUpdate:value": ($event) => $data.searchform.term = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Search ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" New BOM ")
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_table, {
                      columns: [
                        {
                          title: "BOM ID",
                          key: "bom_id",
                          dataIndex: "bom_id"
                        },
                        {
                          title: "BOM Name",
                          key: "bom_name",
                          dataIndex: "bom_name"
                        },
                        {
                          title: "Product Name",
                          key: "product_name",
                          dataIndex: "product_name"
                        },
                        {
                          title: "No of Raw Materials",
                          key: "no_of_rm",
                          dataIndex: "no_of_rm"
                        },
                        {
                          title: "Action",
                          key: "action",
                          width: "3%"
                        }
                      ],
                      "data-source": [
                        {
                          key: "1",
                          bom_id: "BOM-0001",
                          bom_name: "BOM-0001",
                          product_name: "Computer",
                          no_of_rm: "1"
                        }
                      ],
                      pagination: false
                    }, {
                      bodyCell: withCtx(({ column, record }, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          if (column.key === "bom_id") {
                            _push5(`<a${_scopeId4}>${ssrInterpolate(record.bom_id)}</a>`);
                          } else {
                            _push5(`<!---->`);
                          }
                        } else {
                          return [
                            column.key === "bom_id" ? (openBlock(), createBlock("a", {
                              key: 0,
                              onClick: $options.showDetailDrawer
                            }, toDisplayString(record.bom_id), 9, ["onClick"])) : createCommentVNode("", true)
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, {
                        name: "nest-messages",
                        model: $data.searchform,
                        layout: "inline",
                        onFinish: _ctx.search
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                placeholder: "Search by Job Order Number",
                                "allow-clear": true,
                                value: $data.searchform.term,
                                "onUpdate:value": ($event) => $data.searchform.term = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Search ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                shape: "round",
                                onClick: $options.showDrawer
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" New BOM ")
                                ]),
                                _: 1
                              }, 8, ["onClick"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["model", "onFinish"]),
                      createVNode(_component_a_table, {
                        columns: [
                          {
                            title: "BOM ID",
                            key: "bom_id",
                            dataIndex: "bom_id"
                          },
                          {
                            title: "BOM Name",
                            key: "bom_name",
                            dataIndex: "bom_name"
                          },
                          {
                            title: "Product Name",
                            key: "product_name",
                            dataIndex: "product_name"
                          },
                          {
                            title: "No of Raw Materials",
                            key: "no_of_rm",
                            dataIndex: "no_of_rm"
                          },
                          {
                            title: "Action",
                            key: "action",
                            width: "3%"
                          }
                        ],
                        "data-source": [
                          {
                            key: "1",
                            bom_id: "BOM-0001",
                            bom_name: "BOM-0001",
                            product_name: "Computer",
                            no_of_rm: "1"
                          }
                        ],
                        pagination: false
                      }, {
                        bodyCell: withCtx(({ column, record }) => [
                          column.key === "bom_id" ? (openBlock(), createBlock("a", {
                            key: 0,
                            onClick: $options.showDetailDrawer
                          }, toDisplayString(record.bom_id), 9, ["onClick"])) : createCommentVNode("", true)
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_drawer, {
                visible: $data.create_form_visible,
                "onUpdate:visible": ($event) => $data.create_form_visible = $event,
                class: "sales-bill",
                size: "large",
                style: { "color": "red" },
                width: "75%",
                title: "Add BOM",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                footer: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_button, {
                      style: { "margin-right": "8px" },
                      onClick: _ctx.onClose
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`Cancel`);
                        } else {
                          return [
                            createTextVNode("Cancel")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_button, {
                      type: "primary",
                      onClick: _ctx.onClose
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`SAVE`);
                        } else {
                          return [
                            createTextVNode("SAVE")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_button, {
                        style: { "margin-right": "8px" },
                        onClick: _ctx.onClose
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Cancel")
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_button, {
                        type: "primary",
                        onClick: _ctx.onClose
                      }, {
                        default: withCtx(() => [
                          createTextVNode("SAVE")
                        ]),
                        _: 1
                      }, 8, ["onClick"])
                    ];
                  }
                }),
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, mergeProps({ model: $data.form }, _ctx.layout, {
                      name: "nest-messages",
                      "validate-messages": _ctx.validateMessages,
                      onFinish: _ctx.submit,
                      "label-col": { span: 24 },
                      style: { "min-height": "100%" }
                    }), {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "document_name",
                                        label: "Document Name",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: $data.form.document_name,
                                              "onUpdate:value": ($event) => $data.form.document_name = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: $data.form.document_name,
                                                "onUpdate:value": ($event) => $data.form.document_name = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "document_name",
                                          label: "Document Name",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: $data.form.document_name,
                                              "onUpdate:value": ($event) => $data.form.document_name = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "document_number",
                                        label: "Document Number"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: $data.form.document_number,
                                              "onUpdate:value": ($event) => $data.form.document_number = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: $data.form.document_number,
                                                "onUpdate:value": ($event) => $data.form.document_number = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "document_number",
                                          label: "Document Number"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: $data.form.document_number,
                                              "onUpdate:value": ($event) => $data.form.document_number = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "24"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "description",
                                        label: "Description"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: $data.form.description,
                                              "onUpdate:value": ($event) => $data.form.description = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: $data.form.description,
                                                "onUpdate:value": ($event) => $data.form.description = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "description",
                                          label: "Description"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: $data.form.description,
                                              "onUpdate:value": ($event) => $data.form.description = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "document_name",
                                        label: "Document Name",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: $data.form.document_name,
                                            "onUpdate:value": ($event) => $data.form.document_name = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "document_number",
                                        label: "Document Number"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: $data.form.document_number,
                                            "onUpdate:value": ($event) => $data.form.document_number = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "24"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "description",
                                        label: "Description"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: $data.form.description,
                                            "onUpdate:value": ($event) => $data.form.description = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<h4 class="t1"${_scopeId4}>Product</h4>`);
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "product",
                                        label: "Select Product",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select, {
                                              value: $data.form.tax,
                                              "onUpdate:value": ($event) => $data.form.tax = $event,
                                              "show-search": "",
                                              placeholder: "Select Product",
                                              style: { "width": "100%" },
                                              "default-active-first-option": false,
                                              options: [{
                                                label: "Red color T-shirt - Md",
                                                value: "Red color T-shirt - Md"
                                              }, {
                                                label: "Red color T-shirt - Lg",
                                                value: "Red color T-shirt - Lg"
                                              }, {
                                                label: "Red color T-shirt - SM",
                                                value: "Red color T-shirt - SM"
                                              }],
                                              "not-found-content": _ctx.value
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select, {
                                                value: $data.form.tax,
                                                "onUpdate:value": ($event) => $data.form.tax = $event,
                                                "show-search": "",
                                                placeholder: "Select Product",
                                                style: { "width": "100%" },
                                                "default-active-first-option": false,
                                                options: [{
                                                  label: "Red color T-shirt - Md",
                                                  value: "Red color T-shirt - Md"
                                                }, {
                                                  label: "Red color T-shirt - Lg",
                                                  value: "Red color T-shirt - Lg"
                                                }, {
                                                  label: "Red color T-shirt - SM",
                                                  value: "Red color T-shirt - SM"
                                                }],
                                                "not-found-content": _ctx.value
                                              }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "product",
                                          label: "Select Product",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              value: $data.form.tax,
                                              "onUpdate:value": ($event) => $data.form.tax = $event,
                                              "show-search": "",
                                              placeholder: "Select Product",
                                              style: { "width": "100%" },
                                              "default-active-first-option": false,
                                              options: [{
                                                label: "Red color T-shirt - Md",
                                                value: "Red color T-shirt - Md"
                                              }, {
                                                label: "Red color T-shirt - Lg",
                                                value: "Red color T-shirt - Lg"
                                              }, {
                                                label: "Red color T-shirt - SM",
                                                value: "Red color T-shirt - SM"
                                              }],
                                              "not-found-content": _ctx.value
                                            }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "quantity",
                                        label: "Quantity",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: $data.form.quantity,
                                              "onUpdate:value": ($event) => $data.form.quantity = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: $data.form.quantity,
                                                "onUpdate:value": ($event) => $data.form.quantity = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "quantity",
                                          label: "Quantity",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: $data.form.quantity,
                                              "onUpdate:value": ($event) => $data.form.quantity = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "unit",
                                        label: "Unit",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select, {
                                              value: $data.form.tax,
                                              "onUpdate:value": ($event) => $data.form.tax = $event,
                                              "show-search": "",
                                              placeholder: "Select Unit",
                                              style: { "width": "100%" },
                                              "default-active-first-option": false,
                                              options: [{
                                                label: "KG",
                                                value: "KG"
                                              }, {
                                                label: "Ltr",
                                                value: "Ltr"
                                              }, {
                                                label: "Pcs",
                                                value: "Pcs"
                                              }]
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select, {
                                                value: $data.form.tax,
                                                "onUpdate:value": ($event) => $data.form.tax = $event,
                                                "show-search": "",
                                                placeholder: "Select Unit",
                                                style: { "width": "100%" },
                                                "default-active-first-option": false,
                                                options: [{
                                                  label: "KG",
                                                  value: "KG"
                                                }, {
                                                  label: "Ltr",
                                                  value: "Ltr"
                                                }, {
                                                  label: "Pcs",
                                                  value: "Pcs"
                                                }]
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "unit",
                                          label: "Unit",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              value: $data.form.tax,
                                              "onUpdate:value": ($event) => $data.form.tax = $event,
                                              "show-search": "",
                                              placeholder: "Select Unit",
                                              style: { "width": "100%" },
                                              "default-active-first-option": false,
                                              options: [{
                                                label: "KG",
                                                value: "KG"
                                              }, {
                                                label: "Ltr",
                                                value: "Ltr"
                                              }, {
                                                label: "Pcs",
                                                value: "Pcs"
                                              }]
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        name: "cost_allocation",
                                        label: "Cost Allocation",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: $data.form.cost_allocation,
                                              "onUpdate:value": ($event) => $data.form.cost_allocation = $event
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: $data.form.cost_allocation,
                                                "onUpdate:value": ($event) => $data.form.cost_allocation = $event
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          name: "cost_allocation",
                                          label: "Cost Allocation",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: $data.form.cost_allocation,
                                              "onUpdate:value": ($event) => $data.form.cost_allocation = $event
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "product",
                                        label: "Select Product",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            value: $data.form.tax,
                                            "onUpdate:value": ($event) => $data.form.tax = $event,
                                            "show-search": "",
                                            placeholder: "Select Product",
                                            style: { "width": "100%" },
                                            "default-active-first-option": false,
                                            options: [{
                                              label: "Red color T-shirt - Md",
                                              value: "Red color T-shirt - Md"
                                            }, {
                                              label: "Red color T-shirt - Lg",
                                              value: "Red color T-shirt - Lg"
                                            }, {
                                              label: "Red color T-shirt - SM",
                                              value: "Red color T-shirt - SM"
                                            }],
                                            "not-found-content": _ctx.value
                                          }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "quantity",
                                        label: "Quantity",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: $data.form.quantity,
                                            "onUpdate:value": ($event) => $data.form.quantity = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "unit",
                                        label: "Unit",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            value: $data.form.tax,
                                            "onUpdate:value": ($event) => $data.form.tax = $event,
                                            "show-search": "",
                                            placeholder: "Select Unit",
                                            style: { "width": "100%" },
                                            "default-active-first-option": false,
                                            options: [{
                                              label: "KG",
                                              value: "KG"
                                            }, {
                                              label: "Ltr",
                                              value: "Ltr"
                                            }, {
                                              label: "Pcs",
                                              value: "Pcs"
                                            }]
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: "12"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        name: "cost_allocation",
                                        label: "Cost Allocation",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: $data.form.cost_allocation,
                                            "onUpdate:value": ($event) => $data.form.cost_allocation = $event
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<h4 class="t1"${_scopeId4}>Raw Materials</h4>`);
                          _push5(ssrRenderComponent(_component_a_table, {
                            columns: [
                              {
                                title: "Raw Material",
                                dataIndex: "raw_material",
                                key: "raw_material"
                              },
                              {
                                title: "Quantity",
                                dataIndex: "quantity",
                                key: "quantity"
                              },
                              {
                                title: "Unit",
                                dataIndex: "unit",
                                key: "unit"
                              },
                              {
                                title: "Notes",
                                dataIndex: "notes",
                                key: "notes"
                              },
                              {
                                title: "Action",
                                key: "action",
                                width: "3%"
                              }
                            ],
                            "data-source": [{}],
                            pagination: false
                          }, {
                            bodyCell: withCtx(({ column, record }, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                if (column.key === "raw_material") {
                                  _push6(ssrRenderComponent(_component_a_select, {
                                    value: $data.form.tax,
                                    "onUpdate:value": ($event) => $data.form.tax = $event,
                                    "show-search": "",
                                    placeholder: "Select Product",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    options: [{
                                      label: "Red color T-shirt - Md",
                                      value: "Red color T-shirt - Md"
                                    }, {
                                      label: "Red color T-shirt - Lg",
                                      value: "Red color T-shirt - Lg"
                                    }, {
                                      label: "Red color T-shirt - SM",
                                      value: "Red color T-shirt - SM"
                                    }],
                                    "not-found-content": _ctx.value
                                  }, null, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "quantity") {
                                  _push6(ssrRenderComponent(_component_a_input, {
                                    value: record.quantity,
                                    "onUpdate:value": ($event) => record.quantity = $event
                                  }, null, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "unit") {
                                  _push6(ssrRenderComponent(_component_a_select, {
                                    value: $data.form.tax,
                                    "onUpdate:value": ($event) => $data.form.tax = $event,
                                    "show-search": "",
                                    placeholder: "Select Unit",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    options: [{
                                      label: "Kg",
                                      value: "Kg"
                                    }, {
                                      label: "Ltr",
                                      value: "Ltr"
                                    }]
                                  }, null, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "notes") {
                                  _push6(ssrRenderComponent(_component_a_textarea, {
                                    value: $data.form.description,
                                    "onUpdate:value": ($event) => $data.form.description = $event
                                  }, null, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "action") {
                                  _push6(ssrRenderComponent(_component_a_dropdown_button, { onClick: _ctx.handleButtonClick }, {
                                    icon: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_MoreOutlined, null, null, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_MoreOutlined)
                                        ];
                                      }
                                    }),
                                    overlay: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                          default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(ssrRenderComponent(_component_a_menu_item, { key: "1" }, {
                                                default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                  if (_push9) {
                                                    _push9(ssrRenderComponent(_component_UserOutlined, null, null, _parent9, _scopeId8));
                                                    _push9(` Remove `);
                                                  } else {
                                                    return [
                                                      createVNode(_component_UserOutlined),
                                                      createTextVNode(" Remove ")
                                                    ];
                                                  }
                                                }),
                                                _: 2
                                              }, _parent8, _scopeId7));
                                            } else {
                                              return [
                                                createVNode(_component_a_menu_item, { key: "1" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_UserOutlined),
                                                    createTextVNode(" Remove ")
                                                  ]),
                                                  _: 1
                                                })
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_menu_item, { key: "1" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_UserOutlined),
                                                  createTextVNode(" Remove ")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }, 8, ["onClick"])
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                              } else {
                                return [
                                  column.key === "raw_material" ? (openBlock(), createBlock(_component_a_select, {
                                    key: 0,
                                    value: $data.form.tax,
                                    "onUpdate:value": ($event) => $data.form.tax = $event,
                                    "show-search": "",
                                    placeholder: "Select Product",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    options: [{
                                      label: "Red color T-shirt - Md",
                                      value: "Red color T-shirt - Md"
                                    }, {
                                      label: "Red color T-shirt - Lg",
                                      value: "Red color T-shirt - Lg"
                                    }, {
                                      label: "Red color T-shirt - SM",
                                      value: "Red color T-shirt - SM"
                                    }],
                                    "not-found-content": _ctx.value
                                  }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                                  column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                                    key: 1,
                                    value: record.quantity,
                                    "onUpdate:value": ($event) => record.quantity = $event
                                  }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                  column.key === "unit" ? (openBlock(), createBlock(_component_a_select, {
                                    key: 2,
                                    value: $data.form.tax,
                                    "onUpdate:value": ($event) => $data.form.tax = $event,
                                    "show-search": "",
                                    placeholder: "Select Unit",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    options: [{
                                      label: "Kg",
                                      value: "Kg"
                                    }, {
                                      label: "Ltr",
                                      value: "Ltr"
                                    }]
                                  }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                  column.key === "notes" ? (openBlock(), createBlock(_component_a_textarea, {
                                    key: 3,
                                    value: $data.form.description,
                                    "onUpdate:value": ($event) => $data.form.description = $event
                                  }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                  column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                                    key: 4,
                                    onClick: _ctx.handleButtonClick
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_MoreOutlined)
                                    ]),
                                    overlay: withCtx(() => [
                                      createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_menu_item, { key: "1" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_UserOutlined),
                                              createTextVNode(" Remove ")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["onClick"])
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])) : createCommentVNode("", true)
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<br${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_space, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "success",
                                  size: "small"
                                }, {
                                  icon: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_plus_circle_outlined)
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Add RM `);
                                    } else {
                                      return [
                                        createTextVNode(" Add RM ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "success",
                                    size: "small"
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Add RM ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<br${_scopeId4}><h4 class="t1"${_scopeId4}>Routing</h4>`);
                          _push5(ssrRenderComponent(_component_a_table, {
                            columns: [
                              {
                                title: "Routing",
                                dataIndex: "routing",
                                key: "routing"
                              },
                              {
                                title: "Comment",
                                dataIndex: "comment",
                                key: "comment"
                              },
                              {
                                title: "Action",
                                key: "action",
                                width: "3%"
                              }
                            ],
                            "data-source": [{}],
                            pagination: false
                          }, {
                            bodyCell: withCtx(({ column, record }, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                if (column.key === "routing") {
                                  _push6(ssrRenderComponent(_component_a_select, {
                                    value: $data.form.tax,
                                    "onUpdate:value": ($event) => $data.form.tax = $event,
                                    "show-search": "",
                                    placeholder: "Select Routing",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    options: [{
                                      label: "Routing 1",
                                      value: "Routing 1"
                                    }, {
                                      label: "Routing 2",
                                      value: "Routing 2"
                                    }, {
                                      label: "Routing 3",
                                      value: "Routing 3"
                                    }],
                                    "not-found-content": _ctx.value
                                  }, null, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "comment") {
                                  _push6(ssrRenderComponent(_component_a_textarea, {
                                    value: $data.form.description,
                                    "onUpdate:value": ($event) => $data.form.description = $event
                                  }, null, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "action") {
                                  _push6(ssrRenderComponent(_component_a_dropdown_button, { onClick: _ctx.handleButtonClick }, {
                                    icon: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_MoreOutlined, null, null, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_MoreOutlined)
                                        ];
                                      }
                                    }),
                                    overlay: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                          default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(ssrRenderComponent(_component_a_menu_item, { key: "1" }, {
                                                default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                  if (_push9) {
                                                    _push9(ssrRenderComponent(_component_UserOutlined, null, null, _parent9, _scopeId8));
                                                    _push9(` Remove `);
                                                  } else {
                                                    return [
                                                      createVNode(_component_UserOutlined),
                                                      createTextVNode(" Remove ")
                                                    ];
                                                  }
                                                }),
                                                _: 2
                                              }, _parent8, _scopeId7));
                                            } else {
                                              return [
                                                createVNode(_component_a_menu_item, { key: "1" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_UserOutlined),
                                                    createTextVNode(" Remove ")
                                                  ]),
                                                  _: 1
                                                })
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_menu_item, { key: "1" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_UserOutlined),
                                                  createTextVNode(" Remove ")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }, 8, ["onClick"])
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                              } else {
                                return [
                                  column.key === "routing" ? (openBlock(), createBlock(_component_a_select, {
                                    key: 0,
                                    value: $data.form.tax,
                                    "onUpdate:value": ($event) => $data.form.tax = $event,
                                    "show-search": "",
                                    placeholder: "Select Routing",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    options: [{
                                      label: "Routing 1",
                                      value: "Routing 1"
                                    }, {
                                      label: "Routing 2",
                                      value: "Routing 2"
                                    }, {
                                      label: "Routing 3",
                                      value: "Routing 3"
                                    }],
                                    "not-found-content": _ctx.value
                                  }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                                  column.key === "comment" ? (openBlock(), createBlock(_component_a_textarea, {
                                    key: 1,
                                    value: $data.form.description,
                                    "onUpdate:value": ($event) => $data.form.description = $event
                                  }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                  column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                                    key: 2,
                                    onClick: _ctx.handleButtonClick
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_MoreOutlined)
                                    ]),
                                    overlay: withCtx(() => [
                                      createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_menu_item, { key: "1" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_UserOutlined),
                                              createTextVNode(" Remove ")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["onClick"])
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])) : createCommentVNode("", true)
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<br${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_space, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "success",
                                  size: "small"
                                }, {
                                  icon: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_plus_circle_outlined)
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Add Routing `);
                                    } else {
                                      return [
                                        createTextVNode(" Add Routing ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "success",
                                    size: "small"
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Add Routing ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<br${_scopeId4}><h4 class="t1"${_scopeId4}>Other Charges</h4>`);
                          _push5(ssrRenderComponent(_component_a_table, {
                            columns: [
                              {
                                title: "Classification",
                                dataIndex: "classification",
                                key: "classification"
                              },
                              {
                                title: "Amount",
                                dataIndex: "amount",
                                key: "amount"
                              },
                              {
                                title: "Comment",
                                dataIndex: "comment",
                                key: "comment"
                              }
                            ],
                            "data-source": [
                              {
                                key: "1",
                                classification: "Classification 1",
                                amount: "0",
                                comment: ""
                              },
                              {
                                key: "1",
                                classification: "Classification 1",
                                amount: "0",
                                comment: ""
                              },
                              {
                                key: "1",
                                classification: "Classification 1",
                                amount: "0",
                                comment: ""
                              },
                              {
                                key: "1",
                                classification: "Classification 1",
                                amount: "0",
                                comment: ""
                              }
                            ],
                            pagination: false
                          }, {
                            bodyCell: withCtx(({ column, record }, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                if (column.key === "classification") {
                                  _push6(`<!--[-->${ssrInterpolate(record.classification)}<!--]-->`);
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "amount") {
                                  _push6(ssrRenderComponent(_component_a_input, {
                                    value: record.amount,
                                    "onUpdate:value": ($event) => record.amount = $event
                                  }, null, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "comment") {
                                  _push6(ssrRenderComponent(_component_a_input, {
                                    value: record.comment,
                                    "onUpdate:value": ($event) => record.comment = $event
                                  }, null, _parent6, _scopeId5));
                                } else {
                                  _push6(`<!---->`);
                                }
                              } else {
                                return [
                                  column.key === "classification" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                                    createTextVNode(toDisplayString(record.classification), 1)
                                  ], 64)) : createCommentVNode("", true),
                                  column.key === "amount" ? (openBlock(), createBlock(_component_a_input, {
                                    key: 1,
                                    value: record.amount,
                                    "onUpdate:value": ($event) => record.amount = $event
                                  }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                  column.key === "comment" ? (openBlock(), createBlock(_component_a_input, {
                                    key: 2,
                                    value: record.comment,
                                    "onUpdate:value": ($event) => record.comment = $event
                                  }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true)
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_row, { gutter: 24 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "document_name",
                                      label: "Document Name",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: $data.form.document_name,
                                          "onUpdate:value": ($event) => $data.form.document_name = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "document_number",
                                      label: "Document Number"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: $data.form.document_number,
                                          "onUpdate:value": ($event) => $data.form.document_number = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "24"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "description",
                                      label: "Description"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: $data.form.description,
                                          "onUpdate:value": ($event) => $data.form.description = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("h4", { class: "t1" }, "Product"),
                            createVNode(_component_a_row, { gutter: 24 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "product",
                                      label: "Select Product",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          value: $data.form.tax,
                                          "onUpdate:value": ($event) => $data.form.tax = $event,
                                          "show-search": "",
                                          placeholder: "Select Product",
                                          style: { "width": "100%" },
                                          "default-active-first-option": false,
                                          options: [{
                                            label: "Red color T-shirt - Md",
                                            value: "Red color T-shirt - Md"
                                          }, {
                                            label: "Red color T-shirt - Lg",
                                            value: "Red color T-shirt - Lg"
                                          }, {
                                            label: "Red color T-shirt - SM",
                                            value: "Red color T-shirt - SM"
                                          }],
                                          "not-found-content": _ctx.value
                                        }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "quantity",
                                      label: "Quantity",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: $data.form.quantity,
                                          "onUpdate:value": ($event) => $data.form.quantity = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "unit",
                                      label: "Unit",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          value: $data.form.tax,
                                          "onUpdate:value": ($event) => $data.form.tax = $event,
                                          "show-search": "",
                                          placeholder: "Select Unit",
                                          style: { "width": "100%" },
                                          "default-active-first-option": false,
                                          options: [{
                                            label: "KG",
                                            value: "KG"
                                          }, {
                                            label: "Ltr",
                                            value: "Ltr"
                                          }, {
                                            label: "Pcs",
                                            value: "Pcs"
                                          }]
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: "12"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      name: "cost_allocation",
                                      label: "Cost Allocation",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: $data.form.cost_allocation,
                                          "onUpdate:value": ($event) => $data.form.cost_allocation = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("h4", { class: "t1" }, "Raw Materials"),
                            createVNode(_component_a_table, {
                              columns: [
                                {
                                  title: "Raw Material",
                                  dataIndex: "raw_material",
                                  key: "raw_material"
                                },
                                {
                                  title: "Quantity",
                                  dataIndex: "quantity",
                                  key: "quantity"
                                },
                                {
                                  title: "Unit",
                                  dataIndex: "unit",
                                  key: "unit"
                                },
                                {
                                  title: "Notes",
                                  dataIndex: "notes",
                                  key: "notes"
                                },
                                {
                                  title: "Action",
                                  key: "action",
                                  width: "3%"
                                }
                              ],
                              "data-source": [{}],
                              pagination: false
                            }, {
                              bodyCell: withCtx(({ column, record }) => [
                                column.key === "raw_material" ? (openBlock(), createBlock(_component_a_select, {
                                  key: 0,
                                  value: $data.form.tax,
                                  "onUpdate:value": ($event) => $data.form.tax = $event,
                                  "show-search": "",
                                  placeholder: "Select Product",
                                  style: { "width": "100%" },
                                  "default-active-first-option": false,
                                  options: [{
                                    label: "Red color T-shirt - Md",
                                    value: "Red color T-shirt - Md"
                                  }, {
                                    label: "Red color T-shirt - Lg",
                                    value: "Red color T-shirt - Lg"
                                  }, {
                                    label: "Red color T-shirt - SM",
                                    value: "Red color T-shirt - SM"
                                  }],
                                  "not-found-content": _ctx.value
                                }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                                column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                                  key: 1,
                                  value: record.quantity,
                                  "onUpdate:value": ($event) => record.quantity = $event
                                }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                column.key === "unit" ? (openBlock(), createBlock(_component_a_select, {
                                  key: 2,
                                  value: $data.form.tax,
                                  "onUpdate:value": ($event) => $data.form.tax = $event,
                                  "show-search": "",
                                  placeholder: "Select Unit",
                                  style: { "width": "100%" },
                                  "default-active-first-option": false,
                                  options: [{
                                    label: "Kg",
                                    value: "Kg"
                                  }, {
                                    label: "Ltr",
                                    value: "Ltr"
                                  }]
                                }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                column.key === "notes" ? (openBlock(), createBlock(_component_a_textarea, {
                                  key: 3,
                                  value: $data.form.description,
                                  "onUpdate:value": ($event) => $data.form.description = $event
                                }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                                  key: 4,
                                  onClick: _ctx.handleButtonClick
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_MoreOutlined)
                                  ]),
                                  overlay: withCtx(() => [
                                    createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_menu_item, { key: "1" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_UserOutlined),
                                            createTextVNode(" Remove ")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["onClick"])
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])) : createCommentVNode("", true)
                              ]),
                              _: 1
                            }),
                            createVNode("br"),
                            createVNode(_component_a_space, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "success",
                                  size: "small"
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Add RM ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("br"),
                            createVNode("h4", { class: "t1" }, "Routing"),
                            createVNode(_component_a_table, {
                              columns: [
                                {
                                  title: "Routing",
                                  dataIndex: "routing",
                                  key: "routing"
                                },
                                {
                                  title: "Comment",
                                  dataIndex: "comment",
                                  key: "comment"
                                },
                                {
                                  title: "Action",
                                  key: "action",
                                  width: "3%"
                                }
                              ],
                              "data-source": [{}],
                              pagination: false
                            }, {
                              bodyCell: withCtx(({ column, record }) => [
                                column.key === "routing" ? (openBlock(), createBlock(_component_a_select, {
                                  key: 0,
                                  value: $data.form.tax,
                                  "onUpdate:value": ($event) => $data.form.tax = $event,
                                  "show-search": "",
                                  placeholder: "Select Routing",
                                  style: { "width": "100%" },
                                  "default-active-first-option": false,
                                  options: [{
                                    label: "Routing 1",
                                    value: "Routing 1"
                                  }, {
                                    label: "Routing 2",
                                    value: "Routing 2"
                                  }, {
                                    label: "Routing 3",
                                    value: "Routing 3"
                                  }],
                                  "not-found-content": _ctx.value
                                }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                                column.key === "comment" ? (openBlock(), createBlock(_component_a_textarea, {
                                  key: 1,
                                  value: $data.form.description,
                                  "onUpdate:value": ($event) => $data.form.description = $event
                                }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                                  key: 2,
                                  onClick: _ctx.handleButtonClick
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_MoreOutlined)
                                  ]),
                                  overlay: withCtx(() => [
                                    createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_menu_item, { key: "1" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_UserOutlined),
                                            createTextVNode(" Remove ")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["onClick"])
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])) : createCommentVNode("", true)
                              ]),
                              _: 1
                            }),
                            createVNode("br"),
                            createVNode(_component_a_space, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "success",
                                  size: "small"
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Add Routing ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("br"),
                            createVNode("h4", { class: "t1" }, "Other Charges"),
                            createVNode(_component_a_table, {
                              columns: [
                                {
                                  title: "Classification",
                                  dataIndex: "classification",
                                  key: "classification"
                                },
                                {
                                  title: "Amount",
                                  dataIndex: "amount",
                                  key: "amount"
                                },
                                {
                                  title: "Comment",
                                  dataIndex: "comment",
                                  key: "comment"
                                }
                              ],
                              "data-source": [
                                {
                                  key: "1",
                                  classification: "Classification 1",
                                  amount: "0",
                                  comment: ""
                                },
                                {
                                  key: "1",
                                  classification: "Classification 1",
                                  amount: "0",
                                  comment: ""
                                },
                                {
                                  key: "1",
                                  classification: "Classification 1",
                                  amount: "0",
                                  comment: ""
                                },
                                {
                                  key: "1",
                                  classification: "Classification 1",
                                  amount: "0",
                                  comment: ""
                                }
                              ],
                              pagination: false
                            }, {
                              bodyCell: withCtx(({ column, record }) => [
                                column.key === "classification" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                                  createTextVNode(toDisplayString(record.classification), 1)
                                ], 64)) : createCommentVNode("", true),
                                column.key === "amount" ? (openBlock(), createBlock(_component_a_input, {
                                  key: 1,
                                  value: record.amount,
                                  "onUpdate:value": ($event) => record.amount = $event
                                }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                column.key === "comment" ? (openBlock(), createBlock(_component_a_input, {
                                  key: 2,
                                  value: record.comment,
                                  "onUpdate:value": ($event) => record.comment = $event
                                }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true)
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, mergeProps({ model: $data.form }, _ctx.layout, {
                        name: "nest-messages",
                        "validate-messages": _ctx.validateMessages,
                        onFinish: _ctx.submit,
                        "label-col": { span: 24 },
                        style: { "min-height": "100%" }
                      }), {
                        default: withCtx(() => [
                          createVNode(_component_a_row, { gutter: 24 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "document_name",
                                    label: "Document Name",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $data.form.document_name,
                                        "onUpdate:value": ($event) => $data.form.document_name = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "document_number",
                                    label: "Document Number"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $data.form.document_number,
                                        "onUpdate:value": ($event) => $data.form.document_number = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "24"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "description",
                                    label: "Description"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $data.form.description,
                                        "onUpdate:value": ($event) => $data.form.description = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("h4", { class: "t1" }, "Product"),
                          createVNode(_component_a_row, { gutter: 24 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "product",
                                    label: "Select Product",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        value: $data.form.tax,
                                        "onUpdate:value": ($event) => $data.form.tax = $event,
                                        "show-search": "",
                                        placeholder: "Select Product",
                                        style: { "width": "100%" },
                                        "default-active-first-option": false,
                                        options: [{
                                          label: "Red color T-shirt - Md",
                                          value: "Red color T-shirt - Md"
                                        }, {
                                          label: "Red color T-shirt - Lg",
                                          value: "Red color T-shirt - Lg"
                                        }, {
                                          label: "Red color T-shirt - SM",
                                          value: "Red color T-shirt - SM"
                                        }],
                                        "not-found-content": _ctx.value
                                      }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "quantity",
                                    label: "Quantity",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $data.form.quantity,
                                        "onUpdate:value": ($event) => $data.form.quantity = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "unit",
                                    label: "Unit",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        value: $data.form.tax,
                                        "onUpdate:value": ($event) => $data.form.tax = $event,
                                        "show-search": "",
                                        placeholder: "Select Unit",
                                        style: { "width": "100%" },
                                        "default-active-first-option": false,
                                        options: [{
                                          label: "KG",
                                          value: "KG"
                                        }, {
                                          label: "Ltr",
                                          value: "Ltr"
                                        }, {
                                          label: "Pcs",
                                          value: "Pcs"
                                        }]
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: "12"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    name: "cost_allocation",
                                    label: "Cost Allocation",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $data.form.cost_allocation,
                                        "onUpdate:value": ($event) => $data.form.cost_allocation = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("h4", { class: "t1" }, "Raw Materials"),
                          createVNode(_component_a_table, {
                            columns: [
                              {
                                title: "Raw Material",
                                dataIndex: "raw_material",
                                key: "raw_material"
                              },
                              {
                                title: "Quantity",
                                dataIndex: "quantity",
                                key: "quantity"
                              },
                              {
                                title: "Unit",
                                dataIndex: "unit",
                                key: "unit"
                              },
                              {
                                title: "Notes",
                                dataIndex: "notes",
                                key: "notes"
                              },
                              {
                                title: "Action",
                                key: "action",
                                width: "3%"
                              }
                            ],
                            "data-source": [{}],
                            pagination: false
                          }, {
                            bodyCell: withCtx(({ column, record }) => [
                              column.key === "raw_material" ? (openBlock(), createBlock(_component_a_select, {
                                key: 0,
                                value: $data.form.tax,
                                "onUpdate:value": ($event) => $data.form.tax = $event,
                                "show-search": "",
                                placeholder: "Select Product",
                                style: { "width": "100%" },
                                "default-active-first-option": false,
                                options: [{
                                  label: "Red color T-shirt - Md",
                                  value: "Red color T-shirt - Md"
                                }, {
                                  label: "Red color T-shirt - Lg",
                                  value: "Red color T-shirt - Lg"
                                }, {
                                  label: "Red color T-shirt - SM",
                                  value: "Red color T-shirt - SM"
                                }],
                                "not-found-content": _ctx.value
                              }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                              column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                                key: 1,
                                value: record.quantity,
                                "onUpdate:value": ($event) => record.quantity = $event
                              }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                              column.key === "unit" ? (openBlock(), createBlock(_component_a_select, {
                                key: 2,
                                value: $data.form.tax,
                                "onUpdate:value": ($event) => $data.form.tax = $event,
                                "show-search": "",
                                placeholder: "Select Unit",
                                style: { "width": "100%" },
                                "default-active-first-option": false,
                                options: [{
                                  label: "Kg",
                                  value: "Kg"
                                }, {
                                  label: "Ltr",
                                  value: "Ltr"
                                }]
                              }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                              column.key === "notes" ? (openBlock(), createBlock(_component_a_textarea, {
                                key: 3,
                                value: $data.form.description,
                                "onUpdate:value": ($event) => $data.form.description = $event
                              }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                              column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                                key: 4,
                                onClick: _ctx.handleButtonClick
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_MoreOutlined)
                                ]),
                                overlay: withCtx(() => [
                                  createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_menu_item, { key: "1" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_UserOutlined),
                                          createTextVNode(" Remove ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ]),
                                _: 1
                              }, 8, ["onClick"])) : createCommentVNode("", true)
                            ]),
                            _: 1
                          }),
                          createVNode("br"),
                          createVNode(_component_a_space, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "success",
                                size: "small"
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Add RM ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("br"),
                          createVNode("h4", { class: "t1" }, "Routing"),
                          createVNode(_component_a_table, {
                            columns: [
                              {
                                title: "Routing",
                                dataIndex: "routing",
                                key: "routing"
                              },
                              {
                                title: "Comment",
                                dataIndex: "comment",
                                key: "comment"
                              },
                              {
                                title: "Action",
                                key: "action",
                                width: "3%"
                              }
                            ],
                            "data-source": [{}],
                            pagination: false
                          }, {
                            bodyCell: withCtx(({ column, record }) => [
                              column.key === "routing" ? (openBlock(), createBlock(_component_a_select, {
                                key: 0,
                                value: $data.form.tax,
                                "onUpdate:value": ($event) => $data.form.tax = $event,
                                "show-search": "",
                                placeholder: "Select Routing",
                                style: { "width": "100%" },
                                "default-active-first-option": false,
                                options: [{
                                  label: "Routing 1",
                                  value: "Routing 1"
                                }, {
                                  label: "Routing 2",
                                  value: "Routing 2"
                                }, {
                                  label: "Routing 3",
                                  value: "Routing 3"
                                }],
                                "not-found-content": _ctx.value
                              }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                              column.key === "comment" ? (openBlock(), createBlock(_component_a_textarea, {
                                key: 1,
                                value: $data.form.description,
                                "onUpdate:value": ($event) => $data.form.description = $event
                              }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                              column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                                key: 2,
                                onClick: _ctx.handleButtonClick
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_MoreOutlined)
                                ]),
                                overlay: withCtx(() => [
                                  createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_menu_item, { key: "1" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_UserOutlined),
                                          createTextVNode(" Remove ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ]),
                                _: 1
                              }, 8, ["onClick"])) : createCommentVNode("", true)
                            ]),
                            _: 1
                          }),
                          createVNode("br"),
                          createVNode(_component_a_space, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "success",
                                size: "small"
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Add Routing ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("br"),
                          createVNode("h4", { class: "t1" }, "Other Charges"),
                          createVNode(_component_a_table, {
                            columns: [
                              {
                                title: "Classification",
                                dataIndex: "classification",
                                key: "classification"
                              },
                              {
                                title: "Amount",
                                dataIndex: "amount",
                                key: "amount"
                              },
                              {
                                title: "Comment",
                                dataIndex: "comment",
                                key: "comment"
                              }
                            ],
                            "data-source": [
                              {
                                key: "1",
                                classification: "Classification 1",
                                amount: "0",
                                comment: ""
                              },
                              {
                                key: "1",
                                classification: "Classification 1",
                                amount: "0",
                                comment: ""
                              },
                              {
                                key: "1",
                                classification: "Classification 1",
                                amount: "0",
                                comment: ""
                              },
                              {
                                key: "1",
                                classification: "Classification 1",
                                amount: "0",
                                comment: ""
                              }
                            ],
                            pagination: false
                          }, {
                            bodyCell: withCtx(({ column, record }) => [
                              column.key === "classification" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                                createTextVNode(toDisplayString(record.classification), 1)
                              ], 64)) : createCommentVNode("", true),
                              column.key === "amount" ? (openBlock(), createBlock(_component_a_input, {
                                key: 1,
                                value: record.amount,
                                "onUpdate:value": ($event) => record.amount = $event
                              }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                              column.key === "comment" ? (openBlock(), createBlock(_component_a_input, {
                                key: 2,
                                value: record.comment,
                                "onUpdate:value": ($event) => record.comment = $event
                              }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true)
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 16, ["model", "validate-messages", "onFinish"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_drawer, {
                visible: $data.showdetail,
                "onUpdate:visible": ($event) => $data.showdetail = $event,
                class: "custom-class",
                title: "JO-000001",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange,
                width: "60%"
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_tabs, {
                      activeKey: _ctx.activeKey,
                      "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_tab_pane, {
                            key: "JO-1-1",
                            tab: "Progress"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Progress `);
                              } else {
                                return [
                                  createTextVNode("Progress ")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_tab_pane, {
                            key: "JO-1-2",
                            tab: "Raw Materials",
                            "force-render": ""
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_space, null, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "primary",
                                        size: "small"
                                      }, {
                                        icon: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_plus_circle_outlined)
                                            ];
                                          }
                                        }),
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(` Add Raw Material `);
                                          } else {
                                            return [
                                              createTextVNode(" Add Raw Material ")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          size: "small"
                                        }, {
                                          icon: withCtx(() => [
                                            createVNode(_component_plus_circle_outlined)
                                          ]),
                                          default: withCtx(() => [
                                            createTextVNode(" Add Raw Material ")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(`<br${_scopeId5}>`);
                                _push6(ssrRenderComponent(_component_a_table, {
                                  columns: [
                                    {
                                      title: "Product",
                                      dataIndex: "product",
                                      key: "product"
                                    },
                                    {
                                      title: "Quantity/order",
                                      dataIndex: "quantity",
                                      key: "quantity"
                                    },
                                    {
                                      title: "Stock Levels",
                                      dataIndex: "stock_levels",
                                      key: "stock_levels"
                                    },
                                    {
                                      title: "Notes",
                                      dataIndex: "notes",
                                      key: "notes"
                                    },
                                    {
                                      title: "Action",
                                      key: "action",
                                      width: "3%"
                                    }
                                  ],
                                  "data-source": [
                                    {
                                      key: "1",
                                      product: "Computer",
                                      quantity: "1",
                                      stock_levels: "0",
                                      notes: "0"
                                    },
                                    {
                                      key: "2",
                                      product: "Computer",
                                      quantity: "1",
                                      stock_levels: "0",
                                      notes: "0"
                                    },
                                    {
                                      key: "3",
                                      product: "Computer",
                                      quantity: "1",
                                      stock_levels: "0",
                                      notes: "0"
                                    }
                                  ],
                                  pagination: false
                                }, {
                                  bodyCell: withCtx(({ column, record }, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      if (column.key === "product") {
                                        _push7(ssrRenderComponent(_component_a_select, {
                                          value: $data.form.tax,
                                          "onUpdate:value": ($event) => $data.form.tax = $event,
                                          "show-search": "",
                                          placeholder: "Select Product",
                                          style: { "width": "100%" },
                                          "default-active-first-option": false,
                                          options: [{
                                            label: "Red color T-shirt - Md",
                                            value: "Red color T-shirt - Md"
                                          }, {
                                            label: "Red color T-shirt - Lg",
                                            value: "Red color T-shirt - Lg"
                                          }, {
                                            label: "Red color T-shirt - SM",
                                            value: "Red color T-shirt - SM"
                                          }],
                                          "not-found-content": _ctx.value
                                        }, null, _parent7, _scopeId6));
                                      } else {
                                        _push7(`<!---->`);
                                      }
                                      if (column.key === "quantity") {
                                        _push7(ssrRenderComponent(_component_a_input, {
                                          value: record.quantity,
                                          "onUpdate:value": ($event) => record.quantity = $event
                                        }, null, _parent7, _scopeId6));
                                      } else {
                                        _push7(`<!---->`);
                                      }
                                      if (column.key === "stock_levels") {
                                        _push7(`<!--[--> In stock: 0,00 <!--]-->`);
                                      } else {
                                        _push7(`<!---->`);
                                      }
                                      if (column.key === "notes") {
                                        _push7(ssrRenderComponent(_component_a_textarea, {
                                          value: $data.form.description,
                                          "onUpdate:value": ($event) => $data.form.description = $event
                                        }, null, _parent7, _scopeId6));
                                      } else {
                                        _push7(`<!---->`);
                                      }
                                      if (column.key === "action") {
                                        _push7(ssrRenderComponent(_component_a_dropdown_button, { onClick: _ctx.handleButtonClick }, {
                                          icon: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(ssrRenderComponent(_component_MoreOutlined, null, null, _parent8, _scopeId7));
                                            } else {
                                              return [
                                                createVNode(_component_MoreOutlined)
                                              ];
                                            }
                                          }),
                                          overlay: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(ssrRenderComponent(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                                default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                  if (_push9) {
                                                    _push9(ssrRenderComponent(_component_a_menu_item, { key: "1" }, {
                                                      default: withCtx((_8, _push10, _parent10, _scopeId9) => {
                                                        if (_push10) {
                                                          _push10(ssrRenderComponent(_component_UserOutlined, null, null, _parent10, _scopeId9));
                                                          _push10(` Create PO `);
                                                        } else {
                                                          return [
                                                            createVNode(_component_UserOutlined),
                                                            createTextVNode(" Create PO ")
                                                          ];
                                                        }
                                                      }),
                                                      _: 2
                                                    }, _parent9, _scopeId8));
                                                  } else {
                                                    return [
                                                      createVNode(_component_a_menu_item, { key: "1" }, {
                                                        default: withCtx(() => [
                                                          createVNode(_component_UserOutlined),
                                                          createTextVNode(" Create PO ")
                                                        ]),
                                                        _: 1
                                                      })
                                                    ];
                                                  }
                                                }),
                                                _: 2
                                              }, _parent8, _scopeId7));
                                            } else {
                                              return [
                                                createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_menu_item, { key: "1" }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_UserOutlined),
                                                        createTextVNode(" Create PO ")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }, 8, ["onClick"])
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                      } else {
                                        _push7(`<!---->`);
                                      }
                                    } else {
                                      return [
                                        column.key === "product" ? (openBlock(), createBlock(_component_a_select, {
                                          key: 0,
                                          value: $data.form.tax,
                                          "onUpdate:value": ($event) => $data.form.tax = $event,
                                          "show-search": "",
                                          placeholder: "Select Product",
                                          style: { "width": "100%" },
                                          "default-active-first-option": false,
                                          options: [{
                                            label: "Red color T-shirt - Md",
                                            value: "Red color T-shirt - Md"
                                          }, {
                                            label: "Red color T-shirt - Lg",
                                            value: "Red color T-shirt - Lg"
                                          }, {
                                            label: "Red color T-shirt - SM",
                                            value: "Red color T-shirt - SM"
                                          }],
                                          "not-found-content": _ctx.value
                                        }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                                        column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                                          key: 1,
                                          value: record.quantity,
                                          "onUpdate:value": ($event) => record.quantity = $event
                                        }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                        column.key === "stock_levels" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                                          createTextVNode(" In stock: 0,00 ")
                                        ], 64)) : createCommentVNode("", true),
                                        column.key === "notes" ? (openBlock(), createBlock(_component_a_textarea, {
                                          key: 3,
                                          value: $data.form.description,
                                          "onUpdate:value": ($event) => $data.form.description = $event
                                        }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                        column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                                          key: 4,
                                          onClick: _ctx.handleButtonClick
                                        }, {
                                          icon: withCtx(() => [
                                            createVNode(_component_MoreOutlined)
                                          ]),
                                          overlay: withCtx(() => [
                                            createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_menu_item, { key: "1" }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_UserOutlined),
                                                    createTextVNode(" Create PO ")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }, 8, ["onClick"])
                                          ]),
                                          _: 1
                                        }, 8, ["onClick"])) : createCommentVNode("", true)
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(`<h4${_scopeId5}>Summary of raw materials</h4>`);
                                _push6(ssrRenderComponent(_component_a_table, {
                                  columns: [
                                    {
                                      title: "Product",
                                      dataIndex: "product",
                                      key: "product"
                                    },
                                    {
                                      title: "Quantity/order",
                                      dataIndex: "quantity",
                                      key: "quantity"
                                    },
                                    {
                                      title: "Quantity used",
                                      dataIndex: "quantity_used",
                                      key: "quantity_used"
                                    }
                                  ],
                                  "data-source": [
                                    {
                                      key: "1",
                                      product: "Computer",
                                      quantity: "1",
                                      quantity_used: "0"
                                    },
                                    {
                                      key: "2",
                                      product: "Computer",
                                      quantity: "1",
                                      quantity_used: "0"
                                    },
                                    {
                                      key: "3",
                                      product: "Computer",
                                      quantity: "1",
                                      quantity_used: "0"
                                    }
                                  ],
                                  pagination: false
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_space, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        size: "small"
                                      }, {
                                        icon: withCtx(() => [
                                          createVNode(_component_plus_circle_outlined)
                                        ]),
                                        default: withCtx(() => [
                                          createTextVNode(" Add Raw Material ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode("br"),
                                  createVNode(_component_a_table, {
                                    columns: [
                                      {
                                        title: "Product",
                                        dataIndex: "product",
                                        key: "product"
                                      },
                                      {
                                        title: "Quantity/order",
                                        dataIndex: "quantity",
                                        key: "quantity"
                                      },
                                      {
                                        title: "Stock Levels",
                                        dataIndex: "stock_levels",
                                        key: "stock_levels"
                                      },
                                      {
                                        title: "Notes",
                                        dataIndex: "notes",
                                        key: "notes"
                                      },
                                      {
                                        title: "Action",
                                        key: "action",
                                        width: "3%"
                                      }
                                    ],
                                    "data-source": [
                                      {
                                        key: "1",
                                        product: "Computer",
                                        quantity: "1",
                                        stock_levels: "0",
                                        notes: "0"
                                      },
                                      {
                                        key: "2",
                                        product: "Computer",
                                        quantity: "1",
                                        stock_levels: "0",
                                        notes: "0"
                                      },
                                      {
                                        key: "3",
                                        product: "Computer",
                                        quantity: "1",
                                        stock_levels: "0",
                                        notes: "0"
                                      }
                                    ],
                                    pagination: false
                                  }, {
                                    bodyCell: withCtx(({ column, record }) => [
                                      column.key === "product" ? (openBlock(), createBlock(_component_a_select, {
                                        key: 0,
                                        value: $data.form.tax,
                                        "onUpdate:value": ($event) => $data.form.tax = $event,
                                        "show-search": "",
                                        placeholder: "Select Product",
                                        style: { "width": "100%" },
                                        "default-active-first-option": false,
                                        options: [{
                                          label: "Red color T-shirt - Md",
                                          value: "Red color T-shirt - Md"
                                        }, {
                                          label: "Red color T-shirt - Lg",
                                          value: "Red color T-shirt - Lg"
                                        }, {
                                          label: "Red color T-shirt - SM",
                                          value: "Red color T-shirt - SM"
                                        }],
                                        "not-found-content": _ctx.value
                                      }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                                      column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                                        key: 1,
                                        value: record.quantity,
                                        "onUpdate:value": ($event) => record.quantity = $event
                                      }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                      column.key === "stock_levels" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                                        createTextVNode(" In stock: 0,00 ")
                                      ], 64)) : createCommentVNode("", true),
                                      column.key === "notes" ? (openBlock(), createBlock(_component_a_textarea, {
                                        key: 3,
                                        value: $data.form.description,
                                        "onUpdate:value": ($event) => $data.form.description = $event
                                      }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                      column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                                        key: 4,
                                        onClick: _ctx.handleButtonClick
                                      }, {
                                        icon: withCtx(() => [
                                          createVNode(_component_MoreOutlined)
                                        ]),
                                        overlay: withCtx(() => [
                                          createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_menu_item, { key: "1" }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_UserOutlined),
                                                  createTextVNode(" Create PO ")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }, 8, ["onClick"])
                                        ]),
                                        _: 1
                                      }, 8, ["onClick"])) : createCommentVNode("", true)
                                    ]),
                                    _: 1
                                  }),
                                  createVNode("h4", null, "Summary of raw materials"),
                                  createVNode(_component_a_table, {
                                    columns: [
                                      {
                                        title: "Product",
                                        dataIndex: "product",
                                        key: "product"
                                      },
                                      {
                                        title: "Quantity/order",
                                        dataIndex: "quantity",
                                        key: "quantity"
                                      },
                                      {
                                        title: "Quantity used",
                                        dataIndex: "quantity_used",
                                        key: "quantity_used"
                                      }
                                    ],
                                    "data-source": [
                                      {
                                        key: "1",
                                        product: "Computer",
                                        quantity: "1",
                                        quantity_used: "0"
                                      },
                                      {
                                        key: "2",
                                        product: "Computer",
                                        quantity: "1",
                                        quantity_used: "0"
                                      },
                                      {
                                        key: "3",
                                        product: "Computer",
                                        quantity: "1",
                                        quantity_used: "0"
                                      }
                                    ],
                                    pagination: false
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_tab_pane, {
                            key: "JO-1-3",
                            tab: "Manufacturing tasks",
                            "force-render": ""
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_table, {
                                  columns: [
                                    {
                                      title: "Machine/Operation",
                                      dataIndex: "operation",
                                      key: "operation"
                                    },
                                    {
                                      title: "Planned Start",
                                      dataIndex: "planned_start",
                                      key: "planned_start"
                                    },
                                    {
                                      title: "Due Date",
                                      dataIndex: "due_date",
                                      key: "due_date"
                                    },
                                    {
                                      title: "Due Date",
                                      dataIndex: "due_date",
                                      key: "due_date"
                                    }
                                  ],
                                  "data-source": [],
                                  pagination: false
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_table, {
                                    columns: [
                                      {
                                        title: "Machine/Operation",
                                        dataIndex: "operation",
                                        key: "operation"
                                      },
                                      {
                                        title: "Planned Start",
                                        dataIndex: "planned_start",
                                        key: "planned_start"
                                      },
                                      {
                                        title: "Due Date",
                                        dataIndex: "due_date",
                                        key: "due_date"
                                      },
                                      {
                                        title: "Due Date",
                                        dataIndex: "due_date",
                                        key: "due_date"
                                      }
                                    ],
                                    "data-source": [],
                                    pagination: false
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_tab_pane, {
                            key: "JO-1-4",
                            tab: "Operation Tasks"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_space, null, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "primary",
                                        size: "small"
                                      }, {
                                        icon: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_plus_circle_outlined)
                                            ];
                                          }
                                        }),
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(` Add Operation Task `);
                                          } else {
                                            return [
                                              createTextVNode(" Add Operation Task ")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          size: "small"
                                        }, {
                                          icon: withCtx(() => [
                                            createVNode(_component_plus_circle_outlined)
                                          ]),
                                          default: withCtx(() => [
                                            createTextVNode(" Add Operation Task ")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(`<br${_scopeId5}>`);
                                _push6(ssrRenderComponent(_component_a_table, {
                                  columns: [
                                    {
                                      title: "Machine/Operation",
                                      dataIndex: "operation",
                                      key: "operation"
                                    }
                                  ],
                                  "data-source": [],
                                  pagination: false
                                }, null, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_table, {
                                  columns: [
                                    {
                                      title: "Date",
                                      dataIndex: "date",
                                      key: "date"
                                    },
                                    {
                                      title: "Operation",
                                      dataIndex: "operation",
                                      key: "operation"
                                    },
                                    {
                                      title: "User",
                                      dataIndex: "user",
                                      key: "user"
                                    },
                                    {
                                      title: "Notes",
                                      dataIndex: "notes",
                                      key: "notes"
                                    }
                                  ],
                                  "data-source": [],
                                  pagination: false
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_space, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        size: "small"
                                      }, {
                                        icon: withCtx(() => [
                                          createVNode(_component_plus_circle_outlined)
                                        ]),
                                        default: withCtx(() => [
                                          createTextVNode(" Add Operation Task ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode("br"),
                                  createVNode(_component_a_table, {
                                    columns: [
                                      {
                                        title: "Machine/Operation",
                                        dataIndex: "operation",
                                        key: "operation"
                                      }
                                    ],
                                    "data-source": [],
                                    pagination: false
                                  }),
                                  createVNode(_component_a_table, {
                                    columns: [
                                      {
                                        title: "Date",
                                        dataIndex: "date",
                                        key: "date"
                                      },
                                      {
                                        title: "Operation",
                                        dataIndex: "operation",
                                        key: "operation"
                                      },
                                      {
                                        title: "User",
                                        dataIndex: "user",
                                        key: "user"
                                      },
                                      {
                                        title: "Notes",
                                        dataIndex: "notes",
                                        key: "notes"
                                      }
                                    ],
                                    "data-source": [],
                                    pagination: false
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_tab_pane, {
                            key: "JO-1-5",
                            tab: "Inventory Release"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Inventory Release`);
                              } else {
                                return [
                                  createTextVNode("Inventory Release")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_tab_pane, {
                              key: "JO-1-1",
                              tab: "Progress"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Progress ")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_tab_pane, {
                              key: "JO-1-2",
                              tab: "Raw Materials",
                              "force-render": ""
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_space, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      size: "small"
                                    }, {
                                      icon: withCtx(() => [
                                        createVNode(_component_plus_circle_outlined)
                                      ]),
                                      default: withCtx(() => [
                                        createTextVNode(" Add Raw Material ")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode("br"),
                                createVNode(_component_a_table, {
                                  columns: [
                                    {
                                      title: "Product",
                                      dataIndex: "product",
                                      key: "product"
                                    },
                                    {
                                      title: "Quantity/order",
                                      dataIndex: "quantity",
                                      key: "quantity"
                                    },
                                    {
                                      title: "Stock Levels",
                                      dataIndex: "stock_levels",
                                      key: "stock_levels"
                                    },
                                    {
                                      title: "Notes",
                                      dataIndex: "notes",
                                      key: "notes"
                                    },
                                    {
                                      title: "Action",
                                      key: "action",
                                      width: "3%"
                                    }
                                  ],
                                  "data-source": [
                                    {
                                      key: "1",
                                      product: "Computer",
                                      quantity: "1",
                                      stock_levels: "0",
                                      notes: "0"
                                    },
                                    {
                                      key: "2",
                                      product: "Computer",
                                      quantity: "1",
                                      stock_levels: "0",
                                      notes: "0"
                                    },
                                    {
                                      key: "3",
                                      product: "Computer",
                                      quantity: "1",
                                      stock_levels: "0",
                                      notes: "0"
                                    }
                                  ],
                                  pagination: false
                                }, {
                                  bodyCell: withCtx(({ column, record }) => [
                                    column.key === "product" ? (openBlock(), createBlock(_component_a_select, {
                                      key: 0,
                                      value: $data.form.tax,
                                      "onUpdate:value": ($event) => $data.form.tax = $event,
                                      "show-search": "",
                                      placeholder: "Select Product",
                                      style: { "width": "100%" },
                                      "default-active-first-option": false,
                                      options: [{
                                        label: "Red color T-shirt - Md",
                                        value: "Red color T-shirt - Md"
                                      }, {
                                        label: "Red color T-shirt - Lg",
                                        value: "Red color T-shirt - Lg"
                                      }, {
                                        label: "Red color T-shirt - SM",
                                        value: "Red color T-shirt - SM"
                                      }],
                                      "not-found-content": _ctx.value
                                    }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                                    column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                                      key: 1,
                                      value: record.quantity,
                                      "onUpdate:value": ($event) => record.quantity = $event
                                    }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                    column.key === "stock_levels" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                                      createTextVNode(" In stock: 0,00 ")
                                    ], 64)) : createCommentVNode("", true),
                                    column.key === "notes" ? (openBlock(), createBlock(_component_a_textarea, {
                                      key: 3,
                                      value: $data.form.description,
                                      "onUpdate:value": ($event) => $data.form.description = $event
                                    }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                    column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                                      key: 4,
                                      onClick: _ctx.handleButtonClick
                                    }, {
                                      icon: withCtx(() => [
                                        createVNode(_component_MoreOutlined)
                                      ]),
                                      overlay: withCtx(() => [
                                        createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_menu_item, { key: "1" }, {
                                              default: withCtx(() => [
                                                createVNode(_component_UserOutlined),
                                                createTextVNode(" Create PO ")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["onClick"])
                                      ]),
                                      _: 1
                                    }, 8, ["onClick"])) : createCommentVNode("", true)
                                  ]),
                                  _: 1
                                }),
                                createVNode("h4", null, "Summary of raw materials"),
                                createVNode(_component_a_table, {
                                  columns: [
                                    {
                                      title: "Product",
                                      dataIndex: "product",
                                      key: "product"
                                    },
                                    {
                                      title: "Quantity/order",
                                      dataIndex: "quantity",
                                      key: "quantity"
                                    },
                                    {
                                      title: "Quantity used",
                                      dataIndex: "quantity_used",
                                      key: "quantity_used"
                                    }
                                  ],
                                  "data-source": [
                                    {
                                      key: "1",
                                      product: "Computer",
                                      quantity: "1",
                                      quantity_used: "0"
                                    },
                                    {
                                      key: "2",
                                      product: "Computer",
                                      quantity: "1",
                                      quantity_used: "0"
                                    },
                                    {
                                      key: "3",
                                      product: "Computer",
                                      quantity: "1",
                                      quantity_used: "0"
                                    }
                                  ],
                                  pagination: false
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_tab_pane, {
                              key: "JO-1-3",
                              tab: "Manufacturing tasks",
                              "force-render": ""
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_table, {
                                  columns: [
                                    {
                                      title: "Machine/Operation",
                                      dataIndex: "operation",
                                      key: "operation"
                                    },
                                    {
                                      title: "Planned Start",
                                      dataIndex: "planned_start",
                                      key: "planned_start"
                                    },
                                    {
                                      title: "Due Date",
                                      dataIndex: "due_date",
                                      key: "due_date"
                                    },
                                    {
                                      title: "Due Date",
                                      dataIndex: "due_date",
                                      key: "due_date"
                                    }
                                  ],
                                  "data-source": [],
                                  pagination: false
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_tab_pane, {
                              key: "JO-1-4",
                              tab: "Operation Tasks"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_space, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      size: "small"
                                    }, {
                                      icon: withCtx(() => [
                                        createVNode(_component_plus_circle_outlined)
                                      ]),
                                      default: withCtx(() => [
                                        createTextVNode(" Add Operation Task ")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode("br"),
                                createVNode(_component_a_table, {
                                  columns: [
                                    {
                                      title: "Machine/Operation",
                                      dataIndex: "operation",
                                      key: "operation"
                                    }
                                  ],
                                  "data-source": [],
                                  pagination: false
                                }),
                                createVNode(_component_a_table, {
                                  columns: [
                                    {
                                      title: "Date",
                                      dataIndex: "date",
                                      key: "date"
                                    },
                                    {
                                      title: "Operation",
                                      dataIndex: "operation",
                                      key: "operation"
                                    },
                                    {
                                      title: "User",
                                      dataIndex: "user",
                                      key: "user"
                                    },
                                    {
                                      title: "Notes",
                                      dataIndex: "notes",
                                      key: "notes"
                                    }
                                  ],
                                  "data-source": [],
                                  pagination: false
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_tab_pane, {
                              key: "JO-1-5",
                              tab: "Inventory Release"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Inventory Release")
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_tabs, {
                        activeKey: _ctx.activeKey,
                        "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_tab_pane, {
                            key: "JO-1-1",
                            tab: "Progress"
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Progress ")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_tab_pane, {
                            key: "JO-1-2",
                            tab: "Raw Materials",
                            "force-render": ""
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_space, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    size: "small"
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Add Raw Material ")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode("br"),
                              createVNode(_component_a_table, {
                                columns: [
                                  {
                                    title: "Product",
                                    dataIndex: "product",
                                    key: "product"
                                  },
                                  {
                                    title: "Quantity/order",
                                    dataIndex: "quantity",
                                    key: "quantity"
                                  },
                                  {
                                    title: "Stock Levels",
                                    dataIndex: "stock_levels",
                                    key: "stock_levels"
                                  },
                                  {
                                    title: "Notes",
                                    dataIndex: "notes",
                                    key: "notes"
                                  },
                                  {
                                    title: "Action",
                                    key: "action",
                                    width: "3%"
                                  }
                                ],
                                "data-source": [
                                  {
                                    key: "1",
                                    product: "Computer",
                                    quantity: "1",
                                    stock_levels: "0",
                                    notes: "0"
                                  },
                                  {
                                    key: "2",
                                    product: "Computer",
                                    quantity: "1",
                                    stock_levels: "0",
                                    notes: "0"
                                  },
                                  {
                                    key: "3",
                                    product: "Computer",
                                    quantity: "1",
                                    stock_levels: "0",
                                    notes: "0"
                                  }
                                ],
                                pagination: false
                              }, {
                                bodyCell: withCtx(({ column, record }) => [
                                  column.key === "product" ? (openBlock(), createBlock(_component_a_select, {
                                    key: 0,
                                    value: $data.form.tax,
                                    "onUpdate:value": ($event) => $data.form.tax = $event,
                                    "show-search": "",
                                    placeholder: "Select Product",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    options: [{
                                      label: "Red color T-shirt - Md",
                                      value: "Red color T-shirt - Md"
                                    }, {
                                      label: "Red color T-shirt - Lg",
                                      value: "Red color T-shirt - Lg"
                                    }, {
                                      label: "Red color T-shirt - SM",
                                      value: "Red color T-shirt - SM"
                                    }],
                                    "not-found-content": _ctx.value
                                  }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                                  column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                                    key: 1,
                                    value: record.quantity,
                                    "onUpdate:value": ($event) => record.quantity = $event
                                  }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                  column.key === "stock_levels" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                                    createTextVNode(" In stock: 0,00 ")
                                  ], 64)) : createCommentVNode("", true),
                                  column.key === "notes" ? (openBlock(), createBlock(_component_a_textarea, {
                                    key: 3,
                                    value: $data.form.description,
                                    "onUpdate:value": ($event) => $data.form.description = $event
                                  }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                  column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                                    key: 4,
                                    onClick: _ctx.handleButtonClick
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_MoreOutlined)
                                    ]),
                                    overlay: withCtx(() => [
                                      createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_menu_item, { key: "1" }, {
                                            default: withCtx(() => [
                                              createVNode(_component_UserOutlined),
                                              createTextVNode(" Create PO ")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["onClick"])
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])) : createCommentVNode("", true)
                                ]),
                                _: 1
                              }),
                              createVNode("h4", null, "Summary of raw materials"),
                              createVNode(_component_a_table, {
                                columns: [
                                  {
                                    title: "Product",
                                    dataIndex: "product",
                                    key: "product"
                                  },
                                  {
                                    title: "Quantity/order",
                                    dataIndex: "quantity",
                                    key: "quantity"
                                  },
                                  {
                                    title: "Quantity used",
                                    dataIndex: "quantity_used",
                                    key: "quantity_used"
                                  }
                                ],
                                "data-source": [
                                  {
                                    key: "1",
                                    product: "Computer",
                                    quantity: "1",
                                    quantity_used: "0"
                                  },
                                  {
                                    key: "2",
                                    product: "Computer",
                                    quantity: "1",
                                    quantity_used: "0"
                                  },
                                  {
                                    key: "3",
                                    product: "Computer",
                                    quantity: "1",
                                    quantity_used: "0"
                                  }
                                ],
                                pagination: false
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_tab_pane, {
                            key: "JO-1-3",
                            tab: "Manufacturing tasks",
                            "force-render": ""
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_table, {
                                columns: [
                                  {
                                    title: "Machine/Operation",
                                    dataIndex: "operation",
                                    key: "operation"
                                  },
                                  {
                                    title: "Planned Start",
                                    dataIndex: "planned_start",
                                    key: "planned_start"
                                  },
                                  {
                                    title: "Due Date",
                                    dataIndex: "due_date",
                                    key: "due_date"
                                  },
                                  {
                                    title: "Due Date",
                                    dataIndex: "due_date",
                                    key: "due_date"
                                  }
                                ],
                                "data-source": [],
                                pagination: false
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_tab_pane, {
                            key: "JO-1-4",
                            tab: "Operation Tasks"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_space, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    size: "small"
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Add Operation Task ")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode("br"),
                              createVNode(_component_a_table, {
                                columns: [
                                  {
                                    title: "Machine/Operation",
                                    dataIndex: "operation",
                                    key: "operation"
                                  }
                                ],
                                "data-source": [],
                                pagination: false
                              }),
                              createVNode(_component_a_table, {
                                columns: [
                                  {
                                    title: "Date",
                                    dataIndex: "date",
                                    key: "date"
                                  },
                                  {
                                    title: "Operation",
                                    dataIndex: "operation",
                                    key: "operation"
                                  },
                                  {
                                    title: "User",
                                    dataIndex: "user",
                                    key: "user"
                                  },
                                  {
                                    title: "Notes",
                                    dataIndex: "notes",
                                    key: "notes"
                                  }
                                ],
                                "data-source": [],
                                pagination: false
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_tab_pane, {
                            key: "JO-1-5",
                            tab: "Inventory Release"
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Inventory Release")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["activeKey", "onUpdate:activeKey"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_space, {
                  direction: "vertical",
                  style: { width: "100%" }
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, {
                      name: "nest-messages",
                      model: $data.searchform,
                      layout: "inline",
                      onFinish: _ctx.search
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, {
                              placeholder: "Search by Job Order Number",
                              "allow-clear": true,
                              value: $data.searchform.term,
                              "onUpdate:value": ($event) => $data.searchform.term = $event
                            }, null, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Search ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              shape: "round",
                              onClick: $options.showDrawer
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_plus_circle_outlined)
                              ]),
                              default: withCtx(() => [
                                createTextVNode(" New BOM ")
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["model", "onFinish"]),
                    createVNode(_component_a_table, {
                      columns: [
                        {
                          title: "BOM ID",
                          key: "bom_id",
                          dataIndex: "bom_id"
                        },
                        {
                          title: "BOM Name",
                          key: "bom_name",
                          dataIndex: "bom_name"
                        },
                        {
                          title: "Product Name",
                          key: "product_name",
                          dataIndex: "product_name"
                        },
                        {
                          title: "No of Raw Materials",
                          key: "no_of_rm",
                          dataIndex: "no_of_rm"
                        },
                        {
                          title: "Action",
                          key: "action",
                          width: "3%"
                        }
                      ],
                      "data-source": [
                        {
                          key: "1",
                          bom_id: "BOM-0001",
                          bom_name: "BOM-0001",
                          product_name: "Computer",
                          no_of_rm: "1"
                        }
                      ],
                      pagination: false
                    }, {
                      bodyCell: withCtx(({ column, record }) => [
                        column.key === "bom_id" ? (openBlock(), createBlock("a", {
                          key: 0,
                          onClick: $options.showDetailDrawer
                        }, toDisplayString(record.bom_id), 9, ["onClick"])) : createCommentVNode("", true)
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_a_drawer, {
                  visible: $data.create_form_visible,
                  "onUpdate:visible": ($event) => $data.create_form_visible = $event,
                  class: "sales-bill",
                  size: "large",
                  style: { "color": "red" },
                  width: "75%",
                  title: "Add BOM",
                  placement: "right",
                  onAfterVisibleChange: _ctx.afterVisibleChange
                }, {
                  footer: withCtx(() => [
                    createVNode(_component_a_button, {
                      style: { "margin-right": "8px" },
                      onClick: _ctx.onClose
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Cancel")
                      ]),
                      _: 1
                    }, 8, ["onClick"]),
                    createVNode(_component_a_button, {
                      type: "primary",
                      onClick: _ctx.onClose
                    }, {
                      default: withCtx(() => [
                        createTextVNode("SAVE")
                      ]),
                      _: 1
                    }, 8, ["onClick"])
                  ]),
                  default: withCtx(() => [
                    createVNode(_component_a_form, mergeProps({ model: $data.form }, _ctx.layout, {
                      name: "nest-messages",
                      "validate-messages": _ctx.validateMessages,
                      onFinish: _ctx.submit,
                      "label-col": { span: 24 },
                      style: { "min-height": "100%" }
                    }), {
                      default: withCtx(() => [
                        createVNode(_component_a_row, { gutter: 24 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "document_name",
                                  label: "Document Name",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $data.form.document_name,
                                      "onUpdate:value": ($event) => $data.form.document_name = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "document_number",
                                  label: "Document Number"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $data.form.document_number,
                                      "onUpdate:value": ($event) => $data.form.document_number = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "24"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "description",
                                  label: "Description"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $data.form.description,
                                      "onUpdate:value": ($event) => $data.form.description = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode("h4", { class: "t1" }, "Product"),
                        createVNode(_component_a_row, { gutter: 24 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "product",
                                  label: "Select Product",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      value: $data.form.tax,
                                      "onUpdate:value": ($event) => $data.form.tax = $event,
                                      "show-search": "",
                                      placeholder: "Select Product",
                                      style: { "width": "100%" },
                                      "default-active-first-option": false,
                                      options: [{
                                        label: "Red color T-shirt - Md",
                                        value: "Red color T-shirt - Md"
                                      }, {
                                        label: "Red color T-shirt - Lg",
                                        value: "Red color T-shirt - Lg"
                                      }, {
                                        label: "Red color T-shirt - SM",
                                        value: "Red color T-shirt - SM"
                                      }],
                                      "not-found-content": _ctx.value
                                    }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "quantity",
                                  label: "Quantity",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $data.form.quantity,
                                      "onUpdate:value": ($event) => $data.form.quantity = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "unit",
                                  label: "Unit",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      value: $data.form.tax,
                                      "onUpdate:value": ($event) => $data.form.tax = $event,
                                      "show-search": "",
                                      placeholder: "Select Unit",
                                      style: { "width": "100%" },
                                      "default-active-first-option": false,
                                      options: [{
                                        label: "KG",
                                        value: "KG"
                                      }, {
                                        label: "Ltr",
                                        value: "Ltr"
                                      }, {
                                        label: "Pcs",
                                        value: "Pcs"
                                      }]
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: "12"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  name: "cost_allocation",
                                  label: "Cost Allocation",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $data.form.cost_allocation,
                                      "onUpdate:value": ($event) => $data.form.cost_allocation = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode("h4", { class: "t1" }, "Raw Materials"),
                        createVNode(_component_a_table, {
                          columns: [
                            {
                              title: "Raw Material",
                              dataIndex: "raw_material",
                              key: "raw_material"
                            },
                            {
                              title: "Quantity",
                              dataIndex: "quantity",
                              key: "quantity"
                            },
                            {
                              title: "Unit",
                              dataIndex: "unit",
                              key: "unit"
                            },
                            {
                              title: "Notes",
                              dataIndex: "notes",
                              key: "notes"
                            },
                            {
                              title: "Action",
                              key: "action",
                              width: "3%"
                            }
                          ],
                          "data-source": [{}],
                          pagination: false
                        }, {
                          bodyCell: withCtx(({ column, record }) => [
                            column.key === "raw_material" ? (openBlock(), createBlock(_component_a_select, {
                              key: 0,
                              value: $data.form.tax,
                              "onUpdate:value": ($event) => $data.form.tax = $event,
                              "show-search": "",
                              placeholder: "Select Product",
                              style: { "width": "100%" },
                              "default-active-first-option": false,
                              options: [{
                                label: "Red color T-shirt - Md",
                                value: "Red color T-shirt - Md"
                              }, {
                                label: "Red color T-shirt - Lg",
                                value: "Red color T-shirt - Lg"
                              }, {
                                label: "Red color T-shirt - SM",
                                value: "Red color T-shirt - SM"
                              }],
                              "not-found-content": _ctx.value
                            }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                            column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                              key: 1,
                              value: record.quantity,
                              "onUpdate:value": ($event) => record.quantity = $event
                            }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                            column.key === "unit" ? (openBlock(), createBlock(_component_a_select, {
                              key: 2,
                              value: $data.form.tax,
                              "onUpdate:value": ($event) => $data.form.tax = $event,
                              "show-search": "",
                              placeholder: "Select Unit",
                              style: { "width": "100%" },
                              "default-active-first-option": false,
                              options: [{
                                label: "Kg",
                                value: "Kg"
                              }, {
                                label: "Ltr",
                                value: "Ltr"
                              }]
                            }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                            column.key === "notes" ? (openBlock(), createBlock(_component_a_textarea, {
                              key: 3,
                              value: $data.form.description,
                              "onUpdate:value": ($event) => $data.form.description = $event
                            }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                            column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                              key: 4,
                              onClick: _ctx.handleButtonClick
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_MoreOutlined)
                              ]),
                              overlay: withCtx(() => [
                                createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "1" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_UserOutlined),
                                        createTextVNode(" Remove ")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])
                              ]),
                              _: 1
                            }, 8, ["onClick"])) : createCommentVNode("", true)
                          ]),
                          _: 1
                        }),
                        createVNode("br"),
                        createVNode(_component_a_space, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "success",
                              size: "small"
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_plus_circle_outlined)
                              ]),
                              default: withCtx(() => [
                                createTextVNode(" Add RM ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode("br"),
                        createVNode("h4", { class: "t1" }, "Routing"),
                        createVNode(_component_a_table, {
                          columns: [
                            {
                              title: "Routing",
                              dataIndex: "routing",
                              key: "routing"
                            },
                            {
                              title: "Comment",
                              dataIndex: "comment",
                              key: "comment"
                            },
                            {
                              title: "Action",
                              key: "action",
                              width: "3%"
                            }
                          ],
                          "data-source": [{}],
                          pagination: false
                        }, {
                          bodyCell: withCtx(({ column, record }) => [
                            column.key === "routing" ? (openBlock(), createBlock(_component_a_select, {
                              key: 0,
                              value: $data.form.tax,
                              "onUpdate:value": ($event) => $data.form.tax = $event,
                              "show-search": "",
                              placeholder: "Select Routing",
                              style: { "width": "100%" },
                              "default-active-first-option": false,
                              options: [{
                                label: "Routing 1",
                                value: "Routing 1"
                              }, {
                                label: "Routing 2",
                                value: "Routing 2"
                              }, {
                                label: "Routing 3",
                                value: "Routing 3"
                              }],
                              "not-found-content": _ctx.value
                            }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                            column.key === "comment" ? (openBlock(), createBlock(_component_a_textarea, {
                              key: 1,
                              value: $data.form.description,
                              "onUpdate:value": ($event) => $data.form.description = $event
                            }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                            column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                              key: 2,
                              onClick: _ctx.handleButtonClick
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_MoreOutlined)
                              ]),
                              overlay: withCtx(() => [
                                createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "1" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_UserOutlined),
                                        createTextVNode(" Remove ")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])
                              ]),
                              _: 1
                            }, 8, ["onClick"])) : createCommentVNode("", true)
                          ]),
                          _: 1
                        }),
                        createVNode("br"),
                        createVNode(_component_a_space, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "success",
                              size: "small"
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_plus_circle_outlined)
                              ]),
                              default: withCtx(() => [
                                createTextVNode(" Add Routing ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode("br"),
                        createVNode("h4", { class: "t1" }, "Other Charges"),
                        createVNode(_component_a_table, {
                          columns: [
                            {
                              title: "Classification",
                              dataIndex: "classification",
                              key: "classification"
                            },
                            {
                              title: "Amount",
                              dataIndex: "amount",
                              key: "amount"
                            },
                            {
                              title: "Comment",
                              dataIndex: "comment",
                              key: "comment"
                            }
                          ],
                          "data-source": [
                            {
                              key: "1",
                              classification: "Classification 1",
                              amount: "0",
                              comment: ""
                            },
                            {
                              key: "1",
                              classification: "Classification 1",
                              amount: "0",
                              comment: ""
                            },
                            {
                              key: "1",
                              classification: "Classification 1",
                              amount: "0",
                              comment: ""
                            },
                            {
                              key: "1",
                              classification: "Classification 1",
                              amount: "0",
                              comment: ""
                            }
                          ],
                          pagination: false
                        }, {
                          bodyCell: withCtx(({ column, record }) => [
                            column.key === "classification" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                              createTextVNode(toDisplayString(record.classification), 1)
                            ], 64)) : createCommentVNode("", true),
                            column.key === "amount" ? (openBlock(), createBlock(_component_a_input, {
                              key: 1,
                              value: record.amount,
                              "onUpdate:value": ($event) => record.amount = $event
                            }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                            column.key === "comment" ? (openBlock(), createBlock(_component_a_input, {
                              key: 2,
                              value: record.comment,
                              "onUpdate:value": ($event) => record.comment = $event
                            }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true)
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 16, ["model", "validate-messages", "onFinish"])
                  ]),
                  _: 1
                }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"]),
                createVNode(_component_a_drawer, {
                  visible: $data.showdetail,
                  "onUpdate:visible": ($event) => $data.showdetail = $event,
                  class: "custom-class",
                  title: "JO-000001",
                  size: "large",
                  placement: "right",
                  onAfterVisibleChange: _ctx.afterVisibleChange,
                  width: "60%"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_tabs, {
                      activeKey: _ctx.activeKey,
                      "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_tab_pane, {
                          key: "JO-1-1",
                          tab: "Progress"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Progress ")
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_tab_pane, {
                          key: "JO-1-2",
                          tab: "Raw Materials",
                          "force-render": ""
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_space, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  size: "small"
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Add Raw Material ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("br"),
                            createVNode(_component_a_table, {
                              columns: [
                                {
                                  title: "Product",
                                  dataIndex: "product",
                                  key: "product"
                                },
                                {
                                  title: "Quantity/order",
                                  dataIndex: "quantity",
                                  key: "quantity"
                                },
                                {
                                  title: "Stock Levels",
                                  dataIndex: "stock_levels",
                                  key: "stock_levels"
                                },
                                {
                                  title: "Notes",
                                  dataIndex: "notes",
                                  key: "notes"
                                },
                                {
                                  title: "Action",
                                  key: "action",
                                  width: "3%"
                                }
                              ],
                              "data-source": [
                                {
                                  key: "1",
                                  product: "Computer",
                                  quantity: "1",
                                  stock_levels: "0",
                                  notes: "0"
                                },
                                {
                                  key: "2",
                                  product: "Computer",
                                  quantity: "1",
                                  stock_levels: "0",
                                  notes: "0"
                                },
                                {
                                  key: "3",
                                  product: "Computer",
                                  quantity: "1",
                                  stock_levels: "0",
                                  notes: "0"
                                }
                              ],
                              pagination: false
                            }, {
                              bodyCell: withCtx(({ column, record }) => [
                                column.key === "product" ? (openBlock(), createBlock(_component_a_select, {
                                  key: 0,
                                  value: $data.form.tax,
                                  "onUpdate:value": ($event) => $data.form.tax = $event,
                                  "show-search": "",
                                  placeholder: "Select Product",
                                  style: { "width": "100%" },
                                  "default-active-first-option": false,
                                  options: [{
                                    label: "Red color T-shirt - Md",
                                    value: "Red color T-shirt - Md"
                                  }, {
                                    label: "Red color T-shirt - Lg",
                                    value: "Red color T-shirt - Lg"
                                  }, {
                                    label: "Red color T-shirt - SM",
                                    value: "Red color T-shirt - SM"
                                  }],
                                  "not-found-content": _ctx.value
                                }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                                column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                                  key: 1,
                                  value: record.quantity,
                                  "onUpdate:value": ($event) => record.quantity = $event
                                }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                column.key === "stock_levels" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                                  createTextVNode(" In stock: 0,00 ")
                                ], 64)) : createCommentVNode("", true),
                                column.key === "notes" ? (openBlock(), createBlock(_component_a_textarea, {
                                  key: 3,
                                  value: $data.form.description,
                                  "onUpdate:value": ($event) => $data.form.description = $event
                                }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                                column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                                  key: 4,
                                  onClick: _ctx.handleButtonClick
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_MoreOutlined)
                                  ]),
                                  overlay: withCtx(() => [
                                    createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_menu_item, { key: "1" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_UserOutlined),
                                            createTextVNode(" Create PO ")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["onClick"])
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])) : createCommentVNode("", true)
                              ]),
                              _: 1
                            }),
                            createVNode("h4", null, "Summary of raw materials"),
                            createVNode(_component_a_table, {
                              columns: [
                                {
                                  title: "Product",
                                  dataIndex: "product",
                                  key: "product"
                                },
                                {
                                  title: "Quantity/order",
                                  dataIndex: "quantity",
                                  key: "quantity"
                                },
                                {
                                  title: "Quantity used",
                                  dataIndex: "quantity_used",
                                  key: "quantity_used"
                                }
                              ],
                              "data-source": [
                                {
                                  key: "1",
                                  product: "Computer",
                                  quantity: "1",
                                  quantity_used: "0"
                                },
                                {
                                  key: "2",
                                  product: "Computer",
                                  quantity: "1",
                                  quantity_used: "0"
                                },
                                {
                                  key: "3",
                                  product: "Computer",
                                  quantity: "1",
                                  quantity_used: "0"
                                }
                              ],
                              pagination: false
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_tab_pane, {
                          key: "JO-1-3",
                          tab: "Manufacturing tasks",
                          "force-render": ""
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_table, {
                              columns: [
                                {
                                  title: "Machine/Operation",
                                  dataIndex: "operation",
                                  key: "operation"
                                },
                                {
                                  title: "Planned Start",
                                  dataIndex: "planned_start",
                                  key: "planned_start"
                                },
                                {
                                  title: "Due Date",
                                  dataIndex: "due_date",
                                  key: "due_date"
                                },
                                {
                                  title: "Due Date",
                                  dataIndex: "due_date",
                                  key: "due_date"
                                }
                              ],
                              "data-source": [],
                              pagination: false
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_tab_pane, {
                          key: "JO-1-4",
                          tab: "Operation Tasks"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_space, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  size: "small"
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Add Operation Task ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("br"),
                            createVNode(_component_a_table, {
                              columns: [
                                {
                                  title: "Machine/Operation",
                                  dataIndex: "operation",
                                  key: "operation"
                                }
                              ],
                              "data-source": [],
                              pagination: false
                            }),
                            createVNode(_component_a_table, {
                              columns: [
                                {
                                  title: "Date",
                                  dataIndex: "date",
                                  key: "date"
                                },
                                {
                                  title: "Operation",
                                  dataIndex: "operation",
                                  key: "operation"
                                },
                                {
                                  title: "User",
                                  dataIndex: "user",
                                  key: "user"
                                },
                                {
                                  title: "Notes",
                                  dataIndex: "notes",
                                  key: "notes"
                                }
                              ],
                              "data-source": [],
                              pagination: false
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_tab_pane, {
                          key: "JO-1-5",
                          tab: "Inventory Release"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Inventory Release")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["activeKey", "onUpdate:activeKey"])
                  ]),
                  _: 1
                }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_layout_content, null, {
            default: withCtx(() => [
              createVNode(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, {
                    name: "nest-messages",
                    model: $data.searchform,
                    layout: "inline",
                    onFinish: _ctx.search
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            placeholder: "Search by Job Order Number",
                            "allow-clear": true,
                            value: $data.searchform.term,
                            "onUpdate:value": ($event) => $data.searchform.term = $event
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Search ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            shape: "round",
                            onClick: $options.showDrawer
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_plus_circle_outlined)
                            ]),
                            default: withCtx(() => [
                              createTextVNode(" New BOM ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["model", "onFinish"]),
                  createVNode(_component_a_table, {
                    columns: [
                      {
                        title: "BOM ID",
                        key: "bom_id",
                        dataIndex: "bom_id"
                      },
                      {
                        title: "BOM Name",
                        key: "bom_name",
                        dataIndex: "bom_name"
                      },
                      {
                        title: "Product Name",
                        key: "product_name",
                        dataIndex: "product_name"
                      },
                      {
                        title: "No of Raw Materials",
                        key: "no_of_rm",
                        dataIndex: "no_of_rm"
                      },
                      {
                        title: "Action",
                        key: "action",
                        width: "3%"
                      }
                    ],
                    "data-source": [
                      {
                        key: "1",
                        bom_id: "BOM-0001",
                        bom_name: "BOM-0001",
                        product_name: "Computer",
                        no_of_rm: "1"
                      }
                    ],
                    pagination: false
                  }, {
                    bodyCell: withCtx(({ column, record }) => [
                      column.key === "bom_id" ? (openBlock(), createBlock("a", {
                        key: 0,
                        onClick: $options.showDetailDrawer
                      }, toDisplayString(record.bom_id), 9, ["onClick"])) : createCommentVNode("", true)
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(_component_a_drawer, {
                visible: $data.create_form_visible,
                "onUpdate:visible": ($event) => $data.create_form_visible = $event,
                class: "sales-bill",
                size: "large",
                style: { "color": "red" },
                width: "75%",
                title: "Add BOM",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                footer: withCtx(() => [
                  createVNode(_component_a_button, {
                    style: { "margin-right": "8px" },
                    onClick: _ctx.onClose
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Cancel")
                    ]),
                    _: 1
                  }, 8, ["onClick"]),
                  createVNode(_component_a_button, {
                    type: "primary",
                    onClick: _ctx.onClose
                  }, {
                    default: withCtx(() => [
                      createTextVNode("SAVE")
                    ]),
                    _: 1
                  }, 8, ["onClick"])
                ]),
                default: withCtx(() => [
                  createVNode(_component_a_form, mergeProps({ model: $data.form }, _ctx.layout, {
                    name: "nest-messages",
                    "validate-messages": _ctx.validateMessages,
                    onFinish: _ctx.submit,
                    "label-col": { span: 24 },
                    style: { "min-height": "100%" }
                  }), {
                    default: withCtx(() => [
                      createVNode(_component_a_row, { gutter: 24 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "document_name",
                                label: "Document Name",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $data.form.document_name,
                                    "onUpdate:value": ($event) => $data.form.document_name = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "document_number",
                                label: "Document Number"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $data.form.document_number,
                                    "onUpdate:value": ($event) => $data.form.document_number = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "24"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "description",
                                label: "Description"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $data.form.description,
                                    "onUpdate:value": ($event) => $data.form.description = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode("h4", { class: "t1" }, "Product"),
                      createVNode(_component_a_row, { gutter: 24 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "product",
                                label: "Select Product",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    value: $data.form.tax,
                                    "onUpdate:value": ($event) => $data.form.tax = $event,
                                    "show-search": "",
                                    placeholder: "Select Product",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    options: [{
                                      label: "Red color T-shirt - Md",
                                      value: "Red color T-shirt - Md"
                                    }, {
                                      label: "Red color T-shirt - Lg",
                                      value: "Red color T-shirt - Lg"
                                    }, {
                                      label: "Red color T-shirt - SM",
                                      value: "Red color T-shirt - SM"
                                    }],
                                    "not-found-content": _ctx.value
                                  }, null, 8, ["value", "onUpdate:value", "not-found-content"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "quantity",
                                label: "Quantity",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $data.form.quantity,
                                    "onUpdate:value": ($event) => $data.form.quantity = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "unit",
                                label: "Unit",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    value: $data.form.tax,
                                    "onUpdate:value": ($event) => $data.form.tax = $event,
                                    "show-search": "",
                                    placeholder: "Select Unit",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    options: [{
                                      label: "KG",
                                      value: "KG"
                                    }, {
                                      label: "Ltr",
                                      value: "Ltr"
                                    }, {
                                      label: "Pcs",
                                      value: "Pcs"
                                    }]
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: "12"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                name: "cost_allocation",
                                label: "Cost Allocation",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $data.form.cost_allocation,
                                    "onUpdate:value": ($event) => $data.form.cost_allocation = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode("h4", { class: "t1" }, "Raw Materials"),
                      createVNode(_component_a_table, {
                        columns: [
                          {
                            title: "Raw Material",
                            dataIndex: "raw_material",
                            key: "raw_material"
                          },
                          {
                            title: "Quantity",
                            dataIndex: "quantity",
                            key: "quantity"
                          },
                          {
                            title: "Unit",
                            dataIndex: "unit",
                            key: "unit"
                          },
                          {
                            title: "Notes",
                            dataIndex: "notes",
                            key: "notes"
                          },
                          {
                            title: "Action",
                            key: "action",
                            width: "3%"
                          }
                        ],
                        "data-source": [{}],
                        pagination: false
                      }, {
                        bodyCell: withCtx(({ column, record }) => [
                          column.key === "raw_material" ? (openBlock(), createBlock(_component_a_select, {
                            key: 0,
                            value: $data.form.tax,
                            "onUpdate:value": ($event) => $data.form.tax = $event,
                            "show-search": "",
                            placeholder: "Select Product",
                            style: { "width": "100%" },
                            "default-active-first-option": false,
                            options: [{
                              label: "Red color T-shirt - Md",
                              value: "Red color T-shirt - Md"
                            }, {
                              label: "Red color T-shirt - Lg",
                              value: "Red color T-shirt - Lg"
                            }, {
                              label: "Red color T-shirt - SM",
                              value: "Red color T-shirt - SM"
                            }],
                            "not-found-content": _ctx.value
                          }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                          column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                            key: 1,
                            value: record.quantity,
                            "onUpdate:value": ($event) => record.quantity = $event
                          }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                          column.key === "unit" ? (openBlock(), createBlock(_component_a_select, {
                            key: 2,
                            value: $data.form.tax,
                            "onUpdate:value": ($event) => $data.form.tax = $event,
                            "show-search": "",
                            placeholder: "Select Unit",
                            style: { "width": "100%" },
                            "default-active-first-option": false,
                            options: [{
                              label: "Kg",
                              value: "Kg"
                            }, {
                              label: "Ltr",
                              value: "Ltr"
                            }]
                          }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                          column.key === "notes" ? (openBlock(), createBlock(_component_a_textarea, {
                            key: 3,
                            value: $data.form.description,
                            "onUpdate:value": ($event) => $data.form.description = $event
                          }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                          column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                            key: 4,
                            onClick: _ctx.handleButtonClick
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_MoreOutlined)
                            ]),
                            overlay: withCtx(() => [
                              createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "1" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_UserOutlined),
                                      createTextVNode(" Remove ")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["onClick"])
                            ]),
                            _: 1
                          }, 8, ["onClick"])) : createCommentVNode("", true)
                        ]),
                        _: 1
                      }),
                      createVNode("br"),
                      createVNode(_component_a_space, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "success",
                            size: "small"
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_plus_circle_outlined)
                            ]),
                            default: withCtx(() => [
                              createTextVNode(" Add RM ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode("br"),
                      createVNode("h4", { class: "t1" }, "Routing"),
                      createVNode(_component_a_table, {
                        columns: [
                          {
                            title: "Routing",
                            dataIndex: "routing",
                            key: "routing"
                          },
                          {
                            title: "Comment",
                            dataIndex: "comment",
                            key: "comment"
                          },
                          {
                            title: "Action",
                            key: "action",
                            width: "3%"
                          }
                        ],
                        "data-source": [{}],
                        pagination: false
                      }, {
                        bodyCell: withCtx(({ column, record }) => [
                          column.key === "routing" ? (openBlock(), createBlock(_component_a_select, {
                            key: 0,
                            value: $data.form.tax,
                            "onUpdate:value": ($event) => $data.form.tax = $event,
                            "show-search": "",
                            placeholder: "Select Routing",
                            style: { "width": "100%" },
                            "default-active-first-option": false,
                            options: [{
                              label: "Routing 1",
                              value: "Routing 1"
                            }, {
                              label: "Routing 2",
                              value: "Routing 2"
                            }, {
                              label: "Routing 3",
                              value: "Routing 3"
                            }],
                            "not-found-content": _ctx.value
                          }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                          column.key === "comment" ? (openBlock(), createBlock(_component_a_textarea, {
                            key: 1,
                            value: $data.form.description,
                            "onUpdate:value": ($event) => $data.form.description = $event
                          }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                          column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                            key: 2,
                            onClick: _ctx.handleButtonClick
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_MoreOutlined)
                            ]),
                            overlay: withCtx(() => [
                              createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "1" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_UserOutlined),
                                      createTextVNode(" Remove ")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["onClick"])
                            ]),
                            _: 1
                          }, 8, ["onClick"])) : createCommentVNode("", true)
                        ]),
                        _: 1
                      }),
                      createVNode("br"),
                      createVNode(_component_a_space, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "success",
                            size: "small"
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_plus_circle_outlined)
                            ]),
                            default: withCtx(() => [
                              createTextVNode(" Add Routing ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode("br"),
                      createVNode("h4", { class: "t1" }, "Other Charges"),
                      createVNode(_component_a_table, {
                        columns: [
                          {
                            title: "Classification",
                            dataIndex: "classification",
                            key: "classification"
                          },
                          {
                            title: "Amount",
                            dataIndex: "amount",
                            key: "amount"
                          },
                          {
                            title: "Comment",
                            dataIndex: "comment",
                            key: "comment"
                          }
                        ],
                        "data-source": [
                          {
                            key: "1",
                            classification: "Classification 1",
                            amount: "0",
                            comment: ""
                          },
                          {
                            key: "1",
                            classification: "Classification 1",
                            amount: "0",
                            comment: ""
                          },
                          {
                            key: "1",
                            classification: "Classification 1",
                            amount: "0",
                            comment: ""
                          },
                          {
                            key: "1",
                            classification: "Classification 1",
                            amount: "0",
                            comment: ""
                          }
                        ],
                        pagination: false
                      }, {
                        bodyCell: withCtx(({ column, record }) => [
                          column.key === "classification" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                            createTextVNode(toDisplayString(record.classification), 1)
                          ], 64)) : createCommentVNode("", true),
                          column.key === "amount" ? (openBlock(), createBlock(_component_a_input, {
                            key: 1,
                            value: record.amount,
                            "onUpdate:value": ($event) => record.amount = $event
                          }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                          column.key === "comment" ? (openBlock(), createBlock(_component_a_input, {
                            key: 2,
                            value: record.comment,
                            "onUpdate:value": ($event) => record.comment = $event
                          }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true)
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 16, ["model", "validate-messages", "onFinish"])
                ]),
                _: 1
              }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"]),
              createVNode(_component_a_drawer, {
                visible: $data.showdetail,
                "onUpdate:visible": ($event) => $data.showdetail = $event,
                class: "custom-class",
                title: "JO-000001",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange,
                width: "60%"
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_tabs, {
                    activeKey: _ctx.activeKey,
                    "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_tab_pane, {
                        key: "JO-1-1",
                        tab: "Progress"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Progress ")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_tab_pane, {
                        key: "JO-1-2",
                        tab: "Raw Materials",
                        "force-render": ""
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_space, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                size: "small"
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Add Raw Material ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("br"),
                          createVNode(_component_a_table, {
                            columns: [
                              {
                                title: "Product",
                                dataIndex: "product",
                                key: "product"
                              },
                              {
                                title: "Quantity/order",
                                dataIndex: "quantity",
                                key: "quantity"
                              },
                              {
                                title: "Stock Levels",
                                dataIndex: "stock_levels",
                                key: "stock_levels"
                              },
                              {
                                title: "Notes",
                                dataIndex: "notes",
                                key: "notes"
                              },
                              {
                                title: "Action",
                                key: "action",
                                width: "3%"
                              }
                            ],
                            "data-source": [
                              {
                                key: "1",
                                product: "Computer",
                                quantity: "1",
                                stock_levels: "0",
                                notes: "0"
                              },
                              {
                                key: "2",
                                product: "Computer",
                                quantity: "1",
                                stock_levels: "0",
                                notes: "0"
                              },
                              {
                                key: "3",
                                product: "Computer",
                                quantity: "1",
                                stock_levels: "0",
                                notes: "0"
                              }
                            ],
                            pagination: false
                          }, {
                            bodyCell: withCtx(({ column, record }) => [
                              column.key === "product" ? (openBlock(), createBlock(_component_a_select, {
                                key: 0,
                                value: $data.form.tax,
                                "onUpdate:value": ($event) => $data.form.tax = $event,
                                "show-search": "",
                                placeholder: "Select Product",
                                style: { "width": "100%" },
                                "default-active-first-option": false,
                                options: [{
                                  label: "Red color T-shirt - Md",
                                  value: "Red color T-shirt - Md"
                                }, {
                                  label: "Red color T-shirt - Lg",
                                  value: "Red color T-shirt - Lg"
                                }, {
                                  label: "Red color T-shirt - SM",
                                  value: "Red color T-shirt - SM"
                                }],
                                "not-found-content": _ctx.value
                              }, null, 8, ["value", "onUpdate:value", "not-found-content"])) : createCommentVNode("", true),
                              column.key === "quantity" ? (openBlock(), createBlock(_component_a_input, {
                                key: 1,
                                value: record.quantity,
                                "onUpdate:value": ($event) => record.quantity = $event
                              }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                              column.key === "stock_levels" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                                createTextVNode(" In stock: 0,00 ")
                              ], 64)) : createCommentVNode("", true),
                              column.key === "notes" ? (openBlock(), createBlock(_component_a_textarea, {
                                key: 3,
                                value: $data.form.description,
                                "onUpdate:value": ($event) => $data.form.description = $event
                              }, null, 8, ["value", "onUpdate:value"])) : createCommentVNode("", true),
                              column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown_button, {
                                key: 4,
                                onClick: _ctx.handleButtonClick
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_MoreOutlined)
                                ]),
                                overlay: withCtx(() => [
                                  createVNode(_component_a_menu, { onClick: _ctx.handleMenuClick }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_menu_item, { key: "1" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_UserOutlined),
                                          createTextVNode(" Create PO ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ]),
                                _: 1
                              }, 8, ["onClick"])) : createCommentVNode("", true)
                            ]),
                            _: 1
                          }),
                          createVNode("h4", null, "Summary of raw materials"),
                          createVNode(_component_a_table, {
                            columns: [
                              {
                                title: "Product",
                                dataIndex: "product",
                                key: "product"
                              },
                              {
                                title: "Quantity/order",
                                dataIndex: "quantity",
                                key: "quantity"
                              },
                              {
                                title: "Quantity used",
                                dataIndex: "quantity_used",
                                key: "quantity_used"
                              }
                            ],
                            "data-source": [
                              {
                                key: "1",
                                product: "Computer",
                                quantity: "1",
                                quantity_used: "0"
                              },
                              {
                                key: "2",
                                product: "Computer",
                                quantity: "1",
                                quantity_used: "0"
                              },
                              {
                                key: "3",
                                product: "Computer",
                                quantity: "1",
                                quantity_used: "0"
                              }
                            ],
                            pagination: false
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_tab_pane, {
                        key: "JO-1-3",
                        tab: "Manufacturing tasks",
                        "force-render": ""
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_table, {
                            columns: [
                              {
                                title: "Machine/Operation",
                                dataIndex: "operation",
                                key: "operation"
                              },
                              {
                                title: "Planned Start",
                                dataIndex: "planned_start",
                                key: "planned_start"
                              },
                              {
                                title: "Due Date",
                                dataIndex: "due_date",
                                key: "due_date"
                              },
                              {
                                title: "Due Date",
                                dataIndex: "due_date",
                                key: "due_date"
                              }
                            ],
                            "data-source": [],
                            pagination: false
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_tab_pane, {
                        key: "JO-1-4",
                        tab: "Operation Tasks"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_space, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                size: "small"
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Add Operation Task ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("br"),
                          createVNode(_component_a_table, {
                            columns: [
                              {
                                title: "Machine/Operation",
                                dataIndex: "operation",
                                key: "operation"
                              }
                            ],
                            "data-source": [],
                            pagination: false
                          }),
                          createVNode(_component_a_table, {
                            columns: [
                              {
                                title: "Date",
                                dataIndex: "date",
                                key: "date"
                              },
                              {
                                title: "Operation",
                                dataIndex: "operation",
                                key: "operation"
                              },
                              {
                                title: "User",
                                dataIndex: "user",
                                key: "user"
                              },
                              {
                                title: "Notes",
                                dataIndex: "notes",
                                key: "notes"
                              }
                            ],
                            "data-source": [],
                            pagination: false
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_tab_pane, {
                        key: "JO-1-5",
                        tab: "Inventory Release"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Inventory Release")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["activeKey", "onUpdate:activeKey"])
                ]),
                _: 1
              }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"])
            ]),
            _: 1
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Billofmaterial/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Index as default
};
