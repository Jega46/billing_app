import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import "vue-request";
import { resolveComponent, withCtx, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, createVNode, createCommentVNode, useSSRContext } from "vue";
import { Head, Link, useForm, router } from "@inertiajs/vue3";
import "dayjs";
import { DownloadOutlined, PlusCircleOutlined, MoreOutlined, DeleteOutlined } from "@ant-design/icons-vue";
import axios from "axios";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
const columns = [
  {
    title: "Name",
    key: "name",
    dataIndex: "name",
    sorter: true,
    width: "20%"
  },
  {
    title: "Check In",
    key: "checkin",
    width: "10%"
  },
  {
    title: "Checkout",
    key: "checkout",
    width: "10%"
  },
  {
    title: "Overtime",
    key: "overtime",
    width: "10%"
  },
  {
    title: "Late",
    key: "late",
    width: "10%"
  },
  {
    title: "Notes",
    key: "notes",
    width: "30%"
  },
  {
    title: "Status",
    key: "status",
    width: "20%"
  }
];
const innerColumns = [
  { title: "Date", dataIndex: "date", key: "date" },
  { title: "Name", dataIndex: "name", key: "name" },
  { title: "Status", key: "state" },
  { title: "Upgrade Status", dataIndex: "upgradeNum", key: "upgradeNum" },
  {
    title: "Action",
    dataIndex: "operation",
    key: "operation"
  }
];
const _sfc_main = {
  components: { AuthenticatedLayout: _sfc_main$1, DownloadOutlined, PlusCircleOutlined, MoreOutlined, DeleteOutlined, Head, Link },
  props: {
    date: String,
    employees: Object,
    branches: Object,
    pagination: Object,
    errors: Object
  },
  setup(props) {
    return {
      columns
    };
  },
  data(props) {
    const loading = false;
    const delayTime = 1500;
    const formState = useForm({
      term: "",
      date: props.date,
      branch: null
    });
    const innerDataItem = [];
    for (let i = 0; i < 3; ++i) {
      innerDataItem.push({
        key: i,
        date: "2014-12-24 23:12:00",
        name: `This is production name ${i + 1}`,
        upgradeNum: "Upgraded: 56"
      });
    }
    return {
      page: 1,
      pageSize: 50,
      loading,
      delayTime,
      formState,
      innerColumns,
      innerDataItem
    };
  },
  methods: {
    search() {
      this.$inertia.get("/attendance", { s: this.formState.term, date: this.formState.date, branch: this.formState.branch, pageSize: this.pageSize }, { preserveState: true });
    },
    handleTableChange(val) {
      this.page = val.current;
      this.pageSize = val.pageSize;
      console.log(val);
      this.$inertia.get(
        "/attendance",
        { s: this.formState.term, date: this.formState.date, branch: this.formState.branch, page: val.current, pageSize: val.pageSize },
        { preserveState: true }
      );
    },
    updateAttendance(record) {
      this.loading = true;
      axios.post(route("attendance.updateattendance"), { ...record, ...{ date: this.formState.date } }).then((response) => {
        console.log(response);
        this.$inertia.get("/attendance", { s: this.formState.term, date: this.formState.date, branch: this.formState.branch, page: this.page, pageSize: this.pageSize }, { preserveState: true });
      }).finally(() => {
        this.loading = false;
      });
    },
    updateAttendanceStatus(record) {
      this.loading = true;
      axios.post(route("attendance.updateatt_statusnotes"), { ...record, ...{ date: this.formState.date } }).then((response) => {
        console.log(response);
        this.$inertia.get("/attendance", { s: this.formState.term, date: this.formState.date, branch: this.formState.branch, page: this.page, pageSize: this.pageSize }, { preserveState: true });
      }).finally(() => {
        this.loading = false;
      });
    },
    updateOvertime(record) {
      router.post(route("attendance.update_overtime"), { ...record, ...{ date: this.formState.date } }, {
        preserveState: true,
        onStart: (visit) => {
          this.loading = true;
        },
        onSuccess: (page) => {
        },
        onError: (errors) => {
        },
        onFinish: (visit) => {
          this.loading = false;
        }
      });
    },
    updateLate(record) {
      router.post(route("attendance.update_late"), { ...record, ...{ date: this.formState.date } }, {
        preserveState: true,
        onStart: (visit) => {
          this.loading = true;
        },
        onSuccess: (page) => {
        },
        onError: (errors) => {
        },
        onFinish: (visit) => {
          this.loading = false;
        }
      });
    },
    deleteHistory(id) {
      router.post(route("attendance.remove_attendance_history", id), {}, {
        onStart: (visit) => {
          this.loading = true;
        },
        onSuccess: (page) => {
        },
        onError: (errors) => {
          alert("dsfsd");
        },
        onFinish: (visit) => {
          this.loading = false;
        }
      });
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_spin = resolveComponent("a-spin");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_space = resolveComponent("a-space");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_select_option = resolveComponent("a-select-option");
  const _component_a_date_picker = resolveComponent("a-date-picker");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_button = resolveComponent("a-button");
  const _component_a_table = resolveComponent("a-table");
  const _component_a_avatar = resolveComponent("a-avatar");
  const _component_a_time_picker = resolveComponent("a-time-picker");
  const _component_delete_outlined = resolveComponent("delete-outlined");
  const _component_a_badge = resolveComponent("a-badge");
  const _component_a_dropdown = resolveComponent("a-dropdown");
  const _component_a_menu = resolveComponent("a-menu");
  const _component_a_menu_item = resolveComponent("a-menu-item");
  const _component_down_outlined = resolveComponent("down-outlined");
  const _component_a_input_group = resolveComponent("a-input-group");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Employees" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_spin, {
          spinning: $data.loading,
          delay: $data.delayTime
        }, null, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_layout_content, { style: { margin: "24px 16px", padding: "24px", background: "#fff", minHeight: "calc(100vh - 115px)", textAlign: "center" } }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, {
                      name: "nest-messages",
                      model: $data.formState,
                      layout: "inline",
                      onFinish: $options.search
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_select, {
                                  value: $data.formState.branch,
                                  "onUpdate:value": ($event) => $data.formState.branch = $event,
                                  placeholder: "Select Branch",
                                  style: { "min-width": "200px" }
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<!--[-->`);
                                      ssrRenderList($props.branches, (branch) => {
                                        _push7(ssrRenderComponent(_component_a_select_option, {
                                          value: branch.id
                                        }, {
                                          default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(`${ssrInterpolate(branch.branch_name)}`);
                                            } else {
                                              return [
                                                createTextVNode(toDisplayString(branch.branch_name), 1)
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                      });
                                      _push7(`<!--]-->`);
                                    } else {
                                      return [
                                        (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                          return openBlock(), createBlock(_component_a_select_option, {
                                            value: branch.id
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(branch.branch_name), 1)
                                            ]),
                                            _: 2
                                          }, 1032, ["value"]);
                                        }), 256))
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_select, {
                                    value: $data.formState.branch,
                                    "onUpdate:value": ($event) => $data.formState.branch = $event,
                                    placeholder: "Select Branch",
                                    style: { "min-width": "200px" }
                                  }, {
                                    default: withCtx(() => [
                                      (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                        return openBlock(), createBlock(_component_a_select_option, {
                                          value: branch.id
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(branch.branch_name), 1)
                                          ]),
                                          _: 2
                                        }, 1032, ["value"]);
                                      }), 256))
                                    ]),
                                    _: 1
                                  }, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_date_picker, {
                                  value: $data.formState.date,
                                  "onUpdate:value": ($event) => $data.formState.date = $event,
                                  format: "DD-MM-YYYY",
                                  "value-format": "YYYY-MM-DD"
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_date_picker, {
                                    value: $data.formState.date,
                                    "onUpdate:value": ($event) => $data.formState.date = $event,
                                    format: "DD-MM-YYYY",
                                    "value-format": "YYYY-MM-DD"
                                  }, null, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input, {
                                  placeholder: "Search Employees",
                                  value: $data.formState.term,
                                  "onUpdate:value": ($event) => $data.formState.term = $event
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input, {
                                    placeholder: "Search Employees",
                                    value: $data.formState.term,
                                    "onUpdate:value": ($event) => $data.formState.term = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Search `);
                                    } else {
                                      return [
                                        createTextVNode(" Search ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Search ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_select, {
                                  value: $data.formState.branch,
                                  "onUpdate:value": ($event) => $data.formState.branch = $event,
                                  placeholder: "Select Branch",
                                  style: { "min-width": "200px" }
                                }, {
                                  default: withCtx(() => [
                                    (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                      return openBlock(), createBlock(_component_a_select_option, {
                                        value: branch.id
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(branch.branch_name), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["value"]);
                                    }), 256))
                                  ]),
                                  _: 1
                                }, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_date_picker, {
                                  value: $data.formState.date,
                                  "onUpdate:value": ($event) => $data.formState.date = $event,
                                  format: "DD-MM-YYYY",
                                  "value-format": "YYYY-MM-DD"
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  placeholder: "Search Employees",
                                  value: $data.formState.term,
                                  "onUpdate:value": ($event) => $data.formState.term = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Search ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_table, {
                      columns: $setup.columns,
                      "row-key": (employee) => employee.employee_id,
                      "data-source": $props.employees,
                      pagination: $props.pagination,
                      loading: $data.loading,
                      onChange: $options.handleTableChange
                    }, {
                      bodyCell: withCtx(({ column, text, record }, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          if (column.key === "name") {
                            _push5(`<!--[-->`);
                            _push5(ssrRenderComponent(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(`${ssrInterpolate(text[0].toUpperCase())}`);
                                } else {
                                  return [
                                    createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                            _push5(`   ${ssrInterpolate(text)}<!--]-->`);
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "checkin") {
                            _push5(`<!--[-->`);
                            _push5(ssrRenderComponent(_component_a_space, { direction: "vertical" }, {
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(`<!--[-->`);
                                  ssrRenderList(record.history, (history) => {
                                    _push6(ssrRenderComponent(_component_a_time_picker, {
                                      allowClear: false,
                                      format: "hh:mm A",
                                      placeholder: "Check In",
                                      "value-format": "HH:mm:ss",
                                      value: history.checkin,
                                      "onUpdate:value": ($event) => history.checkin = $event,
                                      onChange: ($event) => $options.updateAttendance(record)
                                    }, null, _parent6, _scopeId5));
                                  });
                                  _push6(`<!--]-->`);
                                } else {
                                  return [
                                    (openBlock(true), createBlock(Fragment, null, renderList(record.history, (history) => {
                                      return openBlock(), createBlock(_component_a_time_picker, {
                                        allowClear: false,
                                        format: "hh:mm A",
                                        placeholder: "Check In",
                                        "value-format": "HH:mm:ss",
                                        value: history.checkin,
                                        "onUpdate:value": ($event) => history.checkin = $event,
                                        onChange: ($event) => $options.updateAttendance(record)
                                      }, null, 8, ["value", "onUpdate:value", "onChange"]);
                                    }), 256))
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                            _push5(`<!--[-->`);
                            ssrRenderList(record.history, (history) => {
                              _push5(ssrRenderComponent(_component_a_input, {
                                value: history.id,
                                "onUpdate:value": ($event) => history.id = $event,
                                hidden: true
                              }, null, _parent5, _scopeId4));
                            });
                            _push5(`<!--]--><!--]-->`);
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "checkout") {
                            _push5(ssrRenderComponent(_component_a_space, { direction: "vertical" }, {
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(`<!--[-->`);
                                  ssrRenderList(record.history, (history) => {
                                    _push6(`<div${_scopeId5}>`);
                                    _push6(ssrRenderComponent(_component_a_space, { direction: "horizontal" }, {
                                      default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(_component_a_time_picker, {
                                            allowClear: false,
                                            format: "hh:mm A",
                                            placeholder: "Check Out",
                                            "value-format": "HH:mm:ss",
                                            value: history.checkout,
                                            "onUpdate:value": ($event) => history.checkout = $event,
                                            onChange: ($event) => $options.updateAttendance(record)
                                          }, null, _parent7, _scopeId6));
                                          if (history.checkout != "") {
                                            _push7(`<a${_scopeId6}>`);
                                            _push7(ssrRenderComponent(_component_delete_outlined, null, null, _parent7, _scopeId6));
                                            _push7(`</a>`);
                                          } else {
                                            _push7(`<!---->`);
                                          }
                                        } else {
                                          return [
                                            createVNode(_component_a_time_picker, {
                                              allowClear: false,
                                              format: "hh:mm A",
                                              placeholder: "Check Out",
                                              "value-format": "HH:mm:ss",
                                              value: history.checkout,
                                              "onUpdate:value": ($event) => history.checkout = $event,
                                              onChange: ($event) => $options.updateAttendance(record)
                                            }, null, 8, ["value", "onUpdate:value", "onChange"]),
                                            history.checkout != "" ? (openBlock(), createBlock("a", {
                                              key: 0,
                                              onClick: ($event) => $options.deleteHistory(history.id)
                                            }, [
                                              createVNode(_component_delete_outlined)
                                            ], 8, ["onClick"])) : createCommentVNode("", true)
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                    _push6(`</div>`);
                                  });
                                  _push6(`<!--]-->`);
                                } else {
                                  return [
                                    (openBlock(true), createBlock(Fragment, null, renderList(record.history, (history) => {
                                      return openBlock(), createBlock("div", null, [
                                        createVNode(_component_a_space, { direction: "horizontal" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_time_picker, {
                                              allowClear: false,
                                              format: "hh:mm A",
                                              placeholder: "Check Out",
                                              "value-format": "HH:mm:ss",
                                              value: history.checkout,
                                              "onUpdate:value": ($event) => history.checkout = $event,
                                              onChange: ($event) => $options.updateAttendance(record)
                                            }, null, 8, ["value", "onUpdate:value", "onChange"]),
                                            history.checkout != "" ? (openBlock(), createBlock("a", {
                                              key: 0,
                                              onClick: ($event) => $options.deleteHistory(history.id)
                                            }, [
                                              createVNode(_component_delete_outlined)
                                            ], 8, ["onClick"])) : createCommentVNode("", true)
                                          ]),
                                          _: 2
                                        }, 1024)
                                      ]);
                                    }), 256))
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "overtime") {
                            _push5(ssrRenderComponent(_component_a_space, { direction: "vertical" }, {
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(ssrRenderComponent(_component_a_time_picker, {
                                    allowClear: false,
                                    disabled: true,
                                    format: "HH:mm",
                                    placeholder: "Over Time",
                                    "value-format": "HH:mm",
                                    value: record.overtime,
                                    "onUpdate:value": ($event) => record.overtime = $event,
                                    onChange: ($event) => $options.updateOvertime(record)
                                  }, null, _parent6, _scopeId5));
                                } else {
                                  return [
                                    createVNode(_component_a_time_picker, {
                                      allowClear: false,
                                      disabled: true,
                                      format: "HH:mm",
                                      placeholder: "Over Time",
                                      "value-format": "HH:mm",
                                      value: record.overtime,
                                      "onUpdate:value": ($event) => record.overtime = $event,
                                      onChange: ($event) => $options.updateOvertime(record)
                                    }, null, 8, ["value", "onUpdate:value", "onChange"])
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "late") {
                            _push5(ssrRenderComponent(_component_a_table, {
                              columns: $data.innerColumns,
                              "data-source": _ctx.innerData,
                              pagination: false
                            }, {
                              bodyCell: withCtx(({ column: column2 }, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  if (column2.key === "state") {
                                    _push6(`<span${_scopeId5}>`);
                                    _push6(ssrRenderComponent(_component_a_badge, { status: "success" }, null, _parent6, _scopeId5));
                                    _push6(` Finished </span>`);
                                  } else if (column2.key === "operation") {
                                    _push6(`<span class="table-operation"${_scopeId5}><a${_scopeId5}>Pause</a><a${_scopeId5}>Stop</a>`);
                                    _push6(ssrRenderComponent(_component_a_dropdown, null, {
                                      overlay: withCtx((_4, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(_component_a_menu, null, {
                                            default: withCtx((_5, _push8, _parent8, _scopeId7) => {
                                              if (_push8) {
                                                _push8(ssrRenderComponent(_component_a_menu_item, null, {
                                                  default: withCtx((_6, _push9, _parent9, _scopeId8) => {
                                                    if (_push9) {
                                                      _push9(`Action 1`);
                                                    } else {
                                                      return [
                                                        createTextVNode("Action 1")
                                                      ];
                                                    }
                                                  }),
                                                  _: 2
                                                }, _parent8, _scopeId7));
                                                _push8(ssrRenderComponent(_component_a_menu_item, null, {
                                                  default: withCtx((_6, _push9, _parent9, _scopeId8) => {
                                                    if (_push9) {
                                                      _push9(`Action 2`);
                                                    } else {
                                                      return [
                                                        createTextVNode("Action 2")
                                                      ];
                                                    }
                                                  }),
                                                  _: 2
                                                }, _parent8, _scopeId7));
                                              } else {
                                                return [
                                                  createVNode(_component_a_menu_item, null, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Action 1")
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(_component_a_menu_item, null, {
                                                    default: withCtx(() => [
                                                      createTextVNode("Action 2")
                                                    ]),
                                                    _: 1
                                                  })
                                                ];
                                              }
                                            }),
                                            _: 2
                                          }, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode(_component_a_menu, null, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_menu_item, null, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Action 1")
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(_component_a_menu_item, null, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Action 2")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ];
                                        }
                                      }),
                                      default: withCtx((_4, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`<a${_scopeId6}> More `);
                                          _push7(ssrRenderComponent(_component_down_outlined, null, null, _parent7, _scopeId6));
                                          _push7(`</a>`);
                                        } else {
                                          return [
                                            createVNode("a", null, [
                                              createTextVNode(" More "),
                                              createVNode(_component_down_outlined)
                                            ])
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                    _push6(`</span>`);
                                  } else {
                                    _push6(`<!---->`);
                                  }
                                } else {
                                  return [
                                    column2.key === "state" ? (openBlock(), createBlock("span", { key: 0 }, [
                                      createVNode(_component_a_badge, { status: "success" }),
                                      createTextVNode(" Finished ")
                                    ])) : column2.key === "operation" ? (openBlock(), createBlock("span", {
                                      key: 1,
                                      class: "table-operation"
                                    }, [
                                      createVNode("a", null, "Pause"),
                                      createVNode("a", null, "Stop"),
                                      createVNode(_component_a_dropdown, null, {
                                        overlay: withCtx(() => [
                                          createVNode(_component_a_menu, null, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_menu_item, null, {
                                                default: withCtx(() => [
                                                  createTextVNode("Action 1")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_menu_item, null, {
                                                default: withCtx(() => [
                                                  createTextVNode("Action 2")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        default: withCtx(() => [
                                          createVNode("a", null, [
                                            createTextVNode(" More "),
                                            createVNode(_component_down_outlined)
                                          ])
                                        ]),
                                        _: 1
                                      })
                                    ])) : createCommentVNode("", true)
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "notes") {
                            _push5(ssrRenderComponent(_component_a_input_group, { compact: "" }, {
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(ssrRenderComponent(_component_a_input, {
                                    value: record.notes,
                                    "onUpdate:value": ($event) => record.notes = $event,
                                    style: { "width": "calc(100% - 200px)" }
                                  }, null, _parent6, _scopeId5));
                                  _push6(ssrRenderComponent(_component_a_button, {
                                    type: "primary",
                                    onClick: ($event) => $options.updateAttendanceStatus(record)
                                  }, {
                                    default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(`Save`);
                                      } else {
                                        return [
                                          createTextVNode("Save")
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  return [
                                    createVNode(_component_a_input, {
                                      value: record.notes,
                                      "onUpdate:value": ($event) => record.notes = $event,
                                      style: { "width": "calc(100% - 200px)" }
                                    }, null, 8, ["value", "onUpdate:value"]),
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      onClick: ($event) => $options.updateAttendanceStatus(record)
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Save")
                                      ]),
                                      _: 2
                                    }, 1032, ["onClick"])
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "status") {
                            _push5(ssrRenderComponent(_component_a_select, {
                              value: record.status,
                              "onUpdate:value": ($event) => record.status = $event,
                              onChange: ($event) => $options.updateAttendanceStatus(record)
                            }, {
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(ssrRenderComponent(_component_a_select_option, { value: "Present" }, {
                                    default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(`Present`);
                                      } else {
                                        return [
                                          createTextVNode("Present")
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                  _push6(ssrRenderComponent(_component_a_select_option, { value: "Absent" }, {
                                    default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(`Absent`);
                                      } else {
                                        return [
                                          createTextVNode("Absent")
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                  _push6(ssrRenderComponent(_component_a_select_option, { value: "Paid Leave" }, {
                                    default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(`Paid Leave`);
                                      } else {
                                        return [
                                          createTextVNode("Paid Leave")
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                  _push6(ssrRenderComponent(_component_a_select_option, { value: "Unpaid Leave" }, {
                                    default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(`Unpaid Leave`);
                                      } else {
                                        return [
                                          createTextVNode("Unpaid Leave")
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                  _push6(ssrRenderComponent(_component_a_select_option, { value: "Week Off" }, {
                                    default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(`Week Off`);
                                      } else {
                                        return [
                                          createTextVNode("Week Off")
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  return [
                                    createVNode(_component_a_select_option, { value: "Present" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Present")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Absent" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Absent")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Paid Leave" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Paid Leave")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Unpaid Leave" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Unpaid Leave")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Week Off" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Week Off")
                                      ]),
                                      _: 1
                                    })
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                          } else {
                            _push5(`<!---->`);
                          }
                        } else {
                          return [
                            column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                              createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                                ]),
                                _: 2
                              }, 1024),
                              createTextVNode("   " + toDisplayString(text), 1)
                            ], 64)) : createCommentVNode("", true),
                            column.key === "checkin" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                              createVNode(_component_a_space, { direction: "vertical" }, {
                                default: withCtx(() => [
                                  (openBlock(true), createBlock(Fragment, null, renderList(record.history, (history) => {
                                    return openBlock(), createBlock(_component_a_time_picker, {
                                      allowClear: false,
                                      format: "hh:mm A",
                                      placeholder: "Check In",
                                      "value-format": "HH:mm:ss",
                                      value: history.checkin,
                                      "onUpdate:value": ($event) => history.checkin = $event,
                                      onChange: ($event) => $options.updateAttendance(record)
                                    }, null, 8, ["value", "onUpdate:value", "onChange"]);
                                  }), 256))
                                ]),
                                _: 2
                              }, 1024),
                              (openBlock(true), createBlock(Fragment, null, renderList(record.history, (history) => {
                                return openBlock(), createBlock(_component_a_input, {
                                  value: history.id,
                                  "onUpdate:value": ($event) => history.id = $event,
                                  hidden: true
                                }, null, 8, ["value", "onUpdate:value"]);
                              }), 256))
                            ], 64)) : createCommentVNode("", true),
                            column.key === "checkout" ? (openBlock(), createBlock(_component_a_space, {
                              key: 2,
                              direction: "vertical"
                            }, {
                              default: withCtx(() => [
                                (openBlock(true), createBlock(Fragment, null, renderList(record.history, (history) => {
                                  return openBlock(), createBlock("div", null, [
                                    createVNode(_component_a_space, { direction: "horizontal" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_time_picker, {
                                          allowClear: false,
                                          format: "hh:mm A",
                                          placeholder: "Check Out",
                                          "value-format": "HH:mm:ss",
                                          value: history.checkout,
                                          "onUpdate:value": ($event) => history.checkout = $event,
                                          onChange: ($event) => $options.updateAttendance(record)
                                        }, null, 8, ["value", "onUpdate:value", "onChange"]),
                                        history.checkout != "" ? (openBlock(), createBlock("a", {
                                          key: 0,
                                          onClick: ($event) => $options.deleteHistory(history.id)
                                        }, [
                                          createVNode(_component_delete_outlined)
                                        ], 8, ["onClick"])) : createCommentVNode("", true)
                                      ]),
                                      _: 2
                                    }, 1024)
                                  ]);
                                }), 256))
                              ]),
                              _: 2
                            }, 1024)) : createCommentVNode("", true),
                            column.key === "overtime" ? (openBlock(), createBlock(_component_a_space, {
                              key: 3,
                              direction: "vertical"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_time_picker, {
                                  allowClear: false,
                                  disabled: true,
                                  format: "HH:mm",
                                  placeholder: "Over Time",
                                  "value-format": "HH:mm",
                                  value: record.overtime,
                                  "onUpdate:value": ($event) => record.overtime = $event,
                                  onChange: ($event) => $options.updateOvertime(record)
                                }, null, 8, ["value", "onUpdate:value", "onChange"])
                              ]),
                              _: 2
                            }, 1024)) : createCommentVNode("", true),
                            column.key === "late" ? (openBlock(), createBlock(_component_a_table, {
                              key: 4,
                              columns: $data.innerColumns,
                              "data-source": _ctx.innerData,
                              pagination: false
                            }, {
                              bodyCell: withCtx(({ column: column2 }) => [
                                column2.key === "state" ? (openBlock(), createBlock("span", { key: 0 }, [
                                  createVNode(_component_a_badge, { status: "success" }),
                                  createTextVNode(" Finished ")
                                ])) : column2.key === "operation" ? (openBlock(), createBlock("span", {
                                  key: 1,
                                  class: "table-operation"
                                }, [
                                  createVNode("a", null, "Pause"),
                                  createVNode("a", null, "Stop"),
                                  createVNode(_component_a_dropdown, null, {
                                    overlay: withCtx(() => [
                                      createVNode(_component_a_menu, null, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_menu_item, null, {
                                            default: withCtx(() => [
                                              createTextVNode("Action 1")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_menu_item, null, {
                                            default: withCtx(() => [
                                              createTextVNode("Action 2")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    default: withCtx(() => [
                                      createVNode("a", null, [
                                        createTextVNode(" More "),
                                        createVNode(_component_down_outlined)
                                      ])
                                    ]),
                                    _: 1
                                  })
                                ])) : createCommentVNode("", true)
                              ]),
                              _: 2
                            }, 1032, ["columns", "data-source"])) : createCommentVNode("", true),
                            column.key === "notes" ? (openBlock(), createBlock(_component_a_input_group, {
                              key: 5,
                              compact: ""
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: record.notes,
                                  "onUpdate:value": ($event) => record.notes = $event,
                                  style: { "width": "calc(100% - 200px)" }
                                }, null, 8, ["value", "onUpdate:value"]),
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  onClick: ($event) => $options.updateAttendanceStatus(record)
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Save")
                                  ]),
                                  _: 2
                                }, 1032, ["onClick"])
                              ]),
                              _: 2
                            }, 1024)) : createCommentVNode("", true),
                            column.key === "status" ? (openBlock(), createBlock(_component_a_select, {
                              key: 6,
                              value: record.status,
                              "onUpdate:value": ($event) => record.status = $event,
                              onChange: ($event) => $options.updateAttendanceStatus(record)
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_select_option, { value: "Present" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Present")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_select_option, { value: "Absent" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Absent")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_select_option, { value: "Paid Leave" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Paid Leave")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_select_option, { value: "Unpaid Leave" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Unpaid Leave")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_select_option, { value: "Week Off" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Week Off")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 2
                            }, 1032, ["value", "onUpdate:value", "onChange"])) : createCommentVNode("", true)
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, {
                        name: "nest-messages",
                        model: $data.formState,
                        layout: "inline",
                        onFinish: $options.search
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_select, {
                                value: $data.formState.branch,
                                "onUpdate:value": ($event) => $data.formState.branch = $event,
                                placeholder: "Select Branch",
                                style: { "min-width": "200px" }
                              }, {
                                default: withCtx(() => [
                                  (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                    return openBlock(), createBlock(_component_a_select_option, {
                                      value: branch.id
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(branch.branch_name), 1)
                                      ]),
                                      _: 2
                                    }, 1032, ["value"]);
                                  }), 256))
                                ]),
                                _: 1
                              }, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_date_picker, {
                                value: $data.formState.date,
                                "onUpdate:value": ($event) => $data.formState.date = $event,
                                format: "DD-MM-YYYY",
                                "value-format": "YYYY-MM-DD"
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                placeholder: "Search Employees",
                                value: $data.formState.term,
                                "onUpdate:value": ($event) => $data.formState.term = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Search ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["model", "onFinish"]),
                      createVNode(_component_a_table, {
                        columns: $setup.columns,
                        "row-key": (employee) => employee.employee_id,
                        "data-source": $props.employees,
                        pagination: $props.pagination,
                        loading: $data.loading,
                        onChange: $options.handleTableChange
                      }, {
                        bodyCell: withCtx(({ column, text, record }) => [
                          column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                            createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                              ]),
                              _: 2
                            }, 1024),
                            createTextVNode("   " + toDisplayString(text), 1)
                          ], 64)) : createCommentVNode("", true),
                          column.key === "checkin" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                            createVNode(_component_a_space, { direction: "vertical" }, {
                              default: withCtx(() => [
                                (openBlock(true), createBlock(Fragment, null, renderList(record.history, (history) => {
                                  return openBlock(), createBlock(_component_a_time_picker, {
                                    allowClear: false,
                                    format: "hh:mm A",
                                    placeholder: "Check In",
                                    "value-format": "HH:mm:ss",
                                    value: history.checkin,
                                    "onUpdate:value": ($event) => history.checkin = $event,
                                    onChange: ($event) => $options.updateAttendance(record)
                                  }, null, 8, ["value", "onUpdate:value", "onChange"]);
                                }), 256))
                              ]),
                              _: 2
                            }, 1024),
                            (openBlock(true), createBlock(Fragment, null, renderList(record.history, (history) => {
                              return openBlock(), createBlock(_component_a_input, {
                                value: history.id,
                                "onUpdate:value": ($event) => history.id = $event,
                                hidden: true
                              }, null, 8, ["value", "onUpdate:value"]);
                            }), 256))
                          ], 64)) : createCommentVNode("", true),
                          column.key === "checkout" ? (openBlock(), createBlock(_component_a_space, {
                            key: 2,
                            direction: "vertical"
                          }, {
                            default: withCtx(() => [
                              (openBlock(true), createBlock(Fragment, null, renderList(record.history, (history) => {
                                return openBlock(), createBlock("div", null, [
                                  createVNode(_component_a_space, { direction: "horizontal" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_time_picker, {
                                        allowClear: false,
                                        format: "hh:mm A",
                                        placeholder: "Check Out",
                                        "value-format": "HH:mm:ss",
                                        value: history.checkout,
                                        "onUpdate:value": ($event) => history.checkout = $event,
                                        onChange: ($event) => $options.updateAttendance(record)
                                      }, null, 8, ["value", "onUpdate:value", "onChange"]),
                                      history.checkout != "" ? (openBlock(), createBlock("a", {
                                        key: 0,
                                        onClick: ($event) => $options.deleteHistory(history.id)
                                      }, [
                                        createVNode(_component_delete_outlined)
                                      ], 8, ["onClick"])) : createCommentVNode("", true)
                                    ]),
                                    _: 2
                                  }, 1024)
                                ]);
                              }), 256))
                            ]),
                            _: 2
                          }, 1024)) : createCommentVNode("", true),
                          column.key === "overtime" ? (openBlock(), createBlock(_component_a_space, {
                            key: 3,
                            direction: "vertical"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_time_picker, {
                                allowClear: false,
                                disabled: true,
                                format: "HH:mm",
                                placeholder: "Over Time",
                                "value-format": "HH:mm",
                                value: record.overtime,
                                "onUpdate:value": ($event) => record.overtime = $event,
                                onChange: ($event) => $options.updateOvertime(record)
                              }, null, 8, ["value", "onUpdate:value", "onChange"])
                            ]),
                            _: 2
                          }, 1024)) : createCommentVNode("", true),
                          column.key === "late" ? (openBlock(), createBlock(_component_a_table, {
                            key: 4,
                            columns: $data.innerColumns,
                            "data-source": _ctx.innerData,
                            pagination: false
                          }, {
                            bodyCell: withCtx(({ column: column2 }) => [
                              column2.key === "state" ? (openBlock(), createBlock("span", { key: 0 }, [
                                createVNode(_component_a_badge, { status: "success" }),
                                createTextVNode(" Finished ")
                              ])) : column2.key === "operation" ? (openBlock(), createBlock("span", {
                                key: 1,
                                class: "table-operation"
                              }, [
                                createVNode("a", null, "Pause"),
                                createVNode("a", null, "Stop"),
                                createVNode(_component_a_dropdown, null, {
                                  overlay: withCtx(() => [
                                    createVNode(_component_a_menu, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_menu_item, null, {
                                          default: withCtx(() => [
                                            createTextVNode("Action 1")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_menu_item, null, {
                                          default: withCtx(() => [
                                            createTextVNode("Action 2")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  default: withCtx(() => [
                                    createVNode("a", null, [
                                      createTextVNode(" More "),
                                      createVNode(_component_down_outlined)
                                    ])
                                  ]),
                                  _: 1
                                })
                              ])) : createCommentVNode("", true)
                            ]),
                            _: 2
                          }, 1032, ["columns", "data-source"])) : createCommentVNode("", true),
                          column.key === "notes" ? (openBlock(), createBlock(_component_a_input_group, {
                            key: 5,
                            compact: ""
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: record.notes,
                                "onUpdate:value": ($event) => record.notes = $event,
                                style: { "width": "calc(100% - 200px)" }
                              }, null, 8, ["value", "onUpdate:value"]),
                              createVNode(_component_a_button, {
                                type: "primary",
                                onClick: ($event) => $options.updateAttendanceStatus(record)
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Save")
                                ]),
                                _: 2
                              }, 1032, ["onClick"])
                            ]),
                            _: 2
                          }, 1024)) : createCommentVNode("", true),
                          column.key === "status" ? (openBlock(), createBlock(_component_a_select, {
                            key: 6,
                            value: record.status,
                            "onUpdate:value": ($event) => record.status = $event,
                            onChange: ($event) => $options.updateAttendanceStatus(record)
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_select_option, { value: "Present" }, {
                                default: withCtx(() => [
                                  createTextVNode("Present")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_select_option, { value: "Absent" }, {
                                default: withCtx(() => [
                                  createTextVNode("Absent")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_select_option, { value: "Paid Leave" }, {
                                default: withCtx(() => [
                                  createTextVNode("Paid Leave")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_select_option, { value: "Unpaid Leave" }, {
                                default: withCtx(() => [
                                  createTextVNode("Unpaid Leave")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_select_option, { value: "Week Off" }, {
                                default: withCtx(() => [
                                  createTextVNode("Week Off")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 2
                          }, 1032, ["value", "onUpdate:value", "onChange"])) : createCommentVNode("", true)
                        ]),
                        _: 1
                      }, 8, ["columns", "row-key", "data-source", "pagination", "loading", "onChange"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_space, {
                  direction: "vertical",
                  style: { width: "100%" }
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, {
                      name: "nest-messages",
                      model: $data.formState,
                      layout: "inline",
                      onFinish: $options.search
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_select, {
                              value: $data.formState.branch,
                              "onUpdate:value": ($event) => $data.formState.branch = $event,
                              placeholder: "Select Branch",
                              style: { "min-width": "200px" }
                            }, {
                              default: withCtx(() => [
                                (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                  return openBlock(), createBlock(_component_a_select_option, {
                                    value: branch.id
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(toDisplayString(branch.branch_name), 1)
                                    ]),
                                    _: 2
                                  }, 1032, ["value"]);
                                }), 256))
                              ]),
                              _: 1
                            }, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_date_picker, {
                              value: $data.formState.date,
                              "onUpdate:value": ($event) => $data.formState.date = $event,
                              format: "DD-MM-YYYY",
                              "value-format": "YYYY-MM-DD"
                            }, null, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, {
                              placeholder: "Search Employees",
                              value: $data.formState.term,
                              "onUpdate:value": ($event) => $data.formState.term = $event
                            }, null, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Search ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["model", "onFinish"]),
                    createVNode(_component_a_table, {
                      columns: $setup.columns,
                      "row-key": (employee) => employee.employee_id,
                      "data-source": $props.employees,
                      pagination: $props.pagination,
                      loading: $data.loading,
                      onChange: $options.handleTableChange
                    }, {
                      bodyCell: withCtx(({ column, text, record }) => [
                        column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                          createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                            ]),
                            _: 2
                          }, 1024),
                          createTextVNode("   " + toDisplayString(text), 1)
                        ], 64)) : createCommentVNode("", true),
                        column.key === "checkin" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                          createVNode(_component_a_space, { direction: "vertical" }, {
                            default: withCtx(() => [
                              (openBlock(true), createBlock(Fragment, null, renderList(record.history, (history) => {
                                return openBlock(), createBlock(_component_a_time_picker, {
                                  allowClear: false,
                                  format: "hh:mm A",
                                  placeholder: "Check In",
                                  "value-format": "HH:mm:ss",
                                  value: history.checkin,
                                  "onUpdate:value": ($event) => history.checkin = $event,
                                  onChange: ($event) => $options.updateAttendance(record)
                                }, null, 8, ["value", "onUpdate:value", "onChange"]);
                              }), 256))
                            ]),
                            _: 2
                          }, 1024),
                          (openBlock(true), createBlock(Fragment, null, renderList(record.history, (history) => {
                            return openBlock(), createBlock(_component_a_input, {
                              value: history.id,
                              "onUpdate:value": ($event) => history.id = $event,
                              hidden: true
                            }, null, 8, ["value", "onUpdate:value"]);
                          }), 256))
                        ], 64)) : createCommentVNode("", true),
                        column.key === "checkout" ? (openBlock(), createBlock(_component_a_space, {
                          key: 2,
                          direction: "vertical"
                        }, {
                          default: withCtx(() => [
                            (openBlock(true), createBlock(Fragment, null, renderList(record.history, (history) => {
                              return openBlock(), createBlock("div", null, [
                                createVNode(_component_a_space, { direction: "horizontal" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_time_picker, {
                                      allowClear: false,
                                      format: "hh:mm A",
                                      placeholder: "Check Out",
                                      "value-format": "HH:mm:ss",
                                      value: history.checkout,
                                      "onUpdate:value": ($event) => history.checkout = $event,
                                      onChange: ($event) => $options.updateAttendance(record)
                                    }, null, 8, ["value", "onUpdate:value", "onChange"]),
                                    history.checkout != "" ? (openBlock(), createBlock("a", {
                                      key: 0,
                                      onClick: ($event) => $options.deleteHistory(history.id)
                                    }, [
                                      createVNode(_component_delete_outlined)
                                    ], 8, ["onClick"])) : createCommentVNode("", true)
                                  ]),
                                  _: 2
                                }, 1024)
                              ]);
                            }), 256))
                          ]),
                          _: 2
                        }, 1024)) : createCommentVNode("", true),
                        column.key === "overtime" ? (openBlock(), createBlock(_component_a_space, {
                          key: 3,
                          direction: "vertical"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_time_picker, {
                              allowClear: false,
                              disabled: true,
                              format: "HH:mm",
                              placeholder: "Over Time",
                              "value-format": "HH:mm",
                              value: record.overtime,
                              "onUpdate:value": ($event) => record.overtime = $event,
                              onChange: ($event) => $options.updateOvertime(record)
                            }, null, 8, ["value", "onUpdate:value", "onChange"])
                          ]),
                          _: 2
                        }, 1024)) : createCommentVNode("", true),
                        column.key === "late" ? (openBlock(), createBlock(_component_a_table, {
                          key: 4,
                          columns: $data.innerColumns,
                          "data-source": _ctx.innerData,
                          pagination: false
                        }, {
                          bodyCell: withCtx(({ column: column2 }) => [
                            column2.key === "state" ? (openBlock(), createBlock("span", { key: 0 }, [
                              createVNode(_component_a_badge, { status: "success" }),
                              createTextVNode(" Finished ")
                            ])) : column2.key === "operation" ? (openBlock(), createBlock("span", {
                              key: 1,
                              class: "table-operation"
                            }, [
                              createVNode("a", null, "Pause"),
                              createVNode("a", null, "Stop"),
                              createVNode(_component_a_dropdown, null, {
                                overlay: withCtx(() => [
                                  createVNode(_component_a_menu, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_menu_item, null, {
                                        default: withCtx(() => [
                                          createTextVNode("Action 1")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_menu_item, null, {
                                        default: withCtx(() => [
                                          createTextVNode("Action 2")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                default: withCtx(() => [
                                  createVNode("a", null, [
                                    createTextVNode(" More "),
                                    createVNode(_component_down_outlined)
                                  ])
                                ]),
                                _: 1
                              })
                            ])) : createCommentVNode("", true)
                          ]),
                          _: 2
                        }, 1032, ["columns", "data-source"])) : createCommentVNode("", true),
                        column.key === "notes" ? (openBlock(), createBlock(_component_a_input_group, {
                          key: 5,
                          compact: ""
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, {
                              value: record.notes,
                              "onUpdate:value": ($event) => record.notes = $event,
                              style: { "width": "calc(100% - 200px)" }
                            }, null, 8, ["value", "onUpdate:value"]),
                            createVNode(_component_a_button, {
                              type: "primary",
                              onClick: ($event) => $options.updateAttendanceStatus(record)
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Save")
                              ]),
                              _: 2
                            }, 1032, ["onClick"])
                          ]),
                          _: 2
                        }, 1024)) : createCommentVNode("", true),
                        column.key === "status" ? (openBlock(), createBlock(_component_a_select, {
                          key: 6,
                          value: record.status,
                          "onUpdate:value": ($event) => record.status = $event,
                          onChange: ($event) => $options.updateAttendanceStatus(record)
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_select_option, { value: "Present" }, {
                              default: withCtx(() => [
                                createTextVNode("Present")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_select_option, { value: "Absent" }, {
                              default: withCtx(() => [
                                createTextVNode("Absent")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_select_option, { value: "Paid Leave" }, {
                              default: withCtx(() => [
                                createTextVNode("Paid Leave")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_select_option, { value: "Unpaid Leave" }, {
                              default: withCtx(() => [
                                createTextVNode("Unpaid Leave")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_select_option, { value: "Week Off" }, {
                              default: withCtx(() => [
                                createTextVNode("Week Off")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 2
                        }, 1032, ["value", "onUpdate:value", "onChange"])) : createCommentVNode("", true)
                      ]),
                      _: 1
                    }, 8, ["columns", "row-key", "data-source", "pagination", "loading", "onChange"])
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_spin, {
            spinning: $data.loading,
            delay: $data.delayTime
          }, null, 8, ["spinning", "delay"]),
          createVNode(_component_a_layout_content, { style: { margin: "24px 16px", padding: "24px", background: "#fff", minHeight: "calc(100vh - 115px)", textAlign: "center" } }, {
            default: withCtx(() => [
              createVNode(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, {
                    name: "nest-messages",
                    model: $data.formState,
                    layout: "inline",
                    onFinish: $options.search
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_select, {
                            value: $data.formState.branch,
                            "onUpdate:value": ($event) => $data.formState.branch = $event,
                            placeholder: "Select Branch",
                            style: { "min-width": "200px" }
                          }, {
                            default: withCtx(() => [
                              (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                return openBlock(), createBlock(_component_a_select_option, {
                                  value: branch.id
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(branch.branch_name), 1)
                                  ]),
                                  _: 2
                                }, 1032, ["value"]);
                              }), 256))
                            ]),
                            _: 1
                          }, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_date_picker, {
                            value: $data.formState.date,
                            "onUpdate:value": ($event) => $data.formState.date = $event,
                            format: "DD-MM-YYYY",
                            "value-format": "YYYY-MM-DD"
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            placeholder: "Search Employees",
                            value: $data.formState.term,
                            "onUpdate:value": ($event) => $data.formState.term = $event
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Search ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["model", "onFinish"]),
                  createVNode(_component_a_table, {
                    columns: $setup.columns,
                    "row-key": (employee) => employee.employee_id,
                    "data-source": $props.employees,
                    pagination: $props.pagination,
                    loading: $data.loading,
                    onChange: $options.handleTableChange
                  }, {
                    bodyCell: withCtx(({ column, text, record }) => [
                      column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                        createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                          ]),
                          _: 2
                        }, 1024),
                        createTextVNode("   " + toDisplayString(text), 1)
                      ], 64)) : createCommentVNode("", true),
                      column.key === "checkin" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                        createVNode(_component_a_space, { direction: "vertical" }, {
                          default: withCtx(() => [
                            (openBlock(true), createBlock(Fragment, null, renderList(record.history, (history) => {
                              return openBlock(), createBlock(_component_a_time_picker, {
                                allowClear: false,
                                format: "hh:mm A",
                                placeholder: "Check In",
                                "value-format": "HH:mm:ss",
                                value: history.checkin,
                                "onUpdate:value": ($event) => history.checkin = $event,
                                onChange: ($event) => $options.updateAttendance(record)
                              }, null, 8, ["value", "onUpdate:value", "onChange"]);
                            }), 256))
                          ]),
                          _: 2
                        }, 1024),
                        (openBlock(true), createBlock(Fragment, null, renderList(record.history, (history) => {
                          return openBlock(), createBlock(_component_a_input, {
                            value: history.id,
                            "onUpdate:value": ($event) => history.id = $event,
                            hidden: true
                          }, null, 8, ["value", "onUpdate:value"]);
                        }), 256))
                      ], 64)) : createCommentVNode("", true),
                      column.key === "checkout" ? (openBlock(), createBlock(_component_a_space, {
                        key: 2,
                        direction: "vertical"
                      }, {
                        default: withCtx(() => [
                          (openBlock(true), createBlock(Fragment, null, renderList(record.history, (history) => {
                            return openBlock(), createBlock("div", null, [
                              createVNode(_component_a_space, { direction: "horizontal" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_time_picker, {
                                    allowClear: false,
                                    format: "hh:mm A",
                                    placeholder: "Check Out",
                                    "value-format": "HH:mm:ss",
                                    value: history.checkout,
                                    "onUpdate:value": ($event) => history.checkout = $event,
                                    onChange: ($event) => $options.updateAttendance(record)
                                  }, null, 8, ["value", "onUpdate:value", "onChange"]),
                                  history.checkout != "" ? (openBlock(), createBlock("a", {
                                    key: 0,
                                    onClick: ($event) => $options.deleteHistory(history.id)
                                  }, [
                                    createVNode(_component_delete_outlined)
                                  ], 8, ["onClick"])) : createCommentVNode("", true)
                                ]),
                                _: 2
                              }, 1024)
                            ]);
                          }), 256))
                        ]),
                        _: 2
                      }, 1024)) : createCommentVNode("", true),
                      column.key === "overtime" ? (openBlock(), createBlock(_component_a_space, {
                        key: 3,
                        direction: "vertical"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_time_picker, {
                            allowClear: false,
                            disabled: true,
                            format: "HH:mm",
                            placeholder: "Over Time",
                            "value-format": "HH:mm",
                            value: record.overtime,
                            "onUpdate:value": ($event) => record.overtime = $event,
                            onChange: ($event) => $options.updateOvertime(record)
                          }, null, 8, ["value", "onUpdate:value", "onChange"])
                        ]),
                        _: 2
                      }, 1024)) : createCommentVNode("", true),
                      column.key === "late" ? (openBlock(), createBlock(_component_a_table, {
                        key: 4,
                        columns: $data.innerColumns,
                        "data-source": _ctx.innerData,
                        pagination: false
                      }, {
                        bodyCell: withCtx(({ column: column2 }) => [
                          column2.key === "state" ? (openBlock(), createBlock("span", { key: 0 }, [
                            createVNode(_component_a_badge, { status: "success" }),
                            createTextVNode(" Finished ")
                          ])) : column2.key === "operation" ? (openBlock(), createBlock("span", {
                            key: 1,
                            class: "table-operation"
                          }, [
                            createVNode("a", null, "Pause"),
                            createVNode("a", null, "Stop"),
                            createVNode(_component_a_dropdown, null, {
                              overlay: withCtx(() => [
                                createVNode(_component_a_menu, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, null, {
                                      default: withCtx(() => [
                                        createTextVNode("Action 1")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_menu_item, null, {
                                      default: withCtx(() => [
                                        createTextVNode("Action 2")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              default: withCtx(() => [
                                createVNode("a", null, [
                                  createTextVNode(" More "),
                                  createVNode(_component_down_outlined)
                                ])
                              ]),
                              _: 1
                            })
                          ])) : createCommentVNode("", true)
                        ]),
                        _: 2
                      }, 1032, ["columns", "data-source"])) : createCommentVNode("", true),
                      column.key === "notes" ? (openBlock(), createBlock(_component_a_input_group, {
                        key: 5,
                        compact: ""
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            value: record.notes,
                            "onUpdate:value": ($event) => record.notes = $event,
                            style: { "width": "calc(100% - 200px)" }
                          }, null, 8, ["value", "onUpdate:value"]),
                          createVNode(_component_a_button, {
                            type: "primary",
                            onClick: ($event) => $options.updateAttendanceStatus(record)
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Save")
                            ]),
                            _: 2
                          }, 1032, ["onClick"])
                        ]),
                        _: 2
                      }, 1024)) : createCommentVNode("", true),
                      column.key === "status" ? (openBlock(), createBlock(_component_a_select, {
                        key: 6,
                        value: record.status,
                        "onUpdate:value": ($event) => record.status = $event,
                        onChange: ($event) => $options.updateAttendanceStatus(record)
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_select_option, { value: "Present" }, {
                            default: withCtx(() => [
                              createTextVNode("Present")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_select_option, { value: "Absent" }, {
                            default: withCtx(() => [
                              createTextVNode("Absent")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_select_option, { value: "Paid Leave" }, {
                            default: withCtx(() => [
                              createTextVNode("Paid Leave")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_select_option, { value: "Unpaid Leave" }, {
                            default: withCtx(() => [
                              createTextVNode("Unpaid Leave")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_select_option, { value: "Week Off" }, {
                            default: withCtx(() => [
                              createTextVNode("Week Off")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 2
                      }, 1032, ["value", "onUpdate:value", "onChange"])) : createCommentVNode("", true)
                    ]),
                    _: 1
                  }, 8, ["columns", "row-key", "data-source", "pagination", "loading", "onChange"])
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["style"])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Attendance/Index copy.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Index_copy = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Index_copy as default
};
