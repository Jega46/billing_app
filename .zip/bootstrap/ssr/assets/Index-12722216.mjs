import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import "vue-request";
import { resolveComponent, withCtx, createVNode, createTextVNode, openBlock, createBlock, toDisplayString, createCommentVNode, mergeProps, useSSRContext } from "vue";
import { Head, Link, useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./InputError-6d616b1a.mjs";
import { DownloadOutlined, UploadOutlined, PlusCircleOutlined, DeleteOutlined, EditOutlined, CloudUploadOutlined } from "@ant-design/icons-vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
const columns = [
  {
    title: "Service Name",
    key: "name",
    dataIndex: "name",
    width: "15%"
  },
  {
    title: "SAC",
    key: "sac",
    dataIndex: "sac",
    width: "15%"
  },
  {
    title: "Rate (INR)",
    key: "rate",
    dataIndex: "rate",
    width: "10%"
  },
  {
    title: "Action",
    key: "action",
    fixed: "right",
    width: "2%"
  }
];
const services = [
  {
    key: "1",
    name: "John Brown",
    sac: "FOC1400C",
    rate: 12e3,
    action: ""
  },
  {
    key: "2",
    name: "Jim Green",
    sac: "FOC1400C",
    rate: 12e3,
    action: ""
  },
  {
    key: "3",
    name: "Joe Black",
    sac: "FOC1400C",
    rate: 12e3,
    action: ""
  },
  {
    key: "4",
    name: "John Brown",
    sac: "FOC1400C",
    rate: 12e3,
    action: ""
  },
  {
    key: "5",
    name: "Jim Green",
    sac: "FOC1400C",
    rate: 12e3,
    action: ""
  },
  {
    key: "6",
    name: "Joe Black",
    sac: "FOC1400C",
    rate: 12e3,
    action: ""
  },
  {
    key: "7",
    name: "John Brown",
    sac: "FOC1400C",
    rate: 12e3,
    action: ""
  },
  {
    key: "8",
    name: "Jim Green",
    sac: "FOC1400C",
    rate: 12e3,
    action: ""
  },
  {
    key: "9",
    name: "Joe Black",
    sac: "FOC1400C",
    rate: 12e3,
    action: ""
  },
  {
    key: "10",
    name: "John Brown",
    sac: "FOC1400C",
    rate: 12e3,
    action: ""
  },
  {
    key: "11",
    name: "Jim Green",
    sac: "FOC1400C",
    rate: 12e3,
    action: ""
  },
  {
    key: "12",
    name: "Joe Black",
    sac: "FOC1400C",
    rate: 12e3,
    action: ""
  },
  {
    key: "13",
    name: "John Brown",
    sac: "FOC1400C",
    rate: 12e3,
    action: ""
  },
  {
    key: "14",
    name: "Jim Green",
    sac: "FOC1400C",
    rate: 12e3,
    action: ""
  }
];
const pagination = {
  current: 1,
  pageSize: 10,
  total: 14,
  showSizeChanger: true,
  showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} items`
};
const invoicetransactions_column = [
  {
    title: "Date",
    key: "date",
    dataIndex: "date",
    width: "15%"
  },
  {
    title: "Invoice Number",
    key: "invoice_number",
    dataIndex: "invoice_number",
    width: "15%"
  },
  {
    title: "Customer Name",
    key: "customer_name",
    dataIndex: "customer_name",
    width: "2%"
  },
  {
    title: "Quantity Sold",
    key: "quantity_sold",
    dataIndex: "quantity_sold",
    width: "10%"
  },
  {
    title: "Price",
    key: "price",
    dataIndex: "price",
    width: "2%"
  },
  {
    title: "Total",
    key: "total",
    dataIndex: "total",
    width: "2%"
  },
  {
    title: "Status",
    key: "status",
    dataIndex: "status",
    width: "2%"
  }
];
const invoicetransactions = [
  {
    key: "1",
    date: "10-10-2023",
    invoice_number: "INV-0001",
    quantity_sold: 1,
    customer_name: "John",
    price: 12e3,
    total: 12e3,
    status: "Open"
  },
  {
    key: "2",
    date: "10-10-2023",
    invoice_number: "INV-0002",
    quantity_sold: 1,
    customer_name: "John",
    price: 12e3,
    total: 12e3,
    status: "Open"
  }
];
const _sfc_main = {
  components: { AuthenticatedLayout: _sfc_main$1, DownloadOutlined, UploadOutlined, PlusCircleOutlined, DeleteOutlined, EditOutlined, Head, Link, InputError: _sfc_main$2, CloudUploadOutlined },
  props: {},
  setup(props) {
    return {
      columns,
      services,
      pagination,
      invoicetransactions_column,
      invoicetransactions
    };
  },
  data() {
    const searchform = useForm({
      term: ""
    });
    const layout = {
      labelCol: { span: 24 },
      wrapperCol: { span: 24 }
    };
    const form = useForm({});
    return {
      createvisible: false,
      layout,
      form,
      searchform,
      serviceDetailDrawer: false
    };
  },
  methods: {
    showDrawer() {
      this.createvisible = true;
    },
    showServiceDetailDrawer() {
      this.serviceDetailDrawer = true;
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_space = resolveComponent("a-space");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_button = resolveComponent("a-button");
  const _component_plus_circle_outlined = resolveComponent("plus-circle-outlined");
  const _component_CloudUploadOutlined = resolveComponent("CloudUploadOutlined");
  const _component_a_table = resolveComponent("a-table");
  const _component_a_dropdown = resolveComponent("a-dropdown");
  const _component_DownCircleOutlined = resolveComponent("DownCircleOutlined");
  const _component_a_menu = resolveComponent("a-menu");
  const _component_a_menu_item = resolveComponent("a-menu-item");
  const _component_edit_outlined = resolveComponent("edit-outlined");
  const _component_delete_outlined = resolveComponent("delete-outlined");
  const _component_a_drawer = resolveComponent("a-drawer");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_auto_complete = resolveComponent("a-auto-complete");
  const _component_a_input_number = resolveComponent("a-input-number");
  const _component_a_textarea = resolveComponent("a-textarea");
  const _component_a_tabs = resolveComponent("a-tabs");
  const _component_a_tab_pane = resolveComponent("a-tab-pane");
  const _component_a_descriptions = resolveComponent("a-descriptions");
  const _component_a_descriptions_item = resolveComponent("a-descriptions-item");
  const _component_a_select_option = resolveComponent("a-select-option");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Services" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_layout_content, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, {
                      name: "nest-messages",
                      model: $data.form,
                      layout: "inline",
                      onFinish: _ctx.search
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input, {
                                  placeholder: "Search by service name",
                                  "allow-clear": true,
                                  value: $data.searchform.term,
                                  "onUpdate:value": ($event) => $data.searchform.term = $event
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input, {
                                    placeholder: "Search by service name",
                                    "allow-clear": true,
                                    value: $data.searchform.term,
                                    "onUpdate:value": ($event) => $data.searchform.term = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Search `);
                                    } else {
                                      return [
                                        createTextVNode(" Search ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Search ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_plus_circle_outlined)
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Add New Service `);
                                    } else {
                                      return [
                                        createTextVNode(" Add New Service ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    shape: "round",
                                    onClick: $options.showDrawer
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Add New Service ")
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_CloudUploadOutlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_CloudUploadOutlined)
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Import `);
                                    } else {
                                      return [
                                        createTextVNode(" Import ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    shape: "round",
                                    onClick: $options.showDrawer
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_CloudUploadOutlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Import ")
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  placeholder: "Search by service name",
                                  "allow-clear": true,
                                  value: $data.searchform.term,
                                  "onUpdate:value": ($event) => $data.searchform.term = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Search ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Add New Service ")
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_CloudUploadOutlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Import ")
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_table, {
                      columns: $setup.columns,
                      "data-source": $setup.services,
                      pagination: $setup.pagination
                    }, {
                      bodyCell: withCtx(({ column, record }, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          if (column.key === "name") {
                            _push5(`<a${_scopeId4}>${ssrInterpolate(record.name)}</a>`);
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "action") {
                            _push5(ssrRenderComponent(_component_a_dropdown, null, {
                              overlay: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(ssrRenderComponent(_component_a_menu, null, {
                                    default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_a_menu_item, null, {
                                          default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(`<a href="javascript:;"${_scopeId7}>`);
                                              _push8(ssrRenderComponent(_component_edit_outlined, null, null, _parent8, _scopeId7));
                                              _push8(` Edit </a>`);
                                            } else {
                                              return [
                                                createVNode("a", { href: "javascript:;" }, [
                                                  createVNode(_component_edit_outlined),
                                                  createTextVNode(" Edit ")
                                                ])
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                        _push7(ssrRenderComponent(_component_a_menu_item, null, {
                                          default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(`<a href="javascript:;"${_scopeId7}>`);
                                              _push8(ssrRenderComponent(_component_delete_outlined, null, null, _parent8, _scopeId7));
                                              _push8(` Delete </a>`);
                                            } else {
                                              return [
                                                createVNode("a", { href: "javascript:;" }, [
                                                  createVNode(_component_delete_outlined),
                                                  createTextVNode(" Delete ")
                                                ])
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_a_menu_item, null, {
                                            default: withCtx(() => [
                                              createVNode("a", { href: "javascript:;" }, [
                                                createVNode(_component_edit_outlined),
                                                createTextVNode(" Edit ")
                                              ])
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_menu_item, null, {
                                            default: withCtx(() => [
                                              createVNode("a", { href: "javascript:;" }, [
                                                createVNode(_component_delete_outlined),
                                                createTextVNode(" Delete ")
                                              ])
                                            ]),
                                            _: 1
                                          })
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  return [
                                    createVNode(_component_a_menu, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_menu_item, null, {
                                          default: withCtx(() => [
                                            createVNode("a", { href: "javascript:;" }, [
                                              createVNode(_component_edit_outlined),
                                              createTextVNode(" Edit ")
                                            ])
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_menu_item, null, {
                                          default: withCtx(() => [
                                            createVNode("a", { href: "javascript:;" }, [
                                              createVNode(_component_delete_outlined),
                                              createTextVNode(" Delete ")
                                            ])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ];
                                }
                              }),
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(ssrRenderComponent(_component_a_button, {
                                    type: "primary",
                                    size: _ctx.size,
                                    class: "ant-dropdown-link",
                                    shape: "circle"
                                  }, {
                                    icon: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_DownCircleOutlined, null, null, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_DownCircleOutlined)
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  return [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      size: _ctx.size,
                                      class: "ant-dropdown-link",
                                      shape: "circle"
                                    }, {
                                      icon: withCtx(() => [
                                        createVNode(_component_DownCircleOutlined)
                                      ]),
                                      _: 1
                                    }, 8, ["size"])
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                          } else {
                            _push5(`<!---->`);
                          }
                        } else {
                          return [
                            column.key === "name" ? (openBlock(), createBlock("a", {
                              key: 0,
                              onClick: $options.showServiceDetailDrawer
                            }, toDisplayString(record.name), 9, ["onClick"])) : createCommentVNode("", true),
                            column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 1 }, {
                              overlay: withCtx(() => [
                                createVNode(_component_a_menu, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, null, {
                                      default: withCtx(() => [
                                        createVNode("a", { href: "javascript:;" }, [
                                          createVNode(_component_edit_outlined),
                                          createTextVNode(" Edit ")
                                        ])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_menu_item, null, {
                                      default: withCtx(() => [
                                        createVNode("a", { href: "javascript:;" }, [
                                          createVNode(_component_delete_outlined),
                                          createTextVNode(" Delete ")
                                        ])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  size: _ctx.size,
                                  class: "ant-dropdown-link",
                                  shape: "circle"
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_DownCircleOutlined)
                                  ]),
                                  _: 1
                                }, 8, ["size"])
                              ]),
                              _: 1
                            })) : createCommentVNode("", true)
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, {
                        name: "nest-messages",
                        model: $data.form,
                        layout: "inline",
                        onFinish: _ctx.search
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                placeholder: "Search by service name",
                                "allow-clear": true,
                                value: $data.searchform.term,
                                "onUpdate:value": ($event) => $data.searchform.term = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Search ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                shape: "round",
                                onClick: $options.showDrawer
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Add New Service ")
                                ]),
                                _: 1
                              }, 8, ["onClick"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                shape: "round",
                                onClick: $options.showDrawer
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_CloudUploadOutlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Import ")
                                ]),
                                _: 1
                              }, 8, ["onClick"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["model", "onFinish"]),
                      createVNode(_component_a_table, {
                        columns: $setup.columns,
                        "data-source": $setup.services,
                        pagination: $setup.pagination
                      }, {
                        bodyCell: withCtx(({ column, record }) => [
                          column.key === "name" ? (openBlock(), createBlock("a", {
                            key: 0,
                            onClick: $options.showServiceDetailDrawer
                          }, toDisplayString(record.name), 9, ["onClick"])) : createCommentVNode("", true),
                          column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 1 }, {
                            overlay: withCtx(() => [
                              createVNode(_component_a_menu, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, null, {
                                    default: withCtx(() => [
                                      createVNode("a", { href: "javascript:;" }, [
                                        createVNode(_component_edit_outlined),
                                        createTextVNode(" Edit ")
                                      ])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_menu_item, null, {
                                    default: withCtx(() => [
                                      createVNode("a", { href: "javascript:;" }, [
                                        createVNode(_component_delete_outlined),
                                        createTextVNode(" Delete ")
                                      ])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                size: _ctx.size,
                                class: "ant-dropdown-link",
                                shape: "circle"
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_DownCircleOutlined)
                                ]),
                                _: 1
                              }, 8, ["size"])
                            ]),
                            _: 1
                          })) : createCommentVNode("", true)
                        ]),
                        _: 1
                      }, 8, ["columns", "data-source", "pagination"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_drawer, {
                visible: $data.createvisible,
                "onUpdate:visible": ($event) => $data.createvisible = $event,
                class: "custom-class",
                title: "New Service",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, mergeProps({ model: $data.form }, $data.layout, {
                      name: "nest-messages",
                      loading: _ctx.formloading,
                      "validate-messages": _ctx.validateMessages,
                      onFinish: _ctx.submit,
                      "label-col": { span: 24 }
                    }), {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`<h4 class="t1"${_scopeId4}>Details</h4>`);
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Service Name",
                                        name: "name",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Please enter service name" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Please enter service name" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Service Name",
                                          name: "name",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Please enter service name" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Category",
                                        name: "name",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select, {
                                              "show-search": "",
                                              placeholder: "Select Category",
                                              "default-active-first-option": false,
                                              "not-found-content": _ctx.value
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select, {
                                                "show-search": "",
                                                placeholder: "Select Category",
                                                "default-active-first-option": false,
                                                "not-found-content": _ctx.value
                                              }, null, 8, ["not-found-content"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Category",
                                          name: "name",
                                          rules: [{ required: true }]
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              "show-search": "",
                                              placeholder: "Select Category",
                                              "default-active-first-option": false,
                                              "not-found-content": _ctx.value
                                            }, null, 8, ["not-found-content"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "SAC",
                                        name: "sac"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, { placeholder: "Enter SAC" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, { placeholder: "Enter SAC" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "SAC",
                                          name: "sac"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, { placeholder: "Enter SAC" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Unit",
                                        name: "unit"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_auto_complete, { placeholder: "Select Unit" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Unit",
                                          name: "unit"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Service Name",
                                        name: "name",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Please enter service name" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Category",
                                        name: "name",
                                        rules: [{ required: true }]
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            "show-search": "",
                                            placeholder: "Select Category",
                                            "default-active-first-option": false,
                                            "not-found-content": _ctx.value
                                          }, null, 8, ["not-found-content"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "SAC",
                                        name: "sac"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, { placeholder: "Enter SAC" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Unit",
                                        name: "unit"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<h4 class="t1"${_scopeId4}>Pricing &amp; Tax</h4>`);
                          _push5(ssrRenderComponent(_component_a_row, { gutter: 24 }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Rate (INR)",
                                        name: "rate"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input_number, {
                                              placeholder: "Enter service rate",
                                              style: { "width": "100%" }
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input_number, {
                                                placeholder: "Enter service rate",
                                                style: { "width": "100%" }
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Rate (INR)",
                                          name: "rate"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input_number, {
                                              placeholder: "Enter service rate",
                                              style: { "width": "100%" }
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Tax",
                                        name: "tax"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select, {
                                              "show-search": "",
                                              placeholder: "Tax",
                                              "default-active-first-option": false,
                                              "not-found-content": _ctx.value
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select, {
                                                "show-search": "",
                                                placeholder: "Tax",
                                                "default-active-first-option": false,
                                                "not-found-content": _ctx.value
                                              }, null, 8, ["not-found-content"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, {
                                          label: "Tax",
                                          name: "tax"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              "show-search": "",
                                              placeholder: "Tax",
                                              "default-active-first-option": false,
                                              "not-found-content": _ctx.value
                                            }, null, 8, ["not-found-content"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Rate (INR)",
                                        name: "rate"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input_number, {
                                            placeholder: "Enter service rate",
                                            style: { "width": "100%" }
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, {
                                    class: "gutter-row",
                                    span: 12
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, {
                                        label: "Tax",
                                        name: "tax"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            "show-search": "",
                                            placeholder: "Tax",
                                            "default-active-first-option": false,
                                            "not-found-content": _ctx.value
                                          }, null, 8, ["not-found-content"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<h4 class="t1"${_scopeId4}>Description</h4>`);
                          _push5(ssrRenderComponent(_component_a_form_item, {
                            label: "Description",
                            name: "description"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_textarea, { placeholder: "Enter Description" }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_textarea, { placeholder: "Enter Description" })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit",
                                  disabled: $data.form.processing
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`SUBMIT`);
                                    } else {
                                      return [
                                        createTextVNode("SUBMIT")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit",
                                    disabled: $data.form.processing
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("SUBMIT")
                                    ]),
                                    _: 1
                                  }, 8, ["disabled"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode("h4", { class: "t1" }, "Details"),
                            createVNode(_component_a_row, { gutter: 24 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Service Name",
                                      name: "name",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Please enter service name" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Category",
                                      name: "name",
                                      rules: [{ required: true }]
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          "show-search": "",
                                          placeholder: "Select Category",
                                          "default-active-first-option": false,
                                          "not-found-content": _ctx.value
                                        }, null, 8, ["not-found-content"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "SAC",
                                      name: "sac"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, { placeholder: "Enter SAC" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Unit",
                                      name: "unit"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("h4", { class: "t1" }, "Pricing & Tax"),
                            createVNode(_component_a_row, { gutter: 24 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Rate (INR)",
                                      name: "rate"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input_number, {
                                          placeholder: "Enter service rate",
                                          style: { "width": "100%" }
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, {
                                  class: "gutter-row",
                                  span: 12
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, {
                                      label: "Tax",
                                      name: "tax"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          "show-search": "",
                                          placeholder: "Tax",
                                          "default-active-first-option": false,
                                          "not-found-content": _ctx.value
                                        }, null, 8, ["not-found-content"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("h4", { class: "t1" }, "Description"),
                            createVNode(_component_a_form_item, {
                              label: "Description",
                              name: "description"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_textarea, { placeholder: "Enter Description" })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit",
                                  disabled: $data.form.processing
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("SUBMIT")
                                  ]),
                                  _: 1
                                }, 8, ["disabled"])
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, mergeProps({ model: $data.form }, $data.layout, {
                        name: "nest-messages",
                        loading: _ctx.formloading,
                        "validate-messages": _ctx.validateMessages,
                        onFinish: _ctx.submit,
                        "label-col": { span: 24 }
                      }), {
                        default: withCtx(() => [
                          createVNode("h4", { class: "t1" }, "Details"),
                          createVNode(_component_a_row, { gutter: 24 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Service Name",
                                    name: "name",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Please enter service name" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Category",
                                    name: "name",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        "show-search": "",
                                        placeholder: "Select Category",
                                        "default-active-first-option": false,
                                        "not-found-content": _ctx.value
                                      }, null, 8, ["not-found-content"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "SAC",
                                    name: "sac"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, { placeholder: "Enter SAC" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Unit",
                                    name: "unit"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("h4", { class: "t1" }, "Pricing & Tax"),
                          createVNode(_component_a_row, { gutter: 24 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Rate (INR)",
                                    name: "rate"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input_number, {
                                        placeholder: "Enter service rate",
                                        style: { "width": "100%" }
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, {
                                class: "gutter-row",
                                span: 12
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, {
                                    label: "Tax",
                                    name: "tax"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        "show-search": "",
                                        placeholder: "Tax",
                                        "default-active-first-option": false,
                                        "not-found-content": _ctx.value
                                      }, null, 8, ["not-found-content"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("h4", { class: "t1" }, "Description"),
                          createVNode(_component_a_form_item, {
                            label: "Description",
                            name: "description"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_textarea, { placeholder: "Enter Description" })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit",
                                disabled: $data.form.processing
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("SUBMIT")
                                ]),
                                _: 1
                              }, 8, ["disabled"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 16, ["model", "loading", "validate-messages", "onFinish"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_drawer, {
                visible: $data.serviceDetailDrawer,
                "onUpdate:visible": ($event) => $data.serviceDetailDrawer = $event,
                class: "custom-class",
                title: "Service 1",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                extra: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_space, null, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Edit`);
                              } else {
                                return [
                                  createTextVNode("Edit")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_button, {
                            type: "primary",
                            onClick: _ctx.onClose
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Delete`);
                              } else {
                                return [
                                  createTextVNode("Delete")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                              default: withCtx(() => [
                                createTextVNode("Edit")
                              ]),
                              _: 1
                            }, 8, ["onClick"]),
                            createVNode(_component_a_button, {
                              type: "primary",
                              onClick: _ctx.onClose
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Delete")
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_space, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                            default: withCtx(() => [
                              createTextVNode("Edit")
                            ]),
                            _: 1
                          }, 8, ["onClick"]),
                          createVNode(_component_a_button, {
                            type: "primary",
                            onClick: _ctx.onClose
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Delete")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_tabs, {
                      activeKey: _ctx.activeKey,
                      "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_tab_pane, {
                            key: "Overview",
                            tab: "Overview"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_descriptions, { size: _ctx.size }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_descriptions_item, {
                                        label: "Service Name",
                                        span: 4
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`Service 1`);
                                          } else {
                                            return [
                                              createTextVNode("Service 1")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_descriptions_item, { label: "Description" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget`);
                                          } else {
                                            return [
                                              createTextVNode("Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_descriptions_item, {
                                          label: "Service Name",
                                          span: 4
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("Service 1")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_descriptions_item, { label: "Description" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_descriptions, { size: _ctx.size }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_descriptions_item, {
                                        label: "Service Name",
                                        span: 4
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Service 1")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_descriptions_item, { label: "Description" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["size"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_tab_pane, {
                            key: "Transactions",
                            tab: "Transactions",
                            "force-render": ""
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_space, null, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_select, {
                                        ref: "select",
                                        placeholder: "Filter By"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "jack" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Invoice`);
                                                } else {
                                                  return [
                                                    createTextVNode("Invoice")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "lucy" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Sales Order`);
                                                } else {
                                                  return [
                                                    createTextVNode("Sales Order")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "disabled" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Quote`);
                                                } else {
                                                  return [
                                                    createTextVNode("Quote")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Yiminghe" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Purchase Order`);
                                                } else {
                                                  return [
                                                    createTextVNode("Purchase Order")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select_option, { value: "jack" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Invoice")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "lucy" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Sales Order")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "disabled" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Quote")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Purchase Order")
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_select, {
                                        ref: "select",
                                        placeholder: "Status"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "jack" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`All`);
                                                } else {
                                                  return [
                                                    createTextVNode("All")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "lucy" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Draft`);
                                                } else {
                                                  return [
                                                    createTextVNode("Draft")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select_option, { value: "jack" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("All")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "lucy" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Draft")
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_select, {
                                          ref: "select",
                                          placeholder: "Filter By"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "jack" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Invoice")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "lucy" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Sales Order")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "disabled" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Quote")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Purchase Order")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 512),
                                        createVNode(_component_a_select, {
                                          ref: "select",
                                          placeholder: "Status"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "jack" }, {
                                              default: withCtx(() => [
                                                createTextVNode("All")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "lucy" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Draft")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 512)
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_table, {
                                  columns: $setup.invoicetransactions_column,
                                  "data-source": $setup.invoicetransactions
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_space, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        ref: "select",
                                        placeholder: "Filter By"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "jack" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Invoice")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "lucy" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Sales Order")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "disabled" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Quote")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Purchase Order")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 512),
                                      createVNode(_component_a_select, {
                                        ref: "select",
                                        placeholder: "Status"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "jack" }, {
                                            default: withCtx(() => [
                                              createTextVNode("All")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "lucy" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Draft")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 512)
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_table, {
                                    columns: $setup.invoicetransactions_column,
                                    "data-source": $setup.invoicetransactions
                                  }, null, 8, ["columns", "data-source"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_tab_pane, {
                              key: "Overview",
                              tab: "Overview"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_descriptions, { size: _ctx.size }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_descriptions_item, {
                                      label: "Service Name",
                                      span: 4
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Service 1")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_descriptions_item, { label: "Description" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["size"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_tab_pane, {
                              key: "Transactions",
                              tab: "Transactions",
                              "force-render": ""
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_space, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      ref: "select",
                                      placeholder: "Filter By"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, { value: "jack" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Invoice")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "lucy" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Sales Order")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "disabled" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Quote")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Purchase Order")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 512),
                                    createVNode(_component_a_select, {
                                      ref: "select",
                                      placeholder: "Status"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, { value: "jack" }, {
                                          default: withCtx(() => [
                                            createTextVNode("All")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "lucy" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Draft")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 512)
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_table, {
                                  columns: $setup.invoicetransactions_column,
                                  "data-source": $setup.invoicetransactions
                                }, null, 8, ["columns", "data-source"])
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_tabs, {
                        activeKey: _ctx.activeKey,
                        "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_tab_pane, {
                            key: "Overview",
                            tab: "Overview"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_descriptions, { size: _ctx.size }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_descriptions_item, {
                                    label: "Service Name",
                                    span: 4
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Service 1")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_descriptions_item, { label: "Description" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["size"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_tab_pane, {
                            key: "Transactions",
                            tab: "Transactions",
                            "force-render": ""
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_space, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    ref: "select",
                                    placeholder: "Filter By"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, { value: "jack" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Invoice")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "lucy" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Sales Order")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "disabled" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Quote")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Purchase Order")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 512),
                                  createVNode(_component_a_select, {
                                    ref: "select",
                                    placeholder: "Status"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, { value: "jack" }, {
                                        default: withCtx(() => [
                                          createTextVNode("All")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "lucy" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Draft")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 512)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_table, {
                                columns: $setup.invoicetransactions_column,
                                "data-source": $setup.invoicetransactions
                              }, null, 8, ["columns", "data-source"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["activeKey", "onUpdate:activeKey"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_space, {
                  direction: "vertical",
                  style: { width: "100%" }
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, {
                      name: "nest-messages",
                      model: $data.form,
                      layout: "inline",
                      onFinish: _ctx.search
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, {
                              placeholder: "Search by service name",
                              "allow-clear": true,
                              value: $data.searchform.term,
                              "onUpdate:value": ($event) => $data.searchform.term = $event
                            }, null, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Search ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              shape: "round",
                              onClick: $options.showDrawer
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_plus_circle_outlined)
                              ]),
                              default: withCtx(() => [
                                createTextVNode(" Add New Service ")
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              shape: "round",
                              onClick: $options.showDrawer
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_CloudUploadOutlined)
                              ]),
                              default: withCtx(() => [
                                createTextVNode(" Import ")
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["model", "onFinish"]),
                    createVNode(_component_a_table, {
                      columns: $setup.columns,
                      "data-source": $setup.services,
                      pagination: $setup.pagination
                    }, {
                      bodyCell: withCtx(({ column, record }) => [
                        column.key === "name" ? (openBlock(), createBlock("a", {
                          key: 0,
                          onClick: $options.showServiceDetailDrawer
                        }, toDisplayString(record.name), 9, ["onClick"])) : createCommentVNode("", true),
                        column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 1 }, {
                          overlay: withCtx(() => [
                            createVNode(_component_a_menu, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, null, {
                                  default: withCtx(() => [
                                    createVNode("a", { href: "javascript:;" }, [
                                      createVNode(_component_edit_outlined),
                                      createTextVNode(" Edit ")
                                    ])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_menu_item, null, {
                                  default: withCtx(() => [
                                    createVNode("a", { href: "javascript:;" }, [
                                      createVNode(_component_delete_outlined),
                                      createTextVNode(" Delete ")
                                    ])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              size: _ctx.size,
                              class: "ant-dropdown-link",
                              shape: "circle"
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_DownCircleOutlined)
                              ]),
                              _: 1
                            }, 8, ["size"])
                          ]),
                          _: 1
                        })) : createCommentVNode("", true)
                      ]),
                      _: 1
                    }, 8, ["columns", "data-source", "pagination"])
                  ]),
                  _: 1
                }),
                createVNode(_component_a_drawer, {
                  visible: $data.createvisible,
                  "onUpdate:visible": ($event) => $data.createvisible = $event,
                  class: "custom-class",
                  title: "New Service",
                  size: "large",
                  placement: "right",
                  onAfterVisibleChange: _ctx.afterVisibleChange
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, mergeProps({ model: $data.form }, $data.layout, {
                      name: "nest-messages",
                      loading: _ctx.formloading,
                      "validate-messages": _ctx.validateMessages,
                      onFinish: _ctx.submit,
                      "label-col": { span: 24 }
                    }), {
                      default: withCtx(() => [
                        createVNode("h4", { class: "t1" }, "Details"),
                        createVNode(_component_a_row, { gutter: 24 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Service Name",
                                  name: "name",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Please enter service name" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Category",
                                  name: "name",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      "show-search": "",
                                      placeholder: "Select Category",
                                      "default-active-first-option": false,
                                      "not-found-content": _ctx.value
                                    }, null, 8, ["not-found-content"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "SAC",
                                  name: "sac"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, { placeholder: "Enter SAC" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Unit",
                                  name: "unit"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode("h4", { class: "t1" }, "Pricing & Tax"),
                        createVNode(_component_a_row, { gutter: 24 }, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Rate (INR)",
                                  name: "rate"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input_number, {
                                      placeholder: "Enter service rate",
                                      style: { "width": "100%" }
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, {
                              class: "gutter-row",
                              span: 12
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Tax",
                                  name: "tax"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      "show-search": "",
                                      placeholder: "Tax",
                                      "default-active-first-option": false,
                                      "not-found-content": _ctx.value
                                    }, null, 8, ["not-found-content"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode("h4", { class: "t1" }, "Description"),
                        createVNode(_component_a_form_item, {
                          label: "Description",
                          name: "description"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_textarea, { placeholder: "Enter Description" })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit",
                              disabled: $data.form.processing
                            }, {
                              default: withCtx(() => [
                                createTextVNode("SUBMIT")
                              ]),
                              _: 1
                            }, 8, ["disabled"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 16, ["model", "loading", "validate-messages", "onFinish"])
                  ]),
                  _: 1
                }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"]),
                createVNode(_component_a_drawer, {
                  visible: $data.serviceDetailDrawer,
                  "onUpdate:visible": ($event) => $data.serviceDetailDrawer = $event,
                  class: "custom-class",
                  title: "Service 1",
                  size: "large",
                  placement: "right",
                  onAfterVisibleChange: _ctx.afterVisibleChange
                }, {
                  extra: withCtx(() => [
                    createVNode(_component_a_space, null, {
                      default: withCtx(() => [
                        createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                          default: withCtx(() => [
                            createTextVNode("Edit")
                          ]),
                          _: 1
                        }, 8, ["onClick"]),
                        createVNode(_component_a_button, {
                          type: "primary",
                          onClick: _ctx.onClose
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Delete")
                          ]),
                          _: 1
                        }, 8, ["onClick"])
                      ]),
                      _: 1
                    })
                  ]),
                  default: withCtx(() => [
                    createVNode(_component_a_tabs, {
                      activeKey: _ctx.activeKey,
                      "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_tab_pane, {
                          key: "Overview",
                          tab: "Overview"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_descriptions, { size: _ctx.size }, {
                              default: withCtx(() => [
                                createVNode(_component_a_descriptions_item, {
                                  label: "Service Name",
                                  span: 4
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Service 1")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_descriptions_item, { label: "Description" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["size"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_tab_pane, {
                          key: "Transactions",
                          tab: "Transactions",
                          "force-render": ""
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_space, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_select, {
                                  ref: "select",
                                  placeholder: "Filter By"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select_option, { value: "jack" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Invoice")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "lucy" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Sales Order")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "disabled" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Quote")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Purchase Order")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 512),
                                createVNode(_component_a_select, {
                                  ref: "select",
                                  placeholder: "Status"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select_option, { value: "jack" }, {
                                      default: withCtx(() => [
                                        createTextVNode("All")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "lucy" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Draft")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 512)
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_table, {
                              columns: $setup.invoicetransactions_column,
                              "data-source": $setup.invoicetransactions
                            }, null, 8, ["columns", "data-source"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["activeKey", "onUpdate:activeKey"])
                  ]),
                  _: 1
                }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_layout_content, null, {
            default: withCtx(() => [
              createVNode(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, {
                    name: "nest-messages",
                    model: $data.form,
                    layout: "inline",
                    onFinish: _ctx.search
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            placeholder: "Search by service name",
                            "allow-clear": true,
                            value: $data.searchform.term,
                            "onUpdate:value": ($event) => $data.searchform.term = $event
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Search ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            shape: "round",
                            onClick: $options.showDrawer
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_plus_circle_outlined)
                            ]),
                            default: withCtx(() => [
                              createTextVNode(" Add New Service ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            shape: "round",
                            onClick: $options.showDrawer
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_CloudUploadOutlined)
                            ]),
                            default: withCtx(() => [
                              createTextVNode(" Import ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["model", "onFinish"]),
                  createVNode(_component_a_table, {
                    columns: $setup.columns,
                    "data-source": $setup.services,
                    pagination: $setup.pagination
                  }, {
                    bodyCell: withCtx(({ column, record }) => [
                      column.key === "name" ? (openBlock(), createBlock("a", {
                        key: 0,
                        onClick: $options.showServiceDetailDrawer
                      }, toDisplayString(record.name), 9, ["onClick"])) : createCommentVNode("", true),
                      column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 1 }, {
                        overlay: withCtx(() => [
                          createVNode(_component_a_menu, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, null, {
                                default: withCtx(() => [
                                  createVNode("a", { href: "javascript:;" }, [
                                    createVNode(_component_edit_outlined),
                                    createTextVNode(" Edit ")
                                  ])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_menu_item, null, {
                                default: withCtx(() => [
                                  createVNode("a", { href: "javascript:;" }, [
                                    createVNode(_component_delete_outlined),
                                    createTextVNode(" Delete ")
                                  ])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            size: _ctx.size,
                            class: "ant-dropdown-link",
                            shape: "circle"
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_DownCircleOutlined)
                            ]),
                            _: 1
                          }, 8, ["size"])
                        ]),
                        _: 1
                      })) : createCommentVNode("", true)
                    ]),
                    _: 1
                  }, 8, ["columns", "data-source", "pagination"])
                ]),
                _: 1
              }),
              createVNode(_component_a_drawer, {
                visible: $data.createvisible,
                "onUpdate:visible": ($event) => $data.createvisible = $event,
                class: "custom-class",
                title: "New Service",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, mergeProps({ model: $data.form }, $data.layout, {
                    name: "nest-messages",
                    loading: _ctx.formloading,
                    "validate-messages": _ctx.validateMessages,
                    onFinish: _ctx.submit,
                    "label-col": { span: 24 }
                  }), {
                    default: withCtx(() => [
                      createVNode("h4", { class: "t1" }, "Details"),
                      createVNode(_component_a_row, { gutter: 24 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Service Name",
                                name: "name",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Please enter service name" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Category",
                                name: "name",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    "show-search": "",
                                    placeholder: "Select Category",
                                    "default-active-first-option": false,
                                    "not-found-content": _ctx.value
                                  }, null, 8, ["not-found-content"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "SAC",
                                name: "sac"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, { placeholder: "Enter SAC" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Unit",
                                name: "unit"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_auto_complete, { placeholder: "Select Unit" })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode("h4", { class: "t1" }, "Pricing & Tax"),
                      createVNode(_component_a_row, { gutter: 24 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Rate (INR)",
                                name: "rate"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input_number, {
                                    placeholder: "Enter service rate",
                                    style: { "width": "100%" }
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, {
                            class: "gutter-row",
                            span: 12
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Tax",
                                name: "tax"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    "show-search": "",
                                    placeholder: "Tax",
                                    "default-active-first-option": false,
                                    "not-found-content": _ctx.value
                                  }, null, 8, ["not-found-content"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode("h4", { class: "t1" }, "Description"),
                      createVNode(_component_a_form_item, {
                        label: "Description",
                        name: "description"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_textarea, { placeholder: "Enter Description" })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, { "wrapper-col": { span: 12 } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit",
                            disabled: $data.form.processing
                          }, {
                            default: withCtx(() => [
                              createTextVNode("SUBMIT")
                            ]),
                            _: 1
                          }, 8, ["disabled"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 16, ["model", "loading", "validate-messages", "onFinish"])
                ]),
                _: 1
              }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"]),
              createVNode(_component_a_drawer, {
                visible: $data.serviceDetailDrawer,
                "onUpdate:visible": ($event) => $data.serviceDetailDrawer = $event,
                class: "custom-class",
                title: "Service 1",
                size: "large",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                extra: withCtx(() => [
                  createVNode(_component_a_space, null, {
                    default: withCtx(() => [
                      createVNode(_component_a_button, { onClick: _ctx.onClose }, {
                        default: withCtx(() => [
                          createTextVNode("Edit")
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_button, {
                        type: "primary",
                        onClick: _ctx.onClose
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Delete")
                        ]),
                        _: 1
                      }, 8, ["onClick"])
                    ]),
                    _: 1
                  })
                ]),
                default: withCtx(() => [
                  createVNode(_component_a_tabs, {
                    activeKey: _ctx.activeKey,
                    "onUpdate:activeKey": ($event) => _ctx.activeKey = $event
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_tab_pane, {
                        key: "Overview",
                        tab: "Overview"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_descriptions, { size: _ctx.size }, {
                            default: withCtx(() => [
                              createVNode(_component_a_descriptions_item, {
                                label: "Service Name",
                                span: 4
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Service 1")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_descriptions_item, { label: "Description" }, {
                                default: withCtx(() => [
                                  createTextVNode("Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["size"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_tab_pane, {
                        key: "Transactions",
                        tab: "Transactions",
                        "force-render": ""
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_space, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_select, {
                                ref: "select",
                                placeholder: "Filter By"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select_option, { value: "jack" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Invoice")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "lucy" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Sales Order")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "disabled" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Quote")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Yiminghe" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Purchase Order")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 512),
                              createVNode(_component_a_select, {
                                ref: "select",
                                placeholder: "Status"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select_option, { value: "jack" }, {
                                    default: withCtx(() => [
                                      createTextVNode("All")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "lucy" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Draft")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 512)
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_table, {
                            columns: $setup.invoicetransactions_column,
                            "data-source": $setup.invoicetransactions
                          }, null, 8, ["columns", "data-source"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["activeKey", "onUpdate:activeKey"])
                ]),
                _: 1
              }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"])
            ]),
            _: 1
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Service/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Index as default
};
