import { unref, withCtx, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderStyle } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import { Head } from "@inertiajs/vue3";
import "ant-design-vue";
import "@ant-design/icons-vue";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Pos" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="dashboard-content-one"${_scopeId}><div class="row mt-5"${_scopeId}><div class="col-md-9"${_scopeId}><div class="input-group mb-3 mt-3"${_scopeId}><div class="input-group-prepend"${_scopeId}><span class="input-group-text" id="basic-addon1"${_scopeId}><i class="fa fa-search"${_scopeId}></i></span></div><input type="text" class="form-control" placeholder="Search" aria-label="Search"${_scopeId}></div><div class="row"${_scopeId}><div class="col-md-2 pl-2 pr-2"${_scopeId}><div class="card item-card text-center"${_scopeId}><div class="card-body"${_scopeId}><img src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg" alt="Item"${_scopeId}><p class="mb-1"${_scopeId}>Burger - Md</p><p class="mb-0"${_scopeId}>Rs. 10</p></div></div></div><div class="col-md-2 pl-2 pr-2"${_scopeId}><div class="card item-card text-center"${_scopeId}><div class="card-body"${_scopeId}><img src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg" alt="Item"${_scopeId}><p class="mb-1"${_scopeId}>Burger - Md</p><p class="mb-0"${_scopeId}>Rs. 10</p></div></div></div><div class="col-md-2 pl-2 pr-2"${_scopeId}><div class="card item-card text-center"${_scopeId}><div class="card-body"${_scopeId}><img src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg" alt="Item"${_scopeId}><p class="mb-1"${_scopeId}>Burger - Md</p><p class="mb-0"${_scopeId}>Rs. 10</p></div></div></div><div class="col-md-2 pl-2 pr-2"${_scopeId}><div class="card item-card text-center"${_scopeId}><div class="card-body"${_scopeId}><img src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg" alt="Item"${_scopeId}><p class="mb-1"${_scopeId}>Burger - Md</p><p class="mb-0"${_scopeId}>Rs. 10</p></div></div></div><div class="col-md-2 pl-2 pr-2"${_scopeId}><div class="card item-card text-center"${_scopeId}><div class="card-body"${_scopeId}><img src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg" alt="Item"${_scopeId}><p class="mb-1"${_scopeId}>Burger - Md</p><p class="mb-0"${_scopeId}>Rs. 10</p></div></div></div><div class="col-md-2 pl-2 pr-2"${_scopeId}><div class="card item-card text-center"${_scopeId}><div class="card-body"${_scopeId}><img src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg" alt="Item"${_scopeId}><p class="mb-1"${_scopeId}>Burger - Md</p><p class="mb-0"${_scopeId}>Rs. 10</p></div></div></div><div class="col-md-2 pl-2 pr-2"${_scopeId}><div class="card item-card text-center"${_scopeId}><div class="card-body"${_scopeId}><img src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg" alt="Item"${_scopeId}><p class="mb-1"${_scopeId}>Burger - Md</p><p class="mb-0"${_scopeId}>Rs. 10</p></div></div></div><div class="col-md-2 pl-2 pr-2"${_scopeId}><div class="card item-card text-center"${_scopeId}><div class="card-body"${_scopeId}><img src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg" alt="Item"${_scopeId}><p class="mb-1"${_scopeId}>Burger - Md</p><p class="mb-0"${_scopeId}>Rs. 10</p></div></div></div><div class="col-md-2 pl-2 pr-2"${_scopeId}><div class="card item-card text-center"${_scopeId}><div class="card-body"${_scopeId}><img src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg" alt="Item"${_scopeId}><p class="mb-1"${_scopeId}>Burger - Md</p><p class="mb-0"${_scopeId}>Rs. 10</p></div></div></div><div class="col-md-2 pl-2 pr-2"${_scopeId}><div class="card item-card text-center"${_scopeId}><div class="card-body"${_scopeId}><img src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg" alt="Item"${_scopeId}><p class="mb-1"${_scopeId}>Burger - Md</p><p class="mb-0"${_scopeId}>Rs. 10</p></div></div></div><div class="col-md-2 pl-2 pr-2"${_scopeId}><div class="card item-card text-center"${_scopeId}><div class="card-body"${_scopeId}><img src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg" alt="Item"${_scopeId}><p class="mb-1"${_scopeId}>Burger - Md</p><p class="mb-0"${_scopeId}>Rs. 10</p></div></div></div><div class="col-md-2 pl-2 pr-2"${_scopeId}><div class="card item-card text-center"${_scopeId}><div class="card-body"${_scopeId}><img src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg" alt="Item"${_scopeId}><p class="mb-1"${_scopeId}>Burger - Md</p><p class="mb-0"${_scopeId}>Rs. 10</p></div></div></div></div></div><div class="col-md-3"${_scopeId}><div class="card"${_scopeId}><div class="card-body p-2"${_scopeId}><div class="row"${_scopeId}><div class="col-md-10"${_scopeId}><select class="form-control"${_scopeId}><option value=""${_scopeId}>Select Customer</option></select></div><div class="col-md-2 text-right"${_scopeId}><a href="#"${_scopeId}><i class="fa fa-trash fa-2x"${_scopeId}></i></a></div></div><hr${_scopeId}><table class="table table-borderless"${_scopeId}><tr${_scopeId}><td${_scopeId}><img style="${ssrRenderStyle({ "max-width": "30px" })}" src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg" alt="Item"${_scopeId}></td><td${_scopeId}><p class="m-0"${_scopeId}>Burger - Md</p><p class="m-0"${_scopeId}>Rs.10</p></td><td${_scopeId}><div class="input-group mb-3" style="${ssrRenderStyle({ "max-width": "100px" })}"${_scopeId}><div class="input-group-prepend"${_scopeId}><button class="btn btn-outline-secondary btn-sm" type="button"${_scopeId}><i class="fa fa-minus"${_scopeId}></i></button></div><input type="text" class="form-control" aria-label="Amount (to the nearest dollar)"${_scopeId}><div class="input-group-append"${_scopeId}><button class="btn btn-outline-secondary btn-sm" type="button"${_scopeId}><i class="fa fa-plus"${_scopeId}></i></button></div></div></td></tr><tr${_scopeId}><td${_scopeId}><img style="${ssrRenderStyle({ "max-width": "30px" })}" src="https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg" alt="Item"${_scopeId}></td><td${_scopeId}><p class="m-0"${_scopeId}>Burger - Md</p><p class="m-0"${_scopeId}>Rs.10</p></td><td${_scopeId}><div class="input-group mb-3" style="${ssrRenderStyle({ "max-width": "100px" })}"${_scopeId}><div class="input-group-prepend"${_scopeId}><button class="btn btn-outline-secondary btn-sm" type="button"${_scopeId}><i class="fa fa-minus"${_scopeId}></i></button></div><input type="text" class="form-control" aria-label="Amount (to the nearest dollar)"${_scopeId}><div class="input-group-append"${_scopeId}><button class="btn btn-outline-secondary btn-sm" type="button"${_scopeId}><i class="fa fa-plus"${_scopeId}></i></button></div></div></td></tr></table></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "dashboard-content-one" }, [
                createVNode("div", { class: "row mt-5" }, [
                  createVNode("div", { class: "col-md-9" }, [
                    createVNode("div", { class: "input-group mb-3 mt-3" }, [
                      createVNode("div", { class: "input-group-prepend" }, [
                        createVNode("span", {
                          class: "input-group-text",
                          id: "basic-addon1"
                        }, [
                          createVNode("i", { class: "fa fa-search" })
                        ])
                      ]),
                      createVNode("input", {
                        type: "text",
                        class: "form-control",
                        placeholder: "Search",
                        "aria-label": "Search"
                      })
                    ]),
                    createVNode("div", { class: "row" }, [
                      createVNode("div", { class: "col-md-2 pl-2 pr-2" }, [
                        createVNode("div", { class: "card item-card text-center" }, [
                          createVNode("div", { class: "card-body" }, [
                            createVNode("img", {
                              src: "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg",
                              alt: "Item"
                            }),
                            createVNode("p", { class: "mb-1" }, "Burger - Md"),
                            createVNode("p", { class: "mb-0" }, "Rs. 10")
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "col-md-2 pl-2 pr-2" }, [
                        createVNode("div", { class: "card item-card text-center" }, [
                          createVNode("div", { class: "card-body" }, [
                            createVNode("img", {
                              src: "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg",
                              alt: "Item"
                            }),
                            createVNode("p", { class: "mb-1" }, "Burger - Md"),
                            createVNode("p", { class: "mb-0" }, "Rs. 10")
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "col-md-2 pl-2 pr-2" }, [
                        createVNode("div", { class: "card item-card text-center" }, [
                          createVNode("div", { class: "card-body" }, [
                            createVNode("img", {
                              src: "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg",
                              alt: "Item"
                            }),
                            createVNode("p", { class: "mb-1" }, "Burger - Md"),
                            createVNode("p", { class: "mb-0" }, "Rs. 10")
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "col-md-2 pl-2 pr-2" }, [
                        createVNode("div", { class: "card item-card text-center" }, [
                          createVNode("div", { class: "card-body" }, [
                            createVNode("img", {
                              src: "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg",
                              alt: "Item"
                            }),
                            createVNode("p", { class: "mb-1" }, "Burger - Md"),
                            createVNode("p", { class: "mb-0" }, "Rs. 10")
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "col-md-2 pl-2 pr-2" }, [
                        createVNode("div", { class: "card item-card text-center" }, [
                          createVNode("div", { class: "card-body" }, [
                            createVNode("img", {
                              src: "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg",
                              alt: "Item"
                            }),
                            createVNode("p", { class: "mb-1" }, "Burger - Md"),
                            createVNode("p", { class: "mb-0" }, "Rs. 10")
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "col-md-2 pl-2 pr-2" }, [
                        createVNode("div", { class: "card item-card text-center" }, [
                          createVNode("div", { class: "card-body" }, [
                            createVNode("img", {
                              src: "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg",
                              alt: "Item"
                            }),
                            createVNode("p", { class: "mb-1" }, "Burger - Md"),
                            createVNode("p", { class: "mb-0" }, "Rs. 10")
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "col-md-2 pl-2 pr-2" }, [
                        createVNode("div", { class: "card item-card text-center" }, [
                          createVNode("div", { class: "card-body" }, [
                            createVNode("img", {
                              src: "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg",
                              alt: "Item"
                            }),
                            createVNode("p", { class: "mb-1" }, "Burger - Md"),
                            createVNode("p", { class: "mb-0" }, "Rs. 10")
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "col-md-2 pl-2 pr-2" }, [
                        createVNode("div", { class: "card item-card text-center" }, [
                          createVNode("div", { class: "card-body" }, [
                            createVNode("img", {
                              src: "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg",
                              alt: "Item"
                            }),
                            createVNode("p", { class: "mb-1" }, "Burger - Md"),
                            createVNode("p", { class: "mb-0" }, "Rs. 10")
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "col-md-2 pl-2 pr-2" }, [
                        createVNode("div", { class: "card item-card text-center" }, [
                          createVNode("div", { class: "card-body" }, [
                            createVNode("img", {
                              src: "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg",
                              alt: "Item"
                            }),
                            createVNode("p", { class: "mb-1" }, "Burger - Md"),
                            createVNode("p", { class: "mb-0" }, "Rs. 10")
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "col-md-2 pl-2 pr-2" }, [
                        createVNode("div", { class: "card item-card text-center" }, [
                          createVNode("div", { class: "card-body" }, [
                            createVNode("img", {
                              src: "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg",
                              alt: "Item"
                            }),
                            createVNode("p", { class: "mb-1" }, "Burger - Md"),
                            createVNode("p", { class: "mb-0" }, "Rs. 10")
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "col-md-2 pl-2 pr-2" }, [
                        createVNode("div", { class: "card item-card text-center" }, [
                          createVNode("div", { class: "card-body" }, [
                            createVNode("img", {
                              src: "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg",
                              alt: "Item"
                            }),
                            createVNode("p", { class: "mb-1" }, "Burger - Md"),
                            createVNode("p", { class: "mb-0" }, "Rs. 10")
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "col-md-2 pl-2 pr-2" }, [
                        createVNode("div", { class: "card item-card text-center" }, [
                          createVNode("div", { class: "card-body" }, [
                            createVNode("img", {
                              src: "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg",
                              alt: "Item"
                            }),
                            createVNode("p", { class: "mb-1" }, "Burger - Md"),
                            createVNode("p", { class: "mb-0" }, "Rs. 10")
                          ])
                        ])
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "col-md-3" }, [
                    createVNode("div", { class: "card" }, [
                      createVNode("div", { class: "card-body p-2" }, [
                        createVNode("div", { class: "row" }, [
                          createVNode("div", { class: "col-md-10" }, [
                            createVNode("select", { class: "form-control" }, [
                              createVNode("option", { value: "" }, "Select Customer")
                            ])
                          ]),
                          createVNode("div", { class: "col-md-2 text-right" }, [
                            createVNode("a", { href: "#" }, [
                              createVNode("i", { class: "fa fa-trash fa-2x" })
                            ])
                          ])
                        ]),
                        createVNode("hr"),
                        createVNode("table", { class: "table table-borderless" }, [
                          createVNode("tr", null, [
                            createVNode("td", null, [
                              createVNode("img", {
                                style: { "max-width": "30px" },
                                src: "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg",
                                alt: "Item"
                              })
                            ]),
                            createVNode("td", null, [
                              createVNode("p", { class: "m-0" }, "Burger - Md"),
                              createVNode("p", { class: "m-0" }, "Rs.10")
                            ]),
                            createVNode("td", null, [
                              createVNode("div", {
                                class: "input-group mb-3",
                                style: { "max-width": "100px" }
                              }, [
                                createVNode("div", { class: "input-group-prepend" }, [
                                  createVNode("button", {
                                    class: "btn btn-outline-secondary btn-sm",
                                    type: "button"
                                  }, [
                                    createVNode("i", { class: "fa fa-minus" })
                                  ])
                                ]),
                                createVNode("input", {
                                  type: "text",
                                  class: "form-control",
                                  "aria-label": "Amount (to the nearest dollar)"
                                }),
                                createVNode("div", { class: "input-group-append" }, [
                                  createVNode("button", {
                                    class: "btn btn-outline-secondary btn-sm",
                                    type: "button"
                                  }, [
                                    createVNode("i", { class: "fa fa-plus" })
                                  ])
                                ])
                              ])
                            ])
                          ]),
                          createVNode("tr", null, [
                            createVNode("td", null, [
                              createVNode("img", {
                                style: { "max-width": "30px" },
                                src: "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2012/6/1/2/FNM_070112-Copy-That-Almost-Famous-Animal-Style-Burger-Recipe_s4x3.jpg.rend.hgtvcom.616.462.suffix/1382541460839.jpeg",
                                alt: "Item"
                              })
                            ]),
                            createVNode("td", null, [
                              createVNode("p", { class: "m-0" }, "Burger - Md"),
                              createVNode("p", { class: "m-0" }, "Rs.10")
                            ]),
                            createVNode("td", null, [
                              createVNode("div", {
                                class: "input-group mb-3",
                                style: { "max-width": "100px" }
                              }, [
                                createVNode("div", { class: "input-group-prepend" }, [
                                  createVNode("button", {
                                    class: "btn btn-outline-secondary btn-sm",
                                    type: "button"
                                  }, [
                                    createVNode("i", { class: "fa fa-minus" })
                                  ])
                                ]),
                                createVNode("input", {
                                  type: "text",
                                  class: "form-control",
                                  "aria-label": "Amount (to the nearest dollar)"
                                }),
                                createVNode("div", { class: "input-group-append" }, [
                                  createVNode("button", {
                                    class: "btn btn-outline-secondary btn-sm",
                                    type: "button"
                                  }, [
                                    createVNode("i", { class: "fa fa-plus" })
                                  ])
                                ])
                              ])
                            ])
                          ])
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Pos/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
