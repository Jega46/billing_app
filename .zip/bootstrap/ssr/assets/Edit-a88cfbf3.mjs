import { resolveComponent, withCtx, createTextVNode, createVNode, mergeProps, useSSRContext } from "vue";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import { Head, useForm } from "@inertiajs/vue3";
import "dayjs";
import { ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
import "@ant-design/icons-vue";
const _sfc_main = {
  inject: ["validateMessages"],
  components: {
    AuthenticatedLayout: _sfc_main$1,
    Head
  },
  props: {
    branch: Object,
    errors: Object
  },
  setup(props) {
    const layout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 16 }
    };
    const formState = useForm({
      branch_name: props.branch.branch_name,
      address: props.branch.address
    });
    return {
      formState,
      layout
    };
  },
  mounted() {
  },
  methods: {
    triggerSubmit() {
      const btn = this.$refs.submitss;
      console.log(btn);
      btn.click();
    },
    submit() {
      this.formState.put(route("branches.update", this.branch.id));
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_affix = resolveComponent("a-affix");
  const _component_a_page_header = resolveComponent("a-page-header");
  const _component_a_button = resolveComponent("a-button");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_input = resolveComponent("a-input");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Branches" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_affix, { "offset-top": 0 }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_page_header, {
                ghost: false,
                title: $props.branch.branch_name,
                onBack: () => _ctx.$inertia.visit(_ctx.route("branches.index"))
              }, {
                extra: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_button, {
                      key: "1",
                      type: "primary",
                      onClick: ($event) => $options.triggerSubmit()
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`Save`);
                        } else {
                          return [
                            createTextVNode("Save")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_button, {
                        key: "1",
                        type: "primary",
                        onClick: ($event) => $options.triggerSubmit()
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Save")
                        ]),
                        _: 1
                      }, 8, ["onClick"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_page_header, {
                  ghost: false,
                  title: $props.branch.branch_name,
                  onBack: () => _ctx.$inertia.visit(_ctx.route("branches.index"))
                }, {
                  extra: withCtx(() => [
                    createVNode(_component_a_button, {
                      key: "1",
                      type: "primary",
                      onClick: ($event) => $options.triggerSubmit()
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Save")
                      ]),
                      _: 1
                    }, 8, ["onClick"])
                  ]),
                  _: 1
                }, 8, ["title", "onBack"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_layout_content, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_row, null, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_col, {
                      span: 12,
                      offset: 6
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                            name: "nest-messages",
                            "validate-messages": $options.validateMessages,
                            onFinish: $options.submit
                          }), {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`<h3${ssrRenderAttr("wrapper-col", { span: 12, offset: 6 })}${_scopeId5}> Basic </h3>`);
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Branch Name",
                                  name: "branch_name",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: $setup.formState.branch_name,
                                        "onUpdate:value": ($event) => $setup.formState.branch_name = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: $setup.formState.branch_name,
                                          "onUpdate:value": ($event) => $setup.formState.branch_name = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Address",
                                  name: "address",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: $setup.formState.address,
                                        "onUpdate:value": ($event) => $setup.formState.address = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: $setup.formState.address,
                                          "onUpdate:value": ($event) => $setup.formState.address = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        ref: "submitss",
                                        type: "primary",
                                        "html-type": "submit"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`Save`);
                                          } else {
                                            return [
                                              createTextVNode("Save")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          ref: "submitss",
                                          type: "primary",
                                          "html-type": "submit"
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("Save")
                                          ]),
                                          _: 1
                                        }, 512)
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Basic "),
                                  createVNode(_component_a_form_item, {
                                    label: "Branch Name",
                                    name: "branch_name",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $setup.formState.branch_name,
                                        "onUpdate:value": ($event) => $setup.formState.branch_name = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Address",
                                    name: "address",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: $setup.formState.address,
                                        "onUpdate:value": ($event) => $setup.formState.address = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        ref: "submitss",
                                        type: "primary",
                                        "html-type": "submit"
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Save")
                                        ]),
                                        _: 1
                                      }, 512)
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                              name: "nest-messages",
                              "validate-messages": $options.validateMessages,
                              onFinish: $options.submit
                            }), {
                              default: withCtx(() => [
                                createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Basic "),
                                createVNode(_component_a_form_item, {
                                  label: "Branch Name",
                                  name: "branch_name",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $setup.formState.branch_name,
                                      "onUpdate:value": ($event) => $setup.formState.branch_name = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Address",
                                  name: "address",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: $setup.formState.address,
                                      "onUpdate:value": ($event) => $setup.formState.address = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      ref: "submitss",
                                      type: "primary",
                                      "html-type": "submit"
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Save")
                                      ]),
                                      _: 1
                                    }, 512)
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 16, ["model", "validate-messages", "onFinish"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_col, {
                        span: 12,
                        offset: 6
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                            name: "nest-messages",
                            "validate-messages": $options.validateMessages,
                            onFinish: $options.submit
                          }), {
                            default: withCtx(() => [
                              createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Basic "),
                              createVNode(_component_a_form_item, {
                                label: "Branch Name",
                                name: "branch_name",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $setup.formState.branch_name,
                                    "onUpdate:value": ($event) => $setup.formState.branch_name = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Address",
                                name: "address",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: $setup.formState.address,
                                    "onUpdate:value": ($event) => $setup.formState.address = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    ref: "submitss",
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Save")
                                    ]),
                                    _: 1
                                  }, 512)
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 16, ["model", "validate-messages", "onFinish"])
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_a_col, {
                      span: 12,
                      offset: 6
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                          name: "nest-messages",
                          "validate-messages": $options.validateMessages,
                          onFinish: $options.submit
                        }), {
                          default: withCtx(() => [
                            createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Basic "),
                            createVNode(_component_a_form_item, {
                              label: "Branch Name",
                              name: "branch_name",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: $setup.formState.branch_name,
                                  "onUpdate:value": ($event) => $setup.formState.branch_name = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Address",
                              name: "address",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: $setup.formState.address,
                                  "onUpdate:value": ($event) => $setup.formState.address = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  ref: "submitss",
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Save")
                                  ]),
                                  _: 1
                                }, 512)
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 16, ["model", "validate-messages", "onFinish"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_affix, { "offset-top": 0 }, {
            default: withCtx(() => [
              createVNode(_component_a_page_header, {
                ghost: false,
                title: $props.branch.branch_name,
                onBack: () => _ctx.$inertia.visit(_ctx.route("branches.index"))
              }, {
                extra: withCtx(() => [
                  createVNode(_component_a_button, {
                    key: "1",
                    type: "primary",
                    onClick: ($event) => $options.triggerSubmit()
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Save")
                    ]),
                    _: 1
                  }, 8, ["onClick"])
                ]),
                _: 1
              }, 8, ["title", "onBack"])
            ]),
            _: 1
          }),
          createVNode(_component_a_layout_content, null, {
            default: withCtx(() => [
              createVNode(_component_a_row, null, {
                default: withCtx(() => [
                  createVNode(_component_a_col, {
                    span: 12,
                    offset: 6
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                        name: "nest-messages",
                        "validate-messages": $options.validateMessages,
                        onFinish: $options.submit
                      }), {
                        default: withCtx(() => [
                          createVNode("h3", { "wrapper-col": { span: 12, offset: 6 } }, " Basic "),
                          createVNode(_component_a_form_item, {
                            label: "Branch Name",
                            name: "branch_name",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: $setup.formState.branch_name,
                                "onUpdate:value": ($event) => $setup.formState.branch_name = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Address",
                            name: "address",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: $setup.formState.address,
                                "onUpdate:value": ($event) => $setup.formState.address = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                ref: "submitss",
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Save")
                                ]),
                                _: 1
                              }, 512)
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 16, ["model", "validate-messages", "onFinish"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Salesorder/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Edit = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Edit as default
};
