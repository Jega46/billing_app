import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import "vue-request";
import { resolveComponent, withCtx, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, createCommentVNode, useSSRContext } from "vue";
import { DownloadOutlined, PlusCircleOutlined, MoreOutlined } from "@ant-design/icons-vue";
import { Head, Link, useForm } from "@inertiajs/vue3";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
const Index_vue_vue_type_style_index_0_lang = "";
const columns = [
  {
    title: "ID",
    key: "id",
    dataIndex: "id",
    width: "10%"
  },
  {
    title: "Name",
    key: "name",
    dataIndex: "name",
    sorter: true,
    width: "20%"
  },
  {
    title: "Expense Type",
    key: "expensetype",
    dataIndex: "expensetype",
    width: "20%"
  },
  {
    title: "Amount",
    key: "amount",
    dataIndex: "amount",
    width: "10%"
  },
  {
    title: "Date",
    key: "date",
    dataIndex: "date",
    width: "20%"
  },
  {
    title: "Created Date",
    key: "created_at",
    dataIndex: "created_at",
    width: "20%"
  },
  {
    title: "Action",
    key: "action",
    fixed: "right",
    width: "2%"
  }
];
const _sfc_main = {
  components: { AuthenticatedLayout: _sfc_main$1, DownloadOutlined, PlusCircleOutlined, MoreOutlined, Head, Link },
  props: {
    expenses: Object,
    pagination: Object,
    errors: Object
  },
  setup(props) {
    return {
      columns
    };
  },
  data() {
    const loading = false;
    const formState = useForm({
      term: ""
    });
    return {
      loading,
      formState
    };
  },
  methods: {
    search() {
      this.$inertia.get("/expenses", { s: this.formState.term }, { preserveState: true });
    },
    handleTableChange(val) {
      this.$inertia.get(
        "/expenses",
        { page: val.current },
        { preserveState: true }
      );
    },
    deleteExpenses(id) {
      this.$inertia.delete(route("expensetype.destroy", id));
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_space = resolveComponent("a-space");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_button = resolveComponent("a-button");
  const _component_Link = resolveComponent("Link");
  const _component_plus_circle_outlined = resolveComponent("plus-circle-outlined");
  const _component_DownloadOutlined = resolveComponent("DownloadOutlined");
  const _component_a_table = resolveComponent("a-table");
  const _component_a_avatar = resolveComponent("a-avatar");
  const _component_a_dropdown = resolveComponent("a-dropdown");
  const _component_a_menu = resolveComponent("a-menu");
  const _component_a_menu_item = resolveComponent("a-menu-item");
  const _component_more_outlined = resolveComponent("more-outlined");
  const _component_DownOutlined = resolveComponent("DownOutlined");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Expenses" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_layout_content, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, {
                      name: "customized_form_controls",
                      layout: "inline",
                      model: $data.formState,
                      onFinish: _ctx.onFinish
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input, {
                                  value: _ctx.value,
                                  "onUpdate:value": ($event) => _ctx.value = $event,
                                  placeholder: "Search by Name, Email, Phone..."
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input, {
                                    value: _ctx.value,
                                    "onUpdate:value": ($event) => _ctx.value = $event,
                                    placeholder: "Search by Name, Email, Phone..."
                                  }, null, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`Search`);
                                    } else {
                                      return [
                                        createTextVNode("Search")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Search")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_Link, {
                                  href: _ctx.route("expensetype.create")
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "primary",
                                        shape: "round",
                                        size: _ctx.size
                                      }, {
                                        icon: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_plus_circle_outlined)
                                            ];
                                          }
                                        }),
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(` Add New Expense `);
                                          } else {
                                            return [
                                              createTextVNode(" Add New Expense ")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          shape: "round",
                                          size: _ctx.size
                                        }, {
                                          icon: withCtx(() => [
                                            createVNode(_component_plus_circle_outlined)
                                          ]),
                                          default: withCtx(() => [
                                            createTextVNode(" Add New Expense ")
                                          ]),
                                          _: 1
                                        }, 8, ["size"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_Link, {
                                    href: _ctx.route("expensetype.create")
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        shape: "round",
                                        size: _ctx.size
                                      }, {
                                        icon: withCtx(() => [
                                          createVNode(_component_plus_circle_outlined)
                                        ]),
                                        default: withCtx(() => [
                                          createTextVNode(" Add New Expense ")
                                        ]),
                                        _: 1
                                      }, 8, ["size"])
                                    ]),
                                    _: 1
                                  }, 8, ["href"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  size: _ctx.size
                                }, {
                                  icon: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_DownloadOutlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_DownloadOutlined)
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Export All `);
                                    } else {
                                      return [
                                        createTextVNode(" Export All ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    shape: "round",
                                    size: _ctx.size
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_DownloadOutlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Export All ")
                                    ]),
                                    _: 1
                                  }, 8, ["size"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: _ctx.value,
                                  "onUpdate:value": ($event) => _ctx.value = $event,
                                  placeholder: "Search by Name, Email, Phone..."
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Search")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_Link, {
                                  href: _ctx.route("expensetype.create")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      shape: "round",
                                      size: _ctx.size
                                    }, {
                                      icon: withCtx(() => [
                                        createVNode(_component_plus_circle_outlined)
                                      ]),
                                      default: withCtx(() => [
                                        createTextVNode(" Add New Expense ")
                                      ]),
                                      _: 1
                                    }, 8, ["size"])
                                  ]),
                                  _: 1
                                }, 8, ["href"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  size: _ctx.size
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_DownloadOutlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Export All ")
                                  ]),
                                  _: 1
                                }, 8, ["size"])
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_table, {
                      columns: $setup.columns,
                      "row-key": (expense) => expense.id,
                      "data-source": $props.expenses.data,
                      pagination: $props.pagination,
                      loading: $data.loading,
                      onChange: $options.handleTableChange
                    }, {
                      bodyCell: withCtx(({ column, text, record }, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          if (column.key === "expenseid") {
                            _push5(`<!--[-->${ssrInterpolate(text ?? "-")}<!--]-->`);
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "name") {
                            _push5(`<!--[-->`);
                            _push5(ssrRenderComponent(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(`${ssrInterpolate(text[0].toUpperCase())}`);
                                } else {
                                  return [
                                    createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                            _push5(`   ${ssrInterpolate(text)}<!--]-->`);
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "action") {
                            _push5(ssrRenderComponent(_component_a_dropdown, null, {
                              overlay: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(ssrRenderComponent(_component_a_menu, null, {
                                    default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_Link, {
                                          href: _ctx.route("expensetype.edit", record.id)
                                        }, {
                                          default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(ssrRenderComponent(_component_a_menu_item, { key: "1" }, {
                                                default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                  if (_push9) {
                                                    _push9(` Edit Expenses `);
                                                  } else {
                                                    return [
                                                      createTextVNode(" Edit Expenses ")
                                                    ];
                                                  }
                                                }),
                                                _: 2
                                              }, _parent8, _scopeId7));
                                            } else {
                                              return [
                                                createVNode(_component_a_menu_item, { key: "1" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode(" Edit Expenses ")
                                                  ]),
                                                  _: 1
                                                })
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                        _push7(ssrRenderComponent(_component_a_menu_item, {
                                          key: "2",
                                          onClick: ($event) => $options.deleteExpenses(record.id)
                                        }, {
                                          default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(` Delete Expenses `);
                                            } else {
                                              return [
                                                createTextVNode(" Delete Expenses ")
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_Link, {
                                            href: _ctx.route("expensetype.edit", record.id)
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_menu_item, { key: "1" }, {
                                                default: withCtx(() => [
                                                  createTextVNode(" Edit Expenses ")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 2
                                          }, 1032, ["href"]),
                                          createVNode(_component_a_menu_item, {
                                            key: "2",
                                            onClick: ($event) => $options.deleteExpenses(record.id)
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(" Delete Expenses ")
                                            ]),
                                            _: 2
                                          }, 1032, ["onClick"])
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  return [
                                    createVNode(_component_a_menu, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_Link, {
                                          href: _ctx.route("expensetype.edit", record.id)
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_menu_item, { key: "1" }, {
                                              default: withCtx(() => [
                                                createTextVNode(" Edit Expenses ")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 2
                                        }, 1032, ["href"]),
                                        createVNode(_component_a_menu_item, {
                                          key: "2",
                                          onClick: ($event) => $options.deleteExpenses(record.id)
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(" Delete Expenses ")
                                          ]),
                                          _: 2
                                        }, 1032, ["onClick"])
                                      ]),
                                      _: 2
                                    }, 1024)
                                  ];
                                }
                              }),
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(ssrRenderComponent(_component_a_button, null, {
                                    default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_more_outlined, null, null, _parent7, _scopeId6));
                                        _push7(ssrRenderComponent(_component_DownOutlined, null, null, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_more_outlined),
                                          createVNode(_component_DownOutlined)
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  return [
                                    createVNode(_component_a_button, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_more_outlined),
                                        createVNode(_component_DownOutlined)
                                      ]),
                                      _: 1
                                    })
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                          } else {
                            _push5(`<!---->`);
                          }
                        } else {
                          return [
                            column.key === "expenseid" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                              createTextVNode(toDisplayString(text ?? "-"), 1)
                            ], 64)) : createCommentVNode("", true),
                            column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                              createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                                ]),
                                _: 2
                              }, 1024),
                              createTextVNode("   " + toDisplayString(text), 1)
                            ], 64)) : createCommentVNode("", true),
                            column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 2 }, {
                              overlay: withCtx(() => [
                                createVNode(_component_a_menu, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_Link, {
                                      href: _ctx.route("expensetype.edit", record.id)
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_menu_item, { key: "1" }, {
                                          default: withCtx(() => [
                                            createTextVNode(" Edit Expenses ")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 2
                                    }, 1032, ["href"]),
                                    createVNode(_component_a_menu_item, {
                                      key: "2",
                                      onClick: ($event) => $options.deleteExpenses(record.id)
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(" Delete Expenses ")
                                      ]),
                                      _: 2
                                    }, 1032, ["onClick"])
                                  ]),
                                  _: 2
                                }, 1024)
                              ]),
                              default: withCtx(() => [
                                createVNode(_component_a_button, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_more_outlined),
                                    createVNode(_component_DownOutlined)
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 2
                            }, 1024)) : createCommentVNode("", true)
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, {
                        name: "customized_form_controls",
                        layout: "inline",
                        model: $data.formState,
                        onFinish: _ctx.onFinish
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: _ctx.value,
                                "onUpdate:value": ($event) => _ctx.value = $event,
                                placeholder: "Search by Name, Email, Phone..."
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Search")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_Link, {
                                href: _ctx.route("expensetype.create")
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    shape: "round",
                                    size: _ctx.size
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" Add New Expense ")
                                    ]),
                                    _: 1
                                  }, 8, ["size"])
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                shape: "round",
                                size: _ctx.size
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_DownloadOutlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Export All ")
                                ]),
                                _: 1
                              }, 8, ["size"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["model", "onFinish"]),
                      createVNode(_component_a_table, {
                        columns: $setup.columns,
                        "row-key": (expense) => expense.id,
                        "data-source": $props.expenses.data,
                        pagination: $props.pagination,
                        loading: $data.loading,
                        onChange: $options.handleTableChange
                      }, {
                        bodyCell: withCtx(({ column, text, record }) => [
                          column.key === "expenseid" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                            createTextVNode(toDisplayString(text ?? "-"), 1)
                          ], 64)) : createCommentVNode("", true),
                          column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                            createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                              ]),
                              _: 2
                            }, 1024),
                            createTextVNode("   " + toDisplayString(text), 1)
                          ], 64)) : createCommentVNode("", true),
                          column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 2 }, {
                            overlay: withCtx(() => [
                              createVNode(_component_a_menu, null, {
                                default: withCtx(() => [
                                  createVNode(_component_Link, {
                                    href: _ctx.route("expensetype.edit", record.id)
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_menu_item, { key: "1" }, {
                                        default: withCtx(() => [
                                          createTextVNode(" Edit Expenses ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 2
                                  }, 1032, ["href"]),
                                  createVNode(_component_a_menu_item, {
                                    key: "2",
                                    onClick: ($event) => $options.deleteExpenses(record.id)
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Delete Expenses ")
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"])
                                ]),
                                _: 2
                              }, 1024)
                            ]),
                            default: withCtx(() => [
                              createVNode(_component_a_button, null, {
                                default: withCtx(() => [
                                  createVNode(_component_more_outlined),
                                  createVNode(_component_DownOutlined)
                                ]),
                                _: 1
                              })
                            ]),
                            _: 2
                          }, 1024)) : createCommentVNode("", true)
                        ]),
                        _: 1
                      }, 8, ["columns", "row-key", "data-source", "pagination", "loading", "onChange"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_space, {
                  direction: "vertical",
                  style: { width: "100%" }
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, {
                      name: "customized_form_controls",
                      layout: "inline",
                      model: $data.formState,
                      onFinish: _ctx.onFinish
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, {
                              value: _ctx.value,
                              "onUpdate:value": ($event) => _ctx.value = $event,
                              placeholder: "Search by Name, Email, Phone..."
                            }, null, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Search")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_Link, {
                              href: _ctx.route("expensetype.create")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  size: _ctx.size
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" Add New Expense ")
                                  ]),
                                  _: 1
                                }, 8, ["size"])
                              ]),
                              _: 1
                            }, 8, ["href"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              shape: "round",
                              size: _ctx.size
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_DownloadOutlined)
                              ]),
                              default: withCtx(() => [
                                createTextVNode(" Export All ")
                              ]),
                              _: 1
                            }, 8, ["size"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["model", "onFinish"]),
                    createVNode(_component_a_table, {
                      columns: $setup.columns,
                      "row-key": (expense) => expense.id,
                      "data-source": $props.expenses.data,
                      pagination: $props.pagination,
                      loading: $data.loading,
                      onChange: $options.handleTableChange
                    }, {
                      bodyCell: withCtx(({ column, text, record }) => [
                        column.key === "expenseid" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                          createTextVNode(toDisplayString(text ?? "-"), 1)
                        ], 64)) : createCommentVNode("", true),
                        column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                          createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                            ]),
                            _: 2
                          }, 1024),
                          createTextVNode("   " + toDisplayString(text), 1)
                        ], 64)) : createCommentVNode("", true),
                        column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 2 }, {
                          overlay: withCtx(() => [
                            createVNode(_component_a_menu, null, {
                              default: withCtx(() => [
                                createVNode(_component_Link, {
                                  href: _ctx.route("expensetype.edit", record.id)
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "1" }, {
                                      default: withCtx(() => [
                                        createTextVNode(" Edit Expenses ")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 2
                                }, 1032, ["href"]),
                                createVNode(_component_a_menu_item, {
                                  key: "2",
                                  onClick: ($event) => $options.deleteExpenses(record.id)
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Delete Expenses ")
                                  ]),
                                  _: 2
                                }, 1032, ["onClick"])
                              ]),
                              _: 2
                            }, 1024)
                          ]),
                          default: withCtx(() => [
                            createVNode(_component_a_button, null, {
                              default: withCtx(() => [
                                createVNode(_component_more_outlined),
                                createVNode(_component_DownOutlined)
                              ]),
                              _: 1
                            })
                          ]),
                          _: 2
                        }, 1024)) : createCommentVNode("", true)
                      ]),
                      _: 1
                    }, 8, ["columns", "row-key", "data-source", "pagination", "loading", "onChange"])
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_layout_content, null, {
            default: withCtx(() => [
              createVNode(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, {
                    name: "customized_form_controls",
                    layout: "inline",
                    model: $data.formState,
                    onFinish: _ctx.onFinish
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            value: _ctx.value,
                            "onUpdate:value": ($event) => _ctx.value = $event,
                            placeholder: "Search by Name, Email, Phone..."
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Search")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_Link, {
                            href: _ctx.route("expensetype.create")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                shape: "round",
                                size: _ctx.size
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" Add New Expense ")
                                ]),
                                _: 1
                              }, 8, ["size"])
                            ]),
                            _: 1
                          }, 8, ["href"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            shape: "round",
                            size: _ctx.size
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_DownloadOutlined)
                            ]),
                            default: withCtx(() => [
                              createTextVNode(" Export All ")
                            ]),
                            _: 1
                          }, 8, ["size"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["model", "onFinish"]),
                  createVNode(_component_a_table, {
                    columns: $setup.columns,
                    "row-key": (expense) => expense.id,
                    "data-source": $props.expenses.data,
                    pagination: $props.pagination,
                    loading: $data.loading,
                    onChange: $options.handleTableChange
                  }, {
                    bodyCell: withCtx(({ column, text, record }) => [
                      column.key === "expenseid" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                        createTextVNode(toDisplayString(text ?? "-"), 1)
                      ], 64)) : createCommentVNode("", true),
                      column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                        createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                          ]),
                          _: 2
                        }, 1024),
                        createTextVNode("   " + toDisplayString(text), 1)
                      ], 64)) : createCommentVNode("", true),
                      column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 2 }, {
                        overlay: withCtx(() => [
                          createVNode(_component_a_menu, null, {
                            default: withCtx(() => [
                              createVNode(_component_Link, {
                                href: _ctx.route("expensetype.edit", record.id)
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "1" }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Edit Expenses ")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 2
                              }, 1032, ["href"]),
                              createVNode(_component_a_menu_item, {
                                key: "2",
                                onClick: ($event) => $options.deleteExpenses(record.id)
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Delete Expenses ")
                                ]),
                                _: 2
                              }, 1032, ["onClick"])
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        default: withCtx(() => [
                          createVNode(_component_a_button, null, {
                            default: withCtx(() => [
                              createVNode(_component_more_outlined),
                              createVNode(_component_DownOutlined)
                            ]),
                            _: 1
                          })
                        ]),
                        _: 2
                      }, 1024)) : createCommentVNode("", true)
                    ]),
                    _: 1
                  }, 8, ["columns", "row-key", "data-source", "pagination", "loading", "onChange"])
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Expensetype/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Index as default
};
