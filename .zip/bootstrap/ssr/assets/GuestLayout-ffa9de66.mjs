import { useSSRContext, mergeProps, resolveComponent, withCtx, unref, createVNode, renderSlot } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import { Link } from "@inertiajs/vue3";
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<img${ssrRenderAttrs(mergeProps({
    src: "https://moziztech.com/images/logo/moziz-logo.png",
    class: "app-logo"
  }, _attrs))}>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/ApplicationLogo.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const ApplicationLogo = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = {
  __name: "GuestLayout",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_a_layout = resolveComponent("a-layout");
      const _component_a_row = resolveComponent("a-row");
      const _component_a_col = resolveComponent("a-col");
      _push(ssrRenderComponent(_component_a_layout, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_a_row, {
              type: "flex",
              justify: "space-around",
              align: "middle",
              style: { "height": "100vh" }
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_a_col, { span: 6 }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="auth-box"${_scopeId3}>`);
                        _push4(ssrRenderComponent(unref(Link), { href: "/" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(ApplicationLogo, { class: "w-20 h-20 fill-current text-gray-500" }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(ApplicationLogo, { class: "w-20 h-20 fill-current text-gray-500" })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        ssrRenderSlot(_ctx.$slots, "default", {}, null, _push4, _parent4, _scopeId3);
                        _push4(`</div>`);
                      } else {
                        return [
                          createVNode("div", { class: "auth-box" }, [
                            createVNode(unref(Link), { href: "/" }, {
                              default: withCtx(() => [
                                createVNode(ApplicationLogo, { class: "w-20 h-20 fill-current text-gray-500" })
                              ]),
                              _: 1
                            }),
                            renderSlot(_ctx.$slots, "default")
                          ])
                        ];
                      }
                    }),
                    _: 3
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_a_col, { span: 6 }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "auth-box" }, [
                          createVNode(unref(Link), { href: "/" }, {
                            default: withCtx(() => [
                              createVNode(ApplicationLogo, { class: "w-20 h-20 fill-current text-gray-500" })
                            ]),
                            _: 1
                          }),
                          renderSlot(_ctx.$slots, "default")
                        ])
                      ]),
                      _: 3
                    })
                  ];
                }
              }),
              _: 3
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_a_row, {
                type: "flex",
                justify: "space-around",
                align: "middle",
                style: { "height": "100vh" }
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_col, { span: 6 }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "auth-box" }, [
                        createVNode(unref(Link), { href: "/" }, {
                          default: withCtx(() => [
                            createVNode(ApplicationLogo, { class: "w-20 h-20 fill-current text-gray-500" })
                          ]),
                          _: 1
                        }),
                        renderSlot(_ctx.$slots, "default")
                      ])
                    ]),
                    _: 3
                  })
                ]),
                _: 3
              })
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/GuestLayout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
