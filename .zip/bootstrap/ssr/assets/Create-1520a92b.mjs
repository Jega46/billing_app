import { defineComponent, ref, resolveComponent, withCtx, createTextVNode, createVNode, mergeProps, toDisplayString, openBlock, createBlock, Fragment, renderList, withModifiers, useSSRContext } from "vue";
import { PlusCircleOutlined, UserOutlined } from "@ant-design/icons-vue";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import { Head, useForm, router } from "@inertiajs/vue3";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
const Create_vue_vue_type_style_index_0_lang = "";
const _sfc_main = defineComponent({
  inject: ["validateMessages"],
  components: {
    AuthenticatedLayout: _sfc_main$1,
    PlusCircleOutlined,
    UserOutlined,
    Head
  },
  props: {
    expensetypes: Object,
    errors: Object
  },
  setup(props) {
    const exmodel_visible = ref(false);
    const loading = ref(false);
    const layout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 16 }
    };
    const ExformState = useForm({
      expensetype: ""
    });
    const formState = useForm({
      name: "",
      expensetype_id: [],
      amount: "",
      method: "",
      date: "",
      description: ""
    });
    return {
      ExformState,
      formState,
      loading,
      layout,
      exmodel_visible
    };
  },
  data() {
    return {
      exmodel_visible: false
    };
  },
  methods: {
    EXsubmit() {
      alert("sdfdsf");
      router.post(route("expensetype.update_expensetype"), this.ExformState, {
        onSuccess: (page) => {
        },
        onError: (errors) => {
        },
        onFinish: (visit) => {
          this.exmodel_visible = false;
        }
      });
    },
    submit() {
      this.formState.post(route("expensetype.store"));
    }
  }
});
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_affix = resolveComponent("a-affix");
  const _component_a_page_header = resolveComponent("a-page-header");
  const _component_a_button = resolveComponent("a-button");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_input = resolveComponent("a-input");
  const _component_user_outlined = resolveComponent("user-outlined");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_select_option = resolveComponent("a-select-option");
  const _component_PlusCircleOutlined = resolveComponent("PlusCircleOutlined");
  const _component_a_date_picker = resolveComponent("a-date-picker");
  const _component_a_textarea = resolveComponent("a-textarea");
  const _component_a_modal = resolveComponent("a-modal");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Expense" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_affix, { "offset-top": 0 }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_page_header, {
                ghost: false,
                title: "Add Expense",
                onBack: () => _ctx.$inertia.visit(_ctx.route("expensetype.index"))
              }, {
                extra: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_button, {
                      key: "1",
                      type: "primary"
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`Save`);
                        } else {
                          return [
                            createTextVNode("Save")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_button, {
                        key: "1",
                        type: "primary"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Save")
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_page_header, {
                  ghost: false,
                  title: "Add Expense",
                  onBack: () => _ctx.$inertia.visit(_ctx.route("expensetype.index"))
                }, {
                  extra: withCtx(() => [
                    createVNode(_component_a_button, {
                      key: "1",
                      type: "primary"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Save")
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }, 8, ["onBack"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_layout_content, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_row, null, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_col, {
                      span: 12,
                      offset: 6
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                            name: "nest-messages",
                            "validate-messages": _ctx.validateMessages,
                            onFinish: _ctx.submit
                          }), {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Name",
                                  name: "name",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: _ctx.formState.name,
                                        "onUpdate:value": ($event) => _ctx.formState.name = $event
                                      }, {
                                        prefix: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_user_outlined, { type: "user" }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_user_outlined, { type: "user" })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: _ctx.formState.name,
                                          "onUpdate:value": ($event) => _ctx.formState.name = $event
                                        }, {
                                          prefix: withCtx(() => [
                                            createVNode(_component_user_outlined, { type: "user" })
                                          ]),
                                          _: 1
                                        }, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, { label: "Expense Type" }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_select, {
                                        placeholder: "Select Expense Type",
                                        value: _ctx.formState.expensetype_id,
                                        "onUpdate:value": ($event) => _ctx.formState.expensetype_id = $event
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`<!--[-->`);
                                            ssrRenderList(_ctx.expensetypes, (expensetype) => {
                                              _push8(ssrRenderComponent(_component_a_select_option, {
                                                value: expensetype.id
                                              }, {
                                                default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                  if (_push9) {
                                                    _push9(`${ssrInterpolate(expensetype.expensetype)}`);
                                                  } else {
                                                    return [
                                                      createTextVNode(toDisplayString(expensetype.expensetype), 1)
                                                    ];
                                                  }
                                                }),
                                                _: 2
                                              }, _parent8, _scopeId7));
                                            });
                                            _push8(`<!--]-->`);
                                            _push8(ssrRenderComponent(_component_a_select_option, {
                                              value: "",
                                              onClick: () => {
                                                _ctx.exmodel_visible = true;
                                              }
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_PlusCircleOutlined, null, null, _parent9, _scopeId8));
                                                  _push9(` Add More`);
                                                } else {
                                                  return [
                                                    createVNode(_component_PlusCircleOutlined),
                                                    createTextVNode(" Add More")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.expensetypes, (expensetype) => {
                                                return openBlock(), createBlock(_component_a_select_option, {
                                                  value: expensetype.id
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode(toDisplayString(expensetype.expensetype), 1)
                                                  ]),
                                                  _: 2
                                                }, 1032, ["value"]);
                                              }), 256)),
                                              createVNode(_component_a_select_option, {
                                                value: "",
                                                onClick: withModifiers(() => {
                                                  _ctx.exmodel_visible = true;
                                                }, ["stop"])
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_PlusCircleOutlined),
                                                  createTextVNode(" Add More")
                                                ]),
                                                _: 1
                                              }, 8, ["onClick"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_select, {
                                          placeholder: "Select Expense Type",
                                          value: _ctx.formState.expensetype_id,
                                          "onUpdate:value": ($event) => _ctx.formState.expensetype_id = $event
                                        }, {
                                          default: withCtx(() => [
                                            (openBlock(true), createBlock(Fragment, null, renderList(_ctx.expensetypes, (expensetype) => {
                                              return openBlock(), createBlock(_component_a_select_option, {
                                                value: expensetype.id
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode(toDisplayString(expensetype.expensetype), 1)
                                                ]),
                                                _: 2
                                              }, 1032, ["value"]);
                                            }), 256)),
                                            createVNode(_component_a_select_option, {
                                              value: "",
                                              onClick: withModifiers(() => {
                                                _ctx.exmodel_visible = true;
                                              }, ["stop"])
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_PlusCircleOutlined),
                                                createTextVNode(" Add More")
                                              ]),
                                              _: 1
                                            }, 8, ["onClick"])
                                          ]),
                                          _: 1
                                        }, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Amount",
                                  name: "amount",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: _ctx.formState.amount,
                                        "onUpdate:value": ($event) => _ctx.formState.amount = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: _ctx.formState.amount,
                                          "onUpdate:value": ($event) => _ctx.formState.amount = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Payment Method",
                                  name: "method",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_select, {
                                        value: _ctx.formState.method,
                                        "onUpdate:value": ($event) => _ctx.formState.method = $event
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Bank Transfer" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Bank Transfer`);
                                                } else {
                                                  return [
                                                    createTextVNode("Bank Transfer")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Cash Payment" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Cash Payment`);
                                                } else {
                                                  return [
                                                    createTextVNode("Cash Payment")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Cheque Payment" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Cheque Payment`);
                                                } else {
                                                  return [
                                                    createTextVNode("Cheque Payment")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                            _push8(ssrRenderComponent(_component_a_select_option, { value: "Online Payments" }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(`Online Payments`);
                                                } else {
                                                  return [
                                                    createTextVNode("Online Payments")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select_option, { value: "Bank Transfer" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Bank Transfer")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Cash Payment" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Cash Payment")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Cheque Payment" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Cheque Payment")
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(_component_a_select_option, { value: "Online Payments" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Online Payments")
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_select, {
                                          value: _ctx.formState.method,
                                          "onUpdate:value": ($event) => _ctx.formState.method = $event
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "Bank Transfer" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Bank Transfer")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Cash Payment" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Cash Payment")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Cheque Payment" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Cheque Payment")
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(_component_a_select_option, { value: "Online Payments" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Online Payments")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Date",
                                  name: "date",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_date_picker, {
                                        "value-format": "YYYY-MM-DD",
                                        style: { "width": "100%" },
                                        value: _ctx.formState.date,
                                        "onUpdate:value": ($event) => _ctx.formState.date = $event
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_date_picker, {
                                          "value-format": "YYYY-MM-DD",
                                          style: { "width": "100%" },
                                          value: _ctx.formState.date,
                                          "onUpdate:value": ($event) => _ctx.formState.date = $event
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Description",
                                  name: "description",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_textarea, {
                                        value: _ctx.formState.description,
                                        "onUpdate:value": ($event) => _ctx.formState.description = $event,
                                        placeholder: "Enter Description",
                                        rows: 4
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_textarea, {
                                          value: _ctx.formState.description,
                                          "onUpdate:value": ($event) => _ctx.formState.description = $event,
                                          placeholder: "Enter Description",
                                          rows: 4
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`Save`);
                                          } else {
                                            return [
                                              createTextVNode("Save")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          "html-type": "submit"
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("Save")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_form_item, {
                                    label: "Name",
                                    name: "name",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.formState.name,
                                        "onUpdate:value": ($event) => _ctx.formState.name = $event
                                      }, {
                                        prefix: withCtx(() => [
                                          createVNode(_component_user_outlined, { type: "user" })
                                        ]),
                                        _: 1
                                      }, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, { label: "Expense Type" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        placeholder: "Select Expense Type",
                                        value: _ctx.formState.expensetype_id,
                                        "onUpdate:value": ($event) => _ctx.formState.expensetype_id = $event
                                      }, {
                                        default: withCtx(() => [
                                          (openBlock(true), createBlock(Fragment, null, renderList(_ctx.expensetypes, (expensetype) => {
                                            return openBlock(), createBlock(_component_a_select_option, {
                                              value: expensetype.id
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode(toDisplayString(expensetype.expensetype), 1)
                                              ]),
                                              _: 2
                                            }, 1032, ["value"]);
                                          }), 256)),
                                          createVNode(_component_a_select_option, {
                                            value: "",
                                            onClick: withModifiers(() => {
                                              _ctx.exmodel_visible = true;
                                            }, ["stop"])
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_PlusCircleOutlined),
                                              createTextVNode(" Add More")
                                            ]),
                                            _: 1
                                          }, 8, ["onClick"])
                                        ]),
                                        _: 1
                                      }, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Amount",
                                    name: "amount",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.formState.amount,
                                        "onUpdate:value": ($event) => _ctx.formState.amount = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Payment Method",
                                    name: "method",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        value: _ctx.formState.method,
                                        "onUpdate:value": ($event) => _ctx.formState.method = $event
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "Bank Transfer" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Bank Transfer")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Cash Payment" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Cash Payment")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Cheque Payment" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Cheque Payment")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_select_option, { value: "Online Payments" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Online Payments")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Date",
                                    name: "date",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_date_picker, {
                                        "value-format": "YYYY-MM-DD",
                                        style: { "width": "100%" },
                                        value: _ctx.formState.date,
                                        "onUpdate:value": ($event) => _ctx.formState.date = $event
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Description",
                                    name: "description",
                                    rules: [{ required: true }]
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_textarea, {
                                        value: _ctx.formState.description,
                                        "onUpdate:value": ($event) => _ctx.formState.description = $event,
                                        placeholder: "Enter Description",
                                        rows: 4
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit"
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Save")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                              name: "nest-messages",
                              "validate-messages": _ctx.validateMessages,
                              onFinish: _ctx.submit
                            }), {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, {
                                  label: "Name",
                                  name: "name",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: _ctx.formState.name,
                                      "onUpdate:value": ($event) => _ctx.formState.name = $event
                                    }, {
                                      prefix: withCtx(() => [
                                        createVNode(_component_user_outlined, { type: "user" })
                                      ]),
                                      _: 1
                                    }, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, { label: "Expense Type" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      placeholder: "Select Expense Type",
                                      value: _ctx.formState.expensetype_id,
                                      "onUpdate:value": ($event) => _ctx.formState.expensetype_id = $event
                                    }, {
                                      default: withCtx(() => [
                                        (openBlock(true), createBlock(Fragment, null, renderList(_ctx.expensetypes, (expensetype) => {
                                          return openBlock(), createBlock(_component_a_select_option, {
                                            value: expensetype.id
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(expensetype.expensetype), 1)
                                            ]),
                                            _: 2
                                          }, 1032, ["value"]);
                                        }), 256)),
                                        createVNode(_component_a_select_option, {
                                          value: "",
                                          onClick: withModifiers(() => {
                                            _ctx.exmodel_visible = true;
                                          }, ["stop"])
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_PlusCircleOutlined),
                                            createTextVNode(" Add More")
                                          ]),
                                          _: 1
                                        }, 8, ["onClick"])
                                      ]),
                                      _: 1
                                    }, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Amount",
                                  name: "amount",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: _ctx.formState.amount,
                                      "onUpdate:value": ($event) => _ctx.formState.amount = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Payment Method",
                                  name: "method",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      value: _ctx.formState.method,
                                      "onUpdate:value": ($event) => _ctx.formState.method = $event
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, { value: "Bank Transfer" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Bank Transfer")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "Cash Payment" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Cash Payment")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "Cheque Payment" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Cheque Payment")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_select_option, { value: "Online Payments" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Online Payments")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Date",
                                  name: "date",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_date_picker, {
                                      "value-format": "YYYY-MM-DD",
                                      style: { "width": "100%" },
                                      value: _ctx.formState.date,
                                      "onUpdate:value": ($event) => _ctx.formState.date = $event
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Description",
                                  name: "description",
                                  rules: [{ required: true }]
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_textarea, {
                                      value: _ctx.formState.description,
                                      "onUpdate:value": ($event) => _ctx.formState.description = $event,
                                      placeholder: "Enter Description",
                                      rows: 4
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      "html-type": "submit"
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Save")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 16, ["model", "validate-messages", "onFinish"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_col, {
                        span: 12,
                        offset: 6
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                            name: "nest-messages",
                            "validate-messages": _ctx.validateMessages,
                            onFinish: _ctx.submit
                          }), {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, {
                                label: "Name",
                                name: "name",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: _ctx.formState.name,
                                    "onUpdate:value": ($event) => _ctx.formState.name = $event
                                  }, {
                                    prefix: withCtx(() => [
                                      createVNode(_component_user_outlined, { type: "user" })
                                    ]),
                                    _: 1
                                  }, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, { label: "Expense Type" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    placeholder: "Select Expense Type",
                                    value: _ctx.formState.expensetype_id,
                                    "onUpdate:value": ($event) => _ctx.formState.expensetype_id = $event
                                  }, {
                                    default: withCtx(() => [
                                      (openBlock(true), createBlock(Fragment, null, renderList(_ctx.expensetypes, (expensetype) => {
                                        return openBlock(), createBlock(_component_a_select_option, {
                                          value: expensetype.id
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(expensetype.expensetype), 1)
                                          ]),
                                          _: 2
                                        }, 1032, ["value"]);
                                      }), 256)),
                                      createVNode(_component_a_select_option, {
                                        value: "",
                                        onClick: withModifiers(() => {
                                          _ctx.exmodel_visible = true;
                                        }, ["stop"])
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_PlusCircleOutlined),
                                          createTextVNode(" Add More")
                                        ]),
                                        _: 1
                                      }, 8, ["onClick"])
                                    ]),
                                    _: 1
                                  }, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Amount",
                                name: "amount",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: _ctx.formState.amount,
                                    "onUpdate:value": ($event) => _ctx.formState.amount = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Payment Method",
                                name: "method",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    value: _ctx.formState.method,
                                    "onUpdate:value": ($event) => _ctx.formState.method = $event
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, { value: "Bank Transfer" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Bank Transfer")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "Cash Payment" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Cash Payment")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "Cheque Payment" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Cheque Payment")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_select_option, { value: "Online Payments" }, {
                                        default: withCtx(() => [
                                          createTextVNode("Online Payments")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Date",
                                name: "date",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_date_picker, {
                                    "value-format": "YYYY-MM-DD",
                                    style: { "width": "100%" },
                                    value: _ctx.formState.date,
                                    "onUpdate:value": ($event) => _ctx.formState.date = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Description",
                                name: "description",
                                rules: [{ required: true }]
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_textarea, {
                                    value: _ctx.formState.description,
                                    "onUpdate:value": ($event) => _ctx.formState.description = $event,
                                    placeholder: "Enter Description",
                                    rows: 4
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Save")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 16, ["model", "validate-messages", "onFinish"])
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_a_col, {
                      span: 12,
                      offset: 6
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                          name: "nest-messages",
                          "validate-messages": _ctx.validateMessages,
                          onFinish: _ctx.submit
                        }), {
                          default: withCtx(() => [
                            createVNode(_component_a_form_item, {
                              label: "Name",
                              name: "name",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: _ctx.formState.name,
                                  "onUpdate:value": ($event) => _ctx.formState.name = $event
                                }, {
                                  prefix: withCtx(() => [
                                    createVNode(_component_user_outlined, { type: "user" })
                                  ]),
                                  _: 1
                                }, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, { label: "Expense Type" }, {
                              default: withCtx(() => [
                                createVNode(_component_a_select, {
                                  placeholder: "Select Expense Type",
                                  value: _ctx.formState.expensetype_id,
                                  "onUpdate:value": ($event) => _ctx.formState.expensetype_id = $event
                                }, {
                                  default: withCtx(() => [
                                    (openBlock(true), createBlock(Fragment, null, renderList(_ctx.expensetypes, (expensetype) => {
                                      return openBlock(), createBlock(_component_a_select_option, {
                                        value: expensetype.id
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(expensetype.expensetype), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["value"]);
                                    }), 256)),
                                    createVNode(_component_a_select_option, {
                                      value: "",
                                      onClick: withModifiers(() => {
                                        _ctx.exmodel_visible = true;
                                      }, ["stop"])
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_PlusCircleOutlined),
                                        createTextVNode(" Add More")
                                      ]),
                                      _: 1
                                    }, 8, ["onClick"])
                                  ]),
                                  _: 1
                                }, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Amount",
                              name: "amount",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: _ctx.formState.amount,
                                  "onUpdate:value": ($event) => _ctx.formState.amount = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Payment Method",
                              name: "method",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_select, {
                                  value: _ctx.formState.method,
                                  "onUpdate:value": ($event) => _ctx.formState.method = $event
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select_option, { value: "Bank Transfer" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Bank Transfer")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Cash Payment" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Cash Payment")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Cheque Payment" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Cheque Payment")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_select_option, { value: "Online Payments" }, {
                                      default: withCtx(() => [
                                        createTextVNode("Online Payments")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Date",
                              name: "date",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_date_picker, {
                                  "value-format": "YYYY-MM-DD",
                                  style: { "width": "100%" },
                                  value: _ctx.formState.date,
                                  "onUpdate:value": ($event) => _ctx.formState.date = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Description",
                              name: "description",
                              rules: [{ required: true }]
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_textarea, {
                                  value: _ctx.formState.description,
                                  "onUpdate:value": ($event) => _ctx.formState.description = $event,
                                  placeholder: "Enter Description",
                                  rows: 4
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Save")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 16, ["model", "validate-messages", "onFinish"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_modal, {
          visible: _ctx.exmodel_visible,
          title: "Title",
          closable: true,
          onClose: ($event) => _ctx.exmodel_visible = false
        }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_form, mergeProps({
                model: _ctx.ExformState,
                method: "post"
              }, _ctx.layout, {
                name: "nest-messages",
                "validate-messages": _ctx.validateMessages,
                onFinish: _ctx.EXsubmit
              }), {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Expense Type",
                      name: "expensetype",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_input, {
                            value: _ctx.ExformState.expensetype,
                            "onUpdate:value": ($event) => _ctx.ExformState.expensetype = $event,
                            placeholder: "Enter Expense Type"
                          }, null, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_input, {
                              value: _ctx.ExformState.expensetype,
                              "onUpdate:value": ($event) => _ctx.ExformState.expensetype = $event,
                              placeholder: "Enter Expense Type"
                            }, null, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Save`);
                              } else {
                                return [
                                  createTextVNode("Save")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Save")
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form_item, {
                        label: "Expense Type",
                        name: "expensetype",
                        rules: [{ required: true }]
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            value: _ctx.ExformState.expensetype,
                            "onUpdate:value": ($event) => _ctx.ExformState.expensetype = $event,
                            placeholder: "Enter Expense Type"
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Save")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_form, mergeProps({
                  model: _ctx.ExformState,
                  method: "post"
                }, _ctx.layout, {
                  name: "nest-messages",
                  "validate-messages": _ctx.validateMessages,
                  onFinish: _ctx.EXsubmit
                }), {
                  default: withCtx(() => [
                    createVNode(_component_a_form_item, {
                      label: "Expense Type",
                      name: "expensetype",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_input, {
                          value: _ctx.ExformState.expensetype,
                          "onUpdate:value": ($event) => _ctx.ExformState.expensetype = $event,
                          placeholder: "Enter Expense Type"
                        }, null, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                      default: withCtx(() => [
                        createVNode(_component_a_button, {
                          type: "primary",
                          "html-type": "submit"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Save")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }, 16, ["model", "validate-messages", "onFinish"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_affix, { "offset-top": 0 }, {
            default: withCtx(() => [
              createVNode(_component_a_page_header, {
                ghost: false,
                title: "Add Expense",
                onBack: () => _ctx.$inertia.visit(_ctx.route("expensetype.index"))
              }, {
                extra: withCtx(() => [
                  createVNode(_component_a_button, {
                    key: "1",
                    type: "primary"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Save")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["onBack"])
            ]),
            _: 1
          }),
          createVNode(_component_a_layout_content, null, {
            default: withCtx(() => [
              createVNode(_component_a_row, null, {
                default: withCtx(() => [
                  createVNode(_component_a_col, {
                    span: 12,
                    offset: 6
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                        name: "nest-messages",
                        "validate-messages": _ctx.validateMessages,
                        onFinish: _ctx.submit
                      }), {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, {
                            label: "Name",
                            name: "name",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: _ctx.formState.name,
                                "onUpdate:value": ($event) => _ctx.formState.name = $event
                              }, {
                                prefix: withCtx(() => [
                                  createVNode(_component_user_outlined, { type: "user" })
                                ]),
                                _: 1
                              }, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, { label: "Expense Type" }, {
                            default: withCtx(() => [
                              createVNode(_component_a_select, {
                                placeholder: "Select Expense Type",
                                value: _ctx.formState.expensetype_id,
                                "onUpdate:value": ($event) => _ctx.formState.expensetype_id = $event
                              }, {
                                default: withCtx(() => [
                                  (openBlock(true), createBlock(Fragment, null, renderList(_ctx.expensetypes, (expensetype) => {
                                    return openBlock(), createBlock(_component_a_select_option, {
                                      value: expensetype.id
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(expensetype.expensetype), 1)
                                      ]),
                                      _: 2
                                    }, 1032, ["value"]);
                                  }), 256)),
                                  createVNode(_component_a_select_option, {
                                    value: "",
                                    onClick: withModifiers(() => {
                                      _ctx.exmodel_visible = true;
                                    }, ["stop"])
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_PlusCircleOutlined),
                                      createTextVNode(" Add More")
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ]),
                                _: 1
                              }, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Amount",
                            name: "amount",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: _ctx.formState.amount,
                                "onUpdate:value": ($event) => _ctx.formState.amount = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Payment Method",
                            name: "method",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_select, {
                                value: _ctx.formState.method,
                                "onUpdate:value": ($event) => _ctx.formState.method = $event
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select_option, { value: "Bank Transfer" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Bank Transfer")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Cash Payment" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Cash Payment")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Cheque Payment" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Cheque Payment")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Online Payments" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Online Payments")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Date",
                            name: "date",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_date_picker, {
                                "value-format": "YYYY-MM-DD",
                                style: { "width": "100%" },
                                value: _ctx.formState.date,
                                "onUpdate:value": ($event) => _ctx.formState.date = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Description",
                            name: "description",
                            rules: [{ required: true }]
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_textarea, {
                                value: _ctx.formState.description,
                                "onUpdate:value": ($event) => _ctx.formState.description = $event,
                                placeholder: "Enter Description",
                                rows: 4
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Save")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 16, ["model", "validate-messages", "onFinish"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_a_modal, {
            visible: _ctx.exmodel_visible,
            title: "Title",
            closable: true,
            onClose: ($event) => _ctx.exmodel_visible = false
          }, {
            default: withCtx(() => [
              createVNode(_component_a_form, mergeProps({
                model: _ctx.ExformState,
                method: "post"
              }, _ctx.layout, {
                name: "nest-messages",
                "validate-messages": _ctx.validateMessages,
                onFinish: _ctx.EXsubmit
              }), {
                default: withCtx(() => [
                  createVNode(_component_a_form_item, {
                    label: "Expense Type",
                    name: "expensetype",
                    rules: [{ required: true }]
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_input, {
                        value: _ctx.ExformState.expensetype,
                        "onUpdate:value": ($event) => _ctx.ExformState.expensetype = $event,
                        placeholder: "Enter Expense Type"
                      }, null, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                    default: withCtx(() => [
                      createVNode(_component_a_button, {
                        type: "primary",
                        "html-type": "submit"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Save")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 16, ["model", "validate-messages", "onFinish"])
            ]),
            _: 1
          }, 8, ["visible", "onClose"])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Expensetype/Create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Create = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Create as default
};
