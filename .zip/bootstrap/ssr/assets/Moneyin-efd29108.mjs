import { ref, defineComponent, resolveComponent, withCtx, createTextVNode, createVNode, withModifiers, mergeProps, openBlock, createBlock, createCommentVNode, Fragment, toDisplayString, useSSRContext } from "vue";
import { PlusOutlined, DownOutlined, PlusCircleOutlined } from "@ant-design/icons-vue";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import { Head, useForm } from "@inertiajs/vue3";
import { ssrRenderComponent, ssrRenderAttr, ssrRenderStyle, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
const Moneyin_vue_vue_type_style_index_0_lang = "";
const columns = [
  {
    title: "S.NO",
    key: "sno",
    dataIndex: "sno",
    width: "8%"
  },
  {
    title: "Category",
    key: "category",
    dataIndex: "category",
    width: "15%"
  },
  {
    title: "Details",
    key: "details",
    dataIndex: "details",
    width: "10%"
  },
  {
    title: "Net",
    key: "net",
    dataIndex: "net",
    width: "10%"
  },
  {
    title: "Tax Rate",
    key: "taxrate",
    dataIndex: "taxrate",
    width: "10%"
  },
  {
    title: "Tax",
    key: "tax",
    dataIndex: "tax",
    width: "10%"
  },
  {
    title: "Total (₹)",
    key: "total",
    dataIndex: "total",
    fixed: "right",
    width: "10%"
  }
];
const dataSource = ref([
  {
    key: "1",
    sno: "0",
    category: "",
    details: "",
    net: "",
    taxrate: "",
    tax: "",
    total: ""
  }
]);
const _sfc_main = defineComponent({
  inject: ["validateMessages"],
  props: {
    pagination: Object,
    errors: Object
  },
  components: {
    AuthenticatedLayout: _sfc_main$1,
    Head,
    PlusOutlined,
    DownOutlined,
    PlusCircleOutlined
  },
  setup(props) {
    const layout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 16 }
    };
    const checked = ref(false);
    const formParty = useForm({
      partyname: "",
      mobile: "",
      who_r_they: "",
      gstin: "",
      flat_no: "",
      area_loc: "",
      pincode: "",
      city: "",
      state: "",
      same_ship: false
    });
    const formState = useForm({
      valuess: ""
    });
    return {
      formParty,
      formState,
      layout,
      columns,
      checked,
      dataSource
    };
  },
  mounted() {
  },
  data() {
    return {
      showmodel_visible: false,
      menu_visible: false
    };
  },
  methods: {
    partySubmit() {
      this.formParty.post(this.route("purchase.store"), {
        onError: (errors) => {
        },
        onFinish: (visit) => {
          this.showmodel_visible = false;
        }
      });
    },
    handleTableChange(val) {
      this.$inertia.get(
        "/purchase/index",
        { page: val.current },
        { preserveState: true }
      );
    }
  }
});
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_affix = resolveComponent("a-affix");
  const _component_a_page_header = resolveComponent("a-page-header");
  const _component_a_button = resolveComponent("a-button");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_card = resolveComponent("a-card");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_select_option = resolveComponent("a-select-option");
  const _component_PlusCircleOutlined = resolveComponent("PlusCircleOutlined");
  const _component_a_date_picker = resolveComponent("a-date-picker");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_modal = resolveComponent("a-modal");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_radio_group = resolveComponent("a-radio-group");
  const _component_a_radio = resolveComponent("a-radio");
  const _component_a_menu = resolveComponent("a-menu");
  const _component_a_sub_menu = resolveComponent("a-sub-menu");
  const _component_a_checkbox = resolveComponent("a-checkbox");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_table = resolveComponent("a-table");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Employees" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_affix, { "offset-top": 0 }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_page_header, {
                ghost: false,
                title: "Money In",
                onBack: () => _ctx.$inertia.visit(_ctx.route("cashbook.index"))
              }, {
                extra: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_button, { type: "primary" }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`Save`);
                        } else {
                          return [
                            createTextVNode("Save")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_button, { type: "primary" }, {
                        default: withCtx(() => [
                          createTextVNode("Save")
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_page_header, {
                  ghost: false,
                  title: "Money In",
                  onBack: () => _ctx.$inertia.visit(_ctx.route("cashbook.index"))
                }, {
                  extra: withCtx(() => [
                    createVNode(_component_a_button, { type: "primary" }, {
                      default: withCtx(() => [
                        createTextVNode("Save")
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }, 8, ["onBack"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_row, { style: { "padding": "'24px'", "background": "'#fff'", "margin-top": "12px", "margin-bottom": "12px", "margin-left": "16px", "minHeight": "'180px'" } }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_col, { span: 24 }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_card, { style: { "width": "1118px" } }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_row, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, { span: 4 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "Contact(optional)" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select, {
                                              placeholder: "Search for a Customer",
                                              style: { "width": "160px" }
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_select_option, {
                                                    value: "undefined",
                                                    onClick: () => {
                                                      _ctx.showmodel_visible = true;
                                                    }
                                                  }, {
                                                    default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                      if (_push10) {
                                                        _push10(ssrRenderComponent(_component_PlusCircleOutlined, null, null, _parent10, _scopeId9));
                                                        _push10(` Add New Customer`);
                                                      } else {
                                                        return [
                                                          createVNode(_component_PlusCircleOutlined),
                                                          createTextVNode(" Add New Customer")
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_select_option, {
                                                      value: "undefined",
                                                      onClick: withModifiers(() => {
                                                        _ctx.showmodel_visible = true;
                                                      }, ["stop"])
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(_component_PlusCircleOutlined),
                                                        createTextVNode(" Add New Customer")
                                                      ]),
                                                      _: 1
                                                    }, 8, ["onClick"])
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select, {
                                                placeholder: "Search for a Customer",
                                                style: { "width": "160px" }
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select_option, {
                                                    value: "undefined",
                                                    onClick: withModifiers(() => {
                                                      _ctx.showmodel_visible = true;
                                                    }, ["stop"])
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_PlusCircleOutlined),
                                                      createTextVNode(" Add New Customer")
                                                    ]),
                                                    _: 1
                                                  }, 8, ["onClick"])
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "Contact(optional)" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              placeholder: "Search for a Customer",
                                              style: { "width": "160px" }
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select_option, {
                                                  value: "undefined",
                                                  onClick: withModifiers(() => {
                                                    _ctx.showmodel_visible = true;
                                                  }, ["stop"])
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_PlusCircleOutlined),
                                                    createTextVNode(" Add New Customer")
                                                  ]),
                                                  _: 1
                                                }, 8, ["onClick"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 4 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "Paid into Bank Account" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select, {
                                              placeholder: "Please Select",
                                              style: { "width": "160px" }
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_select_option, { value: "undefined" }, null, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_select_option, { value: "undefined" })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select, {
                                                placeholder: "Please Select",
                                                style: { "width": "160px" }
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select_option, { value: "undefined" })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "Paid into Bank Account" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              placeholder: "Please Select",
                                              style: { "width": "160px" }
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select_option, { value: "undefined" })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 4 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "Method" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_select, {
                                              placeholder: "Please Select",
                                              style: { "width": "160px" }
                                            }, {
                                              default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                if (_push9) {
                                                  _push9(ssrRenderComponent(_component_a_select_option, { value: "undefined" }, null, _parent9, _scopeId8));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_select_option, { value: "undefined" })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_select, {
                                                placeholder: "Please Select",
                                                style: { "width": "160px" }
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_a_select_option, { value: "undefined" })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "Method" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select, {
                                              placeholder: "Please Select",
                                              style: { "width": "160px" }
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_select_option, { value: "undefined" })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 4 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "Date Received" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_date_picker, {
                                              value: _ctx.date,
                                              "onUpdate:value": ($event) => _ctx.date = $event,
                                              format: "DD-MM-YYYY",
                                              "value-format": "YYYY-MM-DD",
                                              style: { "width": "160px" }
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_date_picker, {
                                                value: _ctx.date,
                                                "onUpdate:value": ($event) => _ctx.date = $event,
                                                format: "DD-MM-YYYY",
                                                "value-format": "YYYY-MM-DD",
                                                style: { "width": "160px" }
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "Date Received" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_date_picker, {
                                              value: _ctx.date,
                                              "onUpdate:value": ($event) => _ctx.date = $event,
                                              format: "DD-MM-YYYY",
                                              "value-format": "YYYY-MM-DD",
                                              style: { "width": "160px" }
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 4 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "Your Reference (optional)" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: _ctx.value,
                                              "onUpdate:value": ($event) => _ctx.value = $event,
                                              placeholder: "e.g. Check number",
                                              style: { "width": "160px" }
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: _ctx.value,
                                                "onUpdate:value": ($event) => _ctx.value = $event,
                                                placeholder: "e.g. Check number",
                                                style: { "width": "160px" }
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "Your Reference (optional)" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: _ctx.value,
                                              "onUpdate:value": ($event) => _ctx.value = $event,
                                              placeholder: "e.g. Check number",
                                              style: { "width": "160px" }
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 4 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "Amount Received" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              value: _ctx.value,
                                              "onUpdate:value": ($event) => _ctx.value = $event,
                                              placeholder: "",
                                              style: { "width": "160px" }
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                value: _ctx.value,
                                                "onUpdate:value": ($event) => _ctx.value = $event,
                                                placeholder: "",
                                                style: { "width": "160px" }
                                              }, null, 8, ["value", "onUpdate:value"])
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "Amount Received" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              value: _ctx.value,
                                              "onUpdate:value": ($event) => _ctx.value = $event,
                                              placeholder: "",
                                              style: { "width": "160px" }
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, { span: 4 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "Contact(optional)" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            placeholder: "Search for a Customer",
                                            style: { "width": "160px" }
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select_option, {
                                                value: "undefined",
                                                onClick: withModifiers(() => {
                                                  _ctx.showmodel_visible = true;
                                                }, ["stop"])
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_PlusCircleOutlined),
                                                  createTextVNode(" Add New Customer")
                                                ]),
                                                _: 1
                                              }, 8, ["onClick"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 4 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "Paid into Bank Account" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            placeholder: "Please Select",
                                            style: { "width": "160px" }
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select_option, { value: "undefined" })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 4 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "Method" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select, {
                                            placeholder: "Please Select",
                                            style: { "width": "160px" }
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_select_option, { value: "undefined" })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 4 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "Date Received" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_date_picker, {
                                            value: _ctx.date,
                                            "onUpdate:value": ($event) => _ctx.date = $event,
                                            format: "DD-MM-YYYY",
                                            "value-format": "YYYY-MM-DD",
                                            style: { "width": "160px" }
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 4 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "Your Reference (optional)" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: _ctx.value,
                                            "onUpdate:value": ($event) => _ctx.value = $event,
                                            placeholder: "e.g. Check number",
                                            style: { "width": "160px" }
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 4 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "Amount Received" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            value: _ctx.value,
                                            "onUpdate:value": ($event) => _ctx.value = $event,
                                            placeholder: "",
                                            style: { "width": "160px" }
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_row, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 4 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "Contact(optional)" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          placeholder: "Search for a Customer",
                                          style: { "width": "160px" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, {
                                              value: "undefined",
                                              onClick: withModifiers(() => {
                                                _ctx.showmodel_visible = true;
                                              }, ["stop"])
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_PlusCircleOutlined),
                                                createTextVNode(" Add New Customer")
                                              ]),
                                              _: 1
                                            }, 8, ["onClick"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 4 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "Paid into Bank Account" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          placeholder: "Please Select",
                                          style: { "width": "160px" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "undefined" })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 4 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "Method" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select, {
                                          placeholder: "Please Select",
                                          style: { "width": "160px" }
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_select_option, { value: "undefined" })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 4 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "Date Received" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_date_picker, {
                                          value: _ctx.date,
                                          "onUpdate:value": ($event) => _ctx.date = $event,
                                          format: "DD-MM-YYYY",
                                          "value-format": "YYYY-MM-DD",
                                          style: { "width": "160px" }
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 4 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "Your Reference (optional)" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: _ctx.value,
                                          "onUpdate:value": ($event) => _ctx.value = $event,
                                          placeholder: "e.g. Check number",
                                          style: { "width": "160px" }
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 4 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "Amount Received" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          value: _ctx.value,
                                          "onUpdate:value": ($event) => _ctx.value = $event,
                                          placeholder: "",
                                          style: { "width": "160px" }
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_card, { style: { "width": "1118px" } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_row, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, { span: 4 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "Contact(optional)" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        placeholder: "Search for a Customer",
                                        style: { "width": "160px" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, {
                                            value: "undefined",
                                            onClick: withModifiers(() => {
                                              _ctx.showmodel_visible = true;
                                            }, ["stop"])
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_PlusCircleOutlined),
                                              createTextVNode(" Add New Customer")
                                            ]),
                                            _: 1
                                          }, 8, ["onClick"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 4 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "Paid into Bank Account" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        placeholder: "Please Select",
                                        style: { "width": "160px" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "undefined" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 4 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "Method" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select, {
                                        placeholder: "Please Select",
                                        style: { "width": "160px" }
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_select_option, { value: "undefined" })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 4 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "Date Received" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_date_picker, {
                                        value: _ctx.date,
                                        "onUpdate:value": ($event) => _ctx.date = $event,
                                        format: "DD-MM-YYYY",
                                        "value-format": "YYYY-MM-DD",
                                        style: { "width": "160px" }
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 4 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "Your Reference (optional)" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.value,
                                        "onUpdate:value": ($event) => _ctx.value = $event,
                                        placeholder: "e.g. Check number",
                                        style: { "width": "160px" }
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 4 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "Amount Received" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.value,
                                        "onUpdate:value": ($event) => _ctx.value = $event,
                                        placeholder: "",
                                        style: { "width": "160px" }
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_col, { span: 24 }, {
                  default: withCtx(() => [
                    createVNode(_component_a_card, { style: { "width": "1118px" } }, {
                      default: withCtx(() => [
                        createVNode(_component_a_row, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, { span: 4 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "Contact(optional)" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      placeholder: "Search for a Customer",
                                      style: { "width": "160px" }
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, {
                                          value: "undefined",
                                          onClick: withModifiers(() => {
                                            _ctx.showmodel_visible = true;
                                          }, ["stop"])
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_PlusCircleOutlined),
                                            createTextVNode(" Add New Customer")
                                          ]),
                                          _: 1
                                        }, 8, ["onClick"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 4 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "Paid into Bank Account" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      placeholder: "Please Select",
                                      style: { "width": "160px" }
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, { value: "undefined" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 4 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "Method" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_select, {
                                      placeholder: "Please Select",
                                      style: { "width": "160px" }
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_select_option, { value: "undefined" })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 4 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "Date Received" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_date_picker, {
                                      value: _ctx.date,
                                      "onUpdate:value": ($event) => _ctx.date = $event,
                                      format: "DD-MM-YYYY",
                                      "value-format": "YYYY-MM-DD",
                                      style: { "width": "160px" }
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 4 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "Your Reference (optional)" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: _ctx.value,
                                      "onUpdate:value": ($event) => _ctx.value = $event,
                                      placeholder: "e.g. Check number",
                                      style: { "width": "160px" }
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 4 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "Amount Received" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: _ctx.value,
                                      "onUpdate:value": ($event) => _ctx.value = $event,
                                      placeholder: "",
                                      style: { "width": "160px" }
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_modal, {
          title: "Add New Customer",
          closable: true,
          visible: _ctx.showmodel_visible,
          "onUpdate:visible": ($event) => _ctx.showmodel_visible = $event,
          onClose: ($event) => _ctx.showmodel_visible = false
        }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_form, mergeProps({ model: _ctx.formParty }, _ctx.layout, {
                name: "nest-messages",
                "validate-messages": _ctx.validateMessages,
                onFinish: _ctx.partySubmit
              }), {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Party Name",
                      name: "partyname",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_input, {
                            value: _ctx.formParty.partyname,
                            "onUpdate:value": ($event) => _ctx.formParty.partyname = $event,
                            placeholder: "Enter Customer Name"
                          }, null, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_input, {
                              value: _ctx.formParty.partyname,
                              "onUpdate:value": ($event) => _ctx.formParty.partyname = $event,
                              placeholder: "Enter Customer Name"
                            }, null, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Mobile Number",
                      name: "mobile"
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_input, {
                            value: _ctx.formParty.mobile,
                            "onUpdate:value": ($event) => _ctx.formParty.mobile = $event,
                            placeholder: "Enter Mobile Number"
                          }, null, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_input, {
                              value: _ctx.formParty.mobile,
                              "onUpdate:value": ($event) => _ctx.formParty.mobile = $event,
                              placeholder: "Enter Mobile Number"
                            }, null, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Who are they?",
                      name: "who_r_they"
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_radio_group, {
                            value: _ctx.formParty.who_r_they,
                            "onUpdate:value": ($event) => _ctx.formParty.who_r_they = $event
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_radio, { value: "customer" }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`Customer`);
                                    } else {
                                      return [
                                        createTextVNode("Customer")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_radio, { value: "supplier" }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`Supplier`);
                                    } else {
                                      return [
                                        createTextVNode("Supplier")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_radio, { value: "customer" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Customer")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_radio, { value: "supplier" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Supplier")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_radio_group, {
                              value: _ctx.formParty.who_r_they,
                              "onUpdate:value": ($event) => _ctx.formParty.who_r_they = $event
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_radio, { value: "customer" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Customer")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_radio, { value: "supplier" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Supplier")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "GSTIN",
                      name: "gstin",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_input, {
                            value: _ctx.formParty.gstin,
                            "onUpdate:value": ($event) => _ctx.formParty.gstin = $event,
                            placeholder: "Enter GSTIN"
                          }, null, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_input, {
                              value: _ctx.formParty.gstin,
                              "onUpdate:value": ($event) => _ctx.formParty.gstin = $event,
                              placeholder: "Enter GSTIN"
                            }, null, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_menu, {
                      id: "dddddd",
                      style: { "width": "100%" },
                      mode: "inline",
                      onClick: () => {
                        _ctx.menu_visible = true;
                      }
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_sub_menu, {
                            key: "sub1",
                            visible: _ctx.menu_visible,
                            onClose: ($event) => _ctx.menu_visible = false
                          }, {
                            title: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Add GSTIN &amp; Address (Optional)`);
                              } else {
                                return [
                                  createTextVNode("Add GSTIN & Address (Optional)")
                                ];
                              }
                            }),
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`<h5${ssrRenderAttr("wrapper-col", { span: 12, offset: 6 })} style="${ssrRenderStyle({ "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" })}"${_scopeId5}>Shipping Address</h5><br${_scopeId5}><br${_scopeId5}>`);
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Flat / Building Number",
                                  name: "flat_no"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: _ctx.formParty.flat_no,
                                        "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                        placeholder: "Enter Flat / Building Number"
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: _ctx.formParty.flat_no,
                                          "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                          placeholder: "Enter Flat / Building Number"
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "Area / Locality",
                                  name: "area_loc"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: _ctx.formParty.area_loc,
                                        "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                        placeholder: "Enter Area / Locality"
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: _ctx.formParty.area_loc,
                                          "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                          placeholder: "Enter Area / Locality"
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "PIN Code",
                                  name: "pincode"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: _ctx.formParty.pincode,
                                        "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                        placeholder: "Enter PIN Code"
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: _ctx.formParty.pincode,
                                          "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                          placeholder: "Enter PIN Code"
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "City",
                                  name: "city"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: _ctx.formParty.city,
                                        "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                        placeholder: "Enter City"
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: _ctx.formParty.city,
                                          "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                          placeholder: "Enter City"
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, {
                                  label: "State",
                                  name: "state"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_input, {
                                        value: _ctx.formParty.state,
                                        "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                        placeholder: "Enter State"
                                      }, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_input, {
                                          value: _ctx.formParty.state,
                                          "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                          placeholder: "Enter State"
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_form_item, { name: "same_ship" }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_checkbox, {
                                        checked: _ctx.formParty.same_ship,
                                        "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`Shipping address same as billing address`);
                                          } else {
                                            return [
                                              createTextVNode("Shipping address same as billing address")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_checkbox, {
                                          checked: _ctx.formParty.same_ship,
                                          "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("Shipping address same as billing address")
                                          ]),
                                          _: 1
                                        }, 8, ["checked", "onUpdate:checked"])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode("h5", {
                                    "wrapper-col": { span: 12, offset: 6 },
                                    style: { "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" }
                                  }, "Shipping Address"),
                                  createVNode("br"),
                                  createVNode("br"),
                                  createVNode(_component_a_form_item, {
                                    label: "Flat / Building Number",
                                    name: "flat_no"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.formParty.flat_no,
                                        "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                        placeholder: "Enter Flat / Building Number"
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Area / Locality",
                                    name: "area_loc"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.formParty.area_loc,
                                        "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                        placeholder: "Enter Area / Locality"
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "PIN Code",
                                    name: "pincode"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.formParty.pincode,
                                        "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                        placeholder: "Enter PIN Code"
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "City",
                                    name: "city"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.formParty.city,
                                        "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                        placeholder: "Enter City"
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "State",
                                    name: "state"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        value: _ctx.formParty.state,
                                        "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                        placeholder: "Enter State"
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, { name: "same_ship" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_checkbox, {
                                        checked: _ctx.formParty.same_ship,
                                        "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Shipping address same as billing address")
                                        ]),
                                        _: 1
                                      }, 8, ["checked", "onUpdate:checked"])
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_sub_menu, {
                              key: "sub1",
                              visible: _ctx.menu_visible,
                              onClose: ($event) => _ctx.menu_visible = false
                            }, {
                              title: withCtx(() => [
                                createTextVNode("Add GSTIN & Address (Optional)")
                              ]),
                              default: withCtx(() => [
                                createVNode("h5", {
                                  "wrapper-col": { span: 12, offset: 6 },
                                  style: { "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" }
                                }, "Shipping Address"),
                                createVNode("br"),
                                createVNode("br"),
                                createVNode(_component_a_form_item, {
                                  label: "Flat / Building Number",
                                  name: "flat_no"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: _ctx.formParty.flat_no,
                                      "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                      placeholder: "Enter Flat / Building Number"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Area / Locality",
                                  name: "area_loc"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: _ctx.formParty.area_loc,
                                      "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                      placeholder: "Enter Area / Locality"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "PIN Code",
                                  name: "pincode"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: _ctx.formParty.pincode,
                                      "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                      placeholder: "Enter PIN Code"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "City",
                                  name: "city"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: _ctx.formParty.city,
                                      "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                      placeholder: "Enter City"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "State",
                                  name: "state"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      value: _ctx.formParty.state,
                                      "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                      placeholder: "Enter State"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, { name: "same_ship" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_checkbox, {
                                      checked: _ctx.formParty.same_ship,
                                      "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Shipping address same as billing address")
                                      ]),
                                      _: 1
                                    }, 8, ["checked", "onUpdate:checked"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["visible", "onClose"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      "wrapper-col": { span: 12, offset: 6 },
                      style: { "margin-top": "19px", "margin-left": "100px" }
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Save`);
                              } else {
                                return [
                                  createTextVNode("Save")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Save")
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form_item, {
                        label: "Party Name",
                        name: "partyname",
                        rules: [{ required: true }]
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            value: _ctx.formParty.partyname,
                            "onUpdate:value": ($event) => _ctx.formParty.partyname = $event,
                            placeholder: "Enter Customer Name"
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, {
                        label: "Mobile Number",
                        name: "mobile"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            value: _ctx.formParty.mobile,
                            "onUpdate:value": ($event) => _ctx.formParty.mobile = $event,
                            placeholder: "Enter Mobile Number"
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, {
                        label: "Who are they?",
                        name: "who_r_they"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_radio_group, {
                            value: _ctx.formParty.who_r_they,
                            "onUpdate:value": ($event) => _ctx.formParty.who_r_they = $event
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_radio, { value: "customer" }, {
                                default: withCtx(() => [
                                  createTextVNode("Customer")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_radio, { value: "supplier" }, {
                                default: withCtx(() => [
                                  createTextVNode("Supplier")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, {
                        label: "GSTIN",
                        name: "gstin",
                        rules: [{ required: true }]
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            value: _ctx.formParty.gstin,
                            "onUpdate:value": ($event) => _ctx.formParty.gstin = $event,
                            placeholder: "Enter GSTIN"
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_menu, {
                        id: "dddddd",
                        style: { "width": "100%" },
                        mode: "inline",
                        onClick: withModifiers(() => {
                          _ctx.menu_visible = true;
                        }, ["stop"])
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_sub_menu, {
                            key: "sub1",
                            visible: _ctx.menu_visible,
                            onClose: ($event) => _ctx.menu_visible = false
                          }, {
                            title: withCtx(() => [
                              createTextVNode("Add GSTIN & Address (Optional)")
                            ]),
                            default: withCtx(() => [
                              createVNode("h5", {
                                "wrapper-col": { span: 12, offset: 6 },
                                style: { "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" }
                              }, "Shipping Address"),
                              createVNode("br"),
                              createVNode("br"),
                              createVNode(_component_a_form_item, {
                                label: "Flat / Building Number",
                                name: "flat_no"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: _ctx.formParty.flat_no,
                                    "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                    placeholder: "Enter Flat / Building Number"
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Area / Locality",
                                name: "area_loc"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: _ctx.formParty.area_loc,
                                    "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                    placeholder: "Enter Area / Locality"
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "PIN Code",
                                name: "pincode"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: _ctx.formParty.pincode,
                                    "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                    placeholder: "Enter PIN Code"
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "City",
                                name: "city"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: _ctx.formParty.city,
                                    "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                    placeholder: "Enter City"
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "State",
                                name: "state"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: _ctx.formParty.state,
                                    "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                    placeholder: "Enter State"
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, { name: "same_ship" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_checkbox, {
                                    checked: _ctx.formParty.same_ship,
                                    "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Shipping address same as billing address")
                                    ]),
                                    _: 1
                                  }, 8, ["checked", "onUpdate:checked"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["visible", "onClose"])
                        ]),
                        _: 1
                      }, 8, ["onClick"]),
                      createVNode(_component_a_form_item, {
                        "wrapper-col": { span: 12, offset: 6 },
                        style: { "margin-top": "19px", "margin-left": "100px" }
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Save")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_form, mergeProps({ model: _ctx.formParty }, _ctx.layout, {
                  name: "nest-messages",
                  "validate-messages": _ctx.validateMessages,
                  onFinish: _ctx.partySubmit
                }), {
                  default: withCtx(() => [
                    createVNode(_component_a_form_item, {
                      label: "Party Name",
                      name: "partyname",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_input, {
                          value: _ctx.formParty.partyname,
                          "onUpdate:value": ($event) => _ctx.formParty.partyname = $event,
                          placeholder: "Enter Customer Name"
                        }, null, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, {
                      label: "Mobile Number",
                      name: "mobile"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_input, {
                          value: _ctx.formParty.mobile,
                          "onUpdate:value": ($event) => _ctx.formParty.mobile = $event,
                          placeholder: "Enter Mobile Number"
                        }, null, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, {
                      label: "Who are they?",
                      name: "who_r_they"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_radio_group, {
                          value: _ctx.formParty.who_r_they,
                          "onUpdate:value": ($event) => _ctx.formParty.who_r_they = $event
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_radio, { value: "customer" }, {
                              default: withCtx(() => [
                                createTextVNode("Customer")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_radio, { value: "supplier" }, {
                              default: withCtx(() => [
                                createTextVNode("Supplier")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, {
                      label: "GSTIN",
                      name: "gstin",
                      rules: [{ required: true }]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_input, {
                          value: _ctx.formParty.gstin,
                          "onUpdate:value": ($event) => _ctx.formParty.gstin = $event,
                          placeholder: "Enter GSTIN"
                        }, null, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_menu, {
                      id: "dddddd",
                      style: { "width": "100%" },
                      mode: "inline",
                      onClick: withModifiers(() => {
                        _ctx.menu_visible = true;
                      }, ["stop"])
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_sub_menu, {
                          key: "sub1",
                          visible: _ctx.menu_visible,
                          onClose: ($event) => _ctx.menu_visible = false
                        }, {
                          title: withCtx(() => [
                            createTextVNode("Add GSTIN & Address (Optional)")
                          ]),
                          default: withCtx(() => [
                            createVNode("h5", {
                              "wrapper-col": { span: 12, offset: 6 },
                              style: { "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" }
                            }, "Shipping Address"),
                            createVNode("br"),
                            createVNode("br"),
                            createVNode(_component_a_form_item, {
                              label: "Flat / Building Number",
                              name: "flat_no"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: _ctx.formParty.flat_no,
                                  "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                  placeholder: "Enter Flat / Building Number"
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "Area / Locality",
                              name: "area_loc"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: _ctx.formParty.area_loc,
                                  "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                  placeholder: "Enter Area / Locality"
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "PIN Code",
                              name: "pincode"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: _ctx.formParty.pincode,
                                  "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                  placeholder: "Enter PIN Code"
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "City",
                              name: "city"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: _ctx.formParty.city,
                                  "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                  placeholder: "Enter City"
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, {
                              label: "State",
                              name: "state"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  value: _ctx.formParty.state,
                                  "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                  placeholder: "Enter State"
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, { name: "same_ship" }, {
                              default: withCtx(() => [
                                createVNode(_component_a_checkbox, {
                                  checked: _ctx.formParty.same_ship,
                                  "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Shipping address same as billing address")
                                  ]),
                                  _: 1
                                }, 8, ["checked", "onUpdate:checked"])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 8, ["visible", "onClose"])
                      ]),
                      _: 1
                    }, 8, ["onClick"]),
                    createVNode(_component_a_form_item, {
                      "wrapper-col": { span: 12, offset: 6 },
                      style: { "margin-top": "19px", "margin-left": "100px" }
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_button, {
                          type: "primary",
                          "html-type": "submit"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Save")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }, 16, ["model", "validate-messages", "onFinish"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_layout_content, { style: { margin: "5px 16px", padding: "24px", background: "#fff", minHeight: "calc(100vh - 115px)" } }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_table, {
                columns: _ctx.columns,
                dataSource: _ctx.dataSource,
                pagination: _ctx.pagination,
                loading: _ctx.loading,
                onChange: _ctx.handleTableChange,
                bordered: ""
              }, {
                headerCell: withCtx(({ column }, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    if (column.key === "discount") {
                      _push4(`<span style="${ssrRenderStyle({ "margin-right": "15px" })}"${_scopeId3}> Discount </span>`);
                    } else {
                      _push4(`<!---->`);
                    }
                    if (column.key === "tax") {
                      _push4(`<!--[--><!--]-->`);
                    } else {
                      _push4(`<!---->`);
                    }
                  } else {
                    return [
                      column.key === "discount" ? (openBlock(), createBlock("span", {
                        key: 0,
                        style: { "margin-right": "15px" }
                      }, " Discount ")) : createCommentVNode("", true),
                      column.key === "tax" ? (openBlock(), createBlock(Fragment, { key: 1 }, [], 64)) : createCommentVNode("", true)
                    ];
                  }
                }),
                bodyCell: withCtx(({ column, text, record, index }, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(`<template${_scopeId3}>${ssrInterpolate(text ?? "-")}</template>`);
                    if (column.key === "category") {
                      _push4(ssrRenderComponent(_component_a_form_item, null, {
                        default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                          if (_push5) {
                            _push5(ssrRenderComponent(_component_a_select, { placeholder: "" }, {
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(ssrRenderComponent(_component_a_select_option, { value: "undefined" }, null, _parent6, _scopeId5));
                                } else {
                                  return [
                                    createVNode(_component_a_select_option, { value: "undefined" })
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                          } else {
                            return [
                              createVNode(_component_a_select, { placeholder: "" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select_option, { value: "undefined" })
                                ]),
                                _: 1
                              })
                            ];
                          }
                        }),
                        _: 2
                      }, _parent4, _scopeId3));
                    } else {
                      _push4(`<!---->`);
                    }
                    if (column.key === "sno") {
                      _push4(`<!--[-->${ssrInterpolate(index + 1)}<!--]-->`);
                    } else {
                      _push4(`<!---->`);
                    }
                  } else {
                    return [
                      createVNode("template", null, [
                        createTextVNode(toDisplayString(text ?? "-"), 1)
                      ]),
                      column.key === "category" ? (openBlock(), createBlock(_component_a_form_item, { key: 0 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_select, { placeholder: "" }, {
                            default: withCtx(() => [
                              createVNode(_component_a_select_option, { value: "undefined" })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })) : createCommentVNode("", true),
                      column.key === "sno" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                        createTextVNode(toDisplayString(index + 1), 1)
                      ], 64)) : createCommentVNode("", true)
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_row, null, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_col, { span: 12 }, null, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_col, { span: 12 }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_card, { style: { "width": "350px", "float": "right", "margin-top": "12px" } }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                                  name: "nest-messages",
                                  "validate-messages": _ctx.validateMessages,
                                  onFinish: _ctx.submit
                                }), {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_form_item, { label: "Total Net" }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              placeholder: "",
                                              style: { "width": "160px" }
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                placeholder: "",
                                                style: { "width": "160px" }
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Total Tax",
                                        name: "area_loc"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              placeholder: "",
                                              style: { "width": "160px" }
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                placeholder: "",
                                                style: { "width": "160px" }
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                      _push7(ssrRenderComponent(_component_a_form_item, {
                                        label: "Total",
                                        name: "area_loc"
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(ssrRenderComponent(_component_a_input, {
                                              placeholder: "",
                                              style: { "width": "160px" }
                                            }, null, _parent8, _scopeId7));
                                          } else {
                                            return [
                                              createVNode(_component_a_input, {
                                                placeholder: "",
                                                style: { "width": "160px" }
                                              })
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_form_item, { label: "Total Net" }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              placeholder: "",
                                              style: { "width": "160px" }
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_form_item, {
                                          label: "Total Tax",
                                          name: "area_loc"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              placeholder: "",
                                              style: { "width": "160px" }
                                            })
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_form_item, {
                                          label: "Total",
                                          name: "area_loc"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_input, {
                                              placeholder: "",
                                              style: { "width": "160px" }
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                                    name: "nest-messages",
                                    "validate-messages": _ctx.validateMessages,
                                    onFinish: _ctx.submit
                                  }), {
                                    default: withCtx(() => [
                                      createVNode(_component_a_form_item, { label: "Total Net" }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            placeholder: "",
                                            style: { "width": "160px" }
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_form_item, {
                                        label: "Total Tax",
                                        name: "area_loc"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            placeholder: "",
                                            style: { "width": "160px" }
                                          })
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_a_form_item, {
                                        label: "Total",
                                        name: "area_loc"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_input, {
                                            placeholder: "",
                                            style: { "width": "160px" }
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 16, ["model", "validate-messages", "onFinish"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_card, { style: { "width": "350px", "float": "right", "margin-top": "12px" } }, {
                              default: withCtx(() => [
                                createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                                  name: "nest-messages",
                                  "validate-messages": _ctx.validateMessages,
                                  onFinish: _ctx.submit
                                }), {
                                  default: withCtx(() => [
                                    createVNode(_component_a_form_item, { label: "Total Net" }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          placeholder: "",
                                          style: { "width": "160px" }
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_form_item, {
                                      label: "Total Tax",
                                      name: "area_loc"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          placeholder: "",
                                          style: { "width": "160px" }
                                        })
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_form_item, {
                                      label: "Total",
                                      name: "area_loc"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_input, {
                                          placeholder: "",
                                          style: { "width": "160px" }
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 16, ["model", "validate-messages", "onFinish"])
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_col, { span: 12 }),
                      createVNode(_component_a_col, { span: 12 }, {
                        default: withCtx(() => [
                          createVNode(_component_a_card, { style: { "width": "350px", "float": "right", "margin-top": "12px" } }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                                name: "nest-messages",
                                "validate-messages": _ctx.validateMessages,
                                onFinish: _ctx.submit
                              }), {
                                default: withCtx(() => [
                                  createVNode(_component_a_form_item, { label: "Total Net" }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        placeholder: "",
                                        style: { "width": "160px" }
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Total Tax",
                                    name: "area_loc"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        placeholder: "",
                                        style: { "width": "160px" }
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_form_item, {
                                    label: "Total",
                                    name: "area_loc"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_input, {
                                        placeholder: "",
                                        style: { "width": "160px" }
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 16, ["model", "validate-messages", "onFinish"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_table, {
                  columns: _ctx.columns,
                  dataSource: _ctx.dataSource,
                  pagination: _ctx.pagination,
                  loading: _ctx.loading,
                  onChange: _ctx.handleTableChange,
                  bordered: ""
                }, {
                  headerCell: withCtx(({ column }) => [
                    column.key === "discount" ? (openBlock(), createBlock("span", {
                      key: 0,
                      style: { "margin-right": "15px" }
                    }, " Discount ")) : createCommentVNode("", true),
                    column.key === "tax" ? (openBlock(), createBlock(Fragment, { key: 1 }, [], 64)) : createCommentVNode("", true)
                  ]),
                  bodyCell: withCtx(({ column, text, record, index }) => [
                    createVNode("template", null, [
                      createTextVNode(toDisplayString(text ?? "-"), 1)
                    ]),
                    column.key === "category" ? (openBlock(), createBlock(_component_a_form_item, { key: 0 }, {
                      default: withCtx(() => [
                        createVNode(_component_a_select, { placeholder: "" }, {
                          default: withCtx(() => [
                            createVNode(_component_a_select_option, { value: "undefined" })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })) : createCommentVNode("", true),
                    column.key === "sno" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                      createTextVNode(toDisplayString(index + 1), 1)
                    ], 64)) : createCommentVNode("", true)
                  ]),
                  _: 1
                }, 8, ["columns", "dataSource", "pagination", "loading", "onChange"]),
                createVNode(_component_a_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_a_col, { span: 12 }),
                    createVNode(_component_a_col, { span: 12 }, {
                      default: withCtx(() => [
                        createVNode(_component_a_card, { style: { "width": "350px", "float": "right", "margin-top": "12px" } }, {
                          default: withCtx(() => [
                            createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                              name: "nest-messages",
                              "validate-messages": _ctx.validateMessages,
                              onFinish: _ctx.submit
                            }), {
                              default: withCtx(() => [
                                createVNode(_component_a_form_item, { label: "Total Net" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      placeholder: "",
                                      style: { "width": "160px" }
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Total Tax",
                                  name: "area_loc"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      placeholder: "",
                                      style: { "width": "160px" }
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_form_item, {
                                  label: "Total",
                                  name: "area_loc"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_input, {
                                      placeholder: "",
                                      style: { "width": "160px" }
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 16, ["model", "validate-messages", "onFinish"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_affix, { "offset-top": 0 }, {
            default: withCtx(() => [
              createVNode(_component_a_page_header, {
                ghost: false,
                title: "Money In",
                onBack: () => _ctx.$inertia.visit(_ctx.route("cashbook.index"))
              }, {
                extra: withCtx(() => [
                  createVNode(_component_a_button, { type: "primary" }, {
                    default: withCtx(() => [
                      createTextVNode("Save")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["onBack"])
            ]),
            _: 1
          }),
          createVNode(_component_a_row, { style: { "padding": "'24px'", "background": "'#fff'", "margin-top": "12px", "margin-bottom": "12px", "margin-left": "16px", "minHeight": "'180px'" } }, {
            default: withCtx(() => [
              createVNode(_component_a_col, { span: 24 }, {
                default: withCtx(() => [
                  createVNode(_component_a_card, { style: { "width": "1118px" } }, {
                    default: withCtx(() => [
                      createVNode(_component_a_row, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, { span: 4 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "Contact(optional)" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    placeholder: "Search for a Customer",
                                    style: { "width": "160px" }
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, {
                                        value: "undefined",
                                        onClick: withModifiers(() => {
                                          _ctx.showmodel_visible = true;
                                        }, ["stop"])
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_PlusCircleOutlined),
                                          createTextVNode(" Add New Customer")
                                        ]),
                                        _: 1
                                      }, 8, ["onClick"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { span: 4 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "Paid into Bank Account" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    placeholder: "Please Select",
                                    style: { "width": "160px" }
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, { value: "undefined" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { span: 4 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "Method" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_select, {
                                    placeholder: "Please Select",
                                    style: { "width": "160px" }
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_select_option, { value: "undefined" })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { span: 4 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "Date Received" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_date_picker, {
                                    value: _ctx.date,
                                    "onUpdate:value": ($event) => _ctx.date = $event,
                                    format: "DD-MM-YYYY",
                                    "value-format": "YYYY-MM-DD",
                                    style: { "width": "160px" }
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { span: 4 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "Your Reference (optional)" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: _ctx.value,
                                    "onUpdate:value": ($event) => _ctx.value = $event,
                                    placeholder: "e.g. Check number",
                                    style: { "width": "160px" }
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { span: 4 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "Amount Received" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    value: _ctx.value,
                                    "onUpdate:value": ($event) => _ctx.value = $event,
                                    placeholder: "",
                                    style: { "width": "160px" }
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_a_modal, {
            title: "Add New Customer",
            closable: true,
            visible: _ctx.showmodel_visible,
            "onUpdate:visible": ($event) => _ctx.showmodel_visible = $event,
            onClose: ($event) => _ctx.showmodel_visible = false
          }, {
            default: withCtx(() => [
              createVNode(_component_a_form, mergeProps({ model: _ctx.formParty }, _ctx.layout, {
                name: "nest-messages",
                "validate-messages": _ctx.validateMessages,
                onFinish: _ctx.partySubmit
              }), {
                default: withCtx(() => [
                  createVNode(_component_a_form_item, {
                    label: "Party Name",
                    name: "partyname",
                    rules: [{ required: true }]
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_input, {
                        value: _ctx.formParty.partyname,
                        "onUpdate:value": ($event) => _ctx.formParty.partyname = $event,
                        placeholder: "Enter Customer Name"
                      }, null, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, {
                    label: "Mobile Number",
                    name: "mobile"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_input, {
                        value: _ctx.formParty.mobile,
                        "onUpdate:value": ($event) => _ctx.formParty.mobile = $event,
                        placeholder: "Enter Mobile Number"
                      }, null, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, {
                    label: "Who are they?",
                    name: "who_r_they"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_radio_group, {
                        value: _ctx.formParty.who_r_they,
                        "onUpdate:value": ($event) => _ctx.formParty.who_r_they = $event
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_radio, { value: "customer" }, {
                            default: withCtx(() => [
                              createTextVNode("Customer")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_radio, { value: "supplier" }, {
                            default: withCtx(() => [
                              createTextVNode("Supplier")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, {
                    label: "GSTIN",
                    name: "gstin",
                    rules: [{ required: true }]
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_input, {
                        value: _ctx.formParty.gstin,
                        "onUpdate:value": ($event) => _ctx.formParty.gstin = $event,
                        placeholder: "Enter GSTIN"
                      }, null, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_menu, {
                    id: "dddddd",
                    style: { "width": "100%" },
                    mode: "inline",
                    onClick: withModifiers(() => {
                      _ctx.menu_visible = true;
                    }, ["stop"])
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_sub_menu, {
                        key: "sub1",
                        visible: _ctx.menu_visible,
                        onClose: ($event) => _ctx.menu_visible = false
                      }, {
                        title: withCtx(() => [
                          createTextVNode("Add GSTIN & Address (Optional)")
                        ]),
                        default: withCtx(() => [
                          createVNode("h5", {
                            "wrapper-col": { span: 12, offset: 6 },
                            style: { "margin-bottom": "20px", "font-size": "15px", "margin-top": "20px" }
                          }, "Shipping Address"),
                          createVNode("br"),
                          createVNode("br"),
                          createVNode(_component_a_form_item, {
                            label: "Flat / Building Number",
                            name: "flat_no"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: _ctx.formParty.flat_no,
                                "onUpdate:value": ($event) => _ctx.formParty.flat_no = $event,
                                placeholder: "Enter Flat / Building Number"
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "Area / Locality",
                            name: "area_loc"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: _ctx.formParty.area_loc,
                                "onUpdate:value": ($event) => _ctx.formParty.area_loc = $event,
                                placeholder: "Enter Area / Locality"
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "PIN Code",
                            name: "pincode"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: _ctx.formParty.pincode,
                                "onUpdate:value": ($event) => _ctx.formParty.pincode = $event,
                                placeholder: "Enter PIN Code"
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "City",
                            name: "city"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: _ctx.formParty.city,
                                "onUpdate:value": ($event) => _ctx.formParty.city = $event,
                                placeholder: "Enter City"
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, {
                            label: "State",
                            name: "state"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                value: _ctx.formParty.state,
                                "onUpdate:value": ($event) => _ctx.formParty.state = $event,
                                placeholder: "Enter State"
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, { name: "same_ship" }, {
                            default: withCtx(() => [
                              createVNode(_component_a_checkbox, {
                                checked: _ctx.formParty.same_ship,
                                "onUpdate:checked": ($event) => _ctx.formParty.same_ship = $event
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Shipping address same as billing address")
                                ]),
                                _: 1
                              }, 8, ["checked", "onUpdate:checked"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["visible", "onClose"])
                    ]),
                    _: 1
                  }, 8, ["onClick"]),
                  createVNode(_component_a_form_item, {
                    "wrapper-col": { span: 12, offset: 6 },
                    style: { "margin-top": "19px", "margin-left": "100px" }
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_button, {
                        type: "primary",
                        "html-type": "submit"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Save")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 16, ["model", "validate-messages", "onFinish"])
            ]),
            _: 1
          }, 8, ["visible", "onUpdate:visible", "onClose"]),
          createVNode(_component_a_layout_content, { style: { margin: "5px 16px", padding: "24px", background: "#fff", minHeight: "calc(100vh - 115px)" } }, {
            default: withCtx(() => [
              createVNode(_component_a_table, {
                columns: _ctx.columns,
                dataSource: _ctx.dataSource,
                pagination: _ctx.pagination,
                loading: _ctx.loading,
                onChange: _ctx.handleTableChange,
                bordered: ""
              }, {
                headerCell: withCtx(({ column }) => [
                  column.key === "discount" ? (openBlock(), createBlock("span", {
                    key: 0,
                    style: { "margin-right": "15px" }
                  }, " Discount ")) : createCommentVNode("", true),
                  column.key === "tax" ? (openBlock(), createBlock(Fragment, { key: 1 }, [], 64)) : createCommentVNode("", true)
                ]),
                bodyCell: withCtx(({ column, text, record, index }) => [
                  createVNode("template", null, [
                    createTextVNode(toDisplayString(text ?? "-"), 1)
                  ]),
                  column.key === "category" ? (openBlock(), createBlock(_component_a_form_item, { key: 0 }, {
                    default: withCtx(() => [
                      createVNode(_component_a_select, { placeholder: "" }, {
                        default: withCtx(() => [
                          createVNode(_component_a_select_option, { value: "undefined" })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })) : createCommentVNode("", true),
                  column.key === "sno" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                    createTextVNode(toDisplayString(index + 1), 1)
                  ], 64)) : createCommentVNode("", true)
                ]),
                _: 1
              }, 8, ["columns", "dataSource", "pagination", "loading", "onChange"]),
              createVNode(_component_a_row, null, {
                default: withCtx(() => [
                  createVNode(_component_a_col, { span: 12 }),
                  createVNode(_component_a_col, { span: 12 }, {
                    default: withCtx(() => [
                      createVNode(_component_a_card, { style: { "width": "350px", "float": "right", "margin-top": "12px" } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form, mergeProps({ model: _ctx.formState }, _ctx.layout, {
                            name: "nest-messages",
                            "validate-messages": _ctx.validateMessages,
                            onFinish: _ctx.submit
                          }), {
                            default: withCtx(() => [
                              createVNode(_component_a_form_item, { label: "Total Net" }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    placeholder: "",
                                    style: { "width": "160px" }
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Total Tax",
                                name: "area_loc"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    placeholder: "",
                                    style: { "width": "160px" }
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_form_item, {
                                label: "Total",
                                name: "area_loc"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_input, {
                                    placeholder: "",
                                    style: { "width": "160px" }
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 16, ["model", "validate-messages", "onFinish"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["style"])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Cashbook/Moneyin.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Moneyin = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Moneyin as default
};
