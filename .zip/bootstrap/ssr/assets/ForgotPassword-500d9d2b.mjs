import { resolveComponent, withCtx, unref, createVNode, createTextVNode, openBlock, createBlock, toDisplayString, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./GuestLayout-ffa9de66.mjs";
import { _ as _sfc_main$2 } from "./InputError-6d616b1a.mjs";
import "./TextInput-90c24419.mjs";
import "./PrimaryButton-b82fb16e.mjs";
import { useForm, Head, Link } from "@inertiajs/vue3";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "ForgotPassword",
  __ssrInlineRender: true,
  props: {
    status: String
  },
  setup(__props) {
    const form = useForm({
      email: ""
    });
    const submit = () => {
      form.post(route("password.email"), {
        onFinish: () => form.reset("password")
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_a_form = resolveComponent("a-form");
      const _component_a_form_item = resolveComponent("a-form-item");
      const _component_a_input = resolveComponent("a-input");
      const _component_a_button = resolveComponent("a-button");
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Forgot Password" }, null, _parent2, _scopeId));
            _push2(`<div class="mb-4 text-sm text-gray-600"${_scopeId}> Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one. </div><br${_scopeId}>`);
            if (__props.status) {
              _push2(`<div class="mb-4 font-medium text-sm text-green-600"${_scopeId}>${ssrInterpolate(__props.status)} <br${_scopeId}></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(ssrRenderComponent(_component_a_form, {
              model: unref(form),
              name: "basic",
              "label-col": { span: 24 },
              autocomplete: "off",
              onFinish: submit,
              onFinishFailed: _ctx.onFinishFailed
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_a_form_item, {
                    label: "Email",
                    name: "email"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_a_input, {
                          value: unref(form).email,
                          "onUpdate:value": ($event) => unref(form).email = $event
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_sfc_main$2, {
                          class: "mt-2",
                          message: unref(form).errors.email
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_a_input, {
                            value: unref(form).email,
                            "onUpdate:value": ($event) => unref(form).email = $event
                          }, null, 8, ["value", "onUpdate:value"]),
                          createVNode(_sfc_main$2, {
                            class: "mt-2",
                            message: unref(form).errors.email
                          }, null, 8, ["message"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(Link), {
                    href: _ctx.route("login"),
                    style: { "margin": "15px 0", "display": "block" }
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<u${_scopeId3}>Back to login</u>`);
                      } else {
                        return [
                          createVNode("u", null, "Back to login")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_a_form_item, null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_a_button, {
                          type: "primary",
                          "html-type": "submit",
                          size: "large",
                          disabled: unref(form).processing,
                          block: ""
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`Submit`);
                            } else {
                              return [
                                createTextVNode("Submit")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit",
                            size: "large",
                            disabled: unref(form).processing,
                            block: ""
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Submit")
                            ]),
                            _: 1
                          }, 8, ["disabled"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_a_form_item, {
                      label: "Email",
                      name: "email"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_input, {
                          value: unref(form).email,
                          "onUpdate:value": ($event) => unref(form).email = $event
                        }, null, 8, ["value", "onUpdate:value"]),
                        createVNode(_sfc_main$2, {
                          class: "mt-2",
                          message: unref(form).errors.email
                        }, null, 8, ["message"])
                      ]),
                      _: 1
                    }),
                    createVNode(unref(Link), {
                      href: _ctx.route("login"),
                      style: { "margin": "15px 0", "display": "block" }
                    }, {
                      default: withCtx(() => [
                        createVNode("u", null, "Back to login")
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode(_component_a_form_item, null, {
                      default: withCtx(() => [
                        createVNode(_component_a_button, {
                          type: "primary",
                          "html-type": "submit",
                          size: "large",
                          disabled: unref(form).processing,
                          block: ""
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Submit")
                          ]),
                          _: 1
                        }, 8, ["disabled"])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Head), { title: "Forgot Password" }),
              createVNode("div", { class: "mb-4 text-sm text-gray-600" }, " Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one. "),
              createVNode("br"),
              __props.status ? (openBlock(), createBlock("div", {
                key: 0,
                class: "mb-4 font-medium text-sm text-green-600"
              }, [
                createTextVNode(toDisplayString(__props.status) + " ", 1),
                createVNode("br")
              ])) : createCommentVNode("", true),
              createVNode(_component_a_form, {
                model: unref(form),
                name: "basic",
                "label-col": { span: 24 },
                autocomplete: "off",
                onFinish: submit,
                onFinishFailed: _ctx.onFinishFailed
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form_item, {
                    label: "Email",
                    name: "email"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_input, {
                        value: unref(form).email,
                        "onUpdate:value": ($event) => unref(form).email = $event
                      }, null, 8, ["value", "onUpdate:value"]),
                      createVNode(_sfc_main$2, {
                        class: "mt-2",
                        message: unref(form).errors.email
                      }, null, 8, ["message"])
                    ]),
                    _: 1
                  }),
                  createVNode(unref(Link), {
                    href: _ctx.route("login"),
                    style: { "margin": "15px 0", "display": "block" }
                  }, {
                    default: withCtx(() => [
                      createVNode("u", null, "Back to login")
                    ]),
                    _: 1
                  }, 8, ["href"]),
                  createVNode(_component_a_form_item, null, {
                    default: withCtx(() => [
                      createVNode(_component_a_button, {
                        type: "primary",
                        "html-type": "submit",
                        size: "large",
                        disabled: unref(form).processing,
                        block: ""
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Submit")
                        ]),
                        _: 1
                      }, 8, ["disabled"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["model", "onFinishFailed"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Auth/ForgotPassword.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
