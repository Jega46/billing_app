import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import "vue-request";
import { resolveComponent, withCtx, createVNode, createTextVNode, openBlock, createBlock, createCommentVNode, mergeProps, useSSRContext } from "vue";
import { Head, Link, useForm } from "@inertiajs/vue3";
import { DownloadOutlined, PlusCircleOutlined, MoreOutlined } from "@ant-design/icons-vue";
import { ssrRenderComponent, ssrRenderStyle } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
const columns = [
  {
    title: "",
    key: "image",
    dataIndex: "image",
    sorter: true,
    width: "5%"
  },
  {
    title: "Name",
    key: "name",
    dataIndex: "name",
    width: "15%"
  },
  {
    title: "Category",
    key: "category",
    dataIndex: "category",
    width: "15%"
  },
  {
    title: "Description",
    key: "description",
    dataIndex: "description",
    width: "30%"
  },
  {
    title: "Price (INR)",
    key: "price",
    dataIndex: "price",
    width: "10%"
  },
  {
    title: "Inventory",
    key: "inventory",
    dataIndex: "",
    width: "20%"
  },
  {
    title: "Action",
    key: "action",
    fixed: "right",
    width: "2%"
  }
];
const _sfc_main = {
  components: { AuthenticatedLayout: _sfc_main$1, DownloadOutlined, PlusCircleOutlined, MoreOutlined, Head, Link },
  props: {
    products: Object,
    pagination: Object,
    errors: Object
  },
  setup(props) {
    return {
      columns
    };
  },
  data() {
    const loading = false;
    const create_form_visible = false;
    const formState = useForm({
      term: ""
    });
    return {
      create_form_visible,
      loading,
      formState
    };
  },
  methods: {
    search() {
      this.$inertia.get("/products", { s: this.formState.term }, { preserveState: true });
    },
    handleTableChange(val) {
      this.$inertia.get(
        "/products",
        { page: val.current },
        { preserveState: true }
      );
    },
    deleteBranch(id) {
    },
    showDrawer() {
      this.create_form_visible = true;
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_space = resolveComponent("a-space");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_button = resolveComponent("a-button");
  const _component_plus_circle_outlined = resolveComponent("plus-circle-outlined");
  const _component_a_table = resolveComponent("a-table");
  const _component_a_dropdown = resolveComponent("a-dropdown");
  const _component_a_menu = resolveComponent("a-menu");
  const _component_a_menu_item = resolveComponent("a-menu-item");
  const _component_more_outlined = resolveComponent("more-outlined");
  const _component_DownOutlined = resolveComponent("DownOutlined");
  const _component_a_drawer = resolveComponent("a-drawer");
  const _component_a_row = resolveComponent("a-row");
  const _component_a_col = resolveComponent("a-col");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_input_number = resolveComponent("a-input-number");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Sales Orders" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_layout_content, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, {
                      name: "nest-messages",
                      model: $data.formState,
                      layout: "inline",
                      onFinish: $options.search
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input, {
                                  placeholder: "Search by product name",
                                  "allow-clear": true,
                                  value: $data.formState.term,
                                  "onUpdate:value": ($event) => $data.formState.term = $event
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input, {
                                    placeholder: "Search by product name",
                                    "allow-clear": true,
                                    value: $data.formState.term,
                                    "onUpdate:value": ($event) => $data.formState.term = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Search `);
                                    } else {
                                      return [
                                        createTextVNode(" Search ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Search ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_plus_circle_outlined, null, null, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_plus_circle_outlined)
                                      ];
                                    }
                                  }),
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` New Sales Order `);
                                    } else {
                                      return [
                                        createTextVNode(" New Sales Order ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    shape: "round",
                                    onClick: $options.showDrawer
                                  }, {
                                    icon: withCtx(() => [
                                      createVNode(_component_plus_circle_outlined)
                                    ]),
                                    default: withCtx(() => [
                                      createTextVNode(" New Sales Order ")
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  placeholder: "Search by product name",
                                  "allow-clear": true,
                                  value: $data.formState.term,
                                  "onUpdate:value": ($event) => $data.formState.term = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Search ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  shape: "round",
                                  onClick: $options.showDrawer
                                }, {
                                  icon: withCtx(() => [
                                    createVNode(_component_plus_circle_outlined)
                                  ]),
                                  default: withCtx(() => [
                                    createTextVNode(" New Sales Order ")
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_table, {
                      columns: $setup.columns,
                      "row-key": (product) => product.id,
                      "data-source": $props.products.data,
                      pagination: $props.pagination,
                      loading: $data.loading,
                      onChange: $options.handleTableChange
                    }, {
                      bodyCell: withCtx(({ column, text, record }, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          if (column.key === "action") {
                            _push5(ssrRenderComponent(_component_a_dropdown, null, {
                              overlay: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(ssrRenderComponent(_component_a_menu, null, {
                                    default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_a_menu_item, { key: "1" }, {
                                          default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(` Edit `);
                                            } else {
                                              return [
                                                createTextVNode(" Edit ")
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                        _push7(ssrRenderComponent(_component_a_menu_item, {
                                          key: "4",
                                          onClick: ($event) => $options.deleteBranch(record.id)
                                        }, {
                                          default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(` Delete `);
                                            } else {
                                              return [
                                                createTextVNode(" Delete ")
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_a_menu_item, { key: "1" }, {
                                            default: withCtx(() => [
                                              createTextVNode(" Edit ")
                                            ]),
                                            _: 1
                                          }),
                                          createVNode(_component_a_menu_item, {
                                            key: "4",
                                            onClick: ($event) => $options.deleteBranch(record.id)
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(" Delete ")
                                            ]),
                                            _: 2
                                          }, 1032, ["onClick"])
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  return [
                                    createVNode(_component_a_menu, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_menu_item, { key: "1" }, {
                                          default: withCtx(() => [
                                            createTextVNode(" Edit ")
                                          ]),
                                          _: 1
                                        }),
                                        createVNode(_component_a_menu_item, {
                                          key: "4",
                                          onClick: ($event) => $options.deleteBranch(record.id)
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(" Delete ")
                                          ]),
                                          _: 2
                                        }, 1032, ["onClick"])
                                      ]),
                                      _: 2
                                    }, 1024)
                                  ];
                                }
                              }),
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(ssrRenderComponent(_component_a_button, null, {
                                    default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                      if (_push7) {
                                        _push7(ssrRenderComponent(_component_more_outlined, null, null, _parent7, _scopeId6));
                                        _push7(ssrRenderComponent(_component_DownOutlined, null, null, _parent7, _scopeId6));
                                      } else {
                                        return [
                                          createVNode(_component_more_outlined),
                                          createVNode(_component_DownOutlined)
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent6, _scopeId5));
                                } else {
                                  return [
                                    createVNode(_component_a_button, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_more_outlined),
                                        createVNode(_component_DownOutlined)
                                      ]),
                                      _: 1
                                    })
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                          } else {
                            _push5(`<!---->`);
                          }
                        } else {
                          return [
                            column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 0 }, {
                              overlay: withCtx(() => [
                                createVNode(_component_a_menu, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_menu_item, { key: "1" }, {
                                      default: withCtx(() => [
                                        createTextVNode(" Edit ")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_a_menu_item, {
                                      key: "4",
                                      onClick: ($event) => $options.deleteBranch(record.id)
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(" Delete ")
                                      ]),
                                      _: 2
                                    }, 1032, ["onClick"])
                                  ]),
                                  _: 2
                                }, 1024)
                              ]),
                              default: withCtx(() => [
                                createVNode(_component_a_button, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_more_outlined),
                                    createVNode(_component_DownOutlined)
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 2
                            }, 1024)) : createCommentVNode("", true)
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, {
                        name: "nest-messages",
                        model: $data.formState,
                        layout: "inline",
                        onFinish: $options.search
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                placeholder: "Search by product name",
                                "allow-clear": true,
                                value: $data.formState.term,
                                "onUpdate:value": ($event) => $data.formState.term = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Search ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                shape: "round",
                                onClick: $options.showDrawer
                              }, {
                                icon: withCtx(() => [
                                  createVNode(_component_plus_circle_outlined)
                                ]),
                                default: withCtx(() => [
                                  createTextVNode(" New Sales Order ")
                                ]),
                                _: 1
                              }, 8, ["onClick"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["model", "onFinish"]),
                      createVNode(_component_a_table, {
                        columns: $setup.columns,
                        "row-key": (product) => product.id,
                        "data-source": $props.products.data,
                        pagination: $props.pagination,
                        loading: $data.loading,
                        onChange: $options.handleTableChange
                      }, {
                        bodyCell: withCtx(({ column, text, record }) => [
                          column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 0 }, {
                            overlay: withCtx(() => [
                              createVNode(_component_a_menu, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_menu_item, { key: "1" }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Edit ")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_menu_item, {
                                    key: "4",
                                    onClick: ($event) => $options.deleteBranch(record.id)
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Delete ")
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"])
                                ]),
                                _: 2
                              }, 1024)
                            ]),
                            default: withCtx(() => [
                              createVNode(_component_a_button, null, {
                                default: withCtx(() => [
                                  createVNode(_component_more_outlined),
                                  createVNode(_component_DownOutlined)
                                ]),
                                _: 1
                              })
                            ]),
                            _: 2
                          }, 1024)) : createCommentVNode("", true)
                        ]),
                        _: 1
                      }, 8, ["columns", "row-key", "data-source", "pagination", "loading", "onChange"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
              _push3(ssrRenderComponent(_component_a_drawer, {
                visible: $data.create_form_visible,
                "onUpdate:visible": ($event) => $data.create_form_visible = $event,
                class: "sales-bill",
                size: "large",
                style: { "color": "red" },
                title: "New Sales Oerder",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, mergeProps({ model: $data.formState }, _ctx.layout, {
                      name: "nest-messages",
                      "validate-messages": _ctx.validateMessages,
                      onFinish: _ctx.submit,
                      "label-col": { span: 24 }
                    }), {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(`<div class="address"${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_row, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, { span: 8 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<img src="https://moziztech.com/images/logo/moziz-logo.png" style="${ssrRenderStyle({ "max-width": "200px" })}"${_scopeId6}>`);
                                    } else {
                                      return [
                                        createVNode("img", {
                                          src: "https://moziztech.com/images/logo/moziz-logo.png",
                                          style: { "max-width": "200px" }
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 16 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<p${_scopeId6}>KK Nagar, Karthick raja complex, Madurai - 625020</p><p${_scopeId6}>Email: support@moziztech.com</p><p${_scopeId6}>Phone: 8072403631</p><p${_scopeId6}>GSTIN: 33NN0033SSJJ933</p>`);
                                    } else {
                                      return [
                                        createVNode("p", null, "KK Nagar, Karthick raja complex, Madurai - 625020"),
                                        createVNode("p", null, "Email: support@moziztech.com"),
                                        createVNode("p", null, "Phone: 8072403631"),
                                        createVNode("p", null, "GSTIN: 33NN0033SSJJ933")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, { span: 8 }, {
                                    default: withCtx(() => [
                                      createVNode("img", {
                                        src: "https://moziztech.com/images/logo/moziz-logo.png",
                                        style: { "max-width": "200px" }
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 16 }, {
                                    default: withCtx(() => [
                                      createVNode("p", null, "KK Nagar, Karthick raja complex, Madurai - 625020"),
                                      createVNode("p", null, "Email: support@moziztech.com"),
                                      createVNode("p", null, "Phone: 8072403631"),
                                      createVNode("p", null, "GSTIN: 33NN0033SSJJ933")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`</div><hr${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_row, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<table${_scopeId6}><tr${_scopeId6}><th${_scopeId6}>Order / Bill No</th><td style="${ssrRenderStyle({ "width": "40px" })}"${_scopeId6}>:</td><td${_scopeId6}>12560</td></tr></table>`);
                                    } else {
                                      return [
                                        createVNode("table", null, [
                                          createVNode("tr", null, [
                                            createVNode("th", null, "Order / Bill No"),
                                            createVNode("td", { style: { "width": "40px" } }, ":"),
                                            createVNode("td", null, "12560")
                                          ])
                                        ])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<table${_scopeId6}><tr${_scopeId6}><th${_scopeId6}>Date</th><td style="${ssrRenderStyle({ "width": "40px" })}"${_scopeId6}>:</td><td${_scopeId6}>10-10-2023</td></tr></table>`);
                                    } else {
                                      return [
                                        createVNode("table", null, [
                                          createVNode("tr", null, [
                                            createVNode("th", null, "Date"),
                                            createVNode("td", { style: { "width": "40px" } }, ":"),
                                            createVNode("td", null, "10-10-2023")
                                          ])
                                        ])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("table", null, [
                                        createVNode("tr", null, [
                                          createVNode("th", null, "Order / Bill No"),
                                          createVNode("td", { style: { "width": "40px" } }, ":"),
                                          createVNode("td", null, "12560")
                                        ])
                                      ])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("table", null, [
                                        createVNode("tr", null, [
                                          createVNode("th", null, "Date"),
                                          createVNode("td", { style: { "width": "40px" } }, ":"),
                                          createVNode("td", null, "10-10-2023")
                                        ])
                                      ])
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<hr${_scopeId4}><table class="products-table"${_scopeId4}><thead${_scopeId4}><tr${_scopeId4}><th${_scopeId4}>Item Name</th><th${_scopeId4}>Qty</th><th${_scopeId4}>Mrp</th><th${_scopeId4}>Rate</th><th${_scopeId4}>Amount</th></tr></thead><tbody${_scopeId4}><tr${_scopeId4}><td${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_select, {
                            value: _ctx.value,
                            "onUpdate:value": ($event) => _ctx.value = $event,
                            "show-search": "",
                            placeholder: "Category",
                            style: { "width": "100%" },
                            "default-active-first-option": false,
                            "show-arrow": true,
                            "filter-option": false,
                            options: [{ value: "Mobile", label: "Mobile" }],
                            "not-found-content": _ctx.value,
                            onSearch: _ctx.handleSearch,
                            bordered: false,
                            onChange: _ctx.handleChange
                          }, null, _parent5, _scopeId4));
                          _push5(`</td><td${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_input_number, {
                            value: $data.formState.price,
                            "onUpdate:value": ($event) => $data.formState.price = $event,
                            style: { "width": "100%" },
                            bordered: false
                          }, null, _parent5, _scopeId4));
                          _push5(`</td><td${_scopeId4}></td><td${_scopeId4}></td><td${_scopeId4}></td></tr><tr${_scopeId4}><td${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_select, {
                            value: _ctx.value,
                            "onUpdate:value": ($event) => _ctx.value = $event,
                            "show-search": "",
                            placeholder: "Category",
                            style: { "width": "100%" },
                            "default-active-first-option": false,
                            "show-arrow": true,
                            "filter-option": false,
                            options: [{ value: "Mobile", label: "Mobile" }],
                            "not-found-content": _ctx.value,
                            onSearch: _ctx.handleSearch,
                            bordered: false,
                            onChange: _ctx.handleChange
                          }, null, _parent5, _scopeId4));
                          _push5(`</td><td${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_input_number, {
                            value: $data.formState.price,
                            "onUpdate:value": ($event) => $data.formState.price = $event,
                            style: { "width": "100%" },
                            bordered: false
                          }, null, _parent5, _scopeId4));
                          _push5(`</td><td${_scopeId4}></td><td${_scopeId4}></td><td${_scopeId4}></td></tr><tr${_scopeId4}><td${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_select, {
                            value: _ctx.value,
                            "onUpdate:value": ($event) => _ctx.value = $event,
                            "show-search": "",
                            placeholder: "Category",
                            style: { "width": "100%" },
                            "default-active-first-option": false,
                            "show-arrow": true,
                            "filter-option": false,
                            options: [{ value: "Mobile", label: "Mobile" }],
                            "not-found-content": _ctx.value,
                            onSearch: _ctx.handleSearch,
                            bordered: false,
                            onChange: _ctx.handleChange
                          }, null, _parent5, _scopeId4));
                          _push5(`</td><td${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_input_number, {
                            value: $data.formState.price,
                            "onUpdate:value": ($event) => $data.formState.price = $event,
                            style: { "width": "100%" },
                            bordered: false
                          }, null, _parent5, _scopeId4));
                          _push5(`</td><td${_scopeId4}></td><td${_scopeId4}></td><td${_scopeId4}></td></tr></tbody></table><hr${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_row, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<table${_scopeId6}><tr${_scopeId6}><th${_scopeId6}>Total Qty</th><td style="${ssrRenderStyle({ "width": "40px" })}"${_scopeId6}>:</td><td${_scopeId6}>3</td></tr><tr${_scopeId6}><th${_scopeId6}>Total Items</th><td style="${ssrRenderStyle({ "width": "40px" })}"${_scopeId6}>:</td><td${_scopeId6}>2</td></tr></table>`);
                                    } else {
                                      return [
                                        createVNode("table", null, [
                                          createVNode("tr", null, [
                                            createVNode("th", null, "Total Qty"),
                                            createVNode("td", { style: { "width": "40px" } }, ":"),
                                            createVNode("td", null, "3")
                                          ]),
                                          createVNode("tr", null, [
                                            createVNode("th", null, "Total Items"),
                                            createVNode("td", { style: { "width": "40px" } }, ":"),
                                            createVNode("td", null, "2")
                                          ])
                                        ])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 12 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<table${_scopeId6}><tr${_scopeId6}><th${_scopeId6}>Total Amount</th><td style="${ssrRenderStyle({ "width": "40px" })}"${_scopeId6}>:</td><td${_scopeId6}>100.00</td></tr><tr${_scopeId6}><th${_scopeId6}>Disc Amount</th><td style="${ssrRenderStyle({ "width": "40px" })}"${_scopeId6}>:</td><td${_scopeId6}>20.00</td></tr></table>`);
                                    } else {
                                      return [
                                        createVNode("table", null, [
                                          createVNode("tr", null, [
                                            createVNode("th", null, "Total Amount"),
                                            createVNode("td", { style: { "width": "40px" } }, ":"),
                                            createVNode("td", null, "100.00")
                                          ]),
                                          createVNode("tr", null, [
                                            createVNode("th", null, "Disc Amount"),
                                            createVNode("td", { style: { "width": "40px" } }, ":"),
                                            createVNode("td", null, "20.00")
                                          ])
                                        ])
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("table", null, [
                                        createVNode("tr", null, [
                                          createVNode("th", null, "Total Qty"),
                                          createVNode("td", { style: { "width": "40px" } }, ":"),
                                          createVNode("td", null, "3")
                                        ]),
                                        createVNode("tr", null, [
                                          createVNode("th", null, "Total Items"),
                                          createVNode("td", { style: { "width": "40px" } }, ":"),
                                          createVNode("td", null, "2")
                                        ])
                                      ])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 12 }, {
                                    default: withCtx(() => [
                                      createVNode("table", null, [
                                        createVNode("tr", null, [
                                          createVNode("th", null, "Total Amount"),
                                          createVNode("td", { style: { "width": "40px" } }, ":"),
                                          createVNode("td", null, "100.00")
                                        ]),
                                        createVNode("tr", null, [
                                          createVNode("th", null, "Disc Amount"),
                                          createVNode("td", { style: { "width": "40px" } }, ":"),
                                          createVNode("td", null, "20.00")
                                        ])
                                      ])
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(`<hr${_scopeId4}><table${_scopeId4}><tr${_scopeId4}><td${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_select, {
                            value: _ctx.value,
                            "onUpdate:value": ($event) => _ctx.value = $event,
                            "show-search": "",
                            placeholder: "Customer",
                            style: { "width": "100%" },
                            class: "customer-dropdown",
                            "default-active-first-option": false,
                            "show-arrow": true,
                            "filter-option": false,
                            options: [{ value: "Mobile", label: "Mobile" }],
                            "not-found-content": _ctx.value,
                            onSearch: _ctx.handleSearch,
                            bordered: false,
                            onChange: _ctx.handleChange
                          }, null, _parent5, _scopeId4));
                          _push5(`</td><th align="right"${_scopeId4}><h2${_scopeId4}>Net Total: 100.00</h2></th></tr></table><br${_scopeId4}>`);
                          _push5(ssrRenderComponent(_component_a_row, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_col, { span: 8 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit",
                                        block: "",
                                        style: { "margin": "0 10px" }
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`SAVE`);
                                          } else {
                                            return [
                                              createTextVNode("SAVE")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          "html-type": "submit",
                                          block: "",
                                          style: { "margin": "0 10px" }
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("SAVE")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 8 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit",
                                        block: "",
                                        style: { "margin": "0 10px" }
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`SAVE &amp; PRINT`);
                                          } else {
                                            return [
                                              createTextVNode("SAVE & PRINT")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          "html-type": "submit",
                                          block: "",
                                          style: { "margin": "0 10px" }
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("SAVE & PRINT")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_col, { span: 8 }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(ssrRenderComponent(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit",
                                        block: "",
                                        style: { "margin": "0 10px" }
                                      }, {
                                        default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                          if (_push8) {
                                            _push8(`HOLD`);
                                          } else {
                                            return [
                                              createTextVNode("HOLD")
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent7, _scopeId6));
                                    } else {
                                      return [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          "html-type": "submit",
                                          block: "",
                                          style: { "margin": "0 10px" }
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("HOLD")
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_col, { span: 8 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit",
                                        block: "",
                                        style: { "margin": "0 10px" }
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("SAVE")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 8 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit",
                                        block: "",
                                        style: { "margin": "0 10px" }
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("SAVE & PRINT")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 8 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        "html-type": "submit",
                                        block: "",
                                        style: { "margin": "0 10px" }
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("HOLD")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode("div", { class: "address" }, [
                              createVNode(_component_a_row, null, {
                                default: withCtx(() => [
                                  createVNode(_component_a_col, { span: 8 }, {
                                    default: withCtx(() => [
                                      createVNode("img", {
                                        src: "https://moziztech.com/images/logo/moziz-logo.png",
                                        style: { "max-width": "200px" }
                                      })
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_col, { span: 16 }, {
                                    default: withCtx(() => [
                                      createVNode("p", null, "KK Nagar, Karthick raja complex, Madurai - 625020"),
                                      createVNode("p", null, "Email: support@moziztech.com"),
                                      createVNode("p", null, "Phone: 8072403631"),
                                      createVNode("p", null, "GSTIN: 33NN0033SSJJ933")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            createVNode("hr"),
                            createVNode(_component_a_row, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode("table", null, [
                                      createVNode("tr", null, [
                                        createVNode("th", null, "Order / Bill No"),
                                        createVNode("td", { style: { "width": "40px" } }, ":"),
                                        createVNode("td", null, "12560")
                                      ])
                                    ])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode("table", null, [
                                      createVNode("tr", null, [
                                        createVNode("th", null, "Date"),
                                        createVNode("td", { style: { "width": "40px" } }, ":"),
                                        createVNode("td", null, "10-10-2023")
                                      ])
                                    ])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("hr"),
                            createVNode("table", { class: "products-table" }, [
                              createVNode("thead", null, [
                                createVNode("tr", null, [
                                  createVNode("th", null, "Item Name"),
                                  createVNode("th", null, "Qty"),
                                  createVNode("th", null, "Mrp"),
                                  createVNode("th", null, "Rate"),
                                  createVNode("th", null, "Amount")
                                ])
                              ]),
                              createVNode("tbody", null, [
                                createVNode("tr", null, [
                                  createVNode("td", null, [
                                    createVNode(_component_a_select, {
                                      value: _ctx.value,
                                      "onUpdate:value": ($event) => _ctx.value = $event,
                                      "show-search": "",
                                      placeholder: "Category",
                                      style: { "width": "100%" },
                                      "default-active-first-option": false,
                                      "show-arrow": true,
                                      "filter-option": false,
                                      options: [{ value: "Mobile", label: "Mobile" }],
                                      "not-found-content": _ctx.value,
                                      onSearch: _ctx.handleSearch,
                                      bordered: false,
                                      onChange: _ctx.handleChange
                                    }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                                  ]),
                                  createVNode("td", null, [
                                    createVNode(_component_a_input_number, {
                                      value: $data.formState.price,
                                      "onUpdate:value": ($event) => $data.formState.price = $event,
                                      style: { "width": "100%" },
                                      bordered: false
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  createVNode("td"),
                                  createVNode("td"),
                                  createVNode("td")
                                ]),
                                createVNode("tr", null, [
                                  createVNode("td", null, [
                                    createVNode(_component_a_select, {
                                      value: _ctx.value,
                                      "onUpdate:value": ($event) => _ctx.value = $event,
                                      "show-search": "",
                                      placeholder: "Category",
                                      style: { "width": "100%" },
                                      "default-active-first-option": false,
                                      "show-arrow": true,
                                      "filter-option": false,
                                      options: [{ value: "Mobile", label: "Mobile" }],
                                      "not-found-content": _ctx.value,
                                      onSearch: _ctx.handleSearch,
                                      bordered: false,
                                      onChange: _ctx.handleChange
                                    }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                                  ]),
                                  createVNode("td", null, [
                                    createVNode(_component_a_input_number, {
                                      value: $data.formState.price,
                                      "onUpdate:value": ($event) => $data.formState.price = $event,
                                      style: { "width": "100%" },
                                      bordered: false
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  createVNode("td"),
                                  createVNode("td"),
                                  createVNode("td")
                                ]),
                                createVNode("tr", null, [
                                  createVNode("td", null, [
                                    createVNode(_component_a_select, {
                                      value: _ctx.value,
                                      "onUpdate:value": ($event) => _ctx.value = $event,
                                      "show-search": "",
                                      placeholder: "Category",
                                      style: { "width": "100%" },
                                      "default-active-first-option": false,
                                      "show-arrow": true,
                                      "filter-option": false,
                                      options: [{ value: "Mobile", label: "Mobile" }],
                                      "not-found-content": _ctx.value,
                                      onSearch: _ctx.handleSearch,
                                      bordered: false,
                                      onChange: _ctx.handleChange
                                    }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                                  ]),
                                  createVNode("td", null, [
                                    createVNode(_component_a_input_number, {
                                      value: $data.formState.price,
                                      "onUpdate:value": ($event) => $data.formState.price = $event,
                                      style: { "width": "100%" },
                                      bordered: false
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  createVNode("td"),
                                  createVNode("td"),
                                  createVNode("td")
                                ])
                              ])
                            ]),
                            createVNode("hr"),
                            createVNode(_component_a_row, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode("table", null, [
                                      createVNode("tr", null, [
                                        createVNode("th", null, "Total Qty"),
                                        createVNode("td", { style: { "width": "40px" } }, ":"),
                                        createVNode("td", null, "3")
                                      ]),
                                      createVNode("tr", null, [
                                        createVNode("th", null, "Total Items"),
                                        createVNode("td", { style: { "width": "40px" } }, ":"),
                                        createVNode("td", null, "2")
                                      ])
                                    ])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 12 }, {
                                  default: withCtx(() => [
                                    createVNode("table", null, [
                                      createVNode("tr", null, [
                                        createVNode("th", null, "Total Amount"),
                                        createVNode("td", { style: { "width": "40px" } }, ":"),
                                        createVNode("td", null, "100.00")
                                      ]),
                                      createVNode("tr", null, [
                                        createVNode("th", null, "Disc Amount"),
                                        createVNode("td", { style: { "width": "40px" } }, ":"),
                                        createVNode("td", null, "20.00")
                                      ])
                                    ])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode("hr"),
                            createVNode("table", null, [
                              createVNode("tr", null, [
                                createVNode("td", null, [
                                  createVNode(_component_a_select, {
                                    value: _ctx.value,
                                    "onUpdate:value": ($event) => _ctx.value = $event,
                                    "show-search": "",
                                    placeholder: "Customer",
                                    style: { "width": "100%" },
                                    class: "customer-dropdown",
                                    "default-active-first-option": false,
                                    "show-arrow": true,
                                    "filter-option": false,
                                    options: [{ value: "Mobile", label: "Mobile" }],
                                    "not-found-content": _ctx.value,
                                    onSearch: _ctx.handleSearch,
                                    bordered: false,
                                    onChange: _ctx.handleChange
                                  }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                                ]),
                                createVNode("th", { align: "right" }, [
                                  createVNode("h2", null, "Net Total: 100.00")
                                ])
                              ])
                            ]),
                            createVNode("br"),
                            createVNode(_component_a_row, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 8 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      "html-type": "submit",
                                      block: "",
                                      style: { "margin": "0 10px" }
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("SAVE")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 8 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      "html-type": "submit",
                                      block: "",
                                      style: { "margin": "0 10px" }
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("SAVE & PRINT")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 8 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      "html-type": "submit",
                                      block: "",
                                      style: { "margin": "0 10px" }
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("HOLD")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, mergeProps({ model: $data.formState }, _ctx.layout, {
                        name: "nest-messages",
                        "validate-messages": _ctx.validateMessages,
                        onFinish: _ctx.submit,
                        "label-col": { span: 24 }
                      }), {
                        default: withCtx(() => [
                          createVNode("div", { class: "address" }, [
                            createVNode(_component_a_row, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_col, { span: 8 }, {
                                  default: withCtx(() => [
                                    createVNode("img", {
                                      src: "https://moziztech.com/images/logo/moziz-logo.png",
                                      style: { "max-width": "200px" }
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_col, { span: 16 }, {
                                  default: withCtx(() => [
                                    createVNode("p", null, "KK Nagar, Karthick raja complex, Madurai - 625020"),
                                    createVNode("p", null, "Email: support@moziztech.com"),
                                    createVNode("p", null, "Phone: 8072403631"),
                                    createVNode("p", null, "GSTIN: 33NN0033SSJJ933")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          createVNode("hr"),
                          createVNode(_component_a_row, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode("table", null, [
                                    createVNode("tr", null, [
                                      createVNode("th", null, "Order / Bill No"),
                                      createVNode("td", { style: { "width": "40px" } }, ":"),
                                      createVNode("td", null, "12560")
                                    ])
                                  ])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode("table", null, [
                                    createVNode("tr", null, [
                                      createVNode("th", null, "Date"),
                                      createVNode("td", { style: { "width": "40px" } }, ":"),
                                      createVNode("td", null, "10-10-2023")
                                    ])
                                  ])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("hr"),
                          createVNode("table", { class: "products-table" }, [
                            createVNode("thead", null, [
                              createVNode("tr", null, [
                                createVNode("th", null, "Item Name"),
                                createVNode("th", null, "Qty"),
                                createVNode("th", null, "Mrp"),
                                createVNode("th", null, "Rate"),
                                createVNode("th", null, "Amount")
                              ])
                            ]),
                            createVNode("tbody", null, [
                              createVNode("tr", null, [
                                createVNode("td", null, [
                                  createVNode(_component_a_select, {
                                    value: _ctx.value,
                                    "onUpdate:value": ($event) => _ctx.value = $event,
                                    "show-search": "",
                                    placeholder: "Category",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    "show-arrow": true,
                                    "filter-option": false,
                                    options: [{ value: "Mobile", label: "Mobile" }],
                                    "not-found-content": _ctx.value,
                                    onSearch: _ctx.handleSearch,
                                    bordered: false,
                                    onChange: _ctx.handleChange
                                  }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                                ]),
                                createVNode("td", null, [
                                  createVNode(_component_a_input_number, {
                                    value: $data.formState.price,
                                    "onUpdate:value": ($event) => $data.formState.price = $event,
                                    style: { "width": "100%" },
                                    bordered: false
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                createVNode("td"),
                                createVNode("td"),
                                createVNode("td")
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", null, [
                                  createVNode(_component_a_select, {
                                    value: _ctx.value,
                                    "onUpdate:value": ($event) => _ctx.value = $event,
                                    "show-search": "",
                                    placeholder: "Category",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    "show-arrow": true,
                                    "filter-option": false,
                                    options: [{ value: "Mobile", label: "Mobile" }],
                                    "not-found-content": _ctx.value,
                                    onSearch: _ctx.handleSearch,
                                    bordered: false,
                                    onChange: _ctx.handleChange
                                  }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                                ]),
                                createVNode("td", null, [
                                  createVNode(_component_a_input_number, {
                                    value: $data.formState.price,
                                    "onUpdate:value": ($event) => $data.formState.price = $event,
                                    style: { "width": "100%" },
                                    bordered: false
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                createVNode("td"),
                                createVNode("td"),
                                createVNode("td")
                              ]),
                              createVNode("tr", null, [
                                createVNode("td", null, [
                                  createVNode(_component_a_select, {
                                    value: _ctx.value,
                                    "onUpdate:value": ($event) => _ctx.value = $event,
                                    "show-search": "",
                                    placeholder: "Category",
                                    style: { "width": "100%" },
                                    "default-active-first-option": false,
                                    "show-arrow": true,
                                    "filter-option": false,
                                    options: [{ value: "Mobile", label: "Mobile" }],
                                    "not-found-content": _ctx.value,
                                    onSearch: _ctx.handleSearch,
                                    bordered: false,
                                    onChange: _ctx.handleChange
                                  }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                                ]),
                                createVNode("td", null, [
                                  createVNode(_component_a_input_number, {
                                    value: $data.formState.price,
                                    "onUpdate:value": ($event) => $data.formState.price = $event,
                                    style: { "width": "100%" },
                                    bordered: false
                                  }, null, 8, ["value", "onUpdate:value"])
                                ]),
                                createVNode("td"),
                                createVNode("td"),
                                createVNode("td")
                              ])
                            ])
                          ]),
                          createVNode("hr"),
                          createVNode(_component_a_row, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode("table", null, [
                                    createVNode("tr", null, [
                                      createVNode("th", null, "Total Qty"),
                                      createVNode("td", { style: { "width": "40px" } }, ":"),
                                      createVNode("td", null, "3")
                                    ]),
                                    createVNode("tr", null, [
                                      createVNode("th", null, "Total Items"),
                                      createVNode("td", { style: { "width": "40px" } }, ":"),
                                      createVNode("td", null, "2")
                                    ])
                                  ])
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 12 }, {
                                default: withCtx(() => [
                                  createVNode("table", null, [
                                    createVNode("tr", null, [
                                      createVNode("th", null, "Total Amount"),
                                      createVNode("td", { style: { "width": "40px" } }, ":"),
                                      createVNode("td", null, "100.00")
                                    ]),
                                    createVNode("tr", null, [
                                      createVNode("th", null, "Disc Amount"),
                                      createVNode("td", { style: { "width": "40px" } }, ":"),
                                      createVNode("td", null, "20.00")
                                    ])
                                  ])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode("hr"),
                          createVNode("table", null, [
                            createVNode("tr", null, [
                              createVNode("td", null, [
                                createVNode(_component_a_select, {
                                  value: _ctx.value,
                                  "onUpdate:value": ($event) => _ctx.value = $event,
                                  "show-search": "",
                                  placeholder: "Customer",
                                  style: { "width": "100%" },
                                  class: "customer-dropdown",
                                  "default-active-first-option": false,
                                  "show-arrow": true,
                                  "filter-option": false,
                                  options: [{ value: "Mobile", label: "Mobile" }],
                                  "not-found-content": _ctx.value,
                                  onSearch: _ctx.handleSearch,
                                  bordered: false,
                                  onChange: _ctx.handleChange
                                }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                              ]),
                              createVNode("th", { align: "right" }, [
                                createVNode("h2", null, "Net Total: 100.00")
                              ])
                            ])
                          ]),
                          createVNode("br"),
                          createVNode(_component_a_row, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, { span: 8 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit",
                                    block: "",
                                    style: { "margin": "0 10px" }
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("SAVE")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 8 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit",
                                    block: "",
                                    style: { "margin": "0 10px" }
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("SAVE & PRINT")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 8 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit",
                                    block: "",
                                    style: { "margin": "0 10px" }
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("HOLD")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 16, ["model", "validate-messages", "onFinish"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_space, {
                  direction: "vertical",
                  style: { width: "100%" }
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, {
                      name: "nest-messages",
                      model: $data.formState,
                      layout: "inline",
                      onFinish: $options.search
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, {
                              placeholder: "Search by product name",
                              "allow-clear": true,
                              value: $data.formState.term,
                              "onUpdate:value": ($event) => $data.formState.term = $event
                            }, null, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Search ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              shape: "round",
                              onClick: $options.showDrawer
                            }, {
                              icon: withCtx(() => [
                                createVNode(_component_plus_circle_outlined)
                              ]),
                              default: withCtx(() => [
                                createTextVNode(" New Sales Order ")
                              ]),
                              _: 1
                            }, 8, ["onClick"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["model", "onFinish"]),
                    createVNode(_component_a_table, {
                      columns: $setup.columns,
                      "row-key": (product) => product.id,
                      "data-source": $props.products.data,
                      pagination: $props.pagination,
                      loading: $data.loading,
                      onChange: $options.handleTableChange
                    }, {
                      bodyCell: withCtx(({ column, text, record }) => [
                        column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 0 }, {
                          overlay: withCtx(() => [
                            createVNode(_component_a_menu, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_menu_item, { key: "1" }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Edit ")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_menu_item, {
                                  key: "4",
                                  onClick: ($event) => $options.deleteBranch(record.id)
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Delete ")
                                  ]),
                                  _: 2
                                }, 1032, ["onClick"])
                              ]),
                              _: 2
                            }, 1024)
                          ]),
                          default: withCtx(() => [
                            createVNode(_component_a_button, null, {
                              default: withCtx(() => [
                                createVNode(_component_more_outlined),
                                createVNode(_component_DownOutlined)
                              ]),
                              _: 1
                            })
                          ]),
                          _: 2
                        }, 1024)) : createCommentVNode("", true)
                      ]),
                      _: 1
                    }, 8, ["columns", "row-key", "data-source", "pagination", "loading", "onChange"])
                  ]),
                  _: 1
                }),
                createVNode(_component_a_drawer, {
                  visible: $data.create_form_visible,
                  "onUpdate:visible": ($event) => $data.create_form_visible = $event,
                  class: "sales-bill",
                  size: "large",
                  style: { "color": "red" },
                  title: "New Sales Oerder",
                  placement: "right",
                  onAfterVisibleChange: _ctx.afterVisibleChange
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, mergeProps({ model: $data.formState }, _ctx.layout, {
                      name: "nest-messages",
                      "validate-messages": _ctx.validateMessages,
                      onFinish: _ctx.submit,
                      "label-col": { span: 24 }
                    }), {
                      default: withCtx(() => [
                        createVNode("div", { class: "address" }, [
                          createVNode(_component_a_row, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_col, { span: 8 }, {
                                default: withCtx(() => [
                                  createVNode("img", {
                                    src: "https://moziztech.com/images/logo/moziz-logo.png",
                                    style: { "max-width": "200px" }
                                  })
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_col, { span: 16 }, {
                                default: withCtx(() => [
                                  createVNode("p", null, "KK Nagar, Karthick raja complex, Madurai - 625020"),
                                  createVNode("p", null, "Email: support@moziztech.com"),
                                  createVNode("p", null, "Phone: 8072403631"),
                                  createVNode("p", null, "GSTIN: 33NN0033SSJJ933")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        createVNode("hr"),
                        createVNode(_component_a_row, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode("table", null, [
                                  createVNode("tr", null, [
                                    createVNode("th", null, "Order / Bill No"),
                                    createVNode("td", { style: { "width": "40px" } }, ":"),
                                    createVNode("td", null, "12560")
                                  ])
                                ])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode("table", null, [
                                  createVNode("tr", null, [
                                    createVNode("th", null, "Date"),
                                    createVNode("td", { style: { "width": "40px" } }, ":"),
                                    createVNode("td", null, "10-10-2023")
                                  ])
                                ])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode("hr"),
                        createVNode("table", { class: "products-table" }, [
                          createVNode("thead", null, [
                            createVNode("tr", null, [
                              createVNode("th", null, "Item Name"),
                              createVNode("th", null, "Qty"),
                              createVNode("th", null, "Mrp"),
                              createVNode("th", null, "Rate"),
                              createVNode("th", null, "Amount")
                            ])
                          ]),
                          createVNode("tbody", null, [
                            createVNode("tr", null, [
                              createVNode("td", null, [
                                createVNode(_component_a_select, {
                                  value: _ctx.value,
                                  "onUpdate:value": ($event) => _ctx.value = $event,
                                  "show-search": "",
                                  placeholder: "Category",
                                  style: { "width": "100%" },
                                  "default-active-first-option": false,
                                  "show-arrow": true,
                                  "filter-option": false,
                                  options: [{ value: "Mobile", label: "Mobile" }],
                                  "not-found-content": _ctx.value,
                                  onSearch: _ctx.handleSearch,
                                  bordered: false,
                                  onChange: _ctx.handleChange
                                }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                              ]),
                              createVNode("td", null, [
                                createVNode(_component_a_input_number, {
                                  value: $data.formState.price,
                                  "onUpdate:value": ($event) => $data.formState.price = $event,
                                  style: { "width": "100%" },
                                  bordered: false
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              createVNode("td"),
                              createVNode("td"),
                              createVNode("td")
                            ]),
                            createVNode("tr", null, [
                              createVNode("td", null, [
                                createVNode(_component_a_select, {
                                  value: _ctx.value,
                                  "onUpdate:value": ($event) => _ctx.value = $event,
                                  "show-search": "",
                                  placeholder: "Category",
                                  style: { "width": "100%" },
                                  "default-active-first-option": false,
                                  "show-arrow": true,
                                  "filter-option": false,
                                  options: [{ value: "Mobile", label: "Mobile" }],
                                  "not-found-content": _ctx.value,
                                  onSearch: _ctx.handleSearch,
                                  bordered: false,
                                  onChange: _ctx.handleChange
                                }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                              ]),
                              createVNode("td", null, [
                                createVNode(_component_a_input_number, {
                                  value: $data.formState.price,
                                  "onUpdate:value": ($event) => $data.formState.price = $event,
                                  style: { "width": "100%" },
                                  bordered: false
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              createVNode("td"),
                              createVNode("td"),
                              createVNode("td")
                            ]),
                            createVNode("tr", null, [
                              createVNode("td", null, [
                                createVNode(_component_a_select, {
                                  value: _ctx.value,
                                  "onUpdate:value": ($event) => _ctx.value = $event,
                                  "show-search": "",
                                  placeholder: "Category",
                                  style: { "width": "100%" },
                                  "default-active-first-option": false,
                                  "show-arrow": true,
                                  "filter-option": false,
                                  options: [{ value: "Mobile", label: "Mobile" }],
                                  "not-found-content": _ctx.value,
                                  onSearch: _ctx.handleSearch,
                                  bordered: false,
                                  onChange: _ctx.handleChange
                                }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                              ]),
                              createVNode("td", null, [
                                createVNode(_component_a_input_number, {
                                  value: $data.formState.price,
                                  "onUpdate:value": ($event) => $data.formState.price = $event,
                                  style: { "width": "100%" },
                                  bordered: false
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              createVNode("td"),
                              createVNode("td"),
                              createVNode("td")
                            ])
                          ])
                        ]),
                        createVNode("hr"),
                        createVNode(_component_a_row, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode("table", null, [
                                  createVNode("tr", null, [
                                    createVNode("th", null, "Total Qty"),
                                    createVNode("td", { style: { "width": "40px" } }, ":"),
                                    createVNode("td", null, "3")
                                  ]),
                                  createVNode("tr", null, [
                                    createVNode("th", null, "Total Items"),
                                    createVNode("td", { style: { "width": "40px" } }, ":"),
                                    createVNode("td", null, "2")
                                  ])
                                ])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 12 }, {
                              default: withCtx(() => [
                                createVNode("table", null, [
                                  createVNode("tr", null, [
                                    createVNode("th", null, "Total Amount"),
                                    createVNode("td", { style: { "width": "40px" } }, ":"),
                                    createVNode("td", null, "100.00")
                                  ]),
                                  createVNode("tr", null, [
                                    createVNode("th", null, "Disc Amount"),
                                    createVNode("td", { style: { "width": "40px" } }, ":"),
                                    createVNode("td", null, "20.00")
                                  ])
                                ])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode("hr"),
                        createVNode("table", null, [
                          createVNode("tr", null, [
                            createVNode("td", null, [
                              createVNode(_component_a_select, {
                                value: _ctx.value,
                                "onUpdate:value": ($event) => _ctx.value = $event,
                                "show-search": "",
                                placeholder: "Customer",
                                style: { "width": "100%" },
                                class: "customer-dropdown",
                                "default-active-first-option": false,
                                "show-arrow": true,
                                "filter-option": false,
                                options: [{ value: "Mobile", label: "Mobile" }],
                                "not-found-content": _ctx.value,
                                onSearch: _ctx.handleSearch,
                                bordered: false,
                                onChange: _ctx.handleChange
                              }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                            ]),
                            createVNode("th", { align: "right" }, [
                              createVNode("h2", null, "Net Total: 100.00")
                            ])
                          ])
                        ]),
                        createVNode("br"),
                        createVNode(_component_a_row, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, { span: 8 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit",
                                  block: "",
                                  style: { "margin": "0 10px" }
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("SAVE")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 8 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit",
                                  block: "",
                                  style: { "margin": "0 10px" }
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("SAVE & PRINT")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 8 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit",
                                  block: "",
                                  style: { "margin": "0 10px" }
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("HOLD")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 16, ["model", "validate-messages", "onFinish"])
                  ]),
                  _: 1
                }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_layout_content, null, {
            default: withCtx(() => [
              createVNode(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, {
                    name: "nest-messages",
                    model: $data.formState,
                    layout: "inline",
                    onFinish: $options.search
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            placeholder: "Search by product name",
                            "allow-clear": true,
                            value: $data.formState.term,
                            "onUpdate:value": ($event) => $data.formState.term = $event
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Search ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            shape: "round",
                            onClick: $options.showDrawer
                          }, {
                            icon: withCtx(() => [
                              createVNode(_component_plus_circle_outlined)
                            ]),
                            default: withCtx(() => [
                              createTextVNode(" New Sales Order ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["model", "onFinish"]),
                  createVNode(_component_a_table, {
                    columns: $setup.columns,
                    "row-key": (product) => product.id,
                    "data-source": $props.products.data,
                    pagination: $props.pagination,
                    loading: $data.loading,
                    onChange: $options.handleTableChange
                  }, {
                    bodyCell: withCtx(({ column, text, record }) => [
                      column.key === "action" ? (openBlock(), createBlock(_component_a_dropdown, { key: 0 }, {
                        overlay: withCtx(() => [
                          createVNode(_component_a_menu, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_menu_item, { key: "1" }, {
                                default: withCtx(() => [
                                  createTextVNode(" Edit ")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_menu_item, {
                                key: "4",
                                onClick: ($event) => $options.deleteBranch(record.id)
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Delete ")
                                ]),
                                _: 2
                              }, 1032, ["onClick"])
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        default: withCtx(() => [
                          createVNode(_component_a_button, null, {
                            default: withCtx(() => [
                              createVNode(_component_more_outlined),
                              createVNode(_component_DownOutlined)
                            ]),
                            _: 1
                          })
                        ]),
                        _: 2
                      }, 1024)) : createCommentVNode("", true)
                    ]),
                    _: 1
                  }, 8, ["columns", "row-key", "data-source", "pagination", "loading", "onChange"])
                ]),
                _: 1
              }),
              createVNode(_component_a_drawer, {
                visible: $data.create_form_visible,
                "onUpdate:visible": ($event) => $data.create_form_visible = $event,
                class: "sales-bill",
                size: "large",
                style: { "color": "red" },
                title: "New Sales Oerder",
                placement: "right",
                onAfterVisibleChange: _ctx.afterVisibleChange
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, mergeProps({ model: $data.formState }, _ctx.layout, {
                    name: "nest-messages",
                    "validate-messages": _ctx.validateMessages,
                    onFinish: _ctx.submit,
                    "label-col": { span: 24 }
                  }), {
                    default: withCtx(() => [
                      createVNode("div", { class: "address" }, [
                        createVNode(_component_a_row, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_col, { span: 8 }, {
                              default: withCtx(() => [
                                createVNode("img", {
                                  src: "https://moziztech.com/images/logo/moziz-logo.png",
                                  style: { "max-width": "200px" }
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_col, { span: 16 }, {
                              default: withCtx(() => [
                                createVNode("p", null, "KK Nagar, Karthick raja complex, Madurai - 625020"),
                                createVNode("p", null, "Email: support@moziztech.com"),
                                createVNode("p", null, "Phone: 8072403631"),
                                createVNode("p", null, "GSTIN: 33NN0033SSJJ933")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      createVNode("hr"),
                      createVNode(_component_a_row, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode("table", null, [
                                createVNode("tr", null, [
                                  createVNode("th", null, "Order / Bill No"),
                                  createVNode("td", { style: { "width": "40px" } }, ":"),
                                  createVNode("td", null, "12560")
                                ])
                              ])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode("table", null, [
                                createVNode("tr", null, [
                                  createVNode("th", null, "Date"),
                                  createVNode("td", { style: { "width": "40px" } }, ":"),
                                  createVNode("td", null, "10-10-2023")
                                ])
                              ])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode("hr"),
                      createVNode("table", { class: "products-table" }, [
                        createVNode("thead", null, [
                          createVNode("tr", null, [
                            createVNode("th", null, "Item Name"),
                            createVNode("th", null, "Qty"),
                            createVNode("th", null, "Mrp"),
                            createVNode("th", null, "Rate"),
                            createVNode("th", null, "Amount")
                          ])
                        ]),
                        createVNode("tbody", null, [
                          createVNode("tr", null, [
                            createVNode("td", null, [
                              createVNode(_component_a_select, {
                                value: _ctx.value,
                                "onUpdate:value": ($event) => _ctx.value = $event,
                                "show-search": "",
                                placeholder: "Category",
                                style: { "width": "100%" },
                                "default-active-first-option": false,
                                "show-arrow": true,
                                "filter-option": false,
                                options: [{ value: "Mobile", label: "Mobile" }],
                                "not-found-content": _ctx.value,
                                onSearch: _ctx.handleSearch,
                                bordered: false,
                                onChange: _ctx.handleChange
                              }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                            ]),
                            createVNode("td", null, [
                              createVNode(_component_a_input_number, {
                                value: $data.formState.price,
                                "onUpdate:value": ($event) => $data.formState.price = $event,
                                style: { "width": "100%" },
                                bordered: false
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            createVNode("td"),
                            createVNode("td"),
                            createVNode("td")
                          ]),
                          createVNode("tr", null, [
                            createVNode("td", null, [
                              createVNode(_component_a_select, {
                                value: _ctx.value,
                                "onUpdate:value": ($event) => _ctx.value = $event,
                                "show-search": "",
                                placeholder: "Category",
                                style: { "width": "100%" },
                                "default-active-first-option": false,
                                "show-arrow": true,
                                "filter-option": false,
                                options: [{ value: "Mobile", label: "Mobile" }],
                                "not-found-content": _ctx.value,
                                onSearch: _ctx.handleSearch,
                                bordered: false,
                                onChange: _ctx.handleChange
                              }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                            ]),
                            createVNode("td", null, [
                              createVNode(_component_a_input_number, {
                                value: $data.formState.price,
                                "onUpdate:value": ($event) => $data.formState.price = $event,
                                style: { "width": "100%" },
                                bordered: false
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            createVNode("td"),
                            createVNode("td"),
                            createVNode("td")
                          ]),
                          createVNode("tr", null, [
                            createVNode("td", null, [
                              createVNode(_component_a_select, {
                                value: _ctx.value,
                                "onUpdate:value": ($event) => _ctx.value = $event,
                                "show-search": "",
                                placeholder: "Category",
                                style: { "width": "100%" },
                                "default-active-first-option": false,
                                "show-arrow": true,
                                "filter-option": false,
                                options: [{ value: "Mobile", label: "Mobile" }],
                                "not-found-content": _ctx.value,
                                onSearch: _ctx.handleSearch,
                                bordered: false,
                                onChange: _ctx.handleChange
                              }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                            ]),
                            createVNode("td", null, [
                              createVNode(_component_a_input_number, {
                                value: $data.formState.price,
                                "onUpdate:value": ($event) => $data.formState.price = $event,
                                style: { "width": "100%" },
                                bordered: false
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            createVNode("td"),
                            createVNode("td"),
                            createVNode("td")
                          ])
                        ])
                      ]),
                      createVNode("hr"),
                      createVNode(_component_a_row, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode("table", null, [
                                createVNode("tr", null, [
                                  createVNode("th", null, "Total Qty"),
                                  createVNode("td", { style: { "width": "40px" } }, ":"),
                                  createVNode("td", null, "3")
                                ]),
                                createVNode("tr", null, [
                                  createVNode("th", null, "Total Items"),
                                  createVNode("td", { style: { "width": "40px" } }, ":"),
                                  createVNode("td", null, "2")
                                ])
                              ])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { span: 12 }, {
                            default: withCtx(() => [
                              createVNode("table", null, [
                                createVNode("tr", null, [
                                  createVNode("th", null, "Total Amount"),
                                  createVNode("td", { style: { "width": "40px" } }, ":"),
                                  createVNode("td", null, "100.00")
                                ]),
                                createVNode("tr", null, [
                                  createVNode("th", null, "Disc Amount"),
                                  createVNode("td", { style: { "width": "40px" } }, ":"),
                                  createVNode("td", null, "20.00")
                                ])
                              ])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode("hr"),
                      createVNode("table", null, [
                        createVNode("tr", null, [
                          createVNode("td", null, [
                            createVNode(_component_a_select, {
                              value: _ctx.value,
                              "onUpdate:value": ($event) => _ctx.value = $event,
                              "show-search": "",
                              placeholder: "Customer",
                              style: { "width": "100%" },
                              class: "customer-dropdown",
                              "default-active-first-option": false,
                              "show-arrow": true,
                              "filter-option": false,
                              options: [{ value: "Mobile", label: "Mobile" }],
                              "not-found-content": _ctx.value,
                              onSearch: _ctx.handleSearch,
                              bordered: false,
                              onChange: _ctx.handleChange
                            }, null, 8, ["value", "onUpdate:value", "not-found-content", "onSearch", "onChange"])
                          ]),
                          createVNode("th", { align: "right" }, [
                            createVNode("h2", null, "Net Total: 100.00")
                          ])
                        ])
                      ]),
                      createVNode("br"),
                      createVNode(_component_a_row, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_col, { span: 8 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit",
                                block: "",
                                style: { "margin": "0 10px" }
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("SAVE")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { span: 8 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit",
                                block: "",
                                style: { "margin": "0 10px" }
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("SAVE & PRINT")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_col, { span: 8 }, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit",
                                block: "",
                                style: { "margin": "0 10px" }
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("HOLD")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 16, ["model", "validate-messages", "onFinish"])
                ]),
                _: 1
              }, 8, ["visible", "onUpdate:visible", "onAfterVisibleChange"])
            ]),
            _: 1
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Salesorder/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Index as default
};
