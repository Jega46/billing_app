import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import "vue-request";
import { resolveComponent, withCtx, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, createVNode, createCommentVNode, useSSRContext } from "vue";
import { Head, Link, useForm, router } from "@inertiajs/vue3";
import "dayjs";
import { message } from "ant-design-vue";
import moment from "moment";
import { DownloadOutlined, PlusCircleOutlined, MoreOutlined, DeleteOutlined, EditOutlined } from "@ant-design/icons-vue";
import axios from "axios";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
const columns = [
  {
    title: "Name",
    key: "name",
    dataIndex: "name",
    sorter: true,
    width: "20%"
  },
  {
    title: "Attendance Status",
    key: "status",
    width: "20%"
  },
  {
    title: "Late Status",
    key: "latestatus",
    width: "10%"
  },
  // {
  //   title: 'Auto Action',
  //   key: 'autoaction',
  //   width: '30%',
  // },
  {
    title: "Action",
    key: "manualaction",
    width: "30%"
  }
];
const innercolumns = [
  {
    title: "Location",
    key: "location",
    dataIndex: ""
  },
  {
    title: "In",
    key: "in",
    dataIndex: "checkin"
  },
  {
    title: "Out",
    key: "out",
    dataIndex: "checkout"
  },
  {
    title: "Break",
    key: "break",
    dataIndex: ""
  },
  {
    title: "Notes",
    key: "notes",
    dataIndex: ""
  },
  {
    title: "Action",
    key: "action",
    dataIndex: ""
  }
];
const _sfc_main = {
  components: {
    AuthenticatedLayout: _sfc_main$1,
    DownloadOutlined,
    PlusCircleOutlined,
    MoreOutlined,
    DeleteOutlined,
    Head,
    Link,
    EditOutlined
  },
  props: {
    date: String,
    employees: Object,
    breaks: Object,
    branches: Object,
    pagination: Object,
    errors: Object
  },
  setup(props) {
    return {
      columns,
      innercolumns
    };
  },
  data(props) {
    const loading = false;
    const delayTime = 1500;
    const formState = useForm({
      term: "",
      date: props.date,
      branch: null
    });
    const statusColor = {
      "Present": "green",
      "Absent": "red",
      "Paid Leave": "blue",
      "Unpaid Leave": "orange",
      "Day Off": "purple"
    };
    return {
      moment,
      editableData: [],
      statusColor,
      page: 1,
      pageSize: 50,
      loading,
      delayTime,
      formState,
      showmanualsave: []
    };
  },
  methods: {
    search() {
      this.$inertia.get("/attendance", { s: this.formState.term, date: this.formState.date, branch: this.formState.branch, pageSize: this.pageSize }, { preserveState: true });
    },
    handleTableChange(val) {
      this.page = val.current;
      this.pageSize = val.pageSize;
      console.log(val);
      this.$inertia.get(
        "/attendance",
        { s: this.formState.term, date: this.formState.date, branch: this.formState.branch, page: val.current, pageSize: val.pageSize },
        { preserveState: true }
      );
    },
    clockIn(record) {
      this.loading = true;
      axios.post(route("attendance.clockin"), { ...record, ...{ date: this.formState.date } }).then((response) => {
        console.log(response);
        this.$inertia.get("/attendance", { s: this.formState.term, date: this.formState.date, branch: this.formState.branch, page: this.page, pageSize: this.pageSize }, { preserveState: true });
      }).finally(() => {
        this.loading = false;
      });
    },
    clockOut(record) {
      this.loading = true;
      axios.post(route("attendance.clockout"), { ...record, ...{ date: this.formState.date } }).then((response) => {
        console.log(response);
        this.$inertia.get("/attendance", { s: this.formState.term, date: this.formState.date, branch: this.formState.branch, page: this.page, pageSize: this.pageSize }, { preserveState: true });
      }).finally(() => {
        this.loading = false;
      });
    },
    addBreak(record, breakid) {
      this.loading = true;
      axios.post(route("attendance.addbreak"), { ...record, ...{ date: this.formState.date, breakid } }).then((response) => {
        console.log(response);
        this.$inertia.get("/attendance", { s: this.formState.term, date: this.formState.date, branch: this.formState.branch, page: this.page, pageSize: this.pageSize }, { preserveState: true });
      }).finally(() => {
        this.loading = false;
      });
    },
    edit(key) {
      this.editableData.push(key);
    },
    cancel(key) {
      const index = this.editableData.indexOf(key);
      if (index > -1) {
        this.editableData.splice(index, 1);
      }
    },
    savehistory(history) {
      var url = route("attendance.updatehistory");
      router.post(url, history, {
        onStart: (visit) => {
          this.loading = true;
        },
        onSuccess: (page) => {
          this.cancel(history.id);
        },
        onError: (errors) => {
          this.loading = false;
          Object.keys(errors).forEach(function(key) {
            message.error(errors[key]);
          });
        },
        onFinish: (visit) => {
          this.loading = false;
        }
      });
    },
    deletehistory(id) {
      router.post(route("attendance.deletehistory", id), {}, {
        onStart: (visit) => {
          this.loading = true;
        },
        onSuccess: (page) => {
        },
        onFinish: (visit) => {
          this.loading = false;
        }
      });
    },
    addmanualrows(record) {
      record.history.push({
        employee_id: record.employee_id,
        attdate: record.attdate,
        id: "",
        checkin: "",
        checkout: "",
        breakid: "",
        notes: ""
      });
      this.showmanualsave.push(record.employee_id);
    },
    savemanualdata(record) {
      var url = route("attendance.addmultiplehistory");
      router.post(url, record, {
        onStart: (visit) => {
          this.loading = true;
        },
        onSuccess: (page) => {
        },
        onError: (errors) => {
          this.loading = false;
          Object.keys(errors).forEach(function(key) {
            message.error(errors[key]);
          });
        },
        onFinish: (visit) => {
          this.loading = false;
        }
      });
    },
    deletemanualrow(parentrecord, record) {
      const index1 = this.employees.indexOf(parentrecord);
      if (index1 > -1) {
        const index = this.employees[index1].history.indexOf(record);
        this.employees[index1].history.splice(index, 1);
      }
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_spin = resolveComponent("a-spin");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_space = resolveComponent("a-space");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_select_option = resolveComponent("a-select-option");
  const _component_a_date_picker = resolveComponent("a-date-picker");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_button = resolveComponent("a-button");
  const _component_a_table = resolveComponent("a-table");
  const _component_a_avatar = resolveComponent("a-avatar");
  const _component_a_tag = resolveComponent("a-tag");
  const _component_a_dropdown = resolveComponent("a-dropdown");
  const _component_a_menu = resolveComponent("a-menu");
  const _component_a_menu_item = resolveComponent("a-menu-item");
  const _component_DownOutlined = resolveComponent("DownOutlined");
  const _component_a_time_picker = resolveComponent("a-time-picker");
  const _component_a_popconfirm = resolveComponent("a-popconfirm");
  const _component_EditOutlined = resolveComponent("EditOutlined");
  const _component_DeleteOutlined = resolveComponent("DeleteOutlined");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Employees" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_spin, {
          spinning: $data.loading,
          delay: $data.delayTime
        }, null, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_layout_content, { style: { margin: "24px 16px", padding: "24px", background: "#fff", minHeight: "calc(100vh - 115px)", textAlign: "center" } }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form, {
                      name: "nest-messages",
                      model: $data.formState,
                      layout: "inline",
                      onFinish: $options.search
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_select, {
                                  value: $data.formState.branch,
                                  "onUpdate:value": ($event) => $data.formState.branch = $event,
                                  placeholder: "Select Branch",
                                  style: { "min-width": "200px" }
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`<!--[-->`);
                                      ssrRenderList($props.branches, (branch) => {
                                        _push7(ssrRenderComponent(_component_a_select_option, {
                                          value: branch.id
                                        }, {
                                          default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                            if (_push8) {
                                              _push8(`${ssrInterpolate(branch.branch_name)}`);
                                            } else {
                                              return [
                                                createTextVNode(toDisplayString(branch.branch_name), 1)
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent7, _scopeId6));
                                      });
                                      _push7(`<!--]-->`);
                                    } else {
                                      return [
                                        (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                          return openBlock(), createBlock(_component_a_select_option, {
                                            value: branch.id
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(branch.branch_name), 1)
                                            ]),
                                            _: 2
                                          }, 1032, ["value"]);
                                        }), 256))
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_select, {
                                    value: $data.formState.branch,
                                    "onUpdate:value": ($event) => $data.formState.branch = $event,
                                    placeholder: "Select Branch",
                                    style: { "min-width": "200px" }
                                  }, {
                                    default: withCtx(() => [
                                      (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                        return openBlock(), createBlock(_component_a_select_option, {
                                          value: branch.id
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(branch.branch_name), 1)
                                          ]),
                                          _: 2
                                        }, 1032, ["value"]);
                                      }), 256))
                                    ]),
                                    _: 1
                                  }, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_date_picker, {
                                  value: $data.formState.date,
                                  "onUpdate:value": ($event) => $data.formState.date = $event,
                                  format: "DD-MM-YYYY",
                                  "value-format": "YYYY-MM-DD"
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_date_picker, {
                                    value: $data.formState.date,
                                    "onUpdate:value": ($event) => $data.formState.date = $event,
                                    format: "DD-MM-YYYY",
                                    "value-format": "YYYY-MM-DD"
                                  }, null, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_input, {
                                  placeholder: "Search Employees",
                                  value: $data.formState.term,
                                  "onUpdate:value": ($event) => $data.formState.term = $event
                                }, null, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_input, {
                                    placeholder: "Search Employees",
                                    value: $data.formState.term,
                                    "onUpdate:value": ($event) => $data.formState.term = $event
                                  }, null, 8, ["value", "onUpdate:value"])
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Search `);
                                    } else {
                                      return [
                                        createTextVNode(" Search ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    "html-type": "submit"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Search ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                          _push5(ssrRenderComponent(_component_a_form_item, null, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_button, { type: "primary" }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(` Add Time Manually `);
                                    } else {
                                      return [
                                        createTextVNode(" Add Time Manually ")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_button, { type: "primary" }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Add Time Manually ")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_select, {
                                  value: $data.formState.branch,
                                  "onUpdate:value": ($event) => $data.formState.branch = $event,
                                  placeholder: "Select Branch",
                                  style: { "min-width": "200px" }
                                }, {
                                  default: withCtx(() => [
                                    (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                      return openBlock(), createBlock(_component_a_select_option, {
                                        value: branch.id
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(branch.branch_name), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["value"]);
                                    }), 256))
                                  ]),
                                  _: 1
                                }, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_date_picker, {
                                  value: $data.formState.date,
                                  "onUpdate:value": ($event) => $data.formState.date = $event,
                                  format: "DD-MM-YYYY",
                                  "value-format": "YYYY-MM-DD"
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_input, {
                                  placeholder: "Search Employees",
                                  value: $data.formState.term,
                                  "onUpdate:value": ($event) => $data.formState.term = $event
                                }, null, 8, ["value", "onUpdate:value"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  "html-type": "submit"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Search ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_form_item, null, {
                              default: withCtx(() => [
                                createVNode(_component_a_button, { type: "primary" }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Add Time Manually ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_table, {
                      columns: $setup.columns,
                      "row-key": (record) => record.employee_id,
                      "data-source": $props.employees,
                      pagination: $props.pagination,
                      loading: $data.loading,
                      onChange: $options.handleTableChange
                    }, {
                      bodyCell: withCtx(({ column, text, record }, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          if (column.key === "name") {
                            _push5(`<!--[-->`);
                            _push5(ssrRenderComponent(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(`${ssrInterpolate(text[0].toUpperCase())}`);
                                } else {
                                  return [
                                    createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                            _push5(`   ${ssrInterpolate(text)}<!--]-->`);
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "status") {
                            _push5(ssrRenderComponent(_component_a_tag, {
                              color: $data.statusColor[record.status]
                            }, {
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(`${ssrInterpolate(record.status)}`);
                                } else {
                                  return [
                                    createTextVNode(toDisplayString(record.status), 1)
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "latestatus") {
                            _push5(`<!--[-->`);
                            if (record.status == "Present") {
                              _push5(ssrRenderComponent(_component_a_tag, {
                                color: record.late == true ? "red" : "green"
                              }, {
                                default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`${ssrInterpolate(record.late == true ? "Late" : "On Time")}`);
                                  } else {
                                    return [
                                      createTextVNode(toDisplayString(record.late == true ? "Late" : "On Time"), 1)
                                    ];
                                  }
                                }),
                                _: 2
                              }, _parent5, _scopeId4));
                            } else {
                              _push5(`<!---->`);
                            }
                            _push5(`<!--]-->`);
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "autoaction") {
                            _push5(ssrRenderComponent(_component_a_space, { direction: "horizontal" }, {
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  if (record.history.length) {
                                    _push6(`<div${_scopeId5}>`);
                                    if (record.history[record.history.length - 1].checkout != null) {
                                      _push6(ssrRenderComponent(_component_a_button, {
                                        type: "primary",
                                        onClick: ($event) => $options.clockIn(record)
                                      }, {
                                        default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                          if (_push7) {
                                            _push7(`Clock In`);
                                          } else {
                                            return [
                                              createTextVNode("Clock In")
                                            ];
                                          }
                                        }),
                                        _: 2
                                      }, _parent6, _scopeId5));
                                    } else {
                                      _push6(`<!---->`);
                                    }
                                    if (record.history[record.history.length - 1].checkout == null) {
                                      _push6(ssrRenderComponent(_component_a_button, {
                                        onClick: ($event) => $options.clockOut(record)
                                      }, {
                                        default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                          if (_push7) {
                                            _push7(`Clock Out`);
                                          } else {
                                            return [
                                              createTextVNode("Clock Out")
                                            ];
                                          }
                                        }),
                                        _: 2
                                      }, _parent6, _scopeId5));
                                    } else {
                                      _push6(`<!---->`);
                                    }
                                    if (record.history[record.history.length - 1].breakid == null) {
                                      _push6(ssrRenderComponent(_component_a_dropdown, null, {
                                        overlay: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                          if (_push7) {
                                            _push7(ssrRenderComponent(_component_a_menu, null, {
                                              default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                                if (_push8) {
                                                  _push8(`<!--[-->`);
                                                  ssrRenderList($props.breaks, (brk) => {
                                                    _push8(ssrRenderComponent(_component_a_menu_item, {
                                                      key: brk.id,
                                                      onClick: ($event) => $options.addBreak(record, brk.id)
                                                    }, {
                                                      default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                        if (_push9) {
                                                          _push9(`${ssrInterpolate(brk.name)}`);
                                                        } else {
                                                          return [
                                                            createTextVNode(toDisplayString(brk.name), 1)
                                                          ];
                                                        }
                                                      }),
                                                      _: 2
                                                    }, _parent8, _scopeId7));
                                                  });
                                                  _push8(`<!--]-->`);
                                                } else {
                                                  return [
                                                    (openBlock(true), createBlock(Fragment, null, renderList($props.breaks, (brk) => {
                                                      return openBlock(), createBlock(_component_a_menu_item, {
                                                        key: brk.id,
                                                        onClick: ($event) => $options.addBreak(record, brk.id)
                                                      }, {
                                                        default: withCtx(() => [
                                                          createTextVNode(toDisplayString(brk.name), 1)
                                                        ]),
                                                        _: 2
                                                      }, 1032, ["onClick"]);
                                                    }), 128))
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent7, _scopeId6));
                                          } else {
                                            return [
                                              createVNode(_component_a_menu, null, {
                                                default: withCtx(() => [
                                                  (openBlock(true), createBlock(Fragment, null, renderList($props.breaks, (brk) => {
                                                    return openBlock(), createBlock(_component_a_menu_item, {
                                                      key: brk.id,
                                                      onClick: ($event) => $options.addBreak(record, brk.id)
                                                    }, {
                                                      default: withCtx(() => [
                                                        createTextVNode(toDisplayString(brk.name), 1)
                                                      ]),
                                                      _: 2
                                                    }, 1032, ["onClick"]);
                                                  }), 128))
                                                ]),
                                                _: 2
                                              }, 1024)
                                            ];
                                          }
                                        }),
                                        default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                          if (_push7) {
                                            _push7(ssrRenderComponent(_component_a_button, null, {
                                              default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                                if (_push8) {
                                                  _push8(` Break `);
                                                  _push8(ssrRenderComponent(_component_DownOutlined, null, null, _parent8, _scopeId7));
                                                } else {
                                                  return [
                                                    createTextVNode(" Break "),
                                                    createVNode(_component_DownOutlined)
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent7, _scopeId6));
                                          } else {
                                            return [
                                              createVNode(_component_a_button, null, {
                                                default: withCtx(() => [
                                                  createTextVNode(" Break "),
                                                  createVNode(_component_DownOutlined)
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 2
                                      }, _parent6, _scopeId5));
                                    } else {
                                      _push6(ssrRenderComponent(_component_a_button, {
                                        onClick: ($event) => $options.clockOut(record)
                                      }, {
                                        default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                          if (_push7) {
                                            _push7(`Close Break`);
                                          } else {
                                            return [
                                              createTextVNode("Close Break")
                                            ];
                                          }
                                        }),
                                        _: 2
                                      }, _parent6, _scopeId5));
                                    }
                                    _push6(`</div>`);
                                  } else {
                                    _push6(`<div${_scopeId5}>`);
                                    _push6(ssrRenderComponent(_component_a_button, {
                                      type: "primary",
                                      onClick: ($event) => $options.clockIn(record)
                                    }, {
                                      default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`Clock In`);
                                        } else {
                                          return [
                                            createTextVNode("Clock In")
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                    _push6(`</div>`);
                                  }
                                } else {
                                  return [
                                    record.history.length ? (openBlock(), createBlock("div", { key: 0 }, [
                                      record.history[record.history.length - 1].checkout != null ? (openBlock(), createBlock(_component_a_button, {
                                        key: 0,
                                        type: "primary",
                                        onClick: ($event) => $options.clockIn(record)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Clock In")
                                        ]),
                                        _: 2
                                      }, 1032, ["onClick"])) : createCommentVNode("", true),
                                      record.history[record.history.length - 1].checkout == null ? (openBlock(), createBlock(_component_a_button, {
                                        key: 1,
                                        onClick: ($event) => $options.clockOut(record)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Clock Out")
                                        ]),
                                        _: 2
                                      }, 1032, ["onClick"])) : createCommentVNode("", true),
                                      record.history[record.history.length - 1].breakid == null ? (openBlock(), createBlock(_component_a_dropdown, { key: 2 }, {
                                        overlay: withCtx(() => [
                                          createVNode(_component_a_menu, null, {
                                            default: withCtx(() => [
                                              (openBlock(true), createBlock(Fragment, null, renderList($props.breaks, (brk) => {
                                                return openBlock(), createBlock(_component_a_menu_item, {
                                                  key: brk.id,
                                                  onClick: ($event) => $options.addBreak(record, brk.id)
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode(toDisplayString(brk.name), 1)
                                                  ]),
                                                  _: 2
                                                }, 1032, ["onClick"]);
                                              }), 128))
                                            ]),
                                            _: 2
                                          }, 1024)
                                        ]),
                                        default: withCtx(() => [
                                          createVNode(_component_a_button, null, {
                                            default: withCtx(() => [
                                              createTextVNode(" Break "),
                                              createVNode(_component_DownOutlined)
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 2
                                      }, 1024)) : (openBlock(), createBlock(_component_a_button, {
                                        key: 3,
                                        onClick: ($event) => $options.clockOut(record)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Close Break")
                                        ]),
                                        _: 2
                                      }, 1032, ["onClick"]))
                                    ])) : (openBlock(), createBlock("div", { key: 1 }, [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        onClick: ($event) => $options.clockIn(record)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Clock In")
                                        ]),
                                        _: 2
                                      }, 1032, ["onClick"])
                                    ]))
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                          } else {
                            _push5(`<!---->`);
                          }
                          if (column.key === "manualaction") {
                            _push5(`<!--[-->`);
                            _push5(ssrRenderComponent(_component_a_button, {
                              type: "default",
                              danger: "",
                              onClick: ($event) => $options.addmanualrows(record)
                            }, {
                              default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                if (_push6) {
                                  _push6(`Add Attendance`);
                                } else {
                                  return [
                                    createTextVNode("Add Attendance")
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent5, _scopeId4));
                            if ($data.showmanualsave.includes(record.employee_id)) {
                              _push5(ssrRenderComponent(_component_a_button, {
                                type: "primary",
                                danger: "",
                                onClick: ($event) => $options.savemanualdata(record)
                              }, {
                                default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`Save Attendance`);
                                  } else {
                                    return [
                                      createTextVNode("Save Attendance")
                                    ];
                                  }
                                }),
                                _: 2
                              }, _parent5, _scopeId4));
                            } else {
                              _push5(`<!---->`);
                            }
                            _push5(`<!--]-->`);
                          } else {
                            _push5(`<!---->`);
                          }
                        } else {
                          return [
                            column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                              createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                                ]),
                                _: 2
                              }, 1024),
                              createTextVNode("   " + toDisplayString(text), 1)
                            ], 64)) : createCommentVNode("", true),
                            column.key === "status" ? (openBlock(), createBlock(_component_a_tag, {
                              key: 1,
                              color: $data.statusColor[record.status]
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(record.status), 1)
                              ]),
                              _: 2
                            }, 1032, ["color"])) : createCommentVNode("", true),
                            column.key === "latestatus" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                              record.status == "Present" ? (openBlock(), createBlock(_component_a_tag, {
                                key: 0,
                                color: record.late == true ? "red" : "green"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(record.late == true ? "Late" : "On Time"), 1)
                                ]),
                                _: 2
                              }, 1032, ["color"])) : createCommentVNode("", true)
                            ], 64)) : createCommentVNode("", true),
                            column.key === "autoaction" ? (openBlock(), createBlock(_component_a_space, {
                              key: 3,
                              direction: "horizontal"
                            }, {
                              default: withCtx(() => [
                                record.history.length ? (openBlock(), createBlock("div", { key: 0 }, [
                                  record.history[record.history.length - 1].checkout != null ? (openBlock(), createBlock(_component_a_button, {
                                    key: 0,
                                    type: "primary",
                                    onClick: ($event) => $options.clockIn(record)
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Clock In")
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"])) : createCommentVNode("", true),
                                  record.history[record.history.length - 1].checkout == null ? (openBlock(), createBlock(_component_a_button, {
                                    key: 1,
                                    onClick: ($event) => $options.clockOut(record)
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Clock Out")
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"])) : createCommentVNode("", true),
                                  record.history[record.history.length - 1].breakid == null ? (openBlock(), createBlock(_component_a_dropdown, { key: 2 }, {
                                    overlay: withCtx(() => [
                                      createVNode(_component_a_menu, null, {
                                        default: withCtx(() => [
                                          (openBlock(true), createBlock(Fragment, null, renderList($props.breaks, (brk) => {
                                            return openBlock(), createBlock(_component_a_menu_item, {
                                              key: brk.id,
                                              onClick: ($event) => $options.addBreak(record, brk.id)
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode(toDisplayString(brk.name), 1)
                                              ]),
                                              _: 2
                                            }, 1032, ["onClick"]);
                                          }), 128))
                                        ]),
                                        _: 2
                                      }, 1024)
                                    ]),
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, null, {
                                        default: withCtx(() => [
                                          createTextVNode(" Break "),
                                          createVNode(_component_DownOutlined)
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 2
                                  }, 1024)) : (openBlock(), createBlock(_component_a_button, {
                                    key: 3,
                                    onClick: ($event) => $options.clockOut(record)
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Close Break")
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"]))
                                ])) : (openBlock(), createBlock("div", { key: 1 }, [
                                  createVNode(_component_a_button, {
                                    type: "primary",
                                    onClick: ($event) => $options.clockIn(record)
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("Clock In")
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"])
                                ]))
                              ]),
                              _: 2
                            }, 1024)) : createCommentVNode("", true),
                            column.key === "manualaction" ? (openBlock(), createBlock(Fragment, { key: 4 }, [
                              createVNode(_component_a_button, {
                                type: "default",
                                danger: "",
                                onClick: ($event) => $options.addmanualrows(record)
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Add Attendance")
                                ]),
                                _: 2
                              }, 1032, ["onClick"]),
                              $data.showmanualsave.includes(record.employee_id) ? (openBlock(), createBlock(_component_a_button, {
                                key: 0,
                                type: "primary",
                                danger: "",
                                onClick: ($event) => $options.savemanualdata(record)
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Save Attendance")
                                ]),
                                _: 2
                              }, 1032, ["onClick"])) : createCommentVNode("", true)
                            ], 64)) : createCommentVNode("", true)
                          ];
                        }
                      }),
                      expandedRowRender: withCtx(({ record }, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_table, {
                            class: "table-sm",
                            pagination: false,
                            columns: $setup.innercolumns,
                            "row-key": (history) => history.id,
                            "data-source": record.history,
                            set: _ctx.parentrecord = record
                          }, {
                            bodyCell: withCtx(({ column, text, record: record2 }, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                if (column.key === "location") {
                                  _push6(`<!--[-->`);
                                  if (record2.id == "" || $data.editableData.includes(record2.id)) {
                                    _push6(ssrRenderComponent(_component_a_select, {
                                      value: record2.branchid,
                                      "onUpdate:value": ($event) => record2.branchid = $event,
                                      placeholder: "Select Branch",
                                      style: { "min-width": "200px" }
                                    }, {
                                      default: withCtx((_4, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`<!--[-->`);
                                          ssrRenderList($props.branches, (branch) => {
                                            _push7(ssrRenderComponent(_component_a_select_option, {
                                              value: branch.id
                                            }, {
                                              default: withCtx((_5, _push8, _parent8, _scopeId7) => {
                                                if (_push8) {
                                                  _push8(`${ssrInterpolate(branch.branch_name)}`);
                                                } else {
                                                  return [
                                                    createTextVNode(toDisplayString(branch.branch_name), 1)
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent7, _scopeId6));
                                          });
                                          _push7(`<!--]-->`);
                                        } else {
                                          return [
                                            (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                              return openBlock(), createBlock(_component_a_select_option, {
                                                value: branch.id
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode(toDisplayString(branch.branch_name), 1)
                                                ]),
                                                _: 2
                                              }, 1032, ["value"]);
                                            }), 256))
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                  } else {
                                    _push6(`<div${_scopeId5}>${ssrInterpolate(record2.branch.branch_name ?? "-")}</div>`);
                                  }
                                  _push6(`<!--]-->`);
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "in") {
                                  _push6(`<!--[-->`);
                                  if (record2.id == "" || $data.editableData.includes(record2.id)) {
                                    _push6(ssrRenderComponent(_component_a_time_picker, {
                                      allowClear: true,
                                      format: "hh:mm A",
                                      placeholder: "Check In",
                                      "value-format": "HH:mm:ss",
                                      value: record2.checkin,
                                      "onUpdate:value": ($event) => record2.checkin = $event
                                    }, null, _parent6, _scopeId5));
                                  } else {
                                    _push6(`<div${_scopeId5}>${ssrInterpolate($data.moment(record2.checkin, "HH:mm:ss").format("hh:mm A"))}</div>`);
                                  }
                                  _push6(`<!--]-->`);
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "out") {
                                  _push6(`<!--[-->`);
                                  if (record2.id == "" || $data.editableData.includes(record2.id)) {
                                    _push6(ssrRenderComponent(_component_a_time_picker, {
                                      allowClear: true,
                                      format: "hh:mm A",
                                      placeholder: "Check Out",
                                      "value-format": "HH:mm:ss",
                                      value: record2.checkout,
                                      "onUpdate:value": ($event) => record2.checkout = $event
                                    }, null, _parent6, _scopeId5));
                                  } else {
                                    _push6(`<div${_scopeId5}>${ssrInterpolate(record2.checkout != null ? $data.moment(record2.checkout, "HH:mm:ss").format("hh:mm A") : "-")}</div>`);
                                  }
                                  _push6(`<!--]-->`);
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "break") {
                                  _push6(`<!--[-->`);
                                  if (record2.id == "" || $data.editableData.includes(record2.id)) {
                                    _push6(ssrRenderComponent(_component_a_select, {
                                      allowClear: true,
                                      value: record2.breakid,
                                      "onUpdate:value": ($event) => record2.breakid = $event,
                                      style: "width: 150px"
                                    }, {
                                      default: withCtx((_4, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`<!--[-->`);
                                          ssrRenderList($props.breaks, (brk) => {
                                            _push7(ssrRenderComponent(_component_a_select_option, {
                                              value: brk.id
                                            }, {
                                              default: withCtx((_5, _push8, _parent8, _scopeId7) => {
                                                if (_push8) {
                                                  _push8(`${ssrInterpolate(brk.name)}`);
                                                } else {
                                                  return [
                                                    createTextVNode(toDisplayString(brk.name), 1)
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent7, _scopeId6));
                                          });
                                          _push7(`<!--]-->`);
                                        } else {
                                          return [
                                            (openBlock(true), createBlock(Fragment, null, renderList($props.breaks, (brk) => {
                                              return openBlock(), createBlock(_component_a_select_option, {
                                                value: brk.id
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode(toDisplayString(brk.name), 1)
                                                ]),
                                                _: 2
                                              }, 1032, ["value"]);
                                            }), 256))
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                  } else {
                                    _push6(`<div${_scopeId5}>`);
                                    if (record2.breakid != null) {
                                      _push6(ssrRenderComponent(_component_a_tag, { color: "blue" }, {
                                        default: withCtx((_4, _push7, _parent7, _scopeId6) => {
                                          if (_push7) {
                                            _push7(`${ssrInterpolate(record2.break.name)}`);
                                          } else {
                                            return [
                                              createTextVNode(toDisplayString(record2.break.name), 1)
                                            ];
                                          }
                                        }),
                                        _: 2
                                      }, _parent6, _scopeId5));
                                    } else {
                                      _push6(`<!---->`);
                                    }
                                    _push6(`</div>`);
                                  }
                                  _push6(`<!--]-->`);
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "notes") {
                                  _push6(`<!--[-->`);
                                  if (record2.id == "" || $data.editableData.includes(record2.id)) {
                                    _push6(ssrRenderComponent(_component_a_input, {
                                      value: record2.notes,
                                      "onUpdate:value": ($event) => record2.notes = $event,
                                      style: { "width": "100%" }
                                    }, null, _parent6, _scopeId5));
                                  } else {
                                    _push6(`<span${_scopeId5}>${ssrInterpolate(record2.notes)}</span>`);
                                  }
                                  _push6(`<!--]-->`);
                                } else {
                                  _push6(`<!---->`);
                                }
                                if (column.key === "action") {
                                  _push6(`<!--[-->`);
                                  if (record2.id != "") {
                                    _push6(ssrRenderComponent(_component_a_space, { direction: "horizontal" }, {
                                      default: withCtx((_4, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`<div class="editable-row-operations"${_scopeId6}>`);
                                          if (record2.id == "" || $data.editableData.includes(record2.id)) {
                                            _push7(`<span${_scopeId6}>`);
                                            _push7(ssrRenderComponent(_component_a_button, {
                                              type: "primary",
                                              onClick: ($event) => $options.savehistory(record2)
                                            }, {
                                              default: withCtx((_5, _push8, _parent8, _scopeId7) => {
                                                if (_push8) {
                                                  _push8(`Save`);
                                                } else {
                                                  return [
                                                    createTextVNode("Save")
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent7, _scopeId6));
                                            _push7(ssrRenderComponent(_component_a_popconfirm, {
                                              title: "Sure to cancel?",
                                              onConfirm: ($event) => $options.cancel(record2.id)
                                            }, {
                                              default: withCtx((_5, _push8, _parent8, _scopeId7) => {
                                                if (_push8) {
                                                  _push8(ssrRenderComponent(_component_a_button, { type: "default" }, {
                                                    default: withCtx((_6, _push9, _parent9, _scopeId8) => {
                                                      if (_push9) {
                                                        _push9(`Cancel`);
                                                      } else {
                                                        return [
                                                          createTextVNode("Cancel")
                                                        ];
                                                      }
                                                    }),
                                                    _: 2
                                                  }, _parent8, _scopeId7));
                                                } else {
                                                  return [
                                                    createVNode(_component_a_button, { type: "default" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Cancel")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent7, _scopeId6));
                                            _push7(`</span>`);
                                          } else {
                                            _push7(`<span${_scopeId6}>`);
                                            _push7(ssrRenderComponent(_component_a_button, {
                                              onClick: ($event) => $options.edit(record2.id)
                                            }, {
                                              icon: withCtx((_5, _push8, _parent8, _scopeId7) => {
                                                if (_push8) {
                                                  _push8(ssrRenderComponent(_component_EditOutlined, null, null, _parent8, _scopeId7));
                                                } else {
                                                  return [
                                                    createVNode(_component_EditOutlined)
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent7, _scopeId6));
                                            _push7(`</span>`);
                                          }
                                          _push7(`</div>`);
                                          _push7(ssrRenderComponent(_component_a_popconfirm, {
                                            title: "Sure to delete?",
                                            onConfirm: ($event) => $options.deletehistory(record2.id)
                                          }, {
                                            default: withCtx((_5, _push8, _parent8, _scopeId7) => {
                                              if (_push8) {
                                                _push8(ssrRenderComponent(_component_a_button, null, {
                                                  icon: withCtx((_6, _push9, _parent9, _scopeId8) => {
                                                    if (_push9) {
                                                      _push9(ssrRenderComponent(_component_DeleteOutlined, null, null, _parent9, _scopeId8));
                                                    } else {
                                                      return [
                                                        createVNode(_component_DeleteOutlined)
                                                      ];
                                                    }
                                                  }),
                                                  _: 2
                                                }, _parent8, _scopeId7));
                                              } else {
                                                return [
                                                  createVNode(_component_a_button, null, {
                                                    icon: withCtx(() => [
                                                      createVNode(_component_DeleteOutlined)
                                                    ]),
                                                    _: 1
                                                  })
                                                ];
                                              }
                                            }),
                                            _: 2
                                          }, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode("div", { class: "editable-row-operations" }, [
                                              record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock("span", { key: 0 }, [
                                                createVNode(_component_a_button, {
                                                  type: "primary",
                                                  onClick: ($event) => $options.savehistory(record2)
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Save")
                                                  ]),
                                                  _: 2
                                                }, 1032, ["onClick"]),
                                                createVNode(_component_a_popconfirm, {
                                                  title: "Sure to cancel?",
                                                  onConfirm: ($event) => $options.cancel(record2.id)
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_a_button, { type: "default" }, {
                                                      default: withCtx(() => [
                                                        createTextVNode("Cancel")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 2
                                                }, 1032, ["onConfirm"])
                                              ])) : (openBlock(), createBlock("span", { key: 1 }, [
                                                createVNode(_component_a_button, {
                                                  onClick: ($event) => $options.edit(record2.id)
                                                }, {
                                                  icon: withCtx(() => [
                                                    createVNode(_component_EditOutlined)
                                                  ]),
                                                  _: 2
                                                }, 1032, ["onClick"])
                                              ]))
                                            ]),
                                            createVNode(_component_a_popconfirm, {
                                              title: "Sure to delete?",
                                              onConfirm: ($event) => $options.deletehistory(record2.id)
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_button, null, {
                                                  icon: withCtx(() => [
                                                    createVNode(_component_DeleteOutlined)
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 2
                                            }, 1032, ["onConfirm"])
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                  } else {
                                    _push6(ssrRenderComponent(_component_a_space, null, {
                                      default: withCtx((_4, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(_component_a_popconfirm, {
                                            title: "Sure to delete?",
                                            onConfirm: ($event) => $options.deletemanualrow(_ctx.parentrecord, record2)
                                          }, {
                                            default: withCtx((_5, _push8, _parent8, _scopeId7) => {
                                              if (_push8) {
                                                _push8(ssrRenderComponent(_component_a_button, null, {
                                                  icon: withCtx((_6, _push9, _parent9, _scopeId8) => {
                                                    if (_push9) {
                                                      _push9(ssrRenderComponent(_component_DeleteOutlined, null, null, _parent9, _scopeId8));
                                                    } else {
                                                      return [
                                                        createVNode(_component_DeleteOutlined)
                                                      ];
                                                    }
                                                  }),
                                                  _: 2
                                                }, _parent8, _scopeId7));
                                              } else {
                                                return [
                                                  createVNode(_component_a_button, null, {
                                                    icon: withCtx(() => [
                                                      createVNode(_component_DeleteOutlined)
                                                    ]),
                                                    _: 1
                                                  })
                                                ];
                                              }
                                            }),
                                            _: 2
                                          }, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode(_component_a_popconfirm, {
                                              title: "Sure to delete?",
                                              onConfirm: ($event) => $options.deletemanualrow(_ctx.parentrecord, record2)
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_button, null, {
                                                  icon: withCtx(() => [
                                                    createVNode(_component_DeleteOutlined)
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 2
                                            }, 1032, ["onConfirm"])
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                  }
                                  _push6(`<!--]-->`);
                                } else {
                                  _push6(`<!---->`);
                                }
                              } else {
                                return [
                                  column.key === "location" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                                    record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_select, {
                                      key: 0,
                                      value: record2.branchid,
                                      "onUpdate:value": ($event) => record2.branchid = $event,
                                      placeholder: "Select Branch",
                                      style: { "min-width": "200px" }
                                    }, {
                                      default: withCtx(() => [
                                        (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                          return openBlock(), createBlock(_component_a_select_option, {
                                            value: branch.id
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(branch.branch_name), 1)
                                            ]),
                                            _: 2
                                          }, 1032, ["value"]);
                                        }), 256))
                                      ]),
                                      _: 2
                                    }, 1032, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, toDisplayString(record2.branch.branch_name ?? "-"), 1))
                                  ], 64)) : createCommentVNode("", true),
                                  column.key === "in" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                                    record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_time_picker, {
                                      key: 0,
                                      allowClear: true,
                                      format: "hh:mm A",
                                      placeholder: "Check In",
                                      "value-format": "HH:mm:ss",
                                      value: record2.checkin,
                                      "onUpdate:value": ($event) => record2.checkin = $event
                                    }, null, 8, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, toDisplayString($data.moment(record2.checkin, "HH:mm:ss").format("hh:mm A")), 1))
                                  ], 64)) : createCommentVNode("", true),
                                  column.key === "out" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                                    record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_time_picker, {
                                      key: 0,
                                      allowClear: true,
                                      format: "hh:mm A",
                                      placeholder: "Check Out",
                                      "value-format": "HH:mm:ss",
                                      value: record2.checkout,
                                      "onUpdate:value": ($event) => record2.checkout = $event
                                    }, null, 8, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, toDisplayString(record2.checkout != null ? $data.moment(record2.checkout, "HH:mm:ss").format("hh:mm A") : "-"), 1))
                                  ], 64)) : createCommentVNode("", true),
                                  column.key === "break" ? (openBlock(), createBlock(Fragment, { key: 3 }, [
                                    record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_select, {
                                      key: 0,
                                      allowClear: true,
                                      value: record2.breakid,
                                      "onUpdate:value": ($event) => record2.breakid = $event,
                                      style: "width: 150px"
                                    }, {
                                      default: withCtx(() => [
                                        (openBlock(true), createBlock(Fragment, null, renderList($props.breaks, (brk) => {
                                          return openBlock(), createBlock(_component_a_select_option, {
                                            value: brk.id
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(brk.name), 1)
                                            ]),
                                            _: 2
                                          }, 1032, ["value"]);
                                        }), 256))
                                      ]),
                                      _: 2
                                    }, 1032, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, [
                                      record2.breakid != null ? (openBlock(), createBlock(_component_a_tag, {
                                        key: 0,
                                        color: "blue"
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(record2.break.name), 1)
                                        ]),
                                        _: 2
                                      }, 1024)) : createCommentVNode("", true)
                                    ]))
                                  ], 64)) : createCommentVNode("", true),
                                  column.key === "notes" ? (openBlock(), createBlock(Fragment, { key: 4 }, [
                                    record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_input, {
                                      key: 0,
                                      value: record2.notes,
                                      "onUpdate:value": ($event) => record2.notes = $event,
                                      style: { "width": "100%" }
                                    }, null, 8, ["value", "onUpdate:value"])) : (openBlock(), createBlock("span", { key: 1 }, toDisplayString(record2.notes), 1))
                                  ], 64)) : createCommentVNode("", true),
                                  column.key === "action" ? (openBlock(), createBlock(Fragment, { key: 5 }, [
                                    record2.id != "" ? (openBlock(), createBlock(_component_a_space, {
                                      key: 0,
                                      direction: "horizontal"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode("div", { class: "editable-row-operations" }, [
                                          record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock("span", { key: 0 }, [
                                            createVNode(_component_a_button, {
                                              type: "primary",
                                              onClick: ($event) => $options.savehistory(record2)
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode("Save")
                                              ]),
                                              _: 2
                                            }, 1032, ["onClick"]),
                                            createVNode(_component_a_popconfirm, {
                                              title: "Sure to cancel?",
                                              onConfirm: ($event) => $options.cancel(record2.id)
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_a_button, { type: "default" }, {
                                                  default: withCtx(() => [
                                                    createTextVNode("Cancel")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 2
                                            }, 1032, ["onConfirm"])
                                          ])) : (openBlock(), createBlock("span", { key: 1 }, [
                                            createVNode(_component_a_button, {
                                              onClick: ($event) => $options.edit(record2.id)
                                            }, {
                                              icon: withCtx(() => [
                                                createVNode(_component_EditOutlined)
                                              ]),
                                              _: 2
                                            }, 1032, ["onClick"])
                                          ]))
                                        ]),
                                        createVNode(_component_a_popconfirm, {
                                          title: "Sure to delete?",
                                          onConfirm: ($event) => $options.deletehistory(record2.id)
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_button, null, {
                                              icon: withCtx(() => [
                                                createVNode(_component_DeleteOutlined)
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 2
                                        }, 1032, ["onConfirm"])
                                      ]),
                                      _: 2
                                    }, 1024)) : (openBlock(), createBlock(_component_a_space, { key: 1 }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_popconfirm, {
                                          title: "Sure to delete?",
                                          onConfirm: ($event) => $options.deletemanualrow(_ctx.parentrecord, record2)
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_button, null, {
                                              icon: withCtx(() => [
                                                createVNode(_component_DeleteOutlined)
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 2
                                        }, 1032, ["onConfirm"])
                                      ]),
                                      _: 2
                                    }, 1024))
                                  ], 64)) : createCommentVNode("", true)
                                ];
                              }
                            }),
                            _: 2
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_table, {
                              class: "table-sm",
                              pagination: false,
                              columns: $setup.innercolumns,
                              "row-key": (history) => history.id,
                              "data-source": record.history,
                              set: _ctx.parentrecord = record
                            }, {
                              bodyCell: withCtx(({ column, text, record: record2 }) => [
                                column.key === "location" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                                  record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_select, {
                                    key: 0,
                                    value: record2.branchid,
                                    "onUpdate:value": ($event) => record2.branchid = $event,
                                    placeholder: "Select Branch",
                                    style: { "min-width": "200px" }
                                  }, {
                                    default: withCtx(() => [
                                      (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                        return openBlock(), createBlock(_component_a_select_option, {
                                          value: branch.id
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(branch.branch_name), 1)
                                          ]),
                                          _: 2
                                        }, 1032, ["value"]);
                                      }), 256))
                                    ]),
                                    _: 2
                                  }, 1032, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, toDisplayString(record2.branch.branch_name ?? "-"), 1))
                                ], 64)) : createCommentVNode("", true),
                                column.key === "in" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                                  record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_time_picker, {
                                    key: 0,
                                    allowClear: true,
                                    format: "hh:mm A",
                                    placeholder: "Check In",
                                    "value-format": "HH:mm:ss",
                                    value: record2.checkin,
                                    "onUpdate:value": ($event) => record2.checkin = $event
                                  }, null, 8, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, toDisplayString($data.moment(record2.checkin, "HH:mm:ss").format("hh:mm A")), 1))
                                ], 64)) : createCommentVNode("", true),
                                column.key === "out" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                                  record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_time_picker, {
                                    key: 0,
                                    allowClear: true,
                                    format: "hh:mm A",
                                    placeholder: "Check Out",
                                    "value-format": "HH:mm:ss",
                                    value: record2.checkout,
                                    "onUpdate:value": ($event) => record2.checkout = $event
                                  }, null, 8, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, toDisplayString(record2.checkout != null ? $data.moment(record2.checkout, "HH:mm:ss").format("hh:mm A") : "-"), 1))
                                ], 64)) : createCommentVNode("", true),
                                column.key === "break" ? (openBlock(), createBlock(Fragment, { key: 3 }, [
                                  record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_select, {
                                    key: 0,
                                    allowClear: true,
                                    value: record2.breakid,
                                    "onUpdate:value": ($event) => record2.breakid = $event,
                                    style: "width: 150px"
                                  }, {
                                    default: withCtx(() => [
                                      (openBlock(true), createBlock(Fragment, null, renderList($props.breaks, (brk) => {
                                        return openBlock(), createBlock(_component_a_select_option, {
                                          value: brk.id
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(brk.name), 1)
                                          ]),
                                          _: 2
                                        }, 1032, ["value"]);
                                      }), 256))
                                    ]),
                                    _: 2
                                  }, 1032, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, [
                                    record2.breakid != null ? (openBlock(), createBlock(_component_a_tag, {
                                      key: 0,
                                      color: "blue"
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(record2.break.name), 1)
                                      ]),
                                      _: 2
                                    }, 1024)) : createCommentVNode("", true)
                                  ]))
                                ], 64)) : createCommentVNode("", true),
                                column.key === "notes" ? (openBlock(), createBlock(Fragment, { key: 4 }, [
                                  record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_input, {
                                    key: 0,
                                    value: record2.notes,
                                    "onUpdate:value": ($event) => record2.notes = $event,
                                    style: { "width": "100%" }
                                  }, null, 8, ["value", "onUpdate:value"])) : (openBlock(), createBlock("span", { key: 1 }, toDisplayString(record2.notes), 1))
                                ], 64)) : createCommentVNode("", true),
                                column.key === "action" ? (openBlock(), createBlock(Fragment, { key: 5 }, [
                                  record2.id != "" ? (openBlock(), createBlock(_component_a_space, {
                                    key: 0,
                                    direction: "horizontal"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("div", { class: "editable-row-operations" }, [
                                        record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock("span", { key: 0 }, [
                                          createVNode(_component_a_button, {
                                            type: "primary",
                                            onClick: ($event) => $options.savehistory(record2)
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode("Save")
                                            ]),
                                            _: 2
                                          }, 1032, ["onClick"]),
                                          createVNode(_component_a_popconfirm, {
                                            title: "Sure to cancel?",
                                            onConfirm: ($event) => $options.cancel(record2.id)
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_a_button, { type: "default" }, {
                                                default: withCtx(() => [
                                                  createTextVNode("Cancel")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 2
                                          }, 1032, ["onConfirm"])
                                        ])) : (openBlock(), createBlock("span", { key: 1 }, [
                                          createVNode(_component_a_button, {
                                            onClick: ($event) => $options.edit(record2.id)
                                          }, {
                                            icon: withCtx(() => [
                                              createVNode(_component_EditOutlined)
                                            ]),
                                            _: 2
                                          }, 1032, ["onClick"])
                                        ]))
                                      ]),
                                      createVNode(_component_a_popconfirm, {
                                        title: "Sure to delete?",
                                        onConfirm: ($event) => $options.deletehistory(record2.id)
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_button, null, {
                                            icon: withCtx(() => [
                                              createVNode(_component_DeleteOutlined)
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 2
                                      }, 1032, ["onConfirm"])
                                    ]),
                                    _: 2
                                  }, 1024)) : (openBlock(), createBlock(_component_a_space, { key: 1 }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_popconfirm, {
                                        title: "Sure to delete?",
                                        onConfirm: ($event) => $options.deletemanualrow(_ctx.parentrecord, record2)
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_button, null, {
                                            icon: withCtx(() => [
                                              createVNode(_component_DeleteOutlined)
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 2
                                      }, 1032, ["onConfirm"])
                                    ]),
                                    _: 2
                                  }, 1024))
                                ], 64)) : createCommentVNode("", true)
                              ]),
                              _: 2
                            }, 1032, ["columns", "row-key", "data-source", "set"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form, {
                        name: "nest-messages",
                        model: $data.formState,
                        layout: "inline",
                        onFinish: $options.search
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_select, {
                                value: $data.formState.branch,
                                "onUpdate:value": ($event) => $data.formState.branch = $event,
                                placeholder: "Select Branch",
                                style: { "min-width": "200px" }
                              }, {
                                default: withCtx(() => [
                                  (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                    return openBlock(), createBlock(_component_a_select_option, {
                                      value: branch.id
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(branch.branch_name), 1)
                                      ]),
                                      _: 2
                                    }, 1032, ["value"]);
                                  }), 256))
                                ]),
                                _: 1
                              }, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_date_picker, {
                                value: $data.formState.date,
                                "onUpdate:value": ($event) => $data.formState.date = $event,
                                format: "DD-MM-YYYY",
                                "value-format": "YYYY-MM-DD"
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_input, {
                                placeholder: "Search Employees",
                                value: $data.formState.term,
                                "onUpdate:value": ($event) => $data.formState.term = $event
                              }, null, 8, ["value", "onUpdate:value"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, {
                                type: "primary",
                                "html-type": "submit"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Search ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_form_item, null, {
                            default: withCtx(() => [
                              createVNode(_component_a_button, { type: "primary" }, {
                                default: withCtx(() => [
                                  createTextVNode(" Add Time Manually ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["model", "onFinish"]),
                      createVNode(_component_a_table, {
                        columns: $setup.columns,
                        "row-key": (record) => record.employee_id,
                        "data-source": $props.employees,
                        pagination: $props.pagination,
                        loading: $data.loading,
                        onChange: $options.handleTableChange
                      }, {
                        bodyCell: withCtx(({ column, text, record }) => [
                          column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                            createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                              ]),
                              _: 2
                            }, 1024),
                            createTextVNode("   " + toDisplayString(text), 1)
                          ], 64)) : createCommentVNode("", true),
                          column.key === "status" ? (openBlock(), createBlock(_component_a_tag, {
                            key: 1,
                            color: $data.statusColor[record.status]
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(record.status), 1)
                            ]),
                            _: 2
                          }, 1032, ["color"])) : createCommentVNode("", true),
                          column.key === "latestatus" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                            record.status == "Present" ? (openBlock(), createBlock(_component_a_tag, {
                              key: 0,
                              color: record.late == true ? "red" : "green"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(record.late == true ? "Late" : "On Time"), 1)
                              ]),
                              _: 2
                            }, 1032, ["color"])) : createCommentVNode("", true)
                          ], 64)) : createCommentVNode("", true),
                          column.key === "autoaction" ? (openBlock(), createBlock(_component_a_space, {
                            key: 3,
                            direction: "horizontal"
                          }, {
                            default: withCtx(() => [
                              record.history.length ? (openBlock(), createBlock("div", { key: 0 }, [
                                record.history[record.history.length - 1].checkout != null ? (openBlock(), createBlock(_component_a_button, {
                                  key: 0,
                                  type: "primary",
                                  onClick: ($event) => $options.clockIn(record)
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Clock In")
                                  ]),
                                  _: 2
                                }, 1032, ["onClick"])) : createCommentVNode("", true),
                                record.history[record.history.length - 1].checkout == null ? (openBlock(), createBlock(_component_a_button, {
                                  key: 1,
                                  onClick: ($event) => $options.clockOut(record)
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Clock Out")
                                  ]),
                                  _: 2
                                }, 1032, ["onClick"])) : createCommentVNode("", true),
                                record.history[record.history.length - 1].breakid == null ? (openBlock(), createBlock(_component_a_dropdown, { key: 2 }, {
                                  overlay: withCtx(() => [
                                    createVNode(_component_a_menu, null, {
                                      default: withCtx(() => [
                                        (openBlock(true), createBlock(Fragment, null, renderList($props.breaks, (brk) => {
                                          return openBlock(), createBlock(_component_a_menu_item, {
                                            key: brk.id,
                                            onClick: ($event) => $options.addBreak(record, brk.id)
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(brk.name), 1)
                                            ]),
                                            _: 2
                                          }, 1032, ["onClick"]);
                                        }), 128))
                                      ]),
                                      _: 2
                                    }, 1024)
                                  ]),
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, null, {
                                      default: withCtx(() => [
                                        createTextVNode(" Break "),
                                        createVNode(_component_DownOutlined)
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 2
                                }, 1024)) : (openBlock(), createBlock(_component_a_button, {
                                  key: 3,
                                  onClick: ($event) => $options.clockOut(record)
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Close Break")
                                  ]),
                                  _: 2
                                }, 1032, ["onClick"]))
                              ])) : (openBlock(), createBlock("div", { key: 1 }, [
                                createVNode(_component_a_button, {
                                  type: "primary",
                                  onClick: ($event) => $options.clockIn(record)
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Clock In")
                                  ]),
                                  _: 2
                                }, 1032, ["onClick"])
                              ]))
                            ]),
                            _: 2
                          }, 1024)) : createCommentVNode("", true),
                          column.key === "manualaction" ? (openBlock(), createBlock(Fragment, { key: 4 }, [
                            createVNode(_component_a_button, {
                              type: "default",
                              danger: "",
                              onClick: ($event) => $options.addmanualrows(record)
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Add Attendance")
                              ]),
                              _: 2
                            }, 1032, ["onClick"]),
                            $data.showmanualsave.includes(record.employee_id) ? (openBlock(), createBlock(_component_a_button, {
                              key: 0,
                              type: "primary",
                              danger: "",
                              onClick: ($event) => $options.savemanualdata(record)
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Save Attendance")
                              ]),
                              _: 2
                            }, 1032, ["onClick"])) : createCommentVNode("", true)
                          ], 64)) : createCommentVNode("", true)
                        ]),
                        expandedRowRender: withCtx(({ record }) => [
                          createVNode(_component_a_table, {
                            class: "table-sm",
                            pagination: false,
                            columns: $setup.innercolumns,
                            "row-key": (history) => history.id,
                            "data-source": record.history,
                            set: _ctx.parentrecord = record
                          }, {
                            bodyCell: withCtx(({ column, text, record: record2 }) => [
                              column.key === "location" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                                record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_select, {
                                  key: 0,
                                  value: record2.branchid,
                                  "onUpdate:value": ($event) => record2.branchid = $event,
                                  placeholder: "Select Branch",
                                  style: { "min-width": "200px" }
                                }, {
                                  default: withCtx(() => [
                                    (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                      return openBlock(), createBlock(_component_a_select_option, {
                                        value: branch.id
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(branch.branch_name), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["value"]);
                                    }), 256))
                                  ]),
                                  _: 2
                                }, 1032, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, toDisplayString(record2.branch.branch_name ?? "-"), 1))
                              ], 64)) : createCommentVNode("", true),
                              column.key === "in" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                                record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_time_picker, {
                                  key: 0,
                                  allowClear: true,
                                  format: "hh:mm A",
                                  placeholder: "Check In",
                                  "value-format": "HH:mm:ss",
                                  value: record2.checkin,
                                  "onUpdate:value": ($event) => record2.checkin = $event
                                }, null, 8, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, toDisplayString($data.moment(record2.checkin, "HH:mm:ss").format("hh:mm A")), 1))
                              ], 64)) : createCommentVNode("", true),
                              column.key === "out" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                                record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_time_picker, {
                                  key: 0,
                                  allowClear: true,
                                  format: "hh:mm A",
                                  placeholder: "Check Out",
                                  "value-format": "HH:mm:ss",
                                  value: record2.checkout,
                                  "onUpdate:value": ($event) => record2.checkout = $event
                                }, null, 8, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, toDisplayString(record2.checkout != null ? $data.moment(record2.checkout, "HH:mm:ss").format("hh:mm A") : "-"), 1))
                              ], 64)) : createCommentVNode("", true),
                              column.key === "break" ? (openBlock(), createBlock(Fragment, { key: 3 }, [
                                record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_select, {
                                  key: 0,
                                  allowClear: true,
                                  value: record2.breakid,
                                  "onUpdate:value": ($event) => record2.breakid = $event,
                                  style: "width: 150px"
                                }, {
                                  default: withCtx(() => [
                                    (openBlock(true), createBlock(Fragment, null, renderList($props.breaks, (brk) => {
                                      return openBlock(), createBlock(_component_a_select_option, {
                                        value: brk.id
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(brk.name), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["value"]);
                                    }), 256))
                                  ]),
                                  _: 2
                                }, 1032, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, [
                                  record2.breakid != null ? (openBlock(), createBlock(_component_a_tag, {
                                    key: 0,
                                    color: "blue"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(toDisplayString(record2.break.name), 1)
                                    ]),
                                    _: 2
                                  }, 1024)) : createCommentVNode("", true)
                                ]))
                              ], 64)) : createCommentVNode("", true),
                              column.key === "notes" ? (openBlock(), createBlock(Fragment, { key: 4 }, [
                                record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_input, {
                                  key: 0,
                                  value: record2.notes,
                                  "onUpdate:value": ($event) => record2.notes = $event,
                                  style: { "width": "100%" }
                                }, null, 8, ["value", "onUpdate:value"])) : (openBlock(), createBlock("span", { key: 1 }, toDisplayString(record2.notes), 1))
                              ], 64)) : createCommentVNode("", true),
                              column.key === "action" ? (openBlock(), createBlock(Fragment, { key: 5 }, [
                                record2.id != "" ? (openBlock(), createBlock(_component_a_space, {
                                  key: 0,
                                  direction: "horizontal"
                                }, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "editable-row-operations" }, [
                                      record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock("span", { key: 0 }, [
                                        createVNode(_component_a_button, {
                                          type: "primary",
                                          onClick: ($event) => $options.savehistory(record2)
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode("Save")
                                          ]),
                                          _: 2
                                        }, 1032, ["onClick"]),
                                        createVNode(_component_a_popconfirm, {
                                          title: "Sure to cancel?",
                                          onConfirm: ($event) => $options.cancel(record2.id)
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_a_button, { type: "default" }, {
                                              default: withCtx(() => [
                                                createTextVNode("Cancel")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 2
                                        }, 1032, ["onConfirm"])
                                      ])) : (openBlock(), createBlock("span", { key: 1 }, [
                                        createVNode(_component_a_button, {
                                          onClick: ($event) => $options.edit(record2.id)
                                        }, {
                                          icon: withCtx(() => [
                                            createVNode(_component_EditOutlined)
                                          ]),
                                          _: 2
                                        }, 1032, ["onClick"])
                                      ]))
                                    ]),
                                    createVNode(_component_a_popconfirm, {
                                      title: "Sure to delete?",
                                      onConfirm: ($event) => $options.deletehistory(record2.id)
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_button, null, {
                                          icon: withCtx(() => [
                                            createVNode(_component_DeleteOutlined)
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 2
                                    }, 1032, ["onConfirm"])
                                  ]),
                                  _: 2
                                }, 1024)) : (openBlock(), createBlock(_component_a_space, { key: 1 }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_popconfirm, {
                                      title: "Sure to delete?",
                                      onConfirm: ($event) => $options.deletemanualrow(_ctx.parentrecord, record2)
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_button, null, {
                                          icon: withCtx(() => [
                                            createVNode(_component_DeleteOutlined)
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 2
                                    }, 1032, ["onConfirm"])
                                  ]),
                                  _: 2
                                }, 1024))
                              ], 64)) : createCommentVNode("", true)
                            ]),
                            _: 2
                          }, 1032, ["columns", "row-key", "data-source", "set"])
                        ]),
                        _: 1
                      }, 8, ["columns", "row-key", "data-source", "pagination", "loading", "onChange"])
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_space, {
                  direction: "vertical",
                  style: { width: "100%" }
                }, {
                  default: withCtx(() => [
                    createVNode(_component_a_form, {
                      name: "nest-messages",
                      model: $data.formState,
                      layout: "inline",
                      onFinish: $options.search
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_select, {
                              value: $data.formState.branch,
                              "onUpdate:value": ($event) => $data.formState.branch = $event,
                              placeholder: "Select Branch",
                              style: { "min-width": "200px" }
                            }, {
                              default: withCtx(() => [
                                (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                  return openBlock(), createBlock(_component_a_select_option, {
                                    value: branch.id
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(toDisplayString(branch.branch_name), 1)
                                    ]),
                                    _: 2
                                  }, 1032, ["value"]);
                                }), 256))
                              ]),
                              _: 1
                            }, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_date_picker, {
                              value: $data.formState.date,
                              "onUpdate:value": ($event) => $data.formState.date = $event,
                              format: "DD-MM-YYYY",
                              "value-format": "YYYY-MM-DD"
                            }, null, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_input, {
                              placeholder: "Search Employees",
                              value: $data.formState.term,
                              "onUpdate:value": ($event) => $data.formState.term = $event
                            }, null, 8, ["value", "onUpdate:value"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Search ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_a_form_item, null, {
                          default: withCtx(() => [
                            createVNode(_component_a_button, { type: "primary" }, {
                              default: withCtx(() => [
                                createTextVNode(" Add Time Manually ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["model", "onFinish"]),
                    createVNode(_component_a_table, {
                      columns: $setup.columns,
                      "row-key": (record) => record.employee_id,
                      "data-source": $props.employees,
                      pagination: $props.pagination,
                      loading: $data.loading,
                      onChange: $options.handleTableChange
                    }, {
                      bodyCell: withCtx(({ column, text, record }) => [
                        column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                          createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                            ]),
                            _: 2
                          }, 1024),
                          createTextVNode("   " + toDisplayString(text), 1)
                        ], 64)) : createCommentVNode("", true),
                        column.key === "status" ? (openBlock(), createBlock(_component_a_tag, {
                          key: 1,
                          color: $data.statusColor[record.status]
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(record.status), 1)
                          ]),
                          _: 2
                        }, 1032, ["color"])) : createCommentVNode("", true),
                        column.key === "latestatus" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                          record.status == "Present" ? (openBlock(), createBlock(_component_a_tag, {
                            key: 0,
                            color: record.late == true ? "red" : "green"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(record.late == true ? "Late" : "On Time"), 1)
                            ]),
                            _: 2
                          }, 1032, ["color"])) : createCommentVNode("", true)
                        ], 64)) : createCommentVNode("", true),
                        column.key === "autoaction" ? (openBlock(), createBlock(_component_a_space, {
                          key: 3,
                          direction: "horizontal"
                        }, {
                          default: withCtx(() => [
                            record.history.length ? (openBlock(), createBlock("div", { key: 0 }, [
                              record.history[record.history.length - 1].checkout != null ? (openBlock(), createBlock(_component_a_button, {
                                key: 0,
                                type: "primary",
                                onClick: ($event) => $options.clockIn(record)
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Clock In")
                                ]),
                                _: 2
                              }, 1032, ["onClick"])) : createCommentVNode("", true),
                              record.history[record.history.length - 1].checkout == null ? (openBlock(), createBlock(_component_a_button, {
                                key: 1,
                                onClick: ($event) => $options.clockOut(record)
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Clock Out")
                                ]),
                                _: 2
                              }, 1032, ["onClick"])) : createCommentVNode("", true),
                              record.history[record.history.length - 1].breakid == null ? (openBlock(), createBlock(_component_a_dropdown, { key: 2 }, {
                                overlay: withCtx(() => [
                                  createVNode(_component_a_menu, null, {
                                    default: withCtx(() => [
                                      (openBlock(true), createBlock(Fragment, null, renderList($props.breaks, (brk) => {
                                        return openBlock(), createBlock(_component_a_menu_item, {
                                          key: brk.id,
                                          onClick: ($event) => $options.addBreak(record, brk.id)
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(brk.name), 1)
                                          ]),
                                          _: 2
                                        }, 1032, ["onClick"]);
                                      }), 128))
                                    ]),
                                    _: 2
                                  }, 1024)
                                ]),
                                default: withCtx(() => [
                                  createVNode(_component_a_button, null, {
                                    default: withCtx(() => [
                                      createTextVNode(" Break "),
                                      createVNode(_component_DownOutlined)
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 2
                              }, 1024)) : (openBlock(), createBlock(_component_a_button, {
                                key: 3,
                                onClick: ($event) => $options.clockOut(record)
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Close Break")
                                ]),
                                _: 2
                              }, 1032, ["onClick"]))
                            ])) : (openBlock(), createBlock("div", { key: 1 }, [
                              createVNode(_component_a_button, {
                                type: "primary",
                                onClick: ($event) => $options.clockIn(record)
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Clock In")
                                ]),
                                _: 2
                              }, 1032, ["onClick"])
                            ]))
                          ]),
                          _: 2
                        }, 1024)) : createCommentVNode("", true),
                        column.key === "manualaction" ? (openBlock(), createBlock(Fragment, { key: 4 }, [
                          createVNode(_component_a_button, {
                            type: "default",
                            danger: "",
                            onClick: ($event) => $options.addmanualrows(record)
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Add Attendance")
                            ]),
                            _: 2
                          }, 1032, ["onClick"]),
                          $data.showmanualsave.includes(record.employee_id) ? (openBlock(), createBlock(_component_a_button, {
                            key: 0,
                            type: "primary",
                            danger: "",
                            onClick: ($event) => $options.savemanualdata(record)
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Save Attendance")
                            ]),
                            _: 2
                          }, 1032, ["onClick"])) : createCommentVNode("", true)
                        ], 64)) : createCommentVNode("", true)
                      ]),
                      expandedRowRender: withCtx(({ record }) => [
                        createVNode(_component_a_table, {
                          class: "table-sm",
                          pagination: false,
                          columns: $setup.innercolumns,
                          "row-key": (history) => history.id,
                          "data-source": record.history,
                          set: _ctx.parentrecord = record
                        }, {
                          bodyCell: withCtx(({ column, text, record: record2 }) => [
                            column.key === "location" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                              record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_select, {
                                key: 0,
                                value: record2.branchid,
                                "onUpdate:value": ($event) => record2.branchid = $event,
                                placeholder: "Select Branch",
                                style: { "min-width": "200px" }
                              }, {
                                default: withCtx(() => [
                                  (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                    return openBlock(), createBlock(_component_a_select_option, {
                                      value: branch.id
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(branch.branch_name), 1)
                                      ]),
                                      _: 2
                                    }, 1032, ["value"]);
                                  }), 256))
                                ]),
                                _: 2
                              }, 1032, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, toDisplayString(record2.branch.branch_name ?? "-"), 1))
                            ], 64)) : createCommentVNode("", true),
                            column.key === "in" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                              record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_time_picker, {
                                key: 0,
                                allowClear: true,
                                format: "hh:mm A",
                                placeholder: "Check In",
                                "value-format": "HH:mm:ss",
                                value: record2.checkin,
                                "onUpdate:value": ($event) => record2.checkin = $event
                              }, null, 8, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, toDisplayString($data.moment(record2.checkin, "HH:mm:ss").format("hh:mm A")), 1))
                            ], 64)) : createCommentVNode("", true),
                            column.key === "out" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                              record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_time_picker, {
                                key: 0,
                                allowClear: true,
                                format: "hh:mm A",
                                placeholder: "Check Out",
                                "value-format": "HH:mm:ss",
                                value: record2.checkout,
                                "onUpdate:value": ($event) => record2.checkout = $event
                              }, null, 8, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, toDisplayString(record2.checkout != null ? $data.moment(record2.checkout, "HH:mm:ss").format("hh:mm A") : "-"), 1))
                            ], 64)) : createCommentVNode("", true),
                            column.key === "break" ? (openBlock(), createBlock(Fragment, { key: 3 }, [
                              record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_select, {
                                key: 0,
                                allowClear: true,
                                value: record2.breakid,
                                "onUpdate:value": ($event) => record2.breakid = $event,
                                style: "width: 150px"
                              }, {
                                default: withCtx(() => [
                                  (openBlock(true), createBlock(Fragment, null, renderList($props.breaks, (brk) => {
                                    return openBlock(), createBlock(_component_a_select_option, {
                                      value: brk.id
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(brk.name), 1)
                                      ]),
                                      _: 2
                                    }, 1032, ["value"]);
                                  }), 256))
                                ]),
                                _: 2
                              }, 1032, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, [
                                record2.breakid != null ? (openBlock(), createBlock(_component_a_tag, {
                                  key: 0,
                                  color: "blue"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(record2.break.name), 1)
                                  ]),
                                  _: 2
                                }, 1024)) : createCommentVNode("", true)
                              ]))
                            ], 64)) : createCommentVNode("", true),
                            column.key === "notes" ? (openBlock(), createBlock(Fragment, { key: 4 }, [
                              record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_input, {
                                key: 0,
                                value: record2.notes,
                                "onUpdate:value": ($event) => record2.notes = $event,
                                style: { "width": "100%" }
                              }, null, 8, ["value", "onUpdate:value"])) : (openBlock(), createBlock("span", { key: 1 }, toDisplayString(record2.notes), 1))
                            ], 64)) : createCommentVNode("", true),
                            column.key === "action" ? (openBlock(), createBlock(Fragment, { key: 5 }, [
                              record2.id != "" ? (openBlock(), createBlock(_component_a_space, {
                                key: 0,
                                direction: "horizontal"
                              }, {
                                default: withCtx(() => [
                                  createVNode("div", { class: "editable-row-operations" }, [
                                    record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock("span", { key: 0 }, [
                                      createVNode(_component_a_button, {
                                        type: "primary",
                                        onClick: ($event) => $options.savehistory(record2)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Save")
                                        ]),
                                        _: 2
                                      }, 1032, ["onClick"]),
                                      createVNode(_component_a_popconfirm, {
                                        title: "Sure to cancel?",
                                        onConfirm: ($event) => $options.cancel(record2.id)
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_a_button, { type: "default" }, {
                                            default: withCtx(() => [
                                              createTextVNode("Cancel")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 2
                                      }, 1032, ["onConfirm"])
                                    ])) : (openBlock(), createBlock("span", { key: 1 }, [
                                      createVNode(_component_a_button, {
                                        onClick: ($event) => $options.edit(record2.id)
                                      }, {
                                        icon: withCtx(() => [
                                          createVNode(_component_EditOutlined)
                                        ]),
                                        _: 2
                                      }, 1032, ["onClick"])
                                    ]))
                                  ]),
                                  createVNode(_component_a_popconfirm, {
                                    title: "Sure to delete?",
                                    onConfirm: ($event) => $options.deletehistory(record2.id)
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, null, {
                                        icon: withCtx(() => [
                                          createVNode(_component_DeleteOutlined)
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 2
                                  }, 1032, ["onConfirm"])
                                ]),
                                _: 2
                              }, 1024)) : (openBlock(), createBlock(_component_a_space, { key: 1 }, {
                                default: withCtx(() => [
                                  createVNode(_component_a_popconfirm, {
                                    title: "Sure to delete?",
                                    onConfirm: ($event) => $options.deletemanualrow(_ctx.parentrecord, record2)
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_a_button, null, {
                                        icon: withCtx(() => [
                                          createVNode(_component_DeleteOutlined)
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 2
                                  }, 1032, ["onConfirm"])
                                ]),
                                _: 2
                              }, 1024))
                            ], 64)) : createCommentVNode("", true)
                          ]),
                          _: 2
                        }, 1032, ["columns", "row-key", "data-source", "set"])
                      ]),
                      _: 1
                    }, 8, ["columns", "row-key", "data-source", "pagination", "loading", "onChange"])
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_spin, {
            spinning: $data.loading,
            delay: $data.delayTime
          }, null, 8, ["spinning", "delay"]),
          createVNode(_component_a_layout_content, { style: { margin: "24px 16px", padding: "24px", background: "#fff", minHeight: "calc(100vh - 115px)", textAlign: "center" } }, {
            default: withCtx(() => [
              createVNode(_component_a_space, {
                direction: "vertical",
                style: { width: "100%" }
              }, {
                default: withCtx(() => [
                  createVNode(_component_a_form, {
                    name: "nest-messages",
                    model: $data.formState,
                    layout: "inline",
                    onFinish: $options.search
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_select, {
                            value: $data.formState.branch,
                            "onUpdate:value": ($event) => $data.formState.branch = $event,
                            placeholder: "Select Branch",
                            style: { "min-width": "200px" }
                          }, {
                            default: withCtx(() => [
                              (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                return openBlock(), createBlock(_component_a_select_option, {
                                  value: branch.id
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(branch.branch_name), 1)
                                  ]),
                                  _: 2
                                }, 1032, ["value"]);
                              }), 256))
                            ]),
                            _: 1
                          }, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_date_picker, {
                            value: $data.formState.date,
                            "onUpdate:value": ($event) => $data.formState.date = $event,
                            format: "DD-MM-YYYY",
                            "value-format": "YYYY-MM-DD"
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            placeholder: "Search Employees",
                            value: $data.formState.term,
                            "onUpdate:value": ($event) => $data.formState.term = $event
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Search ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, null, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, { type: "primary" }, {
                            default: withCtx(() => [
                              createTextVNode(" Add Time Manually ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["model", "onFinish"]),
                  createVNode(_component_a_table, {
                    columns: $setup.columns,
                    "row-key": (record) => record.employee_id,
                    "data-source": $props.employees,
                    pagination: $props.pagination,
                    loading: $data.loading,
                    onChange: $options.handleTableChange
                  }, {
                    bodyCell: withCtx(({ column, text, record }) => [
                      column.key === "name" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                        createVNode(_component_a_avatar, { style: { "color": "#f56a00", "background-color": "#fde3cf" } }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(text[0].toUpperCase()), 1)
                          ]),
                          _: 2
                        }, 1024),
                        createTextVNode("   " + toDisplayString(text), 1)
                      ], 64)) : createCommentVNode("", true),
                      column.key === "status" ? (openBlock(), createBlock(_component_a_tag, {
                        key: 1,
                        color: $data.statusColor[record.status]
                      }, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(record.status), 1)
                        ]),
                        _: 2
                      }, 1032, ["color"])) : createCommentVNode("", true),
                      column.key === "latestatus" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                        record.status == "Present" ? (openBlock(), createBlock(_component_a_tag, {
                          key: 0,
                          color: record.late == true ? "red" : "green"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(record.late == true ? "Late" : "On Time"), 1)
                          ]),
                          _: 2
                        }, 1032, ["color"])) : createCommentVNode("", true)
                      ], 64)) : createCommentVNode("", true),
                      column.key === "autoaction" ? (openBlock(), createBlock(_component_a_space, {
                        key: 3,
                        direction: "horizontal"
                      }, {
                        default: withCtx(() => [
                          record.history.length ? (openBlock(), createBlock("div", { key: 0 }, [
                            record.history[record.history.length - 1].checkout != null ? (openBlock(), createBlock(_component_a_button, {
                              key: 0,
                              type: "primary",
                              onClick: ($event) => $options.clockIn(record)
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Clock In")
                              ]),
                              _: 2
                            }, 1032, ["onClick"])) : createCommentVNode("", true),
                            record.history[record.history.length - 1].checkout == null ? (openBlock(), createBlock(_component_a_button, {
                              key: 1,
                              onClick: ($event) => $options.clockOut(record)
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Clock Out")
                              ]),
                              _: 2
                            }, 1032, ["onClick"])) : createCommentVNode("", true),
                            record.history[record.history.length - 1].breakid == null ? (openBlock(), createBlock(_component_a_dropdown, { key: 2 }, {
                              overlay: withCtx(() => [
                                createVNode(_component_a_menu, null, {
                                  default: withCtx(() => [
                                    (openBlock(true), createBlock(Fragment, null, renderList($props.breaks, (brk) => {
                                      return openBlock(), createBlock(_component_a_menu_item, {
                                        key: brk.id,
                                        onClick: ($event) => $options.addBreak(record, brk.id)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(brk.name), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["onClick"]);
                                    }), 128))
                                  ]),
                                  _: 2
                                }, 1024)
                              ]),
                              default: withCtx(() => [
                                createVNode(_component_a_button, null, {
                                  default: withCtx(() => [
                                    createTextVNode(" Break "),
                                    createVNode(_component_DownOutlined)
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 2
                            }, 1024)) : (openBlock(), createBlock(_component_a_button, {
                              key: 3,
                              onClick: ($event) => $options.clockOut(record)
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Close Break")
                              ]),
                              _: 2
                            }, 1032, ["onClick"]))
                          ])) : (openBlock(), createBlock("div", { key: 1 }, [
                            createVNode(_component_a_button, {
                              type: "primary",
                              onClick: ($event) => $options.clockIn(record)
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Clock In")
                              ]),
                              _: 2
                            }, 1032, ["onClick"])
                          ]))
                        ]),
                        _: 2
                      }, 1024)) : createCommentVNode("", true),
                      column.key === "manualaction" ? (openBlock(), createBlock(Fragment, { key: 4 }, [
                        createVNode(_component_a_button, {
                          type: "default",
                          danger: "",
                          onClick: ($event) => $options.addmanualrows(record)
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Add Attendance")
                          ]),
                          _: 2
                        }, 1032, ["onClick"]),
                        $data.showmanualsave.includes(record.employee_id) ? (openBlock(), createBlock(_component_a_button, {
                          key: 0,
                          type: "primary",
                          danger: "",
                          onClick: ($event) => $options.savemanualdata(record)
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Save Attendance")
                          ]),
                          _: 2
                        }, 1032, ["onClick"])) : createCommentVNode("", true)
                      ], 64)) : createCommentVNode("", true)
                    ]),
                    expandedRowRender: withCtx(({ record }) => [
                      createVNode(_component_a_table, {
                        class: "table-sm",
                        pagination: false,
                        columns: $setup.innercolumns,
                        "row-key": (history) => history.id,
                        "data-source": record.history,
                        set: _ctx.parentrecord = record
                      }, {
                        bodyCell: withCtx(({ column, text, record: record2 }) => [
                          column.key === "location" ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                            record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_select, {
                              key: 0,
                              value: record2.branchid,
                              "onUpdate:value": ($event) => record2.branchid = $event,
                              placeholder: "Select Branch",
                              style: { "min-width": "200px" }
                            }, {
                              default: withCtx(() => [
                                (openBlock(true), createBlock(Fragment, null, renderList($props.branches, (branch) => {
                                  return openBlock(), createBlock(_component_a_select_option, {
                                    value: branch.id
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(toDisplayString(branch.branch_name), 1)
                                    ]),
                                    _: 2
                                  }, 1032, ["value"]);
                                }), 256))
                              ]),
                              _: 2
                            }, 1032, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, toDisplayString(record2.branch.branch_name ?? "-"), 1))
                          ], 64)) : createCommentVNode("", true),
                          column.key === "in" ? (openBlock(), createBlock(Fragment, { key: 1 }, [
                            record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_time_picker, {
                              key: 0,
                              allowClear: true,
                              format: "hh:mm A",
                              placeholder: "Check In",
                              "value-format": "HH:mm:ss",
                              value: record2.checkin,
                              "onUpdate:value": ($event) => record2.checkin = $event
                            }, null, 8, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, toDisplayString($data.moment(record2.checkin, "HH:mm:ss").format("hh:mm A")), 1))
                          ], 64)) : createCommentVNode("", true),
                          column.key === "out" ? (openBlock(), createBlock(Fragment, { key: 2 }, [
                            record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_time_picker, {
                              key: 0,
                              allowClear: true,
                              format: "hh:mm A",
                              placeholder: "Check Out",
                              "value-format": "HH:mm:ss",
                              value: record2.checkout,
                              "onUpdate:value": ($event) => record2.checkout = $event
                            }, null, 8, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, toDisplayString(record2.checkout != null ? $data.moment(record2.checkout, "HH:mm:ss").format("hh:mm A") : "-"), 1))
                          ], 64)) : createCommentVNode("", true),
                          column.key === "break" ? (openBlock(), createBlock(Fragment, { key: 3 }, [
                            record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_select, {
                              key: 0,
                              allowClear: true,
                              value: record2.breakid,
                              "onUpdate:value": ($event) => record2.breakid = $event,
                              style: "width: 150px"
                            }, {
                              default: withCtx(() => [
                                (openBlock(true), createBlock(Fragment, null, renderList($props.breaks, (brk) => {
                                  return openBlock(), createBlock(_component_a_select_option, {
                                    value: brk.id
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(toDisplayString(brk.name), 1)
                                    ]),
                                    _: 2
                                  }, 1032, ["value"]);
                                }), 256))
                              ]),
                              _: 2
                            }, 1032, ["value", "onUpdate:value"])) : (openBlock(), createBlock("div", { key: 1 }, [
                              record2.breakid != null ? (openBlock(), createBlock(_component_a_tag, {
                                key: 0,
                                color: "blue"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(record2.break.name), 1)
                                ]),
                                _: 2
                              }, 1024)) : createCommentVNode("", true)
                            ]))
                          ], 64)) : createCommentVNode("", true),
                          column.key === "notes" ? (openBlock(), createBlock(Fragment, { key: 4 }, [
                            record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock(_component_a_input, {
                              key: 0,
                              value: record2.notes,
                              "onUpdate:value": ($event) => record2.notes = $event,
                              style: { "width": "100%" }
                            }, null, 8, ["value", "onUpdate:value"])) : (openBlock(), createBlock("span", { key: 1 }, toDisplayString(record2.notes), 1))
                          ], 64)) : createCommentVNode("", true),
                          column.key === "action" ? (openBlock(), createBlock(Fragment, { key: 5 }, [
                            record2.id != "" ? (openBlock(), createBlock(_component_a_space, {
                              key: 0,
                              direction: "horizontal"
                            }, {
                              default: withCtx(() => [
                                createVNode("div", { class: "editable-row-operations" }, [
                                  record2.id == "" || $data.editableData.includes(record2.id) ? (openBlock(), createBlock("span", { key: 0 }, [
                                    createVNode(_component_a_button, {
                                      type: "primary",
                                      onClick: ($event) => $options.savehistory(record2)
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Save")
                                      ]),
                                      _: 2
                                    }, 1032, ["onClick"]),
                                    createVNode(_component_a_popconfirm, {
                                      title: "Sure to cancel?",
                                      onConfirm: ($event) => $options.cancel(record2.id)
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_a_button, { type: "default" }, {
                                          default: withCtx(() => [
                                            createTextVNode("Cancel")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 2
                                    }, 1032, ["onConfirm"])
                                  ])) : (openBlock(), createBlock("span", { key: 1 }, [
                                    createVNode(_component_a_button, {
                                      onClick: ($event) => $options.edit(record2.id)
                                    }, {
                                      icon: withCtx(() => [
                                        createVNode(_component_EditOutlined)
                                      ]),
                                      _: 2
                                    }, 1032, ["onClick"])
                                  ]))
                                ]),
                                createVNode(_component_a_popconfirm, {
                                  title: "Sure to delete?",
                                  onConfirm: ($event) => $options.deletehistory(record2.id)
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, null, {
                                      icon: withCtx(() => [
                                        createVNode(_component_DeleteOutlined)
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 2
                                }, 1032, ["onConfirm"])
                              ]),
                              _: 2
                            }, 1024)) : (openBlock(), createBlock(_component_a_space, { key: 1 }, {
                              default: withCtx(() => [
                                createVNode(_component_a_popconfirm, {
                                  title: "Sure to delete?",
                                  onConfirm: ($event) => $options.deletemanualrow(_ctx.parentrecord, record2)
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_a_button, null, {
                                      icon: withCtx(() => [
                                        createVNode(_component_DeleteOutlined)
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 2
                                }, 1032, ["onConfirm"])
                              ]),
                              _: 2
                            }, 1024))
                          ], 64)) : createCommentVNode("", true)
                        ]),
                        _: 2
                      }, 1032, ["columns", "row-key", "data-source", "set"])
                    ]),
                    _: 1
                  }, 8, ["columns", "row-key", "data-source", "pagination", "loading", "onChange"])
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["style"])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Attendance/Index copy 2.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Index_copy_2 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Index_copy_2 as default
};
