import { resolveComponent, withCtx, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, createCommentVNode, mergeProps, useSSRContext } from "vue";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-3ea09569.mjs";
import { Head, useForm } from "@inertiajs/vue3";
import "dayjs";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "ant-design-vue";
import "@ant-design/icons-vue";
const _sfc_main = {
  inject: ["validateMessages"],
  components: {
    AuthenticatedLayout: _sfc_main$1,
    Head
  },
  props: {
    employee: Object,
    attdata: Object,
    errors: Object,
    today: String,
    month: String
  },
  setup(props) {
    const layout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 16 }
    };
    const formState = useForm({
      employee_id: props.employee.id,
      checkin: "",
      checkout: "",
      notes: "",
      status: ""
    });
    return {
      formState,
      layout
    };
  },
  data() {
    return {
      drawervisible: false
    };
  },
  methods: {
    onSelect(val) {
      this.formState.date = val.$d;
      if (this.attdata[val.date()]) {
        this.formState.checkin = this.attdata[val.date()].checkin;
        this.formState.checkout = this.attdata[val.date()].checkout;
        this.formState.notes = this.attdata[val.date()].notes;
        this.formState.status = this.attdata[val.date()].status;
      } else {
        this.formState.checkin = "";
        this.formState.checkout = "";
        this.formState.notes = "";
        this.formState.status = "Absent";
      }
      this.showDrawer();
    },
    showDrawer() {
      this.drawervisible = true;
    },
    onClose() {
      this.drawervisible = false;
    },
    submit() {
      this.formState.post(route("attendance.update"));
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Head = resolveComponent("Head");
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_a_affix = resolveComponent("a-affix");
  const _component_a_page_header = resolveComponent("a-page-header");
  const _component_a_layout_content = resolveComponent("a-layout-content");
  const _component_a_calendar = resolveComponent("a-calendar");
  const _component_a_button = resolveComponent("a-button");
  const _component_a_drawer = resolveComponent("a-drawer");
  const _component_a_form = resolveComponent("a-form");
  const _component_a_form_item = resolveComponent("a-form-item");
  const _component_a_time_picker = resolveComponent("a-time-picker");
  const _component_a_input = resolveComponent("a-input");
  const _component_a_select = resolveComponent("a-select");
  const _component_a_select_option = resolveComponent("a-select-option");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Head, { title: "Employees" }, null, _parent));
  _push(ssrRenderComponent(_component_AuthenticatedLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_a_affix, { "offset-top": 0 }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_page_header, {
                ghost: false,
                title: $props.employee.name + " Attendance",
                onBack: () => _ctx.$inertia.visit(_ctx.route("employees.index"))
              }, null, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_page_header, {
                  ghost: false,
                  title: $props.employee.name + " Attendance",
                  onBack: () => _ctx.$inertia.visit(_ctx.route("employees.index"))
                }, null, 8, ["title", "onBack"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_layout_content, null, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_calendar, {
                value: _ctx.value,
                "onUpdate:value": ($event) => _ctx.value = $event,
                onSelect: $options.onSelect
              }, {
                dateCellRender: withCtx(({ current }, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    if ($props.attdata[current.date()]) {
                      _push4(`<div${_scopeId3}>`);
                      _push4(ssrRenderComponent(_component_a_button, {
                        type: $props.attdata[current.date()].type,
                        shape: "round",
                        size: "sm"
                      }, {
                        default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                          if (_push5) {
                            _push5(`${ssrInterpolate($props.attdata[current.date()].status)}`);
                          } else {
                            return [
                              createTextVNode(toDisplayString($props.attdata[current.date()].status), 1)
                            ];
                          }
                        }),
                        _: 2
                      }, _parent4, _scopeId3));
                      _push4(`</div>`);
                    } else if (current.date() <= $props.today && current.month() + 1 == $props.month) {
                      _push4(`<div${_scopeId3}>`);
                      _push4(ssrRenderComponent(_component_a_button, {
                        type: "primary",
                        danger: "",
                        shape: "round",
                        size: "sm"
                      }, {
                        default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                          if (_push5) {
                            _push5(` Absent `);
                          } else {
                            return [
                              createTextVNode(" Absent ")
                            ];
                          }
                        }),
                        _: 2
                      }, _parent4, _scopeId3));
                      _push4(`</div>`);
                    } else {
                      _push4(`<!---->`);
                    }
                  } else {
                    return [
                      $props.attdata[current.date()] ? (openBlock(), createBlock("div", { key: 0 }, [
                        createVNode(_component_a_button, {
                          type: $props.attdata[current.date()].type,
                          shape: "round",
                          size: "sm"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString($props.attdata[current.date()].status), 1)
                          ]),
                          _: 2
                        }, 1032, ["type"])
                      ])) : current.date() <= $props.today && current.month() + 1 == $props.month ? (openBlock(), createBlock("div", { key: 1 }, [
                        createVNode(_component_a_button, {
                          type: "primary",
                          danger: "",
                          shape: "round",
                          size: "sm"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Absent ")
                          ]),
                          _: 1
                        })
                      ])) : createCommentVNode("", true)
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_calendar, {
                  value: _ctx.value,
                  "onUpdate:value": ($event) => _ctx.value = $event,
                  onSelect: $options.onSelect
                }, {
                  dateCellRender: withCtx(({ current }) => [
                    $props.attdata[current.date()] ? (openBlock(), createBlock("div", { key: 0 }, [
                      createVNode(_component_a_button, {
                        type: $props.attdata[current.date()].type,
                        shape: "round",
                        size: "sm"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString($props.attdata[current.date()].status), 1)
                        ]),
                        _: 2
                      }, 1032, ["type"])
                    ])) : current.date() <= $props.today && current.month() + 1 == $props.month ? (openBlock(), createBlock("div", { key: 1 }, [
                      createVNode(_component_a_button, {
                        type: "primary",
                        danger: "",
                        shape: "round",
                        size: "sm"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Absent ")
                        ]),
                        _: 1
                      })
                    ])) : createCommentVNode("", true)
                  ]),
                  _: 1
                }, 8, ["value", "onUpdate:value", "onSelect"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_a_drawer, {
          title: "Update Attendance",
          placement: "right",
          closable: true,
          visible: $data.drawervisible,
          onClose: $options.onClose
        }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(ssrRenderComponent(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                name: "nest-messages",
                "validate-messages": $options.validateMessages,
                onFinish: $options.submit
              }), {
                default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                  if (_push4) {
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Check In",
                      name: "checkin"
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_time_picker, {
                            format: "hh:mm A",
                            placeholder: "Check In",
                            "value-format": "HH:mm:ss",
                            value: $setup.formState.checkin,
                            "onUpdate:value": ($event) => $setup.formState.checkin = $event
                          }, null, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_time_picker, {
                              format: "hh:mm A",
                              placeholder: "Check In",
                              "value-format": "HH:mm:ss",
                              value: $setup.formState.checkin,
                              "onUpdate:value": ($event) => $setup.formState.checkin = $event
                            }, null, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Check Out",
                      name: "checkout"
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_time_picker, {
                            format: "hh:mm A",
                            placeholder: "Check Out",
                            "value-format": "HH:mm:ss",
                            value: $setup.formState.checkout,
                            "onUpdate:value": ($event) => $setup.formState.checkout = $event
                          }, null, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_time_picker, {
                              format: "hh:mm A",
                              placeholder: "Check Out",
                              "value-format": "HH:mm:ss",
                              value: $setup.formState.checkout,
                              "onUpdate:value": ($event) => $setup.formState.checkout = $event
                            }, null, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Notes",
                      name: "notes"
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_input, {
                            value: $setup.formState.notes,
                            "onUpdate:value": ($event) => $setup.formState.notes = $event,
                            style: { "width": "100%" }
                          }, null, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_input, {
                              value: $setup.formState.notes,
                              "onUpdate:value": ($event) => $setup.formState.notes = $event,
                              style: { "width": "100%" }
                            }, null, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, {
                      label: "Status",
                      name: "notes"
                    }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_select, {
                            value: $setup.formState.status,
                            "onUpdate:value": ($event) => $setup.formState.status = $event
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(ssrRenderComponent(_component_a_select_option, { value: "Present" }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`Present`);
                                    } else {
                                      return [
                                        createTextVNode("Present")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_select_option, { value: "Absent" }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`Absent`);
                                    } else {
                                      return [
                                        createTextVNode("Absent")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_select_option, { value: "Paid Leave" }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`Paid Leave`);
                                    } else {
                                      return [
                                        createTextVNode("Paid Leave")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                                _push6(ssrRenderComponent(_component_a_select_option, { value: "Unpaid Leave" }, {
                                  default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                    if (_push7) {
                                      _push7(`Unpaid Leave`);
                                    } else {
                                      return [
                                        createTextVNode("Unpaid Leave")
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent6, _scopeId5));
                              } else {
                                return [
                                  createVNode(_component_a_select_option, { value: "Present" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Present")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Absent" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Absent")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Paid Leave" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Paid Leave")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_a_select_option, { value: "Unpaid Leave" }, {
                                    default: withCtx(() => [
                                      createTextVNode("Unpaid Leave")
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_select, {
                              value: $setup.formState.status,
                              "onUpdate:value": ($event) => $setup.formState.status = $event
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_a_select_option, { value: "Present" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Present")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_select_option, { value: "Absent" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Absent")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_select_option, { value: "Paid Leave" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Paid Leave")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_a_select_option, { value: "Unpaid Leave" }, {
                                  default: withCtx(() => [
                                    createTextVNode("Unpaid Leave")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["value", "onUpdate:value"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                    _push4(ssrRenderComponent(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                      default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                        if (_push5) {
                          _push5(ssrRenderComponent(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                              if (_push6) {
                                _push6(`Save`);
                              } else {
                                return [
                                  createTextVNode("Save")
                                ];
                              }
                            }),
                            _: 1
                          }, _parent5, _scopeId4));
                        } else {
                          return [
                            createVNode(_component_a_button, {
                              type: "primary",
                              "html-type": "submit"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Save")
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent4, _scopeId3));
                  } else {
                    return [
                      createVNode(_component_a_form_item, {
                        label: "Check In",
                        name: "checkin"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_time_picker, {
                            format: "hh:mm A",
                            placeholder: "Check In",
                            "value-format": "HH:mm:ss",
                            value: $setup.formState.checkin,
                            "onUpdate:value": ($event) => $setup.formState.checkin = $event
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, {
                        label: "Check Out",
                        name: "checkout"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_time_picker, {
                            format: "hh:mm A",
                            placeholder: "Check Out",
                            "value-format": "HH:mm:ss",
                            value: $setup.formState.checkout,
                            "onUpdate:value": ($event) => $setup.formState.checkout = $event
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, {
                        label: "Notes",
                        name: "notes"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_input, {
                            value: $setup.formState.notes,
                            "onUpdate:value": ($event) => $setup.formState.notes = $event,
                            style: { "width": "100%" }
                          }, null, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, {
                        label: "Status",
                        name: "notes"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_select, {
                            value: $setup.formState.status,
                            "onUpdate:value": ($event) => $setup.formState.status = $event
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_a_select_option, { value: "Present" }, {
                                default: withCtx(() => [
                                  createTextVNode("Present")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_select_option, { value: "Absent" }, {
                                default: withCtx(() => [
                                  createTextVNode("Absent")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_select_option, { value: "Paid Leave" }, {
                                default: withCtx(() => [
                                  createTextVNode("Paid Leave")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_a_select_option, { value: "Unpaid Leave" }, {
                                default: withCtx(() => [
                                  createTextVNode("Unpaid Leave")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["value", "onUpdate:value"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                        default: withCtx(() => [
                          createVNode(_component_a_button, {
                            type: "primary",
                            "html-type": "submit"
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Save")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent3, _scopeId2));
            } else {
              return [
                createVNode(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                  name: "nest-messages",
                  "validate-messages": $options.validateMessages,
                  onFinish: $options.submit
                }), {
                  default: withCtx(() => [
                    createVNode(_component_a_form_item, {
                      label: "Check In",
                      name: "checkin"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_time_picker, {
                          format: "hh:mm A",
                          placeholder: "Check In",
                          "value-format": "HH:mm:ss",
                          value: $setup.formState.checkin,
                          "onUpdate:value": ($event) => $setup.formState.checkin = $event
                        }, null, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, {
                      label: "Check Out",
                      name: "checkout"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_time_picker, {
                          format: "hh:mm A",
                          placeholder: "Check Out",
                          "value-format": "HH:mm:ss",
                          value: $setup.formState.checkout,
                          "onUpdate:value": ($event) => $setup.formState.checkout = $event
                        }, null, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, {
                      label: "Notes",
                      name: "notes"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_input, {
                          value: $setup.formState.notes,
                          "onUpdate:value": ($event) => $setup.formState.notes = $event,
                          style: { "width": "100%" }
                        }, null, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, {
                      label: "Status",
                      name: "notes"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_a_select, {
                          value: $setup.formState.status,
                          "onUpdate:value": ($event) => $setup.formState.status = $event
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_a_select_option, { value: "Present" }, {
                              default: withCtx(() => [
                                createTextVNode("Present")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_select_option, { value: "Absent" }, {
                              default: withCtx(() => [
                                createTextVNode("Absent")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_select_option, { value: "Paid Leave" }, {
                              default: withCtx(() => [
                                createTextVNode("Paid Leave")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_a_select_option, { value: "Unpaid Leave" }, {
                              default: withCtx(() => [
                                createTextVNode("Unpaid Leave")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 8, ["value", "onUpdate:value"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                      default: withCtx(() => [
                        createVNode(_component_a_button, {
                          type: "primary",
                          "html-type": "submit"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Save")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }, 16, ["model", "validate-messages", "onFinish"])
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_a_affix, { "offset-top": 0 }, {
            default: withCtx(() => [
              createVNode(_component_a_page_header, {
                ghost: false,
                title: $props.employee.name + " Attendance",
                onBack: () => _ctx.$inertia.visit(_ctx.route("employees.index"))
              }, null, 8, ["title", "onBack"])
            ]),
            _: 1
          }),
          createVNode(_component_a_layout_content, null, {
            default: withCtx(() => [
              createVNode(_component_a_calendar, {
                value: _ctx.value,
                "onUpdate:value": ($event) => _ctx.value = $event,
                onSelect: $options.onSelect
              }, {
                dateCellRender: withCtx(({ current }) => [
                  $props.attdata[current.date()] ? (openBlock(), createBlock("div", { key: 0 }, [
                    createVNode(_component_a_button, {
                      type: $props.attdata[current.date()].type,
                      shape: "round",
                      size: "sm"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString($props.attdata[current.date()].status), 1)
                      ]),
                      _: 2
                    }, 1032, ["type"])
                  ])) : current.date() <= $props.today && current.month() + 1 == $props.month ? (openBlock(), createBlock("div", { key: 1 }, [
                    createVNode(_component_a_button, {
                      type: "primary",
                      danger: "",
                      shape: "round",
                      size: "sm"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Absent ")
                      ]),
                      _: 1
                    })
                  ])) : createCommentVNode("", true)
                ]),
                _: 1
              }, 8, ["value", "onUpdate:value", "onSelect"])
            ]),
            _: 1
          }),
          createVNode(_component_a_drawer, {
            title: "Update Attendance",
            placement: "right",
            closable: true,
            visible: $data.drawervisible,
            onClose: $options.onClose
          }, {
            default: withCtx(() => [
              createVNode(_component_a_form, mergeProps({ model: $setup.formState }, $setup.layout, {
                name: "nest-messages",
                "validate-messages": $options.validateMessages,
                onFinish: $options.submit
              }), {
                default: withCtx(() => [
                  createVNode(_component_a_form_item, {
                    label: "Check In",
                    name: "checkin"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_time_picker, {
                        format: "hh:mm A",
                        placeholder: "Check In",
                        "value-format": "HH:mm:ss",
                        value: $setup.formState.checkin,
                        "onUpdate:value": ($event) => $setup.formState.checkin = $event
                      }, null, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, {
                    label: "Check Out",
                    name: "checkout"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_time_picker, {
                        format: "hh:mm A",
                        placeholder: "Check Out",
                        "value-format": "HH:mm:ss",
                        value: $setup.formState.checkout,
                        "onUpdate:value": ($event) => $setup.formState.checkout = $event
                      }, null, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, {
                    label: "Notes",
                    name: "notes"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_input, {
                        value: $setup.formState.notes,
                        "onUpdate:value": ($event) => $setup.formState.notes = $event,
                        style: { "width": "100%" }
                      }, null, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, {
                    label: "Status",
                    name: "notes"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_a_select, {
                        value: $setup.formState.status,
                        "onUpdate:value": ($event) => $setup.formState.status = $event
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_a_select_option, { value: "Present" }, {
                            default: withCtx(() => [
                              createTextVNode("Present")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_select_option, { value: "Absent" }, {
                            default: withCtx(() => [
                              createTextVNode("Absent")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_select_option, { value: "Paid Leave" }, {
                            default: withCtx(() => [
                              createTextVNode("Paid Leave")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_a_select_option, { value: "Unpaid Leave" }, {
                            default: withCtx(() => [
                              createTextVNode("Unpaid Leave")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["value", "onUpdate:value"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_a_form_item, { "wrapper-col": { span: 12, offset: 6 } }, {
                    default: withCtx(() => [
                      createVNode(_component_a_button, {
                        type: "primary",
                        "html-type": "submit"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Save")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 16, ["model", "validate-messages", "onFinish"])
            ]),
            _: 1
          }, 8, ["visible", "onClose"])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Employees/Attendance.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Attendance = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Attendance as default
};
